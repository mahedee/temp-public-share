# ✅ High Priority (Core Functionality)

## 🔧 `LetterGenerator.java`
- [ ] **Fix connection handling**: Use `try-with-resources` for DB connections/statements
- [ ] **Add error handling**: Catch exceptions per letter type to allow partial success
- [ ] **Log skipped letters**: Print/log when a letter is disabled in config

## 🔧 `FileUtil.java`
- [ ] **Add null checks**: Validate DB values before writing to files
- [ ] **(Optional) Add headers**: Include column names as first row in output files

## 🔧 `DBUtil.java`
- [ ] **Decision needed**: 
  - [ ] Integrate into `LetterGenerator` for centralized connections, **OR**
  - [ ] Remove if unused

# 🚀 Medium Priority (UX & Validation)

## 📌 `App.java`
- [ ] **Improve CLI args**: Support `--mode=encrypt|generate` style arguments
- [ ] **Better usage messages**: Add help text for incorrect inputs

## 📌 `AppConfig.java`
- [ ] **Validate config**: 
  - Check required fields (e.g., `database.url`, `letters.path`) 
  - Validate file paths exist

## 📌 `LetterDefinition.java`
- [ ] **Validate XML**: 
  - Check required tags (`query`, `columns`)
  - Log errors if file not found

# 🔍 Low Priority (Optional Enhancements)

## 🛠 Utility Classes
- [ ] `EncryptionUtil.java`: Add `isEncrypted(String)` helper method
- [ ] `Config.java` models: Add default values via constructors

## 📁 Config & Templates
- [ ] **Letter templates**: Add sample XMLs for all letter types (`HoldLetter.xml`, etc.)
- [ ] **Config paths**: Replace hardcoded paths with variables

## 🧪 Testing
- [ ] **Unit tests**: Add tests for `EncryptionUtil`, `FileUtil` (JUnit 5)
- [ ] **Integration test**: Test full letter generation flow

# 🧹 Maintenance
- [ ] **Cleanup**: Remove unused code (e.g., `DBUtil` if not integrated)
- [ ] **Logging**: Add info logs for key actions (e.g., "Generated 5 letters")