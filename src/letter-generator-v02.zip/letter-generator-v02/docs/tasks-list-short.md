### Task list

- [x] Modify config.json to accomodate all letter's change
- [x] Create script to create relevent table and seed data for the letter
- [x] Create XML files for each letter
- [x] Create SQL files for each letter
- [ ] Now implement the letter generation logic one by one and test
- [ ] Create shell scripts to send file to FileX
- [ ] Check inline query option for each letter
- [ ] Scripts is in scripts folder but not tested yet
- [ ] Implement and test : encrypted password or plain text password for oracle connection
- [ ] Add documentation for how to run the app
- [ ] Seperate class file for separate letter if you are using inline query option
- [ ] Add unit tests for each letter generation logic
- [ ] Set config.json for enabling/disabling letters generation


1. Prepare Oracle database tables
   - Design table structure for letter data
   - Create necessary tables/views
   - Populate with sample data for 4 letters

2. Create/Modify config.json
   - Configure base settings for 4 letters
   - Include placeholders for XML and query references
   - Ensure SRP (Single Responsibility Principle) compliance

3. Develop XML configurations
   - Create 4 separate XML files (1 per letter)
   - Define templates and data mappings

4. Implement query-based generation
   - Create SQL queries for each letter
   - Store in separate .sql files (not inline yet)

5. Build SRP-compliant file structure
   ```
   /letters
     /LETTER1/
       config.xml
       query.sql
     /LETTER2/
       config.xml
       query.sql
     ...(for all 4 letters)
   ```

6. Develop inline configuration option
   - Modify loader to accept inline queries
   - Add switch in config.json (xml vs inline)

7. Implement letter generation logic
   - XML path first
   - Then inline query option

8. Add extensibility features
   - Auto-discover new letter folders
   - Dynamic config.json merging

9. Create shell scripts
   - generate_letters.sh (with letter type selection)
   - encrypt_output.sh (with path parameter)

10. Documentation
    - Add to how-to-run-app.md:
      ```markdown
      ## Generating Specific Letters
      ./generate_letters.sh LETTER1
      ./generate_letters.sh LETTER2 --encrypt
      ```

11. Test scenarios
    - Verify all 4 letters generate correctly
    - Test both XML and inline modes
    - Validate encryption pipeline

12. Future-proofing
    - Document how to add new letters:
      ```
      1. Create new folder under /letters
      2. Add config.xml + query.sql
      3. Add entry in config.json
      ```

Additional recommended tasks:
13. Database schema documentation
14. Environment setup instructions
15. Error handling for missing configs
16. Logging configuration
17. Unit test scaffolding


This is not working

    "HoldLetter": {
      "enabled": true,
      "delimiter": ",",
      "useQueryFromXml": false,
      "exportPath": "output/hold/"
    },