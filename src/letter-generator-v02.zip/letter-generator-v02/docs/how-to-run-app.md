# **Letter Generator Application - Usage Instructions**

## **1. Prerequisites**
- Java JDK 11 or later installed
- Maven installed (for building)
- The compiled JAR file (`letter-generator-1.0-SNAPSHOT.jar`)

---

## **2. Running the Application**

### **Option 1: Generate Letters (Default Mode)**
This runs the default letter generation logic (`LetterGenerator.generateAll()`).

```sh
java -jar target/letter-generator-1.0-SNAPSHOT.jar
```

### **Option 2: Encrypt Text & Save to File**
Encrypts the given text and saves it to a specified directory.

```sh
java -jar target/letter-generator-1.0-SNAPSHOT.jar "Your text to encrypt" "output/directory"
```

**Example:**
```sh
java -jar target/letter-generator-1.0-SNAPSHOT.jar "Secret Message" "output/encrypted"
```
**Output:**
```
Encrypted text written to: D:\Projects\...\output\encrypted\encryptedtext.txt
```

---

## **3. Expected Behavior**
- If the output directory doesn't exist, it will be created automatically.
- The encrypted text is saved in Base64 format in `encryptedtext.txt`.
- The full output path is displayed in the console.

---

## **4. Troubleshooting**
### **Error: "No main manifest attribute"**
- Rebuild the JAR with:
  ```sh
  mvn clean package
  ```
- Then run again.

### **Error: "Directory not found"**
- Ensure you have write permissions in the specified output directory.
- Try a simpler path (e.g., `"output"` instead of nested directories).

### **Error: "Invalid arguments"**
- Make sure you provide **exactly 0 or 2 arguments**:
  - **0 args** → Letter generation mode
  - **2 args** → Encryption mode (`"text" "output/dir"`)

---

## **5. Rebuilding the Application (If Needed)**
If you modify the code, rebuild with:

```sh
mvn clean package
```
The new JAR will be generated in `target/letter-generator-1.0-SNAPSHOT.jar`.

---

### **Summary of Commands**
| Action | Command |
|--------|---------|
| **Generate letters** | `java -jar target/letter-generator-1.0-SNAPSHOT.jar` |
| **Encrypt text** | `java -jar target/letter-generator-1.0-SNAPSHOT.jar "text" "output/dir"` |
| **Rebuild JAR** | `mvn clean package` |
