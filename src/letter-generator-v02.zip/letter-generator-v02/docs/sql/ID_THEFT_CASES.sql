CREATE TABLE ID_THEFT_CASES (
    ACCOUNT_NO     VARCHAR2(20),
    CUSTOMER_NAME  VARCHAR2(100),
    CASE_DETAIL    VARCHAR2(500)
);

-- Insert sample data
INSERT INTO ID_THEFT_CASES (ACCOUNT_NO, CUSTOMER_NAME, CASE_DETAIL) VALUES
('ACC001', 'John Doe', 'Reported unauthorized access to savings account.');

INSERT INTO ID_THEFT_CASES (ACCOUNT_NO, CUSTOMER_NAME, CASE_DETAIL) VALUES
('ACC002', 'Jane Smith', 'Suspicious activity detected in credit card transactions.');

INSERT INTO ID_THEFT_CASES (ACCOUNT_NO, CUSTOMER_NAME, CASE_DETAIL) VALUES
('ACC003', 'Ali Khan', 'Customer claimed fraudulent mobile banking registration.');

COMMIT;


SELECT * from ID_THEFT_CASES;