#!/bin/bash

# Load configuration
source ./letter-generator-config.sh

# Initialize tracking
TRANSFER_SUCCESS=true
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
TRANSFER_LOG="$LOG_DIR/sftp_transfer_$TIMESTAMP.log"

# Process each generated file
find "$OUTPUT_DIR" -type f -name "*.txt" | while read -r file; do
    filename=$(basename "$file")
    
    echo "[$(date)] Transferring $filename to SFTP" >> "$TRANSFER_LOG"
    
    # SFTP transfer using private key authentication
    sftp -i "$SFTP_KEY" -P "$SFTP_PORT" "$SFTP_USER@$SFTP_HOST" <<EOF >> "$TRANSFER_LOG" 2>&1
        put "$file" "$SFTP_REMOTE_DIR/$filename"
        bye
EOF

    if [ $? -eq 0 ]; then
        echo "[$(date)] SFTP transfer successful for $filename" >> "$TRANSFER_LOG"
        # Move to archive
        mkdir -p "$ARCHIVE_DIR"
        mv "$file" "$ARCHIVE_DIR/$filename"
    else
        echo "[$(date)] ERROR: SFTP transfer failed for $filename" >> "$TRANSFER_LOG"
        TRANSFER_SUCCESS=false
    fi
done

# Final status
if [ "$TRANSFER_SUCCESS" = true ]; then
    echo "[$(date)] All files transferred successfully" >> "$TRANSFER_LOG"
    exit 0
else
    echo "[$(date)] Some files failed to transfer" >> "$TRANSFER_LOG"
    exit 1
fi