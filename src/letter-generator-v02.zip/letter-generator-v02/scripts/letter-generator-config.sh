#!/bin/bash

# Global Configuration
JAVA_HOME="/usr/lib/jvm/java-11-openjdk"          # Java installation path
APP_HOME="/opt/letter-generator"                  # Application root directory

# Directory Configuration
JAR_FILE="$APP_HOME/target/letter-generator-1.0-SNAPSHOT.jar"
INPUT_DIR="$APP_HOME/input"                       # Where input files are placed
OUTPUT_DIR="$APP_HOME/output"                     # Generated letter output
ARCHIVE_DIR="$APP_HOME/archive"                   # Successful transfers archive
LOG_DIR="$APP_HOME/logs"                          # Application logs
TEMP_DIR="$APP_HOME/temp"                         # Temporary working directory

# SFTP Configuration
SFTP_HOST="filex.example.com"
SFTP_USER="sftp_user"
SFTP_PORT="22"
SFTP_REMOTE_DIR="/inbound/letters"
SFTP_KEY="$APP_HOME/keys/sftp_private_key.pem"    # SSH private key for SFTP

# Application Parameters
LETTER_TYPES=("DemandLetter" "HoldLetter" "IDTheftLetter" "RelationshipTermLetter")