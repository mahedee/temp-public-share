#!/bin/bash

# Load configuration
source ./letter-generator-config.sh

# Initialize directories
mkdir -p "$LOG_DIR" "$TEMP_DIR"

# Get current timestamp for logging
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOG_FILE="$LOG_DIR/letter_gen_$TIMESTAMP.log"

# Execute JAR for each letter type
for letter_type in "${LETTER_TYPES[@]}"; do
    echo "[$(date)] Processing $letter_type" >> "$LOG_FILE"
    
    "$JAVA_HOME/bin/java" -jar "$JAR_FILE" "$letter_type" "$OUTPUT_DIR" >> "$LOG_FILE" 2>&1
    
    if [ $? -ne 0 ]; then
        echo "[$(date)] ERROR: Failed to generate $letter_type" >> "$LOG_FILE"
        exit 1
    fi
done

echo "[$(date)] All letters generated successfully" >> "$LOG_FILE"
exit 0