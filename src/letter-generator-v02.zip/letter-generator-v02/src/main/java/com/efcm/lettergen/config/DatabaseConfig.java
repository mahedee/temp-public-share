package com.efcm.lettergen.config;

public class DatabaseConfig {
    public String url;
    public String user;
    public String password;
}
