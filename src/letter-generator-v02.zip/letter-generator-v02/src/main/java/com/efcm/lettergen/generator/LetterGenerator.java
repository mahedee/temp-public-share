package com.efcm.lettergen.generator;

import com.efcm.lettergen.config.*;
import com.efcm.lettergen.model.LetterDefinition;
import com.efcm.lettergen.util.EncryptionUtil;
import com.efcm.lettergen.util.FileUtil;

import jakarta.xml.bind.*;
import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class LetterGenerator {
    public void generateAll() throws Exception {
        Config config = AppConfig.getConfig();
        String password = config.isEncryptedPassword
                ? EncryptionUtil.decrypt(config.database.password.replace("ENCRYPTED(", "").replace(")", ""))
                : config.database.password;

        Connection conn = DriverManager.getConnection(
                config.database.url,
                config.database.user,
                password
        );

        for (String letterType : config.letters.keySet()) {
            LetterConfig letter = config.letters.get(letterType);
            if (!letter.enabled) continue;

            String query;
            List<String> columns;

            if (letter.useQueryFromXml) {
                LetterDefinition def = loadDefinition("config/letters/" + letter.queryFile);
                query = def.getQuery();
                columns = def.getColumns();
            } else {
                query = getInlineQuery(letterType);
                columns = getInlineColumns(letterType);
            }

            ResultSet rs = conn.createStatement().executeQuery(query);
            String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
            String fileName = config.fileNamePattern
                    .replace("{LETTER_TYPE}", letterType)
                    .replace("{DATE}", date);

            // Print columns for debugging
            // Print total number of records in columns
            System.out.println(columns.size() + " columns found for letter type: " + letterType);
            for (String column : columns) {
                System.out.print(column + " ");
            }

            new File(letter.exportPath).mkdirs();
            FileUtil.writeResultSetToFile(rs, columns, letter.delimiter, letter.exportPath + fileName);
        }
    }

    private LetterDefinition loadDefinition(String filePath) throws Exception {
        JAXBContext context = JAXBContext.newInstance(LetterDefinition.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        return (LetterDefinition) unmarshaller.unmarshal(new File(filePath));
    }

    private String getInlineQuery(String letterType) {
        switch (letterType) {
            case "HoldLetter":
                return "SELECT ACCOUNT_NO, CUSTOMER_NAME, HOLD_REASON FROM HOLD_CASES";
            default:
                return "";
        }
    }

    private List<String> getInlineColumns(String letterType) {
        switch (letterType) {
            case "HoldLetter":
                return Arrays.asList("ACCOUNT_NO", "CUSTOMER_NAME", "HOLD_REASON");
            default:
                return new ArrayList<>();
        }
    }
}
