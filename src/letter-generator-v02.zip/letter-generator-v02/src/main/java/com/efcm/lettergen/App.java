package com.efcm.lettergen;

import com.efcm.lettergen.generator.LetterGenerator;
import com.efcm.lettergen.util.EncryptionUtil;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class App {
    public static void main(String[] args) throws Exception {
        if (args.length == 2) {
            String textToEncrypt = args[0];
            String outputDir = args[1];
            
            // Normalize path and ensure directory exists
            Path outputPath = Paths.get(outputDir, "encryptedtext.txt");
            Files.createDirectories(outputPath.getParent());
            
            EncryptionUtil.encryptToFile(textToEncrypt, outputPath.toString());
            System.out.println("Encrypted text written to: " + outputPath.toAbsolutePath());
        } else {
            new LetterGenerator().generateAll();
        }
    }
}