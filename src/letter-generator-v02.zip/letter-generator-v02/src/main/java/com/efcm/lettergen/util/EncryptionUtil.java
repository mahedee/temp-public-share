package com.efcm.lettergen.util;

import java.io.File;
import java.io.FileWriter;
import java.nio.charset.StandardCharsets;
import java.util.Base64;

public class EncryptionUtil {
    public static String encrypt(String text) {
        return Base64.getEncoder().encodeToString(text.getBytes(StandardCharsets.UTF_8));
    }

    public static String decrypt(String encrypted) {
        return new String(Base64.getDecoder().decode(encrypted), StandardCharsets.UTF_8);
    }

    public static void encryptToFile(String text, String filePath) throws Exception {
        File outputFile = new File(filePath);
        // Create parent directories if they don't exist
        File parentDir = outputFile.getParentFile();
        if (parentDir != null && !parentDir.exists()) {
            parentDir.mkdirs();
        }
        
        try (FileWriter writer = new FileWriter(outputFile)) {
            String encryptedText = encrypt(text);
            writer.write(encryptedText);
        }
    }
}