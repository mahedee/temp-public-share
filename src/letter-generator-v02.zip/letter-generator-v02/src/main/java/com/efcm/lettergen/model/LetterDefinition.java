package com.efcm.lettergen.model;

import jakarta.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "letter")
@XmlAccessorType(XmlAccessType.FIELD)
public class LetterDefinition {
    private String fileName;
    private String query;
    
    @XmlElementWrapper(name = "columns")
    @XmlElement(name = "column")
    private List<String> columns;

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getQuery() { return query; }
    public void setQuery(String query) { this.query = query; }

    public List<String> getColumns() { return columns; }
    public void setColumns(List<String> columns) { this.columns = columns; }
}
