package com.efcm.lettergen.config;

public class LetterConfig {
    public boolean enabled;
    public String delimiter;
    public boolean useQueryFromXml;
    public String queryFile;
    public String exportPath;
}
