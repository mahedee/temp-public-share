package com.efcm.lettergen.config;

import com.fasterxml.jackson.databind.ObjectMapper;
import java.io.File;

public class AppConfig {
    private static Config config;

    static {
        try {
            ObjectMapper mapper = new ObjectMapper();
            config = mapper.readValue(new File("config/config.json"), Config.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static Config getConfig() {
        return config;
    }
}
