package com.efcm.lettergen.config;
import java.util.Map;

public class Config {
    public boolean isEncryptedPassword;
    public DatabaseConfig database;
    public String fileNamePattern;
    public Map<String, LetterConfig> letters;
}
