package com.efcm.lettergen.util;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

public class FileUtil {
    public static void writeResultSetToFile(ResultSet rs, List<String> columns, String delimiter, String filePath) throws Exception {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            while (rs.next()) {
                for (int i = 0; i < columns.size(); i++) {
                    writer.write(rs.getString(columns.get(i)));
                    if (i != columns.size() - 1) writer.write(delimiter);
                }
                writer.newLine();
            }
        }
    }
}
