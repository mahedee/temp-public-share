#!/bin/bash

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load configuration
source "$SCRIPT_DIR/letter-generator-config.sh"

# Initialize logging
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
MAIN_LOG="$LOG_DIR/main_execution_$TIMESTAMP.log"

{
    echo "=============================================="
    echo "Letter Generation System - Execution Started"
    echo "Timestamp: $(date)"
    echo "=============================================="

    # Step 1: Generate Letters
    echo "Starting letter generation..."
    "$SCRIPT_DIR/execute-generator.sh"
    if [ $? -ne 0 ]; then
        echo "ERROR: Letter generation failed. Aborting process."
        exit 1
    fi

    # Step 2: Transfer Files
    echo "Starting SFTP transfer..."
    "$SCRIPT_DIR/transfer-to-sftp.sh"
    if [ $? -ne 0 ]; then
        echo "WARNING: Some files failed to transfer. Check transfer logs."
    fi

    # Step 3: Cleanup old log files
    echo "Cleaning up log files older than 5 days..."
    "$SCRIPT_DIR/cleanup-old-logs.sh"
    if [ $? -ne 0 ]; then
        echo "WARNING: Log cleanup encountered some issues. Check cleanup logs."
    fi

    # Step 4: Cleanup temporary files
    echo "Cleaning up temporary files..."
    rm -f "$TEMP_DIR"/*

    echo "=============================================="
    echo "Process completed at: $(date)"
    echo "=============================================="
} > "$MAIN_LOG" 2>&1

# Final notification
echo "Process completed. See main log at: $MAIN_LOG"
exit 0