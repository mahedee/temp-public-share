# PowerShell version of letter-generator-main.sh for Windows testing

# Configuration (Windows paths)
$JAVA_HOME = $env:JAVA_HOME
if (-not $JAVA_HOME) {
    $JAVA_HOME = "C:\Program Files\Java\jdk-11"
}

$APP_HOME = Get-Location
$JAR_FILE = "$APP_HOME\target\letter-generator-1.0-SNAPSHOT.jar"
$LOG_DIR = "$APP_HOME\logs"
$OUTPUT_DIR = "$APP_HOME\output"

# Create directories if they don't exist
New-Item -ItemType Directory -Force -Path $LOG_DIR | Out-Null
New-Item -ItemType Directory -Force -Path $OUTPUT_DIR | Out-Null

# Initialize logging
$TIMESTAMP = Get-Date -Format "yyyyMMdd_HHmmss"
$MAIN_LOG = "$LOG_DIR\main_execution_$TIMESTAMP.log"

# Function to write to both console and log
function Write-LogAndConsole {
    param($Message)
    Write-Host $Message
    Add-Content -Path $MAIN_LOG -Value "$(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') - $Message"
}

Write-LogAndConsole "=============================================="
Write-LogAndConsole "Letter Generation System - Execution Started"
Write-LogAndConsole "Timestamp: $(Get-Date)"
Write-LogAndConsole "=============================================="

# Step 1: Generate Letters
Write-LogAndConsole "Starting letter generation..."

try {
    # Run the Java application
    $process = Start-Process -FilePath "java" -ArgumentList "-jar", $JAR_FILE -NoNewWindow -Wait -PassThru -RedirectStandardOutput "$LOG_DIR\java_output_$TIMESTAMP.log" -RedirectStandardError "$LOG_DIR\java_error_$TIMESTAMP.log"
    
    if ($process.ExitCode -eq 0) {
        Write-LogAndConsole "Letter generation completed successfully"
    } else {
        Write-LogAndConsole "ERROR: Letter generation failed with exit code $($process.ExitCode)"
        Write-LogAndConsole "Check java_error_$TIMESTAMP.log for details"
        exit 1
    }
} catch {
    Write-LogAndConsole "ERROR: Failed to execute letter generation: $($_.Exception.Message)"
    exit 1
}

# Step 2: List generated files
Write-LogAndConsole "Generated files:"
$outputDirs = @("demand", "hold", "idtheft", "relationship-term", "welcome")
foreach ($dir in $outputDirs) {
    $dirPath = "$OUTPUT_DIR\$dir"
    if (Test-Path $dirPath) {
        $files = Get-ChildItem -Path $dirPath -File
        foreach ($file in $files) {
            Write-LogAndConsole "  - $dir\$($file.Name)"
        }
    }
}

Write-LogAndConsole "=============================================="
Write-LogAndConsole "Process completed at: $(Get-Date)"
Write-LogAndConsole "=============================================="

# Final notification
Write-Host "Process completed successfully!"
Write-Host "Main log: $MAIN_LOG"
Write-Host "Application logs: $LOG_DIR\letter-generator*.log"
Write-Host "Generated files in: $OUTPUT_DIR"
