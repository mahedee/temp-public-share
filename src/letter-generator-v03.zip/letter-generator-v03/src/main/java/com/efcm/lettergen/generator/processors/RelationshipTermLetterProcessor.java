package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;

/**
 * Letter processor for Relationship Termination Letters
 */
public class RelationshipTermLetterProcessor extends AbstractLetterProcessor {
    
    public RelationshipTermLetterProcessor() {
        super("RelationshipTermLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT ACCOUNT_NO, CUSTOMER_NAME, TERMINATION_DATE, REASON_CODE, FINAL_BALANCE FROM RELATIONSHIP_TERM_NOTICES WHERE STATUS = 'PENDING'";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("ACCOUNT_NO", "CUSTOMER_NAME", "TERMINATION_DATE", "REASON_CODE", "FINAL_BALANCE");
    }
}
