package com.efcm.lettergen.generator;

import java.util.List;

/**
 * Interface for letter processors following Open-Closed Principle
 */
public interface LetterProcessor {
    
    /**
     * Get the inline query for this letter type
     * @return SQL query string
     */
    String getInlineQuery();
    
    /**
     * Get the columns for this letter type
     * @return List of column names
     */
    List<String> getInlineColumns();
    
    /**
     * Get the letter type name
     * @return Letter type name
     */
    String getLetterType();
    
    /**
     * Check if this processor supports inline queries
     * @return true if inline queries are supported
     */
    boolean supportsInlineQuery();
}
