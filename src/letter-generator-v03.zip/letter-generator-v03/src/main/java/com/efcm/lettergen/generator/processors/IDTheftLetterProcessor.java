package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;

/**
 * Letter processor for ID Theft Letters
 */
public class IDTheftLetterProcessor extends AbstractLetterProcessor {
    
    public IDTheftLetterProcessor() {
        super("IDTheftLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT CASE_ID, CUSTOMER_NAME, ACCOUNT_NO, INCIDENT_DATE, RECOVERY_STATUS FROM ID_THEFT_CASES WHERE STATUS = 'PENDING'";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("CASE_ID", "CUSTOMER_NAME", "ACCOUNT_NO", "INCIDENT_DATE", "RECOVERY_STATUS");
    }
}
