package com.efcm.lettergen.generator;

import com.efcm.lettergen.config.*;
import com.efcm.lettergen.model.LetterDefinition;
import com.efcm.lettergen.util.EncryptionUtil;
import com.efcm.lettergen.util.FileUtil;

import jakarta.xml.bind.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class LetterGenerator {
    
    private static final Logger logger = LoggerFactory.getLogger(LetterGenerator.class);
    
    public void generateAll() throws Exception {
        Config config = AppConfig.getConfig();
        String password = config.isEncryptedPassword
                ? EncryptionUtil.decrypt(config.database.password.replace("ENCRYPTED(", "").replace(")", ""))
                : config.database.password;

        Connection conn = DriverManager.getConnection(
                config.database.url,
                config.database.user,
                password
        );

        // Read letter names from config.json and process each one
        for (Map.Entry<String, LetterConfig> entry : config.letters.entrySet()) {
            String letterType = entry.getKey();
            LetterConfig letterConfig = entry.getValue();
            
            if (!letterConfig.enabled) {
                logger.info("Skipping disabled letter type: " + letterType);
                continue;
            }

            try {
                processLetter(conn, letterType, letterConfig, config.fileNamePattern);
            } catch (Exception e) {
                logger.error("Error processing letter type {}: {}", letterType, e.getMessage(), e);
            }
        }
        
        conn.close();
    }
    
    public void generateLetter(String letterType) throws Exception {
        Config config = AppConfig.getConfig();
        String password = config.isEncryptedPassword
                ? EncryptionUtil.decrypt(config.database.password.replace("ENCRYPTED(", "").replace(")", ""))
                : config.database.password;

        Connection conn = DriverManager.getConnection(
                config.database.url,
                config.database.user,
                password
        );

        // Find the specific letter configuration
        LetterConfig letterConfig = config.letters.get(letterType);
        if (letterConfig == null) {
            logger.error("Letter type '{}' not found in configuration. Available types: {}", letterType, config.letters.keySet());
            conn.close();
            return;
        }
        
        if (!letterConfig.enabled) {
            logger.info("Letter type '{}' is disabled in configuration", letterType);
            conn.close();
            return;
        }

        try {
            processLetter(conn, letterType, letterConfig, config.fileNamePattern);
        } catch (Exception e) {
            logger.error("Error processing letter type {}: {}", letterType, e.getMessage(), e);
        }
        
        conn.close();
    }
    
    private void processLetter(Connection conn, String letterType, LetterConfig letterConfig, String fileNamePattern) throws Exception {
        logger.info("Processing letter type: " + letterType);
        
        String query;
        List<String> columns;

        // Determine query source based on configuration
        if ("xml".equalsIgnoreCase(letterConfig.querySource)) {
            logger.info("Using XML query for letter type: " + letterType);
            LetterDefinition def = loadDefinition("config/letters/" + letterConfig.queryFile);
            query = def.getQuery();
            columns = def.getColumns();
        } else if ("inline".equalsIgnoreCase(letterConfig.querySource)) {
            // Use inline query from letter processor
            logger.info("Using inline query for letter type: " + letterType);
            LetterProcessor processor = LetterProcessorFactory.getProcessor(letterType);
            
            if (!processor.supportsInlineQuery()) {
                logger.error("Inline query not found for letter type: {}. Please implement a processor for this letter type or change querySource to 'xml'.", letterType);
                logger.warn("TestLetter cannot be generated because inline query is missing. You have to add inline query in the code or you have to switch to xml query source.");
                return;
            }
            
            query = processor.getInlineQuery();
            columns = processor.getInlineColumns();
            
            if (query.isEmpty() || columns.isEmpty()) {
                logger.error("Empty inline query or columns for letter type: {}. Please check the processor implementation.", letterType);
                return;
            }
        } else {
            logger.error("Invalid querySource '{}' for letter type: {}. Valid values are 'xml' or 'inline'.", letterConfig.querySource, letterType);
            return;
        }

        // Execute query and generate file
        executeQueryAndGenerateFile(conn, letterType, letterConfig, query, columns, fileNamePattern);
    }
    
    private void executeQueryAndGenerateFile(Connection conn, String letterType, LetterConfig letterConfig, 
                                           String query, List<String> columns, String fileNamePattern) throws Exception {
        
        logger.info("Executing query for letter type: " + letterType);
        logger.info("Query: " + query);
        
        ResultSet rs = conn.createStatement().executeQuery(query);
        String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        String fileName = fileNamePattern
                .replace("{LETTER_TYPE}", letterType)
                .replace("{DATE}", date);

        // Log column information
        logger.info(columns.size() + " columns found for letter type: " + letterType);
        logger.info("Columns: " + String.join(", ", columns));

        // Ensure output directory exists
        new File(letterConfig.exportPath).mkdirs();
        
        // Generate the file
        String fullPath = letterConfig.exportPath + fileName;
        FileUtil.writeResultSetToFile(rs, columns, letterConfig.delimiter, fullPath);
        
        logger.info("Generated file for letter type " + letterType + ": " + fullPath);
        rs.close();
    }

    private LetterDefinition loadDefinition(String filePath) throws Exception {
        logger.info("Loading letter definition from: " + filePath);
        JAXBContext context = JAXBContext.newInstance(LetterDefinition.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        return (LetterDefinition) unmarshaller.unmarshal(new File(filePath));
    }
}
