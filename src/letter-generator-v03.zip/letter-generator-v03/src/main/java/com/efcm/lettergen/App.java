package com.efcm.lettergen;

import com.efcm.lettergen.generator.LetterGenerator;
import com.efcm.lettergen.util.EncryptionUtil;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class App {
    public static void main(String[] args) throws Exception {
        if (args.length == 1) {
            // Check if it's a letter type or encryption text
            String argument = args[0];
            
            // If it looks like a letter type (ends with "Letter"), generate specific letter
            if (argument.endsWith("Letter")) {
                new LetterGenerator().generateLetter(argument);
            } else {
                // Treat as encryption text with default output
                String textToEncrypt = argument;
                String outputDir = "output/encrypted";
                
                Path encryptedPath = Paths.get(outputDir, "encryptedtext.txt");
                Files.createDirectories(encryptedPath.getParent());
                
                EncryptionUtil.encryptToFile(textToEncrypt, encryptedPath.toString());
                System.out.println("Encrypted text written to: " + encryptedPath.toAbsolutePath());
            }
        } else if (args.length == 2) {
            // Handle two arguments - could be encryption or letter generation with output dir
            String firstArg = args[0];
            String secondArg = args[1];
            
            // If first argument is a letter type, ignore second argument for now
            if (firstArg.endsWith("Letter")) {
                new LetterGenerator().generateLetter(firstArg);
            } else {
                // Treat as encryption request
                String textToEncrypt = firstArg;
                String outputDir = secondArg;
                
                Path encryptedPath = Paths.get(outputDir, "encryptedtext.txt");
                Files.createDirectories(encryptedPath.getParent());
                
                EncryptionUtil.encryptToFile(textToEncrypt, encryptedPath.toString());
                System.out.println("Encrypted text written to: " + encryptedPath.toAbsolutePath());
            }
        } else {
            // No arguments - generate all letters
            new LetterGenerator().generateAll();
        }
    }
}