package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;

/**
 * Letter processor for Hold Letters
 */
public class HoldLetterProcessor extends AbstractLetterProcessor {
    
    public HoldLetterProcessor() {
        super("HoldLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT HOLD_ID, ACCOUNT_NO, CUSTOMER_NAME, HOLD_REASON, TO_CHAR(HOLD_DATE, 'YYYY-MM-DD') AS HOLD_DATE, RELEASE_COND FROM HOLD_LETTERS";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("HOLD_ID", "ACCOUNT_NO", "CUSTOMER_NAME", "HOLD_REASON", "HOLD_DATE", "RELEASE_COND");
    }
}
