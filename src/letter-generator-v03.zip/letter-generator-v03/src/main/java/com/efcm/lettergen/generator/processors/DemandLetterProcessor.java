package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;

/**
 * Letter processor for Demand Letters
 */
public class DemandLetterProcessor extends AbstractLetterProcessor {
    
    public DemandLetterProcessor() {
        super("DemandLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT CASE_ID, ACCOUNT_NO, CUSTOMER_NAME, DUE_AMOUNT, TO_CHAR(DUE_DATE, 'YYYY-MM-DD') AS DUE_DATE, REASON FROM DEMAND_LETTERS";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("CASE_ID", "ACCOUNT_NO", "CUSTOMER_NAME", "DUE_AMOUNT", "DUE_DATE", "REASON");
    }
}
