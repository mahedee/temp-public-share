package com.efcm.lettergen.generator;

import java.util.List;

/**
 * Abstract base class for letter processors
 */
public abstract class AbstractLetterProcessor implements LetterProcessor {
    
    protected final String letterType;
    
    protected AbstractLetterProcessor(String letterType) {
        this.letterType = letterType;
    }
    
    @Override
    public String getLetterType() {
        return letterType;
    }
    
    @Override
    public boolean supportsInlineQuery() {
        return true; // Default implementation supports inline queries
    }
    
    /**
     * Default implementation returns empty query - subclasses should override
     */
    @Override
    public String getInlineQuery() {
        return "";
    }
    
    /**
     * Default implementation returns empty list - subclasses should override
     */
    @Override
    public List<String> getInlineColumns() {
        return List.of();
    }
}
