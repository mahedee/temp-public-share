package com.batchengine.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.List;

import com.batchengine.model.ManualAccount;

/**
 * Repository for Manual Account Entry data access.
 * Contains all SQL queries related to manual account entry processing.
 */
@Repository
@ConditionalOnBean(DataSource.class)
public class ManualAccountEntryRepository {

    private static final Logger logger = LoggerFactory.getLogger(ManualAccountEntryRepository.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    @Lazy
    private ManualAccountEntryRepository self;


    public void processEntries() {
        logger.info("Processing manual account entries...");

        try {

            // Step 1: Mark relevant BMO_ACCOUNTS_MANUAL records as PROCESSING
            int step1Rows = self.markProcessingStatus();
            logger.info("Step 1 completed - BMO_ACCOUNTS_MANUAL marked as PROCESSING: {} row(s)", step1Rows);

            if (step1Rows == 0) {
                logger.info("No records to process. Skipping remaining steps.");
                return;
            }

            // Step 2: Fetch all entries that are now in PROCESSING status
            List<ManualAccount> processingEntries = getProcessingEntries();
            if(processingEntries.isEmpty()) {
                logger.warn("No records found in PROCESSING status after Step 1. This should not happen. Aborting process.");
                return;
            }

            // Step 3-5: Process each entry individually to ensure transactionality and error isolation
            for (ManualAccount manualAccount : processingEntries) {
                try {
                    self.processSingleAccount(manualAccount);
                } catch (RuntimeException e) {
                    logger.error("Failed to process account ACCOUNT_SOURCE_REF_ID: {}. Skipping. Cause: {}",
                        manualAccount.getAccountSourceRefId(), e.getMessage());
                }
            }
            processingEntries.clear(); // release references promptly

            logger.info("Manual account entry processing completed successfully.");

        } catch (RuntimeException e) {
            logger.error("Manual account entry processing aborted. Cause: {}", e.getMessage());
            throw e;
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void processSingleAccount(ManualAccount manualAccount) {
        String accountId = getAccountIdBySourceRefId(manualAccount.getAccountSourceRefId());

        // update ACCOUNT_DYNAMIC for this account if ACCOUNT_ID is found and does not already exist in ACCOUNT_DYNAMIC
        if (accountId != null && !accountId.equals(manualAccount.getAccountSourceRefId())) {
            int updatedRows = updateAccountDynamicByAccountId(accountId, manualAccount.getAccountSourceRefId());
            logger.info("Updated ACCOUNT_DYNAMIC for ACCOUNT_SOURCE_REF_ID: {} with ACCOUNT_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), accountId, updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping ACCOUNT_DYNAMIC update for this record.", manualAccount.getAccountSourceRefId());
        }

        // update WORKFLOW_WORKITEM_LINK for this account if ACCOUNT_ID is found
        if (accountId != null && !accountId.equals(manualAccount.getAccountSourceRefId())) {
            int updatedRows = updateWorkflowWorkitemLinkByAccountId(accountId, manualAccount.getAccountSourceRefId());
            logger.info("Updated WORKFLOW_WORKITEM_LINK for ACCOUNT_SOURCE_REF_ID: {} with ACCOUNT_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), accountId, updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping WORKFLOW_WORKITEM_LINK update for this record.", manualAccount.getAccountSourceRefId());
        }

        // update BMO_ACC_PH_DETAILS for this account if ACCOUNT_ID is found
        if (accountId != null && !accountId.equals(manualAccount.getAccountSourceRefId())) {
            int updatedRows = updateBmoAccPhDetailsByAccountId(accountId, manualAccount.getAccountSourceRefId());
            logger.info("Updated BMO_ACC_PH_DETAILS for ACCOUNT_SOURCE_REF_ID: {} with ACCOUNT_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), accountId, updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping BMO_ACC_PH_DETAILS update for this record.", manualAccount.getAccountSourceRefId());
        }

        // soft-delete BMO_ACCOUNTS_MANUAL for this account if ACCOUNT_ID is found
        if (accountId != null) {
            int updatedRows = softDeleteManualEntryByAccountSourceRefId(manualAccount.getAccountSourceRefId());
            logger.info("Soft-deleted BMO_ACCOUNTS_MANUAL for ACCOUNT_SOURCE_REF_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping soft-delete for this record.", manualAccount.getAccountSourceRefId());
        }
    }

    /**
     * Step 1: Mark BMO_ACCOUNTS_MANUAL records as PROCESSING.
     * Targets active, non-deleted manual entries that have a matching record in ACCOUNTS.
     * @Transactional(rollbackFor = Exception.class) ensures that if any error occurs during this update, the transaction will be rolled back to maintain data integrity.
     */

    @Transactional(rollbackFor = Exception.class)
    public int markProcessingStatus() {
        String sql =
            "UPDATE BMO_ACCOUNTS_MANUAL man " +
            "SET STATUS = 'PROCESSING' " +
            "WHERE man.IS_DELETED = 'N' AND man.STATUS = 'ACTIVE' " +
            "  AND EXISTS ( " +
            "        SELECT 1 " +
            "        FROM   ACCOUNTS acc " +
            "        WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID " +
            "      )";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 1 failed - Unable to mark BMO_ACCOUNTS_MANUAL records as PROCESSING. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 1 - markProcessingStatus failed", e);
        }
    }


        /**
     * Fetch all BMO_ACCOUNTS_MANUAL records currently in PROCESSING status.
     *
     * @return list of ManualAccount objects containing ACCOUNT_ID, ACCOUNT_SOURCE_REF_ID, and ACCOUNT_SOURCE_UNIQUE_ID
     */
    public List<ManualAccount> getProcessingEntries() {
        String sql =
            "SELECT ACCOUNT_ID, ACCOUNT_SOURCE_REF_ID, ACCOUNT_SOURCE_UNIQUE_ID " +
            "FROM   BMO_ACCOUNTS_MANUAL " +
            "WHERE  STATUS = 'PROCESSING'";
        try {
            List<ManualAccount> results = jdbcTemplate.query(sql, (rs, rowNum) -> {
                ManualAccount account = new ManualAccount();
                account.setAccountId(rs.getString("ACCOUNT_ID"));
                account.setAccountSourceRefId(rs.getString("ACCOUNT_SOURCE_REF_ID"));
                account.setAccountSourceUniqueId(rs.getString("ACCOUNT_SOURCE_UNIQUE_ID"));
                return account;
            });
            logger.info("Fetched {} PROCESSING record(s) from BMO_ACCOUNTS_MANUAL", results.size());
            return results;
        } catch (DataAccessException e) {
            logger.error("Failed to fetch PROCESSING entries from BMO_ACCOUNTS_MANUAL. Error: {}", e.getMessage(), e);
            throw new RuntimeException("getProcessingEntries failed", e);
        }
    }

    // Get Account Id from ACCOUNTS based on ACCOUNT_SOURCE_REF_ID
    private String getAccountIdBySourceRefId(String accountSourceRefId) {
        String sql =
            "SELECT ACCOUNT_ID " +
            "FROM   ACCOUNTS " +
            "WHERE  ACCOUNT_SOURCE_REF_ID = ? " +
            "AND    ACCOUNT_ID IS NOT NULL " +
            "FETCH FIRST 1 ROW ONLY";
        try {
            return jdbcTemplate.queryForObject(sql, String.class, accountSourceRefId);
        } catch (EmptyResultDataAccessException e) {
            return null; // No matching account found — expected business case
        } catch (DataAccessException e) {
            logger.error("Failed to fetch ACCOUNT_ID from ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Error: {}", accountSourceRefId, e.getMessage(), e);
            throw new RuntimeException("getAccountIdBySourceRefId failed for ACCOUNT_SOURCE_REF_ID: " + accountSourceRefId, e);
        }
    }

    private int updateAccountDynamicByAccountId(String accountId, String accountSourceRefId) {
        if(checkAccountIdExistsInAccountDynamic(accountId)) {
            logger.info("ACCOUNT_ID {} already exists in ACCOUNT_DYNAMIC. Skipping update for ACCOUNT_SOURCE_REF_ID: {}", accountId, accountSourceRefId);
            return 0; // No rows updated since ACCOUNT_ID already exists
        }

        String sql =
            "UPDATE ACCOUNT_DYNAMIC " +
            "SET ACCOUNT_ID = ? " +
            "WHERE ACCOUNT_ID = ?"; // Assuming ACCOUNT_ID is currently set to ACCOUNT_SOURCE_REF_ID

        try {
            return jdbcTemplate.update(sql, accountId, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to update ACCOUNT_DYNAMIC for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("updateAccountDynamicByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }

    // Check if ACCOUNT_ID already exists in ACCOUNT_DYNAMIC to prevent duplicate key issues
   private boolean checkAccountIdExistsInAccountDynamic(String accountId) {
        String sql =
            "SELECT COUNT(1) " +
            "FROM ACCOUNT_DYNAMIC " +
            "WHERE ACCOUNT_ID = ?";
        try {
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, accountId);
            return count != null && count > 0;
        } catch (DataAccessException e) {
            logger.error("Failed to check if ACCOUNT_ID exists in ACCOUNT_DYNAMIC for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("checkAccountIdExistsInAccountDynamic failed for ACCOUNT_ID: " + accountId, e);
        }
    }


    // Update WORKFLOW_WORKITEM_LINK for a specific ACCOUNT_ID and ACCOUNT_SOURCE_REF_ID
    private int updateWorkflowWorkitemLinkByAccountId(String accountId, String accountSourceRefId) {
        String sql =
            "UPDATE WORKFLOW_WORKITEM_LINK wwl " +
            "SET LINKED_ENTITY_KEY = ? " +
            "WHERE LINKED_ENTITY_KEY = ?"; // Assuming LINKED_ENTITY_KEY is currently set to ACCOUNT_SOURCE_REF_ID

        try {
            return jdbcTemplate.update(sql, accountId, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to update WORKFLOW_WORKITEM_LINK for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("updateWorkflowWorkitemLinkByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }

    // Overloaded method to update BMO_ACC_PH_DETAILS for a specific ACCOUNT_ID and ACCOUNT_SOURCE_REF_ID
    private int updateBmoAccPhDetailsByAccountId(String accountId, String accountSourceRefId) {
        String sql =
            "UPDATE BMO_ACC_PH_DETAILS ph " +
            "SET FCM_CP_ACCOUNT_ID = ? " +
            "WHERE FCM_CP_ACCOUNT_ID = ?"; // Assuming FCM_CP_ACCOUNT_ID is currently set to ACCOUNT_SOURCE_REF_ID

        try {
            return jdbcTemplate.update(sql, accountId, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to update BMO_ACC_PH_DETAILS for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("updateBmoAccPhDetailsByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }   

    /**
     * Step 5: Soft-delete and finalise PROCESSING records in BMO_ACCOUNTS_MANUAL.
     * Sets IS_DELETED = 'Y', STATUS = 'DELETED', and records the canonical ACCOUNT_ID
     * from ACCOUNTS to mark these manual entries as fully processed.
     */
    
    private int softDeleteManualEntryByAccountSourceRefId(String accountSourceRefId) {
        String sql =
            "UPDATE BMO_ACCOUNTS_MANUAL " +
            "SET IS_DELETED = 'Y', STATUS = 'DELETED' " +
            "WHERE ACCOUNT_SOURCE_REF_ID = ?";

        try {
            return jdbcTemplate.update(sql, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to soft-delete BMO_ACCOUNTS_MANUAL for ACCOUNT_SOURCE_REF_ID: {}. Error: {}", accountSourceRefId, e.getMessage(), e);
            throw new RuntimeException("softDeleteManualEntryByAccountSourceRefId failed for ACCOUNT_SOURCE_REF_ID: " + accountSourceRefId, e);
        }
    }
}
