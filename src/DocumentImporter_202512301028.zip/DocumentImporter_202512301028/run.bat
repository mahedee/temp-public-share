@echo off
:: Organization Unit Management System Launcher
:: This script builds and runs the Document Importer application

echo ==========================================
echo Organization Unit Management System
echo ==========================================

:: Check if Maven is installed
mvn -version >nul 2>&1
if %errorlevel% neq 0 (
    echo Error: Maven is not installed or not in PATH
    pause
    exit /b 1
)

:: Get the directory where the script is located
set SCRIPT_DIR=%~dp0
set PROJECT_DIR=%SCRIPT_DIR%app

:: Change to project directory
cd /d "%PROJECT_DIR%"
if %errorlevel% neq 0 (
    echo Error: Cannot access project directory
    pause
    exit /b 1
)

echo Building application...
mvn clean compile

if %errorlevel% neq 0 (
    echo Error: Build failed
    pause
    exit /b 1
)

echo Starting Organization Unit Management System...
echo ==========================================

:: Run the application
mvn exec:java -Dexec.mainClass="com.documentimporter.App"

echo ==========================================
echo Application finished.
pause