package com.documentImporter.util;

import com.documentImporter.model.FileInfo;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Logger;

/**
 * Utility class for extracting letter IDs from PDF filenames.
 * Handles parsing of structured filenames with pattern: EFCM_CS_yyyyMMddHHH_BMOFraud_Run_XXX_PDF_{letterId}.pdf
 * Author: Mahedee Hasan
 */
public class LetterIdParser {
    
    private static final Logger LOGGER = Logger.getLogger(LetterIdParser.class.getName());
    
    // Pattern to match: EFCM_CS_20251222000_BMOFraud_Run_533_PDF_{letterId}.pdf
    private static final Pattern LETTER_ID_PATTERN = Pattern.compile(
        "^EFCM_CS_\\d+_BMOFraud_Run_\\d+_PDF_(\\d+)\\.pdf$", 
        Pattern.CASE_INSENSITIVE
    );
    
    /**
     * Extract letter ID from PDF filename.
     * 
     * @param fileName The PDF filename to parse
     * @return Letter ID if found, null otherwise
     */
    public static String extractLetterId(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            LOGGER.warning("Filename is null or empty");
            return null;
        }
        
        Matcher matcher = LETTER_ID_PATTERN.matcher(fileName.trim());
        
        if (matcher.matches()) {
            String letterId = matcher.group(1);
            LOGGER.fine("Extracted letter ID: " + letterId + " from filename: " + fileName);
            return letterId;
        }
        
        LOGGER.warning("No letter ID found in filename: " + fileName);
        return null;
    }
    
    /**
     * Validate if filename matches the expected PDF pattern.
     * 
     * @param fileName The filename to validate
     * @return true if filename matches pattern, false otherwise
     */
    public static boolean isValidPdfFileName(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return false;
        }
        
        return LETTER_ID_PATTERN.matcher(fileName.trim()).matches();
    }
    
    /**
     * Extract all components from PDF filename.
     * 
     * @param fileName The PDF filename to parse
     * @return FileInfo object with parsed components
     */
    public static FileInfo parsePdfFileName(String fileName) {
        if (!isValidPdfFileName(fileName)) {
            return null;
        }
        
        String letterId = extractLetterId(fileName);
        return new FileInfo(fileName, letterId);
    }
}