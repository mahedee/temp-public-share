package com.documentImporter.util;

import com.documentImporter.constants.AppConstants;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.Properties;

/**
 * Database Connection Utility using HikariCP connection pool
 * Author: Mahedee Hasan
 */
public class DatabaseConnection {
    
    private static HikariDataSource dataSource;
    
    static {
        try {
            initializeDataSource();
        } catch (Exception e) {
            throw new RuntimeException("Failed to initialize database connection", e);
        }
    }
    
    private static void initializeDataSource() throws IOException {
        Properties properties = loadProperties();
        
        HikariConfig config = new HikariConfig();
        config.setJdbcUrl(properties.getProperty("database.url"));
        config.setUsername(properties.getProperty("database.username"));

        if(properties.getProperty("database.isEncryptedPassword") != null &&
           properties.getProperty("database.isEncryptedPassword").equalsIgnoreCase("true")) {
            try {
                String decryptedPassword = AESEncryptionEngine.decrypt(
                        properties.getProperty("database.password"), AppConstants.SECRET_KEY); // Use your actual key here
                config.setPassword(decryptedPassword);
            } catch (Exception e) {
                throw new IOException("Failed to decrypt database password", e);
            }
        } else {
            config.setPassword(properties.getProperty("database.password"));
        }

        config.setDriverClassName(properties.getProperty("database.driver"));
        
        // HikariCP specific settings
        config.setConnectionTimeout(Long.parseLong(properties.getProperty("hikari.connection-timeout", "20000")));
        config.setMinimumIdle(Integer.parseInt(properties.getProperty("hikari.minimum-idle", "5")));
        config.setMaximumPoolSize(Integer.parseInt(properties.getProperty("hikari.maximum-pool-size", "20")));
        config.setIdleTimeout(Long.parseLong(properties.getProperty("hikari.idle-timeout", "300000")));
        config.setMaxLifetime(Long.parseLong(properties.getProperty("hikari.max-lifetime", "1200000")));
        config.setConnectionTestQuery(properties.getProperty("hikari.connection-test-query", "SELECT 1 FROM DUAL"));
        config.setValidationTimeout(Long.parseLong(properties.getProperty("hikari.validation-timeout", "5000")));
        
        dataSource = new HikariDataSource(config);
    }
    
    private static Properties loadProperties() throws IOException {
        Properties properties = new Properties();
        try (InputStream input = DatabaseConnection.class.getClassLoader()
                .getResourceAsStream("application.properties")) {
            if (input == null) {
                throw new IOException("application.properties file not found in classpath");
            }
            properties.load(input);
        }
        return properties;
    }
    
    /**
     * Get a connection from the connection pool
     * @return Database connection
     * @throws SQLException if unable to get connection
     */
    public static Connection getConnection() throws SQLException {
        if (dataSource == null) {
            throw new SQLException("DataSource is not initialized");
        }
        return dataSource.getConnection();
    }
    
    /**
     * Test database connectivity
     * @return true if connection is successful
     */
    public static boolean testConnection() {
        try (Connection connection = getConnection()) {
            return connection.isValid(5); // 5 second timeout
        } catch (SQLException e) {
            System.err.println("Database connection test failed: " + e.getMessage());
            return false;
        }
    }
    
    /**
     * Close the data source and all connections
     */
    public static void closeDataSource() {
        if (dataSource != null && !dataSource.isClosed()) {
            dataSource.close();
            System.out.println("Database connection pool closed.");
        }
    }
    
    /**
     * Get connection pool information
     * @return Connection pool status string
     */
    public static String getPoolInfo() {
        if (dataSource == null) {
            return "DataSource is not initialized";
        }
        
        return String.format("HikariCP Pool - Active: %d, Idle: %d, Waiting: %d, Total: %d",
                dataSource.getHikariPoolMXBean().getActiveConnections(),
                dataSource.getHikariPoolMXBean().getIdleConnections(),
                dataSource.getHikariPoolMXBean().getThreadsAwaitingConnection(),
                dataSource.getHikariPoolMXBean().getTotalConnections());
    }
    
    /**
     * Initialize shutdown hook to close connection pool gracefully
     */
    static {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> {
            closeDataSource();
        }));
    }
}