package com.documentImporter.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Configuration manager to read application properties.
 * Author: Mahedee Hasan
 */
public class ConfigurationManager {
    
    private static final Logger LOGGER = Logger.getLogger(ConfigurationManager.class.getName());
    private static final String PROPERTIES_FILE = "application.properties";
    private static Properties properties;
    
    static {
        loadProperties();
    }
    
    /**
     * Load properties from application.properties file.
     */
    private static void loadProperties() {
        properties = new Properties();
        
        try (InputStream inputStream = ConfigurationManager.class.getClassLoader()
                .getResourceAsStream(PROPERTIES_FILE)) {
            
            if (inputStream == null) {
                throw new RuntimeException("Properties file '" + PROPERTIES_FILE + "' not found in classpath");
            }
            
            properties.load(inputStream);
            LOGGER.info("Successfully loaded configuration from " + PROPERTIES_FILE);
            
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Error loading properties file: " + PROPERTIES_FILE, e);
            throw new RuntimeException("Failed to load configuration", e);
        }
    }
    
    /**
     * Get a property value by key.
     * 
     * @param key The property key
     * @return The property value or null if not found
     */
    public static String getProperty(String key) {
        return properties.getProperty(key);
    }
    
    /**
     * Get a property value by key with a default value.
     * 
     * @param key The property key
     * @param defaultValue The default value if key is not found
     * @return The property value or default value
     */
    public static String getProperty(String key, String defaultValue) {
        return properties.getProperty(key, defaultValue);
    }
    
    /**
     * Get an integer property value.
     * 
     * @param key The property key
     * @param defaultValue The default value if key is not found or invalid
     * @return The property value as integer
     */
    public static int getIntProperty(String key, int defaultValue) {
        String value = properties.getProperty(key);
        if (value != null) {
            try {
                return Integer.parseInt(value.trim());
            } catch (NumberFormatException e) {
                LOGGER.warning("Invalid integer value for property '" + key + "': " + value + 
                             ". Using default value: " + defaultValue);
            }
        }
        return defaultValue;
    }
    
    /**
     * Get a boolean property value.
     * 
     * @param key The property key
     * @param defaultValue The default value if key is not found
     * @return The property value as boolean
     */
    public static boolean getBooleanProperty(String key, boolean defaultValue) {
        String value = properties.getProperty(key);
        if (value != null) {
            return Boolean.parseBoolean(value.trim());
        }
        return defaultValue;
    }
    
    // Document processing configuration getters
    
    /**
     * Get the incoming folder path.
     * 
     * @return The incoming folder path
     */
    public static String getIncomingFolder() {
        return getProperty("docprocessor.folders.incoming", "incoming/");
    }
    
    /**
     * Get the archive folder path.
     * 
     * @return The archive folder path
     */
    public static String getArchiveFolder() {
        return getProperty("docprocessor.folders.archive", "archive/");
    }
    
    /**
     * Get the backup folder path.
     * 
     * @return The backup folder path
     */
    public static String getBackupFolder() {
        return getProperty("docprocessor.folders.backup", "backup/");
    }
    
    /**
     * Get the error folder path.
     * 
     * @return The error folder path
     */
    public static String getErrorFolder() {
        return getProperty("docprocessor.folders.error", "error/");
    }
    
    /**
     * Get the supported file extensions.
     * 
     * @return Comma-separated list of supported file extensions
     */
    public static String getSupportedExtensions() {
        return getProperty("docprocessor.file.supported-extensions", 
                          "pdf,doc,docx,txt,xml,json,jpeg,png,jpg,tiff");
    }
    
    /**
     * Get the maximum file size in MB.
     * 
     * @return Maximum file size in MB
     */
    public static int getMaxFileSizeMB() {
        return getIntProperty("docprocessor.file.max-size-mb", 50);
    }
    
    /**
     * Get the scan interval in seconds.
     * 
     * @return Scan interval in seconds
     */
    public static int getScanIntervalSeconds() {
        return getIntProperty("docprocessor.file.scan-interval-seconds", 10);
    }
    
    /**
     * Get auto-start processing flag.
     * 
     * @return true if auto-start is enabled
     */
    public static boolean isAutoStartEnabled() {
        return getBooleanProperty("docprocessor.processing.auto-start", true);
    }
    
    /**
     * Get maximum concurrent files to process.
     * 
     * @return Maximum concurrent files
     */
    public static int getMaxConcurrentFiles() {
        return getIntProperty("docprocessor.processing.max-concurrent-files", 5);
    }
    
    /**
     * Get retry attempts for failed processing.
     * 
     * @return Number of retry attempts
     */
    public static int getRetryAttempts() {
        return getIntProperty("docprocessor.processing.retry-attempts", 3);
    }
    
    // Database configuration getters
    
    /**
     * Get database URL.
     * 
     * @return Database URL
     */
    public static String getDatabaseUrl() {
        return getProperty("database.url");
    }
    
    /**
     * Get database username.
     * 
     * @return Database username
     */
    public static String getDatabaseUsername() {
        return getProperty("database.username");
    }
    
    /**
     * Get database password.
     * 
     * @return Database password
     */
    public static String getDatabasePassword() {
        return getProperty("database.password");
    }
    
    /**
     * Get database driver class.
     * 
     * @return Database driver class
     */
    public static String getDatabaseDriver() {
        return getProperty("database.driver");
    }
    
    /**
     * Get application name.
     * 
     * @return Application name
     */
    public static String getApplicationName() {
        return getProperty("application.name", "DocumentImporter");
    }

    public static String getEncryptedDirectory() {
        return getProperty("encryption.output.directory", "output/encrypted");
    }
    
    /**
     * Reload properties from file. Useful for runtime configuration changes.
     */
    public static void reloadProperties() {
        LOGGER.info("Reloading configuration properties...");
        loadProperties();
    }
    
    /**
     * Print all loaded properties (for debugging).
     */
    public static void printAllProperties() {
        LOGGER.info("Current configuration properties:");
        for (String key : properties.stringPropertyNames()) {
            String value = properties.getProperty(key);
            // Mask sensitive information
            if (key.toLowerCase().contains("password")) {
                value = "*****";
            }
            LOGGER.info(key + " = " + value);
        }
    }
}