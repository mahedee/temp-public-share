package com.documentImporter.service;

/**
 * Service interface for UniqueKey ID generation operations.
 * Author: Mahedee Hasan
 */
public interface UniqueKeyService {
    
    /**
     * Generate the next unique ID for a given table.
     * This method ensures thread-safe ID generation.
     * 
     * @param tableName The name of the table to generate ID for
     * @return The next available unique ID
     */
    Integer getNextId(String tableName);
    
    /**
     * Get the current next ID for a table without consuming it.
     * 
     * @param tableName The name of the table
     * @return The current next ID value
     */
    Integer getCurrentNextId(String tableName);
    
    /**
     * Initialize ID generation for a table if it doesn't exist.
     * 
     * @param tableName The table name to initialize
     * @param startingId The starting ID value (optional, defaults to 1)
     * @return true if initialized successfully
     */
    boolean initializeIdGeneration(String tableName, Integer startingId);
    
    /**
     * Check if ID generation is set up for a table.
     * 
     * @param tableName The table name to check
     * @return true if table is configured for ID generation
     */
    boolean isTableConfigured(String tableName);

    boolean updateNextId(String tableName);
}