package com.documentImporter.service;

import java.util.logging.Logger;

import com.documentImporter.dao.PostalMailDao;
import com.documentImporter.dao.PostalMailDaoImpl;

/*
* Service implementation for postal mail operations.
* Author: Mahedee Hasan
 */
public class PostalMailServiceImpl implements PostalMailService {

    private static final Logger LOGGER = Logger.getLogger(PostalMailServiceImpl.class.getName());
    private final PostalMailDao postalMailDao;

    public PostalMailServiceImpl() {
        this.postalMailDao = new PostalMailDaoImpl();
    }
    
    // Constructor for dependency injection (for testing)
    public PostalMailServiceImpl(PostalMailDao postalMailDao) {
        this.postalMailDao = postalMailDao;
    }

    @Override
    public String getEntityKeyByLetterId(String letterId) {
        // Implementation to retrieve entity key by letter ID
        return postalMailDao.getEntityKeyByLetterId(letterId);
    }
    
}
