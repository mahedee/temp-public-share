package com.documentImporter.service;

import com.documentImporter.model.WorkflowDocument;
import java.util.List;

/**
 * Service interface for WorkflowDocument business operations.
 * 
 * Author: Mahedee Hasan
 */
public interface WorkflowDocumentService {
    
    /**
     * Create a new workflow document.
     * 
     * @param document The WorkflowDocument to create
     * @return The created document with generated ID
     */
    WorkflowDocument createDocument(WorkflowDocument document);
    
    /**
     * Find a workflow document by its ID.
     * 
     * @param id The document ID
     * @return The WorkflowDocument if found, null otherwise
     */
    WorkflowDocument findDocumentById(Integer id);
    
    /**
     * Find all workflow documents for a specific entity.
     * 
     * @param entityName The entity name
     * @param entityKey The entity key
     * @return List of WorkflowDocuments for the entity
     */
    List<WorkflowDocument> findDocumentsByEntity(String entityName, String entityKey);
    
    /**
     * Find workflow documents by file name pattern.
     * 
     * @param fileNamePattern The file name pattern (supports wildcards)
     * @return List of matching WorkflowDocuments
     */
    List<WorkflowDocument> findDocumentsByFileName(String fileNamePattern);
    
    /**
     * Get all workflow documents.
     * 
     * @return List of all WorkflowDocuments
     */
    List<WorkflowDocument> getAllDocuments();
    
    /**
     * Update an existing workflow document.
     * 
     * @param document The WorkflowDocument to update
     * @return The updated document
     */
    WorkflowDocument updateDocument(WorkflowDocument document);
    
    /**
     * Delete a workflow document by ID.
     * 
     * @param id The document ID to delete
     * @return true if deleted successfully, false otherwise
     */
    boolean deleteDocument(Integer id);
    
    /**
     * Get total count of workflow documents.
     * 
     * @return Total count of documents
     */
    long getDocumentCount();
    
    /**
     * Validate if a file type is supported for upload.
     * 
     * @param fileName The file name to check
     * @return true if file type is supported, false otherwise
     */
    boolean isSupportedFileType(String fileName);
    
    /**
     * Get the MIME type for a file based on its extension.
     * 
     * @param fileName The file name
     * @return The MIME type string
     */
    String getMimeType(String fileName);
}