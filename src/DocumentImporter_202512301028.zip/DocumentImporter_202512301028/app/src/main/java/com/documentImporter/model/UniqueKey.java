package com.documentImporter.model;

/**
 * UniqueKey Entity representing the UNIQUE_KEYS table for ID generation.
 * 
 * Author: Mahedee Hasan
 */
public class UniqueKey {
    
    private String tableName;
    private Integer nextId;
    
    // Default constructor
    public UniqueKey() {
    }
    
    // Constructor with parameters
    public UniqueKey(String tableName, Integer nextId) {
        this.tableName = tableName;
        this.nextId = nextId;
    }
    
    // Getters and Setters
    public String getTableName() {
        return tableName;
    }
    
    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public Integer getNextId() {
        return nextId;
    }
    
    public void setNextId(Integer nextId) {
        this.nextId = nextId;
    }
    
    @Override
    public String toString() {
        return "UniqueKey{" +
                "tableName='" + tableName + '\'' +
                ", nextId=" + nextId +
                '}';
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        UniqueKey uniqueKey = (UniqueKey) o;
        return tableName != null ? tableName.equals(uniqueKey.tableName) : uniqueKey.tableName == null;
    }
    
    @Override
    public int hashCode() {
        return tableName != null ? tableName.hashCode() : 0;
    }
}