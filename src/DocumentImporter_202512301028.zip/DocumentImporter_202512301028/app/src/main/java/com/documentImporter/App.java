package com.documentImporter;
import com.documentImporter.console.HelperConsole;
import com.documentImporter.constants.AppConstants;
import com.documentImporter.enums.OperationType;
import com.documentImporter.model.CommandLineArgs;
import com.documentImporter.service.CryptoService;
import com.documentImporter.service.CryptoServiceImpl;
import com.documentImporter.service.LetterProcessorService;
import com.documentImporter.service.LetterProcessorServiceImpl;

import oracle.net.aso.c;

import java.io.InputStream;
import java.io.IOException;
import java.util.logging.LogManager;

import org.apache.logging.log4j.core.tools.picocli.CommandLine;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.nio.file.Files;
import java.nio.file.Paths;

/**
 * Main Application Entry Point for DocumentImporter
 * Pure JDBC Application using HikariCP connection pool
 * 
 * This class serves as the main entry point and delegates all application logic
 * to the ApplicationRunner class for better separation of concerns.
 * 
 * @author Mahedee Hasan
 */
public class App {

 
    private static final Logger LOGGER = LoggerFactory.getLogger(App.class);
    //private static final String SECRET_KEY = "oixD8HMZb2GxMzxOMAANwkbEJRmEHC0rhq5tdjAOQro=";

    
    /**
     * Main entry point for the Document Importer application.
     * Creates and runs an ApplicationRunner instance to handle all application logic.
     * 
     * @param args Command line arguments (not currently used)
     */
    public static void main(String[] args) {
        LOGGER.info("Starting Document Importer Application");
        try {
            CommandLineArgs commandLineArgs = parseArguments(args);
            LOGGER.info("Parsed Command Line Arguments: " + commandLineArgs.toString());


            App app = new App();            
            int exitCode = app.run(commandLineArgs);
            System.exit(exitCode);

        } catch (Exception e) {
            LOGGER.error("Application encountered a fatal error and will exit", e);
            System.exit(1);
        }

        // try {
        //     // Create logs directory
        //     // Files.createDirectories(Paths.get("logs"));
            
        //     // Configure Java Util Logging
        //     InputStream configFile = App.class.getClassLoader().getResourceAsStream("logging.properties");
        //     if (configFile != null) {
        //         LogManager.getLogManager().readConfiguration(configFile);
        //         configFile.close();
        //     }
        // } catch (IOException e) {
        //     System.err.println("Failed to configure logging: " + e.getMessage());
        // }
        

        //LetterProcessorService letterProcessorService = new LetterProcessorServiceImpl();
        //letterProcessorService.processAllLetters();


        //ApplicationRunner applicationRunner = new ApplicationRunner();
        //applicationRunner.run();
    }


    // Parse command line arguments and return CommandLineArgs object
    private static CommandLineArgs parseArguments(String[] args) {
        CommandLineArgs commandLineArgs = new CommandLineArgs();
        commandLineArgs.setOperationType(OperationType.PROCESS_FILES); // Default operation

        for(int i = 0; i < args.length; i++) {
            String arg = args[i]; // Current argument to process

            if(arg.equals("--help") || arg.equals("-h")) {
                HelperConsole.printHelp();
                System.exit(0); // Exit after printing help
            }
            else if(arg.equals("--key")){
                commandLineArgs.setOperationType(OperationType.GENERATE_KEY);
            }
            else if (arg.equals("--encrypt")) {
                LOGGER.info("Encrypt operation selected");
                commandLineArgs.setOperationType(OperationType.ENCRYPT);
                if (i + 1 < args.length) {
                    commandLineArgs.setText(args[++i]);
                }
            }
            else if (arg.equals("--decrypt")) {
                commandLineArgs.setOperationType(OperationType.DECRYPT);
                if (i + 1 < args.length) {
                    commandLineArgs.setText(args[++i]);
                }
            }
        }
        return commandLineArgs;
    }

    // private static CommandLineArgs parseCommandLineArgs(String[] args) {
    //     CommandLineArgs cmdArgs = new CommandLineArgs();
    //     CommandLine cmd = new CommandLine(cmdArgs);
    //     cmd.parseArgs(args);
    //     return cmdArgs;
    // }

    public int run(CommandLineArgs cmdArgs) {
        LOGGER.info("Running Document Importer Application");
        switch (cmdArgs.getOperationType()) {
            case GENERATE_KEY:
                try {
                    CryptoService cryptoService = new CryptoServiceImpl();
                    String generatedKey = cryptoService.generateKey();
                    System.out.println("Generated Encryption Key: " + generatedKey);
                } catch (Exception e) {
                    LOGGER.error("Failed to generate encryption key", e);
                    return 1; // Indicate error
                }
                break;

            case ENCRYPT:
                try {
                    CryptoService cryptoService = new CryptoServiceImpl();
                    String encryptedText = cryptoService.encrypt(cmdArgs.getText(), AppConstants.SECRET_KEY);
                    System.out.println("Encrypted Text: " + encryptedText);
                } catch (Exception e) {
                    LOGGER.error("Encryption failed", e);
                    return 1; // Indicate error
                }
                break;
            case DECRYPT:
                try {
                    CryptoService cryptoService = new CryptoServiceImpl();
                    String decryptedText = cryptoService.decrypt(cmdArgs.getText(), AppConstants.SECRET_KEY);
                    System.out.println("Decrypted Text: " + decryptedText);
                } catch (Exception e) {
                    LOGGER.error("Decryption failed", e);
                    return 1; // Indicate error
                }
                break;

            case PROCESS_FILES:
                LetterProcessorService letterProcessorService = new LetterProcessorServiceImpl();
                letterProcessorService.processAllLetters();
                break;
        
            default:
                throw new IllegalArgumentException("Unsupported operation type: " + cmdArgs.getOperationType());
        }
        return 0; // Return appropriate exit code
    }
}