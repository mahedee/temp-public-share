package com.documentImporter.service;

/**
 * Service interface for postal mail operations.
 *
 * Author: Mahedee Hasan
 */

public interface PostalMailService {
    String getEntityKeyByLetterId(String letterId);
}
