package com.documentImporter.dao;

/**
 * Data Access Object interface for PostalMail operations.
 * 
 * Author: Mahedee Hasan
 */
public interface PostalMailDao {

    String getEntityKeyByLetterId(String letterId);
} 