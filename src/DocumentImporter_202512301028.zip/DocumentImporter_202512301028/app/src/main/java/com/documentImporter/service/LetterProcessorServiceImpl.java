package com.documentImporter.service;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Timestamp;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.documentImporter.model.FileInfo;
import com.documentImporter.model.WorkflowDocument;
import com.documentImporter.util.ConfigurationManager;

/**
 * Implementation of LetterProcessorService for processing letters from incoming folder.
 * Author: Mahedee Hasan
 */

public class LetterProcessorServiceImpl implements LetterProcessorService {

    private static final Logger LOGGER = Logger.getLogger(LetterProcessorServiceImpl.class.getName());
    private final LetterService letterService;
    private final UniqueKeyService uniqueKeyService;
    private final PostalMailService postalMailService;
    private final WorkflowDocumentService workflowDocumentService;
    

    /**
     * Default constructor - creates LetterServiceImpl instance.
     */
    public LetterProcessorServiceImpl() {
        this.letterService = new LetterServiceImpl();
        this.uniqueKeyService = new UniqueKeyServiceImpl();
        this.postalMailService = new PostalMailServiceImpl();
        this.workflowDocumentService = new WorkflowDocumentServiceImpl();
    }


        /**
     * Constructor for dependency injection (useful for testing).
     * 
     * @param letterService The LetterService implementation to use
     */
    public LetterProcessorServiceImpl(LetterService letterService, UniqueKeyService uniqueKeyService, PostalMailService postalMailService, WorkflowDocumentService workflowDocumentService) {
        this.letterService = letterService;
        this.uniqueKeyService = uniqueKeyService;
        this.postalMailService = postalMailService;
        this.workflowDocumentService = workflowDocumentService;
    }
    
    @Override
    public boolean processAllLetters() {
      
         LOGGER.info("Starting to process all letters from incoming folder...");

         try {

             // Get all letters and corresponding letter Ids from incoming folder
             var fileInfos = letterService.getAllFileInfo();
             
             LOGGER.info("Total files found: " + fileInfos.size());
             
             for (var fileInfo : fileInfos) {
                // Get entity_key by letterId
                 String letterId = fileInfo.getLetterId();
                 String filename = fileInfo.getFileName();

                 try {
              

                 // Get next id
                 var nextId = uniqueKeyService.getNextId("WORKFLOW_DOCUMENT");
                 LOGGER.info("Next WORKFLOW_DOCUMENT ID: " + nextId);

                Timestamp documentTimestamp = new Timestamp(System.currentTimeMillis());
                LOGGER.info("Processing file: " + fileInfo.getDisplayString() + " Letter ID: " + fileInfo.getLetterId());

                 // Prepare WorkflowDocument object
                WorkflowDocument workflowDocument = new WorkflowDocument();
                workflowDocument.setId(nextId);
                workflowDocument.setDocumentTimestamp(documentTimestamp);
                workflowDocument.setDescription(null);
                workflowDocument.setFileName(filename);
                workflowDocument.setMimeType(fileInfo.getMimeType());
                workflowDocument.setFileData(fileInfo.getFileData());

                String documentUrl = String.format("cm/report/reportView.do?reportKey=%d&type=%s&fileName=%s", 
                                   nextId,
                                   fileInfo.getMimeType(),
                                   fileInfo.getFileName());
                workflowDocument.setDocumentUrl(documentUrl);
                workflowDocument.setEntityName("Case");

                String entityKey = postalMailService.getEntityKeyByLetterId(letterId);
                workflowDocument.setEntityKey(entityKey);

                Integer entityKeyNum = null;
                try {
                    entityKeyNum = Integer.parseInt(entityKey);
                } catch (NumberFormatException nfe) {
                    LOGGER.warning("Entity key is not a valid integer: " + entityKey + " for letter ID: " + letterId);
                }

                LOGGER.info("Setting entity key number: " + entityKeyNum + " for letter ID: " + letterId);

                workflowDocument.setEntityKeyNum(entityKeyNum);
                workflowDocument.setAttachedBy(null);
                workflowDocument.setDocumentName(filename);
                workflowDocument.setDocumentType("ATT00001");
            
                 // Insert WorkflowDocument into database
                workflowDocumentService.createDocument(workflowDocument);

                LOGGER.info("Inserted WorkflowDocument with ID: " + nextId + " for letter ID: " + letterId);

                // Update NextId in UniqueKey table for WORKFLOW_DOCUMENT
                uniqueKeyService.updateNextId("WORKFLOW_DOCUMENT");
                
                // Move file to done folder after processing
                Path doneFolder = Paths.get(getDoneFolder());

                LOGGER.info("Moving processed file to done folder: " + doneFolder.toAbsolutePath());
                
                //File move to done folder
                moveFileToFolder(fileInfo, getDoneFolder(), "done");        
                // Done and bad folder will be configurable in application properties
                 //moveFileToFolder(fileInfo, getDoneFolder(), "done");
                 } catch (Exception fileEx) {
                    LOGGER.log(Level.SEVERE, "Error processing file: " + filename + " with Letter ID: " + letterId, fileEx);
                    // Move file to bad folder if any error occurs during processing
                    moveFileToFolder(fileInfo, getBadFolder(), "bad");
                 }
             }
             
         } catch (Exception e) {
             LOGGER.log(Level.SEVERE, "Error processing letters: ", e);
             return false;
         }

        
        return true; // Placeholder return value
    }

    private String getDoneFolder() {
        return ConfigurationManager.getProperty("docprocessor.folders.success", 
                "");
    }

      private String getBadFolder() {
        return ConfigurationManager.getProperty("docprocessor.folders.error", 
                "");
    }


    private void moveFileToFolder(FileInfo fileInfo, String targetFolder, String folderType) throws IOException {
        try {
            String incomingFolder = ConfigurationManager.getIncomingFolder();
            Path sourcePath = Paths.get(incomingFolder, fileInfo.getFileName());
            Path targetPath = Paths.get(targetFolder, fileInfo.getFileName());
            
            // Check if source file exists
            if (!Files.exists(sourcePath)) {
                LOGGER.warning("Source file does not exist: " + sourcePath);
                return;
            }
            
            // Ensure target folder exists
            Files.createDirectories(targetPath.getParent());
            
            // Handle file name conflicts
            if (Files.exists(targetPath)) {
                targetPath = generateUniqueFileName(targetPath);
                LOGGER.info("File already exists in " + folderType + " folder, using unique name: " + 
                           targetPath.getFileName());
            }
            
            // Move the file
            Files.move(sourcePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
            
            LOGGER.info("Successfully moved file to " + folderType + " folder: " + 
                       fileInfo.getFileName() + " -> " + targetPath.getFileName());
            
        } catch (IOException e) {
            LOGGER.log(Level.SEVERE, "Failed to move file " + fileInfo.getFileName() + 
                      " to " + folderType + " folder: " + targetFolder, e);
            throw e;
        }
    }

        /**
     * Generate unique file name to avoid conflicts.
     * 
     * @param originalPath The original file path
     * @return A unique file path
     */
    private Path generateUniqueFileName(Path originalPath) {
        String fileName = originalPath.getFileName().toString();
        String baseName = fileName.substring(0, fileName.lastIndexOf('.'));
        String extension = fileName.substring(fileName.lastIndexOf('.'));
        Path parentDir = originalPath.getParent();
        
        int counter = 1;
        Path uniquePath;
        
        do {
            String uniqueName = baseName + "_" + counter + extension;
            uniquePath = parentDir.resolve(uniqueName);
            counter++;
        } while (Files.exists(uniquePath));
        
        return uniquePath;
    }
    
}
