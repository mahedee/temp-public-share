package com.documentImporter.dao;

import com.documentImporter.model.UniqueKey;


/**
 * Data Access Object interface for UniqueKey operations.
 * Author: Mahedee Hasan
 */

public interface UniqueKeyDao {
    
    /**
     * Get the next available ID for a given table and increment the counter.
     * This method is thread-safe and ensures unique ID generation.
     * 
     * @param tableName The name of the table to generate ID for
     * @return The next available unique ID
     */
    Integer getNextId(String tableName);
    
    /**
     * Get the current next ID for a table without incrementing.
     * 
     * @param tableName The name of the table
     * @return The current next ID value
     */
    Integer getCurrentNextId(String tableName);
    
    /**
     * Initialize a table entry in UNIQUE_KEYS if it doesn't exist.
     * 
     * @param tableName The table name to initialize
     * @param startingId The starting ID value (default 1)
     * @return true if initialized successfully
     */
    boolean initializeTable(String tableName, Integer startingId);
    
    /**
     * Update the next ID for a specific table.
     * 
     * @param tableName The table name
     * @param nextId The new next ID value
     * @return true if updated successfully
     */
    boolean updateNextId(String tableName, Integer nextId);

    boolean updateNextId(String tableName);
    
    /**
     * Check if a table exists in UNIQUE_KEYS.
     * 
     * @param tableName The table name to check
     * @return true if table entry exists
     */
    boolean tableExists(String tableName);
}