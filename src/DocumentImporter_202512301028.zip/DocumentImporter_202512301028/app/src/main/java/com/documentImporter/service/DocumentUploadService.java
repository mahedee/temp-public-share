package com.documentImporter.service;

import com.documentImporter.model.WorkflowDocument;
import com.documentImporter.util.ConfigurationManager;
import com.documentImporter.util.FileUtils;
import com.documentImporter.util.MimeTypeUtils;

import java.io.IOException;
import java.nio.file.*;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Set;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Service for orchestrating document upload process from incoming folder to database.
 * Handles business logic for file processing workflows and database operations coordination.
 * 
 * Author: Mahedee Hasan
 */
public class DocumentUploadService {
    
    private static final Logger LOGGER = Logger.getLogger(DocumentUploadService.class.getName());
    
    private final WorkflowDocumentService workflowDocumentService;
    private final Set<String> supportedExtensions;
    private final long maxFileSizeBytes;
    private final int maxConcurrentFiles;
    private final ExecutorService executorService;
    
    public DocumentUploadService() {
        this.workflowDocumentService = new WorkflowDocumentServiceImpl();
        this.supportedExtensions = parseSupportedExtensions();
        this.maxFileSizeBytes = ConfigurationManager.getMaxFileSizeMB() * 1024L * 1024L;
        this.maxConcurrentFiles = ConfigurationManager.getMaxConcurrentFiles();
        this.executorService = Executors.newFixedThreadPool(maxConcurrentFiles);
    }
    
    // Constructor for dependency injection (for testing)
    public DocumentUploadService(WorkflowDocumentService workflowDocumentService) {
        this.workflowDocumentService = workflowDocumentService;
        this.supportedExtensions = parseSupportedExtensions();
        this.maxFileSizeBytes = ConfigurationManager.getMaxFileSizeMB() * 1024L * 1024L;
        this.maxConcurrentFiles = ConfigurationManager.getMaxConcurrentFiles();
        this.executorService = Executors.newFixedThreadPool(maxConcurrentFiles);
    }
    
    /**
     * Process all files in the incoming directory and upload them to database.
     * 
     * @return ProcessingResult containing statistics
     */
    public ProcessingResult processIncomingFiles() {
        LOGGER.info("Starting document upload process...");
        
        ProcessingResult result = new ProcessingResult();
        
        try {
            // Get incoming folder path
            String incomingFolderPath = ConfigurationManager.getIncomingFolder();
            Path incomingPath = Paths.get(incomingFolderPath);
            
            // Create directories if they don't exist
            createDirectoriesIfNeeded();
            
            if (!Files.exists(incomingPath)) {
                LOGGER.warning("Incoming folder does not exist: " + incomingPath.toAbsolutePath());
                result.addError("Incoming folder not found: " + incomingPath.toAbsolutePath());
                return result;
            }
            
            // Get list of files to process
            List<Path> filesToProcess = getFilesToProcess(incomingPath);
            result.setTotalFiles(filesToProcess.size());
            
            if (filesToProcess.isEmpty()) {
                LOGGER.info("No files found in incoming directory: " + incomingPath.toAbsolutePath());
                return result;
            }
            
            LOGGER.info("Found " + filesToProcess.size() + " files to process");
            
            // Process files in parallel
            List<CompletableFuture<FileProcessResult>> futures = filesToProcess.stream()
                .map(file -> CompletableFuture.supplyAsync(() -> processFile(file), executorService))
                .collect(Collectors.toList());
            
            // Wait for all processing to complete
            CompletableFuture<Void> allFutures = CompletableFuture.allOf(
                futures.toArray(new CompletableFuture[0]));
            
            allFutures.get(); // Wait for completion
            
            // Collect results
            for (CompletableFuture<FileProcessResult> future : futures) {
                FileProcessResult fileResult = future.get();
                
                if (fileResult.isSuccess()) {
                    result.incrementProcessed();
                    LOGGER.info("Successfully processed: " + fileResult.getFileName());
                } else {
                    result.incrementFailed();
                    result.addError("Failed to process " + fileResult.getFileName() + ": " + fileResult.getError());
                    LOGGER.severe("Failed to process: " + fileResult.getFileName() + " - " + fileResult.getError());
                }
            }
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error during document upload process", e);
            result.addError("Unexpected error: " + e.getMessage());
        }
        
        LOGGER.info("Document upload process completed. Processed: " + result.getProcessedCount() + 
                   ", Failed: " + result.getFailedCount());
        
        return result;
    }
    
    /**
     * Process a single file: read content, create WorkflowDocument, and upload to database.
     * 
     * @param filePath The path to the file
     * @return FileProcessResult containing processing outcome
     */
    private FileProcessResult processFile(Path filePath) {
        String fileName = filePath.getFileName().toString();
        
        try {
            LOGGER.info("Processing file: " + fileName);
            
            // Validate file
            FileProcessResult validation = validateFile(filePath);
            if (!validation.isSuccess()) {
                moveToErrorFolder(filePath, validation.getError());
                return validation;
            }
            
            // Read file content
            byte[] fileData = Files.readAllBytes(filePath);
            
            // Create WorkflowDocument
            WorkflowDocument document = createWorkflowDocument(fileName, fileData, filePath);
            
            // Upload to database
            WorkflowDocument savedDocument = workflowDocumentService.createDocument(document);
            
            // Move file to archive folder
            moveToArchiveFolder(filePath);
            
            return new FileProcessResult(fileName, true, null);
            
        } catch (Exception e) {
            String error = "Error processing file: " + e.getMessage();
            LOGGER.log(Level.SEVERE, error, e);
            
            try {
                moveToErrorFolder(filePath, error);
            } catch (IOException moveError) {
                LOGGER.log(Level.SEVERE, "Failed to move file to error folder: " + moveError.getMessage(), moveError);
            }
            
            return new FileProcessResult(fileName, false, error);
        }
    }
    
    /**
     * Create a WorkflowDocument object from file information.
     * 
     * @param fileName The file name
     * @param fileData The file content
     * @param filePath The file path
     * @return WorkflowDocument object
     */
    private WorkflowDocument createWorkflowDocument(String fileName, byte[] fileData, Path filePath) {
        WorkflowDocument document = new WorkflowDocument();
        
        document.setFileName(fileName);
        document.setDocumentName(fileName);
        document.setFileData(fileData);
        document.setMimeType(MimeTypeUtils.getMimeType(fileName));
        document.setDocumentTimestamp(new Timestamp(System.currentTimeMillis()));
        document.setDescription("Uploaded from incoming folder: " + filePath.toAbsolutePath() + 
                               " (Size: " + FileUtils.formatFileSize(fileData.length) + ")");
        document.setDocumentUrl("file://" + filePath.toAbsolutePath().toString());
        document.setEntityName("DOCUMENT_IMPORT");
        document.setEntityKey("AUTO_UPLOAD");
        document.setDocumentType("UPLOAD");
        document.setFileDataIndexed("N");
        
        return document;
    }
    
    /**
     * Validate a file before processing.
     * 
     * @param filePath The file path
     * @return FileProcessResult with validation outcome
     */
    private FileProcessResult validateFile(Path filePath) {
        String fileName = filePath.getFileName().toString();
        
        // Check if file exists and is valid
        if (!FileUtils.isValidFile(filePath)) {
            return new FileProcessResult(fileName, false, "File does not exist or is not a regular file");
        }
        
        // Check file size
        try {
            if (!FileUtils.isValidFileSize(filePath, maxFileSizeBytes)) {
                long fileSize = FileUtils.getFileSize(filePath);
                if (fileSize == 0) {
                    return new FileProcessResult(fileName, false, "File is empty");
                } else {
                    return new FileProcessResult(fileName, false, 
                        "File size (" + FileUtils.formatFileSize(fileSize) + 
                        ") exceeds maximum allowed size (" + 
                        FileUtils.formatFileSize(maxFileSizeBytes) + ")");
                }
            }
        } catch (IOException e) {
            return new FileProcessResult(fileName, false, "Cannot read file size: " + e.getMessage());
        }
        
        // Check file extension
        if (!FileUtils.isSupportedExtension(fileName, supportedExtensions)) {
            String extension = FileUtils.getFileExtension(fileName);
            return new FileProcessResult(fileName, false, 
                "Unsupported file extension: " + extension + ". Supported: " + supportedExtensions);
        }
        
        return new FileProcessResult(fileName, true, null);
    }
    
    /**
     * Get list of files to process from incoming directory.
     * 
     * @param incomingPath The incoming directory path
     * @return List of file paths
     * @throws IOException If directory cannot be read
     */
    private List<Path> getFilesToProcess(Path incomingPath) throws IOException {
        List<Path> files = new ArrayList<>();
        
        try (DirectoryStream<Path> directoryStream = Files.newDirectoryStream(incomingPath)) {
            for (Path path : directoryStream) {
                if (Files.isRegularFile(path)) {
                    files.add(path);
                }
            }
        }
        
        return files;
    }
    
    /**
     * Move file to archive folder after successful processing.
     * 
     * @param filePath The source file path
     * @throws IOException If move operation fails
     */
    private void moveToArchiveFolder(Path filePath) throws IOException {
        String archiveFolderPath = ConfigurationManager.getArchiveFolder();
        Path archivePath = Paths.get(archiveFolderPath);
        
        Files.createDirectories(archivePath);
        
        Path targetPath = archivePath.resolve(filePath.getFileName());
        targetPath = FileUtils.generateUniqueFileName(targetPath);
        
        Files.move(filePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
        LOGGER.info("Moved file to archive: " + targetPath.toAbsolutePath());
    }
    
    /**
     * Move file to error folder if processing fails.
     * 
     * @param filePath The source file path
     * @param error The error message
     * @throws IOException If move operation fails
     */
    private void moveToErrorFolder(Path filePath, String error) throws IOException {
        String errorFolderPath = ConfigurationManager.getErrorFolder();
        Path errorPath = Paths.get(errorFolderPath);
        
        Files.createDirectories(errorPath);
        
        Path targetPath = errorPath.resolve(filePath.getFileName());
        targetPath = FileUtils.generateUniqueFileName(targetPath);
        
        Files.move(filePath, targetPath, StandardCopyOption.REPLACE_EXISTING);
        
        // Create error log file
        String errorFileName = filePath.getFileName().toString() + ".error";
        Path errorLogPath = errorPath.resolve(errorFileName);
        Files.write(errorLogPath, (new Timestamp(System.currentTimeMillis()) + ": " + error).getBytes());
        
        LOGGER.warning("Moved file to error folder: " + targetPath.toAbsolutePath() + " (Reason: " + error + ")");
    }
    
    /**
     * Create necessary directories if they don't exist.
     */
    private void createDirectoriesIfNeeded() {
        try {
            FileUtils.createDirectoryIfNotExists(ConfigurationManager.getIncomingFolder());
            FileUtils.createDirectoryIfNotExists(ConfigurationManager.getArchiveFolder());
            FileUtils.createDirectoryIfNotExists(ConfigurationManager.getErrorFolder());
            
            String backupFolder = ConfigurationManager.getBackupFolder();
            if (backupFolder != null && !backupFolder.trim().isEmpty()) {
                FileUtils.createDirectoryIfNotExists(backupFolder);
            }
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Failed to create some directories", e);
        }
    }
    
    /**
     * Parse supported file extensions from configuration.
     * 
     * @return Set of supported extensions (lowercase)
     */
    private Set<String> parseSupportedExtensions() {
        String extensionsStr = ConfigurationManager.getSupportedExtensions();
        return Arrays.stream(extensionsStr.split(","))
                .map(String::trim)
                .map(String::toLowerCase)
                .filter(ext -> !ext.isEmpty())
                .collect(Collectors.toSet());
    }
    
    /**
     * Shutdown the executor service.
     */
    public void shutdown() {
        executorService.shutdown();
        try {
            if (!executorService.awaitTermination(30, TimeUnit.SECONDS)) {
                executorService.shutdownNow();
            }
        } catch (InterruptedException e) {
            executorService.shutdownNow();
            Thread.currentThread().interrupt();
        }
    }
    
    /**
     * Result class for individual file processing.
     */
    public static class FileProcessResult {
        private final String fileName;
        private final boolean success;
        private final String error;
        
        public FileProcessResult(String fileName, boolean success, String error) {
            this.fileName = fileName;
            this.success = success;
            this.error = error;
        }
        
        public String getFileName() { return fileName; }
        public boolean isSuccess() { return success; }
        public String getError() { return error; }
    }
    
    /**
     * Result class for overall processing statistics.
     */
    public static class ProcessingResult {
        private int totalFiles;
        private int processedCount;
        private int failedCount;
        private final List<String> errors;
        
        public ProcessingResult() {
            this.errors = new ArrayList<>();
        }
        
        public void setTotalFiles(int totalFiles) { this.totalFiles = totalFiles; }
        public void incrementProcessed() { this.processedCount++; }
        public void incrementFailed() { this.failedCount++; }
        public void addError(String error) { this.errors.add(error); }
        
        public int getTotalFiles() { return totalFiles; }
        public int getProcessedCount() { return processedCount; }
        public int getFailedCount() { return failedCount; }
        public List<String> getErrors() { return errors; }
        
        public boolean hasErrors() { return !errors.isEmpty(); }
        
        @Override
        public String toString() {
            StringBuilder sb = new StringBuilder();
            sb.append("Processing Summary:\n");
            sb.append("  Total Files: ").append(totalFiles).append("\n");
            sb.append("  Successfully Processed: ").append(processedCount).append("\n");
            sb.append("  Failed: ").append(failedCount).append("\n");
            
            if (hasErrors()) {
                sb.append("  Errors:\n");
                for (String error : errors) {
                    sb.append("    - ").append(error).append("\n");
                }
            }
            
            return sb.toString();
        }
    }
}