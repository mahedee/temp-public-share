package com.documentImporter.dao;

import com.documentImporter.util.DatabaseConnection;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;
/**
 * Implementation of UniqueKeyDao interface for UniqueKey operations
 * Author: Mahedee Hasan
 */

public class UniqueKeyDaoImpl implements UniqueKeyDao {
    
    private static final Logger LOGGER = Logger.getLogger(UniqueKeyDaoImpl.class.getName());
    
    // SQL Queries
    private static final String GET_NEXT_ID_SQL = 
        "SELECT NEXT_ID FROM UNIQUE_KEYS WHERE TABLE_NAME = ?";
    
    private static final String UPDATE_NEXT_ID_SQL = 
        "UPDATE UNIQUE_KEYS SET NEXT_ID = NEXT_ID + 1 WHERE TABLE_NAME = ?";
    
    private static final String INSERT_TABLE_SQL = 
        "INSERT INTO UNIQUE_KEYS (TABLE_NAME, NEXT_ID) VALUES (?, ?)";
    
    private static final String CHECK_TABLE_EXISTS_SQL = 
        "SELECT COUNT(*) FROM UNIQUE_KEYS WHERE TABLE_NAME = ?";
    
    private static final String UPDATE_SPECIFIC_NEXT_ID_SQL = 
        "UPDATE UNIQUE_KEYS SET NEXT_ID = ? WHERE TABLE_NAME = ?";
    
    private static final String CALCULATE_NEXT_ID_SQL = 
        "SELECT COALESCE(MAX(ID), 0) + 1 AS NEXT_ID FROM ";


    
    @Override
    public boolean updateNextId(String tableName) {
        validateTableName(tableName);
        String updateSql = "UPDATE UNIQUE_KEYS SET NEXT_ID = (SELECT MAX(ID) + 1 FROM " + tableName + ") WHERE TABLE_NAME = ?";
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(updateSql)) {
            
            statement.setString(1, tableName.toUpperCase());
            
            int affectedRows = statement.executeUpdate();
            boolean success = affectedRows == 1;
            
            if (success) {
                LOGGER.fine("Incremented next ID for table " + tableName);
            } else {
                LOGGER.warning("Failed to increment next ID for table " + tableName);
            }
            
            return success;
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error incrementing next ID for table " + tableName, e);
            return false;
        }
    }

    /**
     * Get the next ID for the specified table without updating the counter.
     * This method only reads the current next ID value.
     * 
     * @param tableName The name of the table
     * @return The next available ID
     * @throws IllegalArgumentException if tableName is null or empty
     * @throws RuntimeException if database error occurs
     */
    @Override
    public Integer getNextId(String tableName) {
        validateTableName(tableName);
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(GET_NEXT_ID_SQL)) {
            
            // Initialize table if it doesn't exist
            if (!tableExists(tableName)) {
                initializeTable(tableName, null);
            }
            
            statement.setString(1, tableName.toUpperCase());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    Integer nextId = resultSet.getInt("NEXT_ID");
                    LOGGER.fine("Retrieved next ID for table " + tableName + ": " + nextId);
                    return nextId;
                } else {
                    throw new RuntimeException("No entry found for table: " + tableName);
                }
            }
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error getting next ID for table: " + tableName, e);
            throw new RuntimeException("Error getting next ID: " + e.getMessage(), e);
        }
    }

    /**
     * Get the current next ID without any modification.
     * Alias for getNextId for backward compatibility.
     * 
     * @param tableName The name of the table
     * @return The current next ID value
     */
    @Override
    public Integer getCurrentNextId(String tableName) {
        return getNextId(tableName);
    }

    /**
     * Initialize a table entry in UNIQUE_KEYS with a starting ID.
     * If startingId is null, calculates the next ID based on existing data.
     * 
     * @param tableName The name of the table to initialize
     * @param startingId The starting ID (null to auto-calculate)
     * @return true if initialization was successful, false otherwise
     */
    @Override
    public boolean initializeTable(String tableName, Integer startingId) {
        validateTableName(tableName);
        
        // Don't initialize if already exists
        if (tableExists(tableName)) {
            LOGGER.fine("Table " + tableName + " already exists in UNIQUE_KEYS");
            return true;
        }
        
        // Calculate starting ID if not provided
        if (startingId == null || startingId < 1) {
            startingId = calculateNextIdFromTable(tableName);
        }
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(INSERT_TABLE_SQL)) {
            
            statement.setString(1, tableName.toUpperCase());
            statement.setInt(2, startingId);
            
            int affectedRows = statement.executeUpdate();
            boolean success = affectedRows == 1;
            
            if (success) {
                LOGGER.info("Initialized table " + tableName + " in UNIQUE_KEYS with starting ID " + startingId);
            } else {
                LOGGER.warning("Failed to initialize table " + tableName + " in UNIQUE_KEYS");
            }
            
            return success;
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error initializing table " + tableName + " in UNIQUE_KEYS", e);
            return false;
        }
    }

    /**
     * Update the next ID for a specific table.
     * 
     * @param tableName The name of the table
     * @param nextId The new next ID value
     * @return true if update was successful, false otherwise
     */
    @Override
    public boolean updateNextId(String tableName, Integer nextId) {
        validateTableName(tableName);
        
        if (nextId == null || nextId < 1) {
            throw new IllegalArgumentException("Next ID must be greater than 0");
        }
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_SPECIFIC_NEXT_ID_SQL)) {
            
            statement.setInt(1, nextId);
            statement.setString(2, tableName.toUpperCase());
            
            int affectedRows = statement.executeUpdate();
            boolean success = affectedRows == 1;
            
            if (success) {
                LOGGER.info("Updated next ID for table " + tableName + " to " + nextId);
            } else {
                LOGGER.warning("Failed to update next ID for table " + tableName);
            }
            
            return success;
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating next ID for table " + tableName, e);
            return false;
        }
    }

    /**
     * Check if a table entry exists in UNIQUE_KEYS.
     * 
     * @param tableName The name of the table to check
     * @return true if the table exists, false otherwise
     */
    @Override
    public boolean tableExists(String tableName) {
        if (tableName == null || tableName.trim().isEmpty()) {
            return false;
        }
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(CHECK_TABLE_EXISTS_SQL)) {
            
            statement.setString(1, tableName.toUpperCase());
            
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    return resultSet.getInt(1) > 0;
                }
                return false;
            }
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error checking if table exists: " + tableName, e);
            return false;
        }
    }
    
    /**
     * Increment the next ID counter for a specific table.
     * This is a separate method for when you actually want to consume/increment the ID.
     * 
     * @param tableName The name of the table
     * @return true if increment was successful, false otherwise
     */
    public boolean incrementNextId(String tableName) {
        validateTableName(tableName);
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(UPDATE_NEXT_ID_SQL)) {
            
            statement.setString(1, tableName.toUpperCase());
            
            int affectedRows = statement.executeUpdate();
            boolean success = affectedRows == 1;
            
            if (success) {
                LOGGER.fine("Incremented next ID for table " + tableName);
            } else {
                LOGGER.warning("Failed to increment next ID for table " + tableName);
            }
            
            return success;
            
        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error incrementing next ID for table " + tableName, e);
            return false;
        }
    }
    
    /**
     * Get the next available ID and increment the counter in one atomic operation.
     * Use this when you want to consume an ID.
     * 
     * @param tableName The name of the table
     * @return The next available ID (before increment)
     */
    public synchronized Integer getAndIncrementNextId(String tableName) {
        validateTableName(tableName);
        
        Connection connection = null;
        
        try {
            connection = DatabaseConnection.getConnection();
            connection.setAutoCommit(false); // Start transaction
            
            // Initialize table if it doesn't exist
            if (!tableExists(tableName)) {
                initializeTable(tableName, null);
            }
            
            // Get current next ID
            Integer currentId;
            try (PreparedStatement selectStatement = connection.prepareStatement(GET_NEXT_ID_SQL)) {
                selectStatement.setString(1, tableName.toUpperCase());
                
                try (ResultSet resultSet = selectStatement.executeQuery()) {
                    if (resultSet.next()) {
                        currentId = resultSet.getInt("NEXT_ID");
                    } else {
                        throw new RuntimeException("No entry found for table: " + tableName);
                    }
                }
            }
            
            // Increment the counter
            try (PreparedStatement updateStatement = connection.prepareStatement(UPDATE_NEXT_ID_SQL)) {
                updateStatement.setString(1, tableName.toUpperCase());
                updateStatement.executeUpdate();
            }
            
            connection.commit();
            LOGGER.fine("Retrieved and incremented ID for table " + tableName + ": " + currentId);
            return currentId;
            
        } catch (SQLException e) {
            if (connection != null) {
                try {
                    connection.rollback();
                } catch (SQLException rollbackEx) {
                    LOGGER.log(Level.SEVERE, "Error during rollback", rollbackEx);
                }
            }
            LOGGER.log(Level.SEVERE, "Error getting and incrementing next ID for table: " + tableName, e);
            throw new RuntimeException("Error getting and incrementing next ID: " + e.getMessage(), e);
        } finally {
            if (connection != null) {
                try {
                    connection.setAutoCommit(true); // Reset auto-commit
                    connection.close();
                } catch (SQLException e) {
                    LOGGER.log(Level.WARNING, "Error closing connection", e);
                }
            }
        }
    }
    
    /**
     * Calculate the next ID based on existing data in the target table.
     * 
     * @param tableName The target table name
     * @return The next available ID
     */
    private Integer calculateNextIdFromTable(String tableName) {
        String sql = CALCULATE_NEXT_ID_SQL + tableName.toUpperCase();
        
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(sql);
             ResultSet resultSet = statement.executeQuery()) {
            
            if (resultSet.next()) {
                int nextId = resultSet.getInt("NEXT_ID");
                LOGGER.info("Calculated next ID for table " + tableName + ": " + nextId);
                return nextId;
            }
            
            return 1; // Default if no data found
            
        } catch (SQLException e) {
            LOGGER.log(Level.WARNING, "Could not calculate next ID for table " + tableName + ", using default 1", e);
            return 1;
        }
    }
    
    /**
     * Validate table name parameter.
     * 
     * @param tableName The table name to validate
     * @throws IllegalArgumentException if table name is invalid
     */
    private void validateTableName(String tableName) {
        if (tableName == null || tableName.trim().isEmpty()) {
            throw new IllegalArgumentException("Table name cannot be null or empty");
        }
    }
}