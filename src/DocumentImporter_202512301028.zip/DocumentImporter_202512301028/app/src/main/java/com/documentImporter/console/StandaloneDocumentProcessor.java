package com.documentImporter.console;

import com.documentImporter.service.DocumentUploadService;
import com.documentImporter.util.DatabaseConnection;
import com.documentImporter.util.ConfigurationManager;

/**
 * Standalone Document Processor - bypasses the interactive menu
 * Directly processes files from incoming folder to database and archive
 */
public class StandaloneDocumentProcessor {
    
    public static void main(String[] args) {
        try {
            // Display application startup info
            System.out.println("=================================================");
            System.out.println("    Standalone Document Processor Starting");
            System.out.println("    Processing files automatically...");
            System.out.println("=================================================");
            
            // Test database connection - skip detailed initialization
            if (DatabaseConnection.testConnection()) {
                System.out.println("✅ Database connection established");
            } else {
                System.err.println("❌ Database connection test failed");
                System.exit(1);
            }
            
            // Process documents directly
            System.out.println("\n=================================================");
            System.out.println("           DOCUMENT UPLOAD PROCESS");
            System.out.println("=================================================");
            
            // Show configuration
            System.out.println("Configuration:");
            System.out.println("  Incoming Folder: " + ConfigurationManager.getIncomingFolder());
            System.out.println("  Archive Folder: " + ConfigurationManager.getArchiveFolder());
            System.out.println("  Error Folder: " + ConfigurationManager.getErrorFolder());
            System.out.println("  Max File Size: " + ConfigurationManager.getMaxFileSizeMB() + " MB");
            System.out.println("  Supported Extensions: " + ConfigurationManager.getSupportedExtensions());
            
            System.out.println("\nStarting document upload process...");
            
            // Process documents
            DocumentUploadService uploadService = new DocumentUploadService();
            DocumentUploadService.ProcessingResult result = uploadService.processIncomingFiles();
            
            // Display results
            System.out.println("\n--- PROCESSING RESULTS ---");
            System.out.println(result.toString());
            
            if (result.getProcessedCount() > 0) {
                System.out.println("✅ Successfully uploaded " + result.getProcessedCount() + " documents to database");
                System.out.println("   Files have been moved to archive folder with timestamp if needed");
            }
            
            if (result.getFailedCount() > 0) {
                System.out.println("❌ Failed to process " + result.getFailedCount() + " files");
                System.out.println("   Check the error folder for details: " + ConfigurationManager.getErrorFolder());
            }
            
            if (result.getTotalFiles() == 0) {
                System.out.println("ℹ️  No files found in incoming folder: " + ConfigurationManager.getIncomingFolder());
            }
            
            // Shutdown upload service
            uploadService.shutdown();
            
            System.out.println("\n=================================================");
            System.out.println("    Standalone Document Processor Completed");
            System.out.println("=================================================");
            
        } catch (Exception e) {
            System.err.println("❌ Application error: " + e.getMessage());
            e.printStackTrace();
            System.exit(1);
        } finally {
            // Ensure connection pool is properly shutdown
            DatabaseConnection.closeDataSource();
        }
    }
}