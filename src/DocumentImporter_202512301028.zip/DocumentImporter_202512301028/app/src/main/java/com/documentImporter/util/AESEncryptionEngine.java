package com.documentImporter.util;

import java.util.Base64;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

/**
 * AES Encryption Engine for encrypting and decrypting data.
 * Author: Mahedee Hasan
 */

public class AESEncryptionEngine {

    private static final Logger LOGGER = LoggerFactory.getLogger(AESEncryptionEngine.class);
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";


    public static String encrypt(String plainText, String secretKey) throws Exception {
        try {
            LOGGER.debug("Starting encryption process");

            SecretKeySpec keySpec = new SecretKeySpec(
                    Base64.getDecoder().decode(secretKey), ALGORITHM);

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);

            byte[] encrypted = cipher.doFinal(plainText.getBytes());
            String encryptedText = Base64.getEncoder().encodeToString(encrypted);

            LOGGER.debug("Encryption completed successfully");
            return encryptedText;

        } catch (Exception e) {
            LOGGER.error("Encryption failed", e);
            throw new Exception("Failed to encrypt data", e);
        }
    }

    public static String decrypt(String encryptedText, String secretKey) throws Exception {
        try {
            LOGGER.debug("Starting decryption process");

            SecretKeySpec keySpec = new SecretKeySpec(
                    Base64.getDecoder().decode(secretKey), ALGORITHM);

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, keySpec);

            byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
            String decryptedText = new String(decrypted);

            LOGGER.debug("Decryption completed successfully");
            return decryptedText;

        } catch (Exception e) {
            LOGGER.error("Decryption failed", e);
            throw new Exception("Failed to decrypt data", e);
        }
    }

    public static String generateSecretKey() throws Exception {
        try {
            LOGGER.debug("Generating new secret key");

            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
            keyGenerator.init(256);
            SecretKey secretKey = keyGenerator.generateKey();

            String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());

            LOGGER.debug("Secret key generated successfully");
            return encodedKey;

        } catch (Exception e) {
            LOGGER.error("Key generation failed", e);
            throw new Exception("Failed to generate secret key", e);
        }
    }

}
