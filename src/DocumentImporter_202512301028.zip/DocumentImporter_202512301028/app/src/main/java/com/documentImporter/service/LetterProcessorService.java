package com.documentImporter.service;

/**
 * Service interface for processing letters in the Document Importer application.
 *
 * Author: Mahedee Hasan
 */

public interface LetterProcessorService {

    boolean processAllLetters();
} 
