package com.documentImporter.service;

public interface CryptoService {
    String generateKey();
    String encrypt(String plainText, String base64Key) throws Exception;
    String decrypt(String encryptedText, String base64Key) throws Exception;   
}
