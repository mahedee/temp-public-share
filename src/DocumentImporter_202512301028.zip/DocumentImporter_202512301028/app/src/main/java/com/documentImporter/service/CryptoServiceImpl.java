package com.documentImporter.service;
import com.documentImporter.util.AESEncryptionEngine;
import com.documentImporter.util.ConfigurationManager;
import com.documentImporter.util.FileUtils;

public class CryptoServiceImpl implements CryptoService {

    String keyFileName = "cryptoKey.key";
    String encryptedTextFile = "encryptedText.enc";
    String decryptedTextFile = "decryptedText.txt";
    

    public CryptoServiceImpl() {
    }

    @Override
    public String generateKey() {
        
        String key = "";
        String encryptedDirPath = "";
        try {
            key = AESEncryptionEngine.generateSecretKey();
            encryptedDirPath = ConfigurationManager.getEncryptedDirectory();
            FileUtils.saveToFile(encryptedDirPath + "/" + keyFileName, key);
        } catch (Exception e) {
            // Handle exception
        }
        return "Key generated in : " + encryptedDirPath + "/" + keyFileName;
    }

    @Override
    public String encrypt(String plainText, String base64Key) throws Exception {

        String encryptedDirPath = "";
        try {
            String encrypteText = AESEncryptionEngine.encrypt(plainText, base64Key);
            encryptedDirPath = ConfigurationManager.getEncryptedDirectory();
            FileUtils.saveToFile(encryptedDirPath + "/" + encryptedTextFile, encrypteText);
        } catch (Exception e) {
            throw new Exception("Encryption failed", e);
        }
        return "Encrypted text saved in : " + encryptedDirPath + "/" + encryptedTextFile;
    }

    @Override
    public String decrypt(String encryptedText, String base64Key) throws Exception {
        String decryptedDirPath = "";
        try {
            String decryptedText = AESEncryptionEngine.decrypt(encryptedText, base64Key);
            decryptedDirPath = ConfigurationManager.getEncryptedDirectory();
            FileUtils.saveToFile(decryptedDirPath + "/" + decryptedTextFile, decryptedText);
        } catch (Exception e) {
            throw new Exception("Decryption failed", e);
        }
        return "Decrypted text saved in : " + decryptedDirPath + "/" + decryptedTextFile;
    }
    
}
