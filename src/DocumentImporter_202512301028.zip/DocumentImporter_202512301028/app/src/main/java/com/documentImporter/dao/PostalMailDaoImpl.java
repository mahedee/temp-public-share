package com.documentImporter.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.logging.Logger;

import com.documentImporter.util.DatabaseConnection;

/**
 * Implementation of PostalMailDao interface for PostalMail operations.
 *
 * Author: Mahedee Hasan
 */


public class PostalMailDaoImpl implements PostalMailDao {

    private static final Logger LOGGER = Logger.getLogger(PostalMailDaoImpl.class.getName());
    
    @Override
    public String getEntityKeyByLetterId(String letterId) {

        String query = "SELECT CASE_KEY FROM POSTAL_MAIL_LETTERS WHERE ID = ?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement statement = connection.prepareStatement(query)) {
             
            statement.setString(1, letterId);
            try (var resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    String caseKey = resultSet.getString("CASE_KEY");
                    LOGGER.info("Retrieved CASE_KEY: " + caseKey + " for Letter ID: " + letterId);
                    return caseKey;
                } else {
                    LOGGER.warning("No CASE_KEY found for Letter ID: " + letterId);
                }
            }
        } catch (Exception e) {
            LOGGER.severe("Error retrieving CASE_KEY for Letter ID: " + letterId + " - " + e.getMessage());
        }
        return null;
    }
    
}
