package com.documentImporter.enums;

/**
 * Enumeration for different types of operations in the Document Importer application.
 * Author: Mahedee Hasan
 */
public enum OperationType {
    PROCESS_FILES,
    GENERATE_KEY,
    ENCRYPT,
    DECRYPT
}
