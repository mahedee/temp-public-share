package com.documentImporter.console;

import com.documentImporter.service.LetterService;
import com.documentImporter.service.LetterServiceImpl;
import com.documentImporter.model.FileInfo;
import com.documentImporter.util.ConfigurationManager;

import java.util.List;
import java.util.Scanner;
import java.util.logging.Logger;

/**
 * Console interface for Letter ID management and display.
 * Provides interactive menu for viewing and managing PDF files with letter IDs.
 */
public class LetterIdConsole {
    
    private static final Logger LOGGER = Logger.getLogger(LetterIdConsole.class.getName());
    private final Scanner scanner;
    private final LetterService letterIdService;
    
    public LetterIdConsole() {
        this.scanner = new Scanner(System.in);
        this.letterIdService = new LetterServiceImpl();
    }
    
    /**
     * Start the Letter ID console interface.
     */
    public void start() {
        System.out.println("\n=================================================");
        System.out.println("           LETTER ID MANAGEMENT CONSOLE");
        System.out.println("=================================================");
        
        while (true) {
            showMenu();
            System.out.print("Enter your choice (1-6): ");
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1":
                    displayAllLetterIds();
                    break;
                case "2":
                    searchByLetterId();
                    break;
                case "3":
                    showLetterIdStatistics();
                    break;
                case "4":
                    validateFileNames();
                    break;
                case "5":
                    getLetterIdByFileName();
                    break;
                case "6":
                    System.out.println("Returning to main menu...");
                    return;
                default:
                    System.out.println("[ERROR: Invalid choice. Please select 1-6.]");
            }
            
            waitForEnter();
        }
    }
    
    /**
     * Display the Letter ID management menu.
     */
    private void showMenu() {
        System.out.println("\n=================================================");
        System.out.println("           LETTER ID MENU OPTIONS");
        System.out.println("=================================================");
        System.out.println("1. Display All Letter IDs and File Names");
        System.out.println("2. Search by Letter ID");
        System.out.println("3. Show Letter ID Statistics");
        System.out.println("4. Validate File Name Patterns");
        System.out.println("5. Get Letter ID by File Name");
        System.out.println("6. Return to Main Menu");
        System.out.println("=================================================");
    }
    
    /**
     * Display all letter IDs with corresponding file names.
     */
    private void displayAllLetterIds() {
        System.out.println("\n=================================================");
        System.out.println("         ALL LETTER IDs AND FILE NAMES");
        System.out.println("=================================================");
        
        try {
            System.out.println("Scanning incoming folder: " + ConfigurationManager.getIncomingFolder());
            System.out.println("Processing PDF files...\n");
            
            List<FileInfo> pdfFiles = letterIdService.getAllFileInfo();
            
            if (pdfFiles.isEmpty()) {
                System.out.println("ℹ️  No PDF files with valid letter ID pattern found in incoming folder.");
                return;
            }
            
            // Display table header
            System.out.println("+-------------+--------------------------------------------------------------+");
            System.out.println("|  Letter ID  |                        File Name                            |");
            System.out.println("+-------------+--------------------------------------------------------------+");
            
            // Sort by letter ID for better readability
            pdfFiles.sort((a, b) -> {
                try {
                    int idA = Integer.parseInt(a.getLetterId());
                    int idB = Integer.parseInt(b.getLetterId());
                    return Integer.compare(idA, idB);
                } catch (NumberFormatException e) {
                    return a.getLetterId().compareTo(b.getLetterId());
                }
            });
            
            // Display each file
            for (FileInfo fileInfo : pdfFiles) {
                String letterId = fileInfo.getLetterId();
                String fileName = fileInfo.getFileName();
                
                // Truncate filename if too long
                if (fileName.length() > 60) {
                    fileName = fileName.substring(0, 57) + "...";
                }
                
                System.out.printf("| %11s | %-60s |%n", letterId, fileName);
            }
            
            System.out.println("+-------------+--------------------------------------------------------------+");
            System.out.println("\nTotal files found: " + pdfFiles.size());
            
        } catch (Exception e) {
            System.err.println("❌ Error displaying letter IDs: " + e.getMessage());
            LOGGER.severe("Error in displayAllLetterIds: " + e.getMessage());
        }
    }
    
    /**
     * Search for files by specific letter ID.
     */
    private void searchByLetterId() {
        System.out.println("\n=================================================");
        System.out.println("              SEARCH BY LETTER ID");
        System.out.println("=================================================");
        
        System.out.print("Enter Letter ID to search for: ");
        String searchId = scanner.nextLine().trim();
        
        if (searchId.isEmpty()) {
            System.out.println("❌ Letter ID cannot be empty.");
            return;
        }
        
        try {
            List<FileInfo> allFiles = letterIdService.getAllFileInfo();
            List<FileInfo> matchingFiles = allFiles.stream()
                    .filter(file -> searchId.equals(file.getLetterId()))
                    .toList();
            
            if (matchingFiles.isEmpty()) {
                System.out.println("ℹ️  No files found with Letter ID: " + searchId);
            } else {
                System.out.println("\n[Files found with Letter ID: " + searchId + "]");
                System.out.println("--------------------------------------------------");
                
                for (int i = 0; i < matchingFiles.size(); i++) {
                    FileInfo fileInfo = matchingFiles.get(i);
                    System.out.println((i + 1) + ". " + fileInfo.getFileName());
                }
                
                System.out.println("\nTotal matches: " + matchingFiles.size());
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error searching for Letter ID: " + e.getMessage());
            LOGGER.severe("Error in searchByLetterId: " + e.getMessage());
        }
    }
    
    /**
     * Show statistics about letter IDs.
     */
    private void showLetterIdStatistics() {
        System.out.println("\n=================================================");
        System.out.println("            LETTER ID STATISTICS");
        System.out.println("=================================================");
        
        try {
            List<FileInfo> validFiles = letterIdService.getAllFileInfo();
            
            // Count unique letter IDs
            long uniqueLetterIds = validFiles.stream()
                    .map(FileInfo::getLetterId)
                    .distinct()
                    .count();
            
            // Find min and max letter IDs (if numeric)
            String minLetterId = "N/A";
            String maxLetterId = "N/A";
            
            try {
                List<Integer> numericIds = validFiles.stream()
                        .map(FileInfo::getLetterId)
                        .map(Integer::parseInt)
                        .distinct()
                        .sorted()
                        .toList();
                
                if (!numericIds.isEmpty()) {
                    minLetterId = String.valueOf(numericIds.get(0));
                    maxLetterId = String.valueOf(numericIds.get(numericIds.size() - 1));
                }
            } catch (NumberFormatException e) {
                // Some letter IDs are not numeric, keep N/A values
            }
            
            // Display statistics
            System.out.println("📊 Statistics Summary:");
            System.out.println("─".repeat(40));
            System.out.println("Total PDF files processed:    " + validFiles.size());
            System.out.println("Unique Letter IDs found:      " + uniqueLetterIds);
            System.out.println("Minimum Letter ID:            " + minLetterId);
            System.out.println("Maximum Letter ID:            " + maxLetterId);
            
            // Show duplicate letter IDs if any
            var duplicateIds = validFiles.stream()
                    .collect(java.util.stream.Collectors.groupingBy(
                            FileInfo::getLetterId,
                            java.util.stream.Collectors.counting()))
                    .entrySet().stream()
                    .filter(entry -> entry.getValue() > 1)
                    .toList();
            
            if (!duplicateIds.isEmpty()) {
                System.out.println("\n⚠️  Duplicate Letter IDs found:");
                System.out.println("─".repeat(40));
                for (var entry : duplicateIds) {
                    System.out.println("Letter ID: " + entry.getKey() + " (appears " + entry.getValue() + " times)");
                }
            } else {
                System.out.println("\n✅ No duplicate Letter IDs found.");
            }
            
        } catch (Exception e) {
            System.err.println("❌ Error generating statistics: " + e.getMessage());
            LOGGER.severe("Error in showLetterIdStatistics: " + e.getMessage());
        }
    }
    
    /**
     * Validate file name patterns in incoming folder.
     */
    private void validateFileNames() {
        System.out.println("\n=================================================");
        System.out.println("           FILE NAME PATTERN VALIDATION");
        System.out.println("=================================================");
        
        try {
            String incomingFolder = ConfigurationManager.getIncomingFolder();
            System.out.println("Validating files in: " + incomingFolder);
            
            java.nio.file.Path incomingPath = java.nio.file.Paths.get(incomingFolder);
            
            if (!java.nio.file.Files.exists(incomingPath)) {
                System.out.println("❌ Incoming folder does not exist: " + incomingFolder);
                return;
            }
            
            // Get all PDF files
            java.util.List<java.nio.file.Path> allPdfFiles = new java.util.ArrayList<>();
            try (java.nio.file.DirectoryStream<java.nio.file.Path> stream = 
                     java.nio.file.Files.newDirectoryStream(incomingPath, "*.pdf")) {
                for (java.nio.file.Path path : stream) {
                    if (java.nio.file.Files.isRegularFile(path)) {
                        allPdfFiles.add(path);
                    }
                }
            }
            
            int totalPdfFiles = allPdfFiles.size();
            int validFiles = 0;
            int invalidFiles = 0;
            
            System.out.println("\n📋 Validation Results:");
            System.out.println("─".repeat(60));
            
            if (totalPdfFiles == 0) {
                System.out.println("ℹ️  No PDF files found in incoming folder.");
                return;
            }
            
            System.out.println("✅ Valid Files (with Letter ID pattern):");
            System.out.println("─".repeat(40));
            
            for (java.nio.file.Path path : allPdfFiles) {
                String fileName = path.getFileName().toString();
                String letterId = com.documentImporter.util.LetterIdParser.extractLetterId(fileName);
                
                if (letterId != null) {
                    validFiles++;
                    System.out.println("  • " + fileName + " (ID: " + letterId + ")");
                }
            }
            
            System.out.println("\n❌ Invalid Files (no Letter ID pattern):");
            System.out.println("─".repeat(40));
            
            for (java.nio.file.Path path : allPdfFiles) {
                String fileName = path.getFileName().toString();
                String letterId = com.documentImporter.util.LetterIdParser.extractLetterId(fileName);
                
                if (letterId == null) {
                    invalidFiles++;
                    System.out.println("  • " + fileName);
                }
            }
            
            // Summary
            System.out.println("\n📊 Validation Summary:");
            System.out.println("─".repeat(30));
            System.out.println("Total PDF files:     " + totalPdfFiles);
            System.out.println("Valid files:         " + validFiles);
            System.out.println("Invalid files:       " + invalidFiles);
            System.out.printf("Success rate:        %.1f%%\n", 
                    totalPdfFiles > 0 ? (validFiles * 100.0 / totalPdfFiles) : 0.0);
            
        } catch (Exception e) {
            System.err.println("❌ Error validating file names: " + e.getMessage());
            LOGGER.severe("Error in validateFileNames: " + e.getMessage());
        }
    }
    
    /**
     * Get letter ID for a specific file name entered by user.
     */
    private void getLetterIdByFileName() {
        System.out.println("\n=================================================");
        System.out.println("           GET LETTER ID BY FILE NAME");
        System.out.println("=================================================");
        
        System.out.print("Enter PDF file name: ");
        String fileName = scanner.nextLine().trim();
        
        if (fileName.isEmpty()) {
            System.out.println("[ERROR: File name cannot be empty.]");
            return;
        }
        
        try {
            // Use the overloaded method to get letter ID for single file
            String letterId = letterIdService.getLetterIds(fileName);
            
            System.out.println("\n[Letter ID Extraction Result:]");
            System.out.println("----------------------------------------------");
            System.out.println("File Name: " + fileName);
            
            if (letterId != null) {
                System.out.println("Letter ID: " + letterId);
                System.out.println("Status:    [SUCCESS: Valid pattern found]");
                
                // Check if this file exists in incoming folder
                List<FileInfo> allFiles = letterIdService.getAllFileInfo();
                boolean fileExists = allFiles.stream()
                        .anyMatch(file -> file.getFileName().equals(fileName));
                
                if (fileExists) {
                    System.out.println("Location:  [FOUND in incoming folder]");
                } else {
                    System.out.println("Location:  [WARNING: Not found in incoming folder]");
                }
            } else {
                System.out.println("Letter ID: [NONE]");
                System.out.println("Status:    [ERROR: Invalid file name pattern]");
                System.out.println("Expected:  EFCM_CS_yyyyMMddHHH_BMOFraud_Run_XXX_PDF_{letterId}.pdf");
                System.out.println("Example:   EFCM_CS_20251222000_BMOFraud_Run_533_PDF_10.pdf");
            }
            
        } catch (Exception e) {
            System.err.println("[ERROR: Error processing file name: " + e.getMessage() + "]");
            LOGGER.severe("Error in getLetterIdByFileName: " + e.getMessage());
        }
    }
    
    /**
     * Wait for user to press Enter.
     */
    private void waitForEnter() {
        System.out.println("\nPress Enter to continue...");
        scanner.nextLine();
    }
}