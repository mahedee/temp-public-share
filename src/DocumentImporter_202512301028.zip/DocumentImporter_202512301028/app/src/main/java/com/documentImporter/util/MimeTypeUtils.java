package com.documentImporter.util;

import java.util.HashMap;
import java.util.Map;

/**
 * Utility class for MIME type detection based on file extensions.
 * Contains stateless helper methods for MIME type operations.
 * Author: Mahedee Hasan
 */
public final class MimeTypeUtils {
    
    private static final Map<String, String> EXTENSION_TO_MIME = new HashMap<>();
    
    static {
        // Initialize MIME type mappings
        initializeMimeTypeMap();
    }
    
    // Private constructor to prevent instantiation
    private MimeTypeUtils() {
        throw new AssertionError("Utility class should not be instantiated");
    }
    
    /**
     * Get MIME type for a file based on its extension.
     * 
     * @param fileName The file name
     * @return The MIME type string
     */
    public static String getMimeType(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return "application/octet-stream"; // Default binary type
        }
        
        String extension = FileUtils.getFileExtension(fileName);
        return EXTENSION_TO_MIME.getOrDefault(extension, "application/octet-stream");
    }
    
    /**
     * Check if file type is supported based on extension.
     * 
     * @param fileName The file name to check
     * @return true if file type has a known MIME type mapping
     */
    public static boolean isSupportedFileType(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return false;
        }
        
        String extension = FileUtils.getFileExtension(fileName);
        return EXTENSION_TO_MIME.containsKey(extension);
    }
    
    /**
     * Get all supported file extensions.
     * 
     * @return Array of supported file extensions
     */
    public static String[] getSupportedExtensions() {
        return EXTENSION_TO_MIME.keySet().toArray(new String[0]);
    }
    
    /**
     * Check if extension is for an image file.
     * 
     * @param fileName The file name
     * @return true if file is an image type
     */
    public static boolean isImageFile(String fileName) {
        String mimeType = getMimeType(fileName);
        return mimeType.startsWith("image/");
    }
    
    /**
     * Check if extension is for a document file.
     * 
     * @param fileName The file name
     * @return true if file is a document type
     */
    public static boolean isDocumentFile(String fileName) {
        String mimeType = getMimeType(fileName);
        return mimeType.startsWith("application/") || mimeType.startsWith("text/");
    }
    
    /**
     * Initialize the MIME type mapping based on file extensions.
     */
    private static void initializeMimeTypeMap() {
        // Document formats
        EXTENSION_TO_MIME.put("pdf", "application/pdf");
        EXTENSION_TO_MIME.put("doc", "application/msword");
        EXTENSION_TO_MIME.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        EXTENSION_TO_MIME.put("txt", "text/plain");
        EXTENSION_TO_MIME.put("xml", "application/xml");
        EXTENSION_TO_MIME.put("json", "application/json");
        EXTENSION_TO_MIME.put("html", "text/html");
        EXTENSION_TO_MIME.put("htm", "text/html");
        EXTENSION_TO_MIME.put("rtf", "application/rtf");
        
        // Image formats
        EXTENSION_TO_MIME.put("jpeg", "image/jpeg");
        EXTENSION_TO_MIME.put("jpg", "image/jpeg");
        EXTENSION_TO_MIME.put("png", "image/png");
        EXTENSION_TO_MIME.put("tiff", "image/tiff");
        EXTENSION_TO_MIME.put("tif", "image/tiff");
        EXTENSION_TO_MIME.put("gif", "image/gif");
        EXTENSION_TO_MIME.put("bmp", "image/bmp");
        EXTENSION_TO_MIME.put("webp", "image/webp");
        
        // Archive formats
        EXTENSION_TO_MIME.put("zip", "application/zip");
        EXTENSION_TO_MIME.put("rar", "application/x-rar-compressed");
        EXTENSION_TO_MIME.put("7z", "application/x-7z-compressed");
        EXTENSION_TO_MIME.put("tar", "application/x-tar");
        EXTENSION_TO_MIME.put("gz", "application/gzip");
        
        // Spreadsheet formats
        EXTENSION_TO_MIME.put("xls", "application/vnd.ms-excel");
        EXTENSION_TO_MIME.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        EXTENSION_TO_MIME.put("csv", "text/csv");
        EXTENSION_TO_MIME.put("ods", "application/vnd.oasis.opendocument.spreadsheet");
        
        // Presentation formats
        EXTENSION_TO_MIME.put("ppt", "application/vnd.ms-powerpoint");
        EXTENSION_TO_MIME.put("pptx", "application/vnd.openxmlformats-officedocument.presentationml.presentation");
        EXTENSION_TO_MIME.put("odp", "application/vnd.oasis.opendocument.presentation");
        
        // Other common formats
        EXTENSION_TO_MIME.put("css", "text/css");
        EXTENSION_TO_MIME.put("js", "application/javascript");
        EXTENSION_TO_MIME.put("mp3", "audio/mpeg");
        EXTENSION_TO_MIME.put("mp4", "video/mp4");
        EXTENSION_TO_MIME.put("avi", "video/x-msvideo");
        EXTENSION_TO_MIME.put("wav", "audio/wav");
    }
}