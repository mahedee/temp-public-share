package com.documentImporter.console;

public class HelperConsole {
        public static void printHelp() {
        System.out.println("Document Uploader Application");
        System.out.println();
        System.out.println("Usage: java -jar file-generator.jar [OPTIONS]");
        System.out.println();
        System.out.println("Operations:");
        System.out.println("  (default)                   Generate files from database queries");
        System.out.println("  --key                       Generate Secret key for encryption/decryption");
        System.out.println("  --encrypt <text>            Encrypt text and save to file");
        System.out.println("  --decrypt <text>            Decrypt text and save to file");
 
        
        System.out.println("  --help, -h                  Display this help message");
        System.out.println("  --version, -v               Display version information");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  java -jar document-importer-1.0.0.jar");
        System.out.println("  java -jar .\\target\\document-importer-1.0.0.jar --help");
        System.out.println("  java -jar .\\target\\document-importer-1.0.0.jar --key");
        System.out.println("  java -jar document-importer-1.0.0.jar --encrypt \"Hello World\"");
        System.out.println("  java -jar document-importer-1.0.0.jar --decrypt \"<encrypted-text>\"");
    } 
}
