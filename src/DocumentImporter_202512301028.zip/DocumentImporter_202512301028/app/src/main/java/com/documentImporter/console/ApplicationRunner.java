// package com.documentImporter.console;

// import com.documentImporter.console.OrganizationUnitConsole;
// import com.documentImporter.console.LetterIdConsole;
// import com.documentImporter.util.DatabaseConnection;
// import com.documentImporter.util.DataSeeder;
// import com.documentImporter.service.DocumentUploadService;
// import com.documentImporter.util.ConfigurationManager;

// import java.util.Scanner;

// /**
//  * Application Runner class that contains all the application startup and execution logic.
//  * Handles database initialization, seeding, and console interface management.
//  * 
//  * @author DocumentImporter
//  */
// public class ApplicationRunner {
    
//     private final Scanner scanner;
    
//     public ApplicationRunner() {
//         this.scanner = new Scanner(System.in);
//     }
    
//     /**
//      * Run the Document Importer application.
//      * This is the main entry point for application execution.
//      */
//     public void run() {
//         try {
//             displayStartupInfo();
//             initializeDatabase();
//             handleDataSeeding();
//             startConsoleInterface();
//             displayCompletionInfo();
            
//         } catch (Exception e) {
//             System.err.println("❌ Application error: " + e.getMessage());
//             e.printStackTrace();
//             System.exit(1);
//         } finally {
//             cleanup();
//         }
//     }
    
//     /**
//      * Display application startup information.
//      */
//     private void displayStartupInfo() {
//         System.out.println("=================================================");
//         System.out.println("    Document Importer Application Starting");
//         System.out.println("    Pure JDBC + HikariCP Version");
//         System.out.println("=================================================");
//     }
    
//     /**
//      * Initialize and test database connection.
//      */
//     private void initializeDatabase() {
//         if (DatabaseConnection.testConnection()) {
//             System.out.println("✅ Database connection pool initialized successfully");
//             System.out.println("Pool Info: " + DatabaseConnection.getPoolInfo());
//         } else {
//             System.err.println("❌ Database connection test failed");
//             System.exit(1);
//         }
//     }
    
//     /**
//      * Handle database seeding operations.
//      */
//     private void handleDataSeeding() {
//         System.out.println("\\n--- Initializing Database ---");
//         DataSeeder seeder = new DataSeeder();
        
//         // Test table structure
//         System.out.println("Testing table structure:");
//         seeder.testTableStructure();
        
//         // Show current data count
//         seeder.showDataCount();
        
//         // Ask user if they want to clear and reseed data
//         System.out.print("\\nDo you want to clear existing data and reseed? (y/N): ");
//         String response = scanner.nextLine().trim();
        
//         if ("y".equalsIgnoreCase(response) || "yes".equalsIgnoreCase(response)) {
//             seeder.clearData();
//             seeder.seedData();
//             System.out.println("\\nAfter clearing and seeding:");
//             seeder.showDataCount();
//         } else {
//             // Just seed if database is empty
//             seeder.seedData();
//             System.out.println("\\nAfter seeding check:");
//             seeder.showDataCount();
//         }
//     }
    
//     /**
//      * Start the console interface and handle user interactions.
//      */
//     private void startConsoleInterface() {
//         System.out.println("\\n--- Starting Application Interface ---");
        
//         // Main application menu loop
//         while (true) {
//             showMainMenu();
//             System.out.print("Enter your choice (1-4): ");
//             String choice = scanner.nextLine().trim();
            
//             switch (choice) {
//                 case "1":
//                     handleOrganizationUnitManagement();
//                     break;
//                 case "2":
//                     handleDocumentUpload();
//                     break;
//                 case "3":
//                     handleLetterIdManagement();
//                     break;
//                 case "4":
//                     return; // Exit the menu loop
//                 default:
//                     System.out.println("❌ Invalid choice. Please select 1, 2, 3, or 4.");
//             }
//         }
//     }
    
//     /**
//      * Display the main application menu.
//      */
//     private void showMainMenu() {
//         System.out.println("\\n=================================================");
//         System.out.println("           DOCUMENT IMPORTER MAIN MENU");
//         System.out.println("=================================================");
//         System.out.println("1. Organization Unit Management");
//         System.out.println("2. Upload Documents from Incoming Folder");
//         System.out.println("3. Letter ID Management");
//         System.out.println("4. Exit Application");
//         System.out.println("=================================================");
//     }
    
//     /**
//      * Handle Organization Unit Management functionality.
//      */
//     private void handleOrganizationUnitManagement() {
//         OrganizationUnitConsole console = new OrganizationUnitConsole();
//         console.start();
//     }
    
//     /**
//      * Handle Document Upload functionality.
//      */
//     private void handleDocumentUpload() {
//         System.out.println("\\n=================================================");
//         System.out.println("           DOCUMENT UPLOAD PROCESS");
//         System.out.println("=================================================");
        
//         try {
//             displayUploadConfiguration();
//             processDocuments();
            
//         } catch (Exception e) {
//             System.err.println("❌ Error during document upload: " + e.getMessage());
//             e.printStackTrace();
//         }
        
//         waitForUserInput("\\nPress Enter to return to main menu...");
//     }
    
//     /**
//      * Display upload configuration information.
//      */
//     private void displayUploadConfiguration() {
//         System.out.println("Configuration:");
//         System.out.println("  Incoming Folder: " + ConfigurationManager.getIncomingFolder());
//         System.out.println("  Archive Folder: " + ConfigurationManager.getArchiveFolder());
//         System.out.println("  Error Folder: " + ConfigurationManager.getErrorFolder());
//         System.out.println("  Max File Size: " + ConfigurationManager.getMaxFileSizeMB() + " MB");
//         System.out.println("  Supported Extensions: " + ConfigurationManager.getSupportedExtensions());
        
//         System.out.println("\\nStarting document upload process...");
//     }
    
//     /**
//      * Process documents and display results.
//      */
//     private void processDocuments() {
//         DocumentUploadService uploadService = new DocumentUploadService();
//         DocumentUploadService.ProcessingResult result = uploadService.processIncomingFiles();
        
//         // Display results
//         System.out.println("\\n--- PROCESSING RESULTS ---");
//         System.out.println(result.toString());
        
//         displayProcessingResults(result);
        
//         // Shutdown upload service
//         uploadService.shutdown();
//     }
    
//     /**
//      * Display processing results with appropriate messages.
//      * 
//      * @param result The processing result to display
//      */
//     private void displayProcessingResults(DocumentUploadService.ProcessingResult result) {
//         if (result.getProcessedCount() > 0) {
//             System.out.println("✅ Successfully uploaded " + result.getProcessedCount() + " documents to database");
//         }
        
//         if (result.getFailedCount() > 0) {
//             System.out.println("❌ Failed to process " + result.getFailedCount() + " files");
//             System.out.println("   Check the error folder for details: " + ConfigurationManager.getErrorFolder());
//         }
        
//         if (result.getTotalFiles() == 0) {
//             System.out.println("ℹ️  No files found in incoming folder: " + ConfigurationManager.getIncomingFolder());
//         }
//     }
    
//     /**
//      * Handle Letter ID Management functionality.
//      */
//     private void handleLetterIdManagement() {
//         LetterIdConsole letterIdConsole = new LetterIdConsole();
//         letterIdConsole.start();
//     }
    
//     /**
//      * Wait for user input with a custom message.
//      * 
//      * @param message The message to display to the user
//      */
//     private void waitForUserInput(String message) {
//         System.out.println(message);
//         try {
//             System.in.read();
//         } catch (Exception ignored) {
//             // Ignore any exceptions from reading input
//         }
//     }
    
//     /**
//      * Display application completion information.
//      */
//     private void displayCompletionInfo() {
//         System.out.println("\\n=================================================");
//         System.out.println("    Document Importer Application Completed");
//         System.out.println("=================================================");
//     }
    
//     /**
//      * Cleanup resources and close connections.
//      */
//     private void cleanup() {
//         try {
//             if (scanner != null) {
//                 scanner.close();
//             }
//         } catch (Exception e) {
//             // Ignore scanner close exceptions
//         }
        
//         // Ensure connection pool is properly shutdown
//         DatabaseConnection.closeDataSource();
//     }
// }