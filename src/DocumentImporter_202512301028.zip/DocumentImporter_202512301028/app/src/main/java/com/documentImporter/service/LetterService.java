package com.documentImporter.service;

import com.documentImporter.model.FileInfo;
import java.util.List;

/**
 * Service interface for letter ID processing operations.
 * Provides methods to extract letter IDs from PDF filenames and manage file processing.
 * 
 * @author Mahedee Hasan
 */
public interface LetterService {
    
    /**
     * Get all file information from PDF files in the incoming folder.
     * Scans for PDF files and extracts letter IDs from filenames.
     * 
     * @return List of FileInfo objects containing filename and letter ID pairs
     */
    List<FileInfo> getAllFileInfo();
    
    /**
     * Get letter IDs for specific PDF files.
     * 
     * @param fileNames List of PDF filenames
     * @return List of letter IDs in same order as input
     */
    List<String> getLetterIds(List<String> fileNames);
    
    /**
     * Get letter ID for a specific PDF file.
     * 
     * @param fileName PDF filename
     * @return Letter ID if found, null otherwise
     */
    String getLetterIds(String fileName);
    
    /**
     * Check if a file has a valid letter ID pattern.
     * 
     * @param fileName The filename to check
     * @return true if file has valid letter ID pattern
     */
    boolean hasValidLetterIdPattern(String fileName);
}