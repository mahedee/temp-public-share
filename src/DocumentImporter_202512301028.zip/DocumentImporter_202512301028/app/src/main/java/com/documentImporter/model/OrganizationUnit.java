package com.documentImporter.model;

import java.io.Serializable;

/**
 * Entity class for ORGANIZATION_UNITS table
 * Author: Mahedee Hasan
 */
public class OrganizationUnit implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long id;
    private Long versionId;
    private String name;
    private String description;
    private Character deleted;
    private String orgunitCode;

    // Default constructor
    public OrganizationUnit() {
    }

    // Constructor with required fields
    public OrganizationUnit(Long id, Long versionId, String name, String orgunitCode) {
        this.id = id;
        this.versionId = versionId;
        this.name = name;
        this.orgunitCode = orgunitCode;
    }

    // Getters and Setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getVersionId() {
        return versionId;
    }

    public void setVersionId(Long versionId) {
        this.versionId = versionId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public Character getDeleted() {
        return deleted;
    }

    public void setDeleted(Character deleted) {
        this.deleted = deleted;
    }

    public String getOrgunitCode() {
        return orgunitCode;
    }

    public void setOrgunitCode(String orgunitCode) {
        this.orgunitCode = orgunitCode;
    }

    @Override
    public String toString() {
        return "OrganizationUnit{" +
                "id=" + id +
                ", versionId=" + versionId +
                ", name='" + name + '\'' +
                ", description='" + description + '\'' +
                ", deleted=" + deleted +
                ", orgunitCode='" + orgunitCode + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;

        OrganizationUnit that = (OrganizationUnit) o;

        return id != null ? id.equals(that.id) : that.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }

    // Utility methods
    public boolean isDeleted() {
        return deleted != null && deleted.equals('Y');
    }

    public void markAsDeleted() {
        this.deleted = 'Y';
    }

    public void markAsActive() {
        this.deleted = null;
    }

    public String getDisplayName() {
        return name != null ? name : orgunitCode;
    }
}