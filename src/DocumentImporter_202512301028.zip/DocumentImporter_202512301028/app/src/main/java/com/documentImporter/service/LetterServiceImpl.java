package com.documentImporter.service;

import com.documentImporter.util.ConfigurationManager;
import com.documentImporter.util.LetterIdParser;
import com.documentImporter.model.FileInfo;

import java.io.IOException;
import java.nio.file.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.stream.Collectors;

/**
 * Implementation of LetterService for processing PDF files and extracting letter IDs from incoming folder.
 * Author: Mahedee Hasan
 */
public class LetterServiceImpl implements LetterService {
    
    private static final Logger LOGGER = Logger.getLogger(LetterServiceImpl.class.getName());
    
    /**
     * Get all file information from PDF files in the incoming folder.
     * Scans for PDF files and extracts letter IDs from filenames.
     * 
     * @return List of FileInfo objects containing filename and letter ID pairs
     */
    @Override
    public List<FileInfo> getAllFileInfo() {
        LOGGER.info("Getting all file information from incoming PDF files...");
        
        List<FileInfo> results = new ArrayList<>();
        
        try {
            String incomingFolderPath = ConfigurationManager.getIncomingFolder();
            LOGGER.info("Raw incoming folder path from config: " + incomingFolderPath);
            Path incomingPath = Paths.get(incomingFolderPath);
            LOGGER.info("Resolved incoming folder path: " + incomingPath.toAbsolutePath());
            
            if (!Files.exists(incomingPath)) {
                LOGGER.warning("Incoming folder does not exist: " + incomingPath.toAbsolutePath());
                return results;
            }
            
            LOGGER.info("Incoming folder exists and is accessible");
            
            // Get all PDF files from incoming directory
            List<Path> pdfFiles = getPdfFiles(incomingPath);
            
            LOGGER.info("Found " + pdfFiles.size() + " PDF files to process");
            
            // Process each PDF file and extract letter ID
            for (Path filePath : pdfFiles) {
                String fileName = filePath.getFileName().toString();
                // Get basic FileInfo with filename and letter ID
                FileInfo fileInfo = LetterIdParser.parsePdfFileName(fileName);
                byte[] fileData = Files.readAllBytes(filePath);                
                fileInfo.setFileData(fileData);
                fileInfo.setMimeType(Files.probeContentType(filePath));

                if (fileInfo != null && fileInfo.getLetterId() != null) {
                    results.add(fileInfo);
                    LOGGER.info("Successfully extracted letter ID: " + fileInfo.getLetterId() + 
                               " from file: " + fileName);
                } else {
                    LOGGER.warning("Could not extract letter ID from file: " + fileName);
                }
            }
            
        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Error processing incoming PDF files for letter ID extraction", e);
        }
        
        LOGGER.info("Letter ID extraction completed. Processed " + results.size() + " valid files");
        return results;
    }
    
    /**
     * Get letter IDs for specific PDF files.
     * 
     * @param fileNames List of PDF filenames
     * @return List of letter IDs in same order as input
     */
    @Override
    public List<String> getLetterIds(List<String> fileNames) {
        return fileNames.stream()
                .map(LetterIdParser::extractLetterId)
                .collect(Collectors.toList());
    }
    
    /**
     * Get letter ID for a specific PDF file.
     * 
     * @param fileName PDF filename
     * @return Letter ID if found, null otherwise
     */
    @Override
    public String getLetterIds(String fileName) {
        return LetterIdParser.extractLetterId(fileName);
    }
    
    /**
     * Check if a file has a valid letter ID pattern.
     * 
     * @param fileName The filename to check
     * @return true if file has valid letter ID pattern
     */
    @Override
    public boolean hasValidLetterIdPattern(String fileName) {
        return LetterIdParser.isValidPdfFileName(fileName);
    }
    
    /**
     * Get all PDF files from the specified directory.
     * 
     * @param directoryPath The directory to scan
     * @return List of PDF file paths
     * @throws IOException If directory cannot be read
     */
    private List<Path> getPdfFiles(Path directoryPath) throws IOException {
        List<Path> pdfFiles = new ArrayList<>();
        
        try (DirectoryStream<Path> stream = Files.newDirectoryStream(directoryPath, "*.pdf")) {
            for (Path path : stream) {
                if (Files.isRegularFile(path)) {
                    pdfFiles.add(path);
                }
            }
        }
        
        return pdfFiles;
    }
    
    /**
     * Result class for letter ID processing statistics.
     */
    public static class LetterIdProcessingResult {
        private final int totalFiles;
        private final int validFiles;
        private final int invalidFiles;
        private final List<FileInfo> validFileInfos;
        private final List<String> invalidFileNames;
        
        public LetterIdProcessingResult(int totalFiles, int validFiles, int invalidFiles, 
                                      List<FileInfo> validFileInfos, List<String> invalidFileNames) {
            this.totalFiles = totalFiles;
            this.validFiles = validFiles;
            this.invalidFiles = invalidFiles;
            this.validFileInfos = validFileInfos;
            this.invalidFileNames = invalidFileNames;
        }
        
        public int getTotalFiles() { return totalFiles; }
        public int getValidFiles() { return validFiles; }
        public int getInvalidFiles() { return invalidFiles; }
        public List<FileInfo> getValidFileInfos() { return validFileInfos; }
        public List<String> getInvalidFileNames() { return invalidFileNames; }
    }
}
