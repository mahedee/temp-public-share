package com.documentImporter.constants;

/**
 * Application-wide constants for Document Importer application.
 * Author: Mahedee Hasan
 */

public final class AppConstants {

    // Private constructor to prevent instantiation
    private AppConstants() {
        throw new UnsupportedOperationException("Utility class");
    }

    public static final String SECRET_KEY = "oixD8HMZb2GxMzxOMAANwkbEJRmEHC0rhq5tdjAOQro=";
    public static final String ENCRYPTION_ALGORITHM = "AES";
    public static final String TRANSFORMATION = "AES/CBC/PKCS5Padding";
    public static final int KEY_LENGTH = 256;
}
