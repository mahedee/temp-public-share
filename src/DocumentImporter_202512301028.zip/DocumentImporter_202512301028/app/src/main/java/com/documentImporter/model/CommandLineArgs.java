package com.documentImporter.model;

import com.documentImporter.enums.OperationType;

/**
 * Command Line Arguments model for Document Importer application.
 * Author: Mahedee Hasan
 */

public class CommandLineArgs {
    private OperationType operationType;
    private String text;

    public  CommandLineArgs() {
        // Default operation type
        this.operationType = OperationType.PROCESS_FILES;
    }

    public OperationType getOperationType() {
        return operationType;
    }
    
    public void setOperationType(OperationType operationType) {
        this.operationType = operationType;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    @Override
    public String toString() {
        return "CommandLineArgs{" +
                "operationType=" + operationType +
                '}';
    }
}
