package com.documentImporter.dao;

import com.documentImporter.model.WorkflowDocument;
import com.documentImporter.service.UniqueKeyService;
import com.documentImporter.service.UniqueKeyServiceImpl;
import com.documentImporter.util.DatabaseConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Implementation of WorkflowDocumentDao interface for WorkflowDocument operations
 *
 * Author: Mahedee Hasan
 */

public class WorkflowDocumentDaoImpl implements WorkflowDocumentDao {
    
    private static final Logger LOGGER = Logger.getLogger(WorkflowDocumentDaoImpl.class.getName());
    private static final String TABLE_NAME = "WORKFLOW_DOCUMENT";
    
    private final UniqueKeyService uniqueKeyService;
    
    public WorkflowDocumentDaoImpl() {
        this.uniqueKeyService = new UniqueKeyServiceImpl();
    }
    
    // Constructor for dependency injection (for testing)
    public WorkflowDocumentDaoImpl(UniqueKeyService uniqueKeyService) {
        this.uniqueKeyService = uniqueKeyService;
    }
    
    private static final String INSERT_SQL = 
        "INSERT INTO WORKFLOW_DOCUMENT (" +
        "ID, DOCUMENT_TIMESTAMP, DESCRIPTION, FILE_NAME, MIME_TYPE, FILE_DATA, " +
        "DOCUMENT_URL, ENTITY_NAME, ENTITY_KEY, ENTITY_KEY_NUM, ATTACHED_BY, " +
        "DOCUMENT_NAME, DOCUMENT_TYPE, FILE_DATA_INDEXED, SNAPSHOT_CONTENT, SNAPSHOT_URL" +
        ") VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
    
    private static final String SELECT_BY_ID_SQL = 
        "SELECT * FROM WORKFLOW_DOCUMENT WHERE ID = ?";
    
    private static final String SELECT_BY_ENTITY_SQL = 
        "SELECT * FROM WORKFLOW_DOCUMENT WHERE ENTITY_NAME = ? AND ENTITY_KEY = ? ORDER BY DOCUMENT_TIMESTAMP DESC";
    
    private static final String SELECT_BY_FILENAME_SQL = 
        "SELECT * FROM WORKFLOW_DOCUMENT WHERE FILE_NAME LIKE ? ORDER BY DOCUMENT_TIMESTAMP DESC";
    
    private static final String SELECT_ALL_SQL = 
        "SELECT * FROM WORKFLOW_DOCUMENT ORDER BY DOCUMENT_TIMESTAMP DESC";
    
    private static final String UPDATE_SQL = 
        "UPDATE WORKFLOW_DOCUMENT SET " +
        "DOCUMENT_TIMESTAMP = ?, DESCRIPTION = ?, FILE_NAME = ?, MIME_TYPE = ?, FILE_DATA = ?, " +
        "DOCUMENT_URL = ?, ENTITY_NAME = ?, ENTITY_KEY = ?, ENTITY_KEY_NUM = ?, ATTACHED_BY = ?, " +
        "DOCUMENT_NAME = ?, DOCUMENT_TYPE = ?, FILE_DATA_INDEXED = ?, SNAPSHOT_CONTENT = ?, SNAPSHOT_URL = ? " +
        "WHERE ID = ?";
    
    private static final String DELETE_SQL = 
        "DELETE FROM WORKFLOW_DOCUMENT WHERE ID = ?";
    
    private static final String COUNT_SQL = 
        "SELECT COUNT(*) FROM WORKFLOW_DOCUMENT";

    @Override
    public WorkflowDocument insert(WorkflowDocument document) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DatabaseConnection.getConnection();
            
            // Get next ID from UNIQUE_KEYS table
            Integer nextId = uniqueKeyService.getNextId(TABLE_NAME);
            document.setId(nextId);

            // Insert document
            statement = connection.prepareStatement(INSERT_SQL);
            statement.setInt(1, document.getId());
            statement.setTimestamp(2, document.getDocumentTimestamp());
            statement.setString(3, document.getDescription());
            statement.setString(4, document.getFileName());
            statement.setString(5, document.getMimeType());
            statement.setBytes(6, document.getFileData());
            statement.setString(7, document.getDocumentUrl());
            statement.setString(8, document.getEntityName());
            statement.setString(9, document.getEntityKey());
            
            if (document.getEntityKeyNum() != null) {
                statement.setInt(10, document.getEntityKeyNum());
            } else {
                statement.setNull(10, Types.INTEGER);
            }
            
            if (document.getAttachedBy() != null) {
                statement.setInt(11, document.getAttachedBy());
            } else {
                statement.setNull(11, Types.INTEGER);
            }
            
            statement.setString(12, document.getDocumentName());
            statement.setString(13, document.getDocumentType());
            statement.setString(14, document.getFileDataIndexed());
            statement.setBytes(15, document.getSnapshotContent());
            statement.setString(16, document.getSnapshotUrl());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Creating workflow document failed, no rows affected.");
            }

            LOGGER.info("Successfully inserted workflow document with ID: " + document.getId() + 
                       ", FileName: " + document.getFileName());
            
            return document;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error inserting workflow document: " + e.getMessage(), e);
            throw new RuntimeException("Error inserting workflow document: " + e.getMessage(), e);
        } finally {
            // Close resources
            if (statement != null) {
                try { statement.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Error closing Statement", e); }
            }
            if (connection != null) {
                try { connection.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Error closing Connection", e); }
            }
        }
    }

    @Override
    public WorkflowDocument findById(Integer id) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(SELECT_BY_ID_SQL);
            statement.setInt(1, id);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return mapResultSetToWorkflowDocument(resultSet);
            }
            return null;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding workflow document by ID: " + id, e);
            throw new RuntimeException("Error finding workflow document: " + e.getMessage(), e);
        } finally {
            closeResources(resultSet, statement, connection);
        }
    }

    @Override
    public List<WorkflowDocument> findByEntity(String entityName, String entityKey) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<WorkflowDocument> documents = new ArrayList<>();

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(SELECT_BY_ENTITY_SQL);
            statement.setString(1, entityName);
            statement.setString(2, entityKey);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                documents.add(mapResultSetToWorkflowDocument(resultSet));
            }

            return documents;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding workflow documents by entity: " + entityName + "/" + entityKey, e);
            throw new RuntimeException("Error finding workflow documents: " + e.getMessage(), e);
        } finally {
            closeResources(resultSet, statement, connection);
        }
    }

    @Override
    public List<WorkflowDocument> findByFileName(String fileNamePattern) {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<WorkflowDocument> documents = new ArrayList<>();

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(SELECT_BY_FILENAME_SQL);
            statement.setString(1, fileNamePattern);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                documents.add(mapResultSetToWorkflowDocument(resultSet));
            }

            return documents;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding workflow documents by filename pattern: " + fileNamePattern, e);
            throw new RuntimeException("Error finding workflow documents: " + e.getMessage(), e);
        } finally {
            closeResources(resultSet, statement, connection);
        }
    }

    @Override
    public List<WorkflowDocument> findAll() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;
        List<WorkflowDocument> documents = new ArrayList<>();

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(SELECT_ALL_SQL);
            resultSet = statement.executeQuery();

            while (resultSet.next()) {
                documents.add(mapResultSetToWorkflowDocument(resultSet));
            }

            return documents;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error finding all workflow documents", e);
            throw new RuntimeException("Error finding workflow documents: " + e.getMessage(), e);
        } finally {
            closeResources(resultSet, statement, connection);
        }
    }

    @Override
    public WorkflowDocument update(WorkflowDocument document) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(UPDATE_SQL);
            
            statement.setTimestamp(1, document.getDocumentTimestamp());
            statement.setString(2, document.getDescription());
            statement.setString(3, document.getFileName());
            statement.setString(4, document.getMimeType());
            statement.setBytes(5, document.getFileData());
            statement.setString(6, document.getDocumentUrl());
            statement.setString(7, document.getEntityName());
            statement.setString(8, document.getEntityKey());
            
            if (document.getEntityKeyNum() != null) {
                statement.setInt(9, document.getEntityKeyNum());
            } else {
                statement.setNull(9, Types.INTEGER);
            }
            
            if (document.getAttachedBy() != null) {
                statement.setInt(10, document.getAttachedBy());
            } else {
                statement.setNull(10, Types.INTEGER);
            }
            
            statement.setString(11, document.getDocumentName());
            statement.setString(12, document.getDocumentType());
            statement.setString(13, document.getFileDataIndexed());
            statement.setBytes(14, document.getSnapshotContent());
            statement.setString(15, document.getSnapshotUrl());
            statement.setInt(16, document.getId());

            int affectedRows = statement.executeUpdate();
            if (affectedRows == 0) {
                throw new SQLException("Updating workflow document failed, no rows affected.");
            }

            LOGGER.info("Successfully updated workflow document with ID: " + document.getId());
            return document;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error updating workflow document with ID: " + document.getId(), e);
            throw new RuntimeException("Error updating workflow document: " + e.getMessage(), e);
        } finally {
            closeResources(null, statement, connection);
        }
    }

    @Override
    public boolean delete(Integer id) {
        Connection connection = null;
        PreparedStatement statement = null;

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(DELETE_SQL);
            statement.setInt(1, id);

            int affectedRows = statement.executeUpdate();
            boolean deleted = affectedRows > 0;
            
            if (deleted) {
                LOGGER.info("Successfully deleted workflow document with ID: " + id);
            } else {
                LOGGER.warning("No workflow document found with ID: " + id);
            }
            
            return deleted;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error deleting workflow document with ID: " + id, e);
            throw new RuntimeException("Error deleting workflow document: " + e.getMessage(), e);
        } finally {
            closeResources(null, statement, connection);
        }
    }

    @Override
    public long count() {
        Connection connection = null;
        PreparedStatement statement = null;
        ResultSet resultSet = null;

        try {
            connection = DatabaseConnection.getConnection();
            statement = connection.prepareStatement(COUNT_SQL);
            resultSet = statement.executeQuery();

            if (resultSet.next()) {
                return resultSet.getLong(1);
            }
            return 0;

        } catch (SQLException e) {
            LOGGER.log(Level.SEVERE, "Error counting workflow documents", e);
            throw new RuntimeException("Error counting workflow documents: " + e.getMessage(), e);
        } finally {
            closeResources(resultSet, statement, connection);
        }
    }

    /**
     * Maps a ResultSet row to a WorkflowDocument object.
     * 
     * @param resultSet The ResultSet containing workflow document data
     * @return WorkflowDocument object
     * @throws SQLException If database access error occurs
     */
    private WorkflowDocument mapResultSetToWorkflowDocument(ResultSet resultSet) throws SQLException {
        WorkflowDocument document = new WorkflowDocument();
        
        document.setId(resultSet.getInt("ID"));
        document.setDocumentTimestamp(resultSet.getTimestamp("DOCUMENT_TIMESTAMP"));
        document.setDescription(resultSet.getString("DESCRIPTION"));
        document.setFileName(resultSet.getString("FILE_NAME"));
        document.setMimeType(resultSet.getString("MIME_TYPE"));
        document.setFileData(resultSet.getBytes("FILE_DATA"));
        document.setDocumentUrl(resultSet.getString("DOCUMENT_URL"));
        document.setEntityName(resultSet.getString("ENTITY_NAME"));
        document.setEntityKey(resultSet.getString("ENTITY_KEY"));
        
        // Handle nullable integers
        int entityKeyNum = resultSet.getInt("ENTITY_KEY_NUM");
        if (!resultSet.wasNull()) {
            document.setEntityKeyNum(entityKeyNum);
        }
        
        int attachedBy = resultSet.getInt("ATTACHED_BY");
        if (!resultSet.wasNull()) {
            document.setAttachedBy(attachedBy);
        }
        
        document.setDocumentName(resultSet.getString("DOCUMENT_NAME"));
        document.setDocumentType(resultSet.getString("DOCUMENT_TYPE"));
        document.setFileDataIndexed(resultSet.getString("FILE_DATA_INDEXED"));
        document.setSnapshotContent(resultSet.getBytes("SNAPSHOT_CONTENT"));
        document.setSnapshotUrl(resultSet.getString("SNAPSHOT_URL"));
        
        return document;
    }

    /**
     * Closes database resources safely.
     * 
     * @param resultSet The ResultSet to close
     * @param statement The Statement to close
     * @param connection The Connection to close
     */
    private void closeResources(ResultSet resultSet, Statement statement, Connection connection) {
        if (resultSet != null) {
            try { resultSet.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Error closing ResultSet", e); }
        }
        if (statement != null) {
            try { statement.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Error closing Statement", e); }
        }
        if (connection != null) {
            try { connection.close(); } catch (SQLException e) { LOGGER.log(Level.WARNING, "Error closing Connection", e); }
        }
    }
}