package com.documentImporter.model;

import java.sql.Timestamp;

/**
 * Enhanced data model class to hold complete PDF file information.
 * Contains filename, extracted letter ID, file data, and metadata for database storage.
 * 
 * @author Mahedee Hasan
 */
public class FileInfo {
    private final String fileName;
    private final String letterId;
    private byte[] fileData;
    private String mimeType;
    private long fileSize;
    private String filePath;
    private Timestamp createdDate;
    private Timestamp modifiedDate;
    private String status;
    private String checksum;
    
    /**
     * Constructor for FileInfo with basic information.
     * 
     * @param fileName The PDF filename
     * @param letterId The extracted letter ID
     */
    public FileInfo(String fileName, String letterId) {
        this.fileName = fileName;
        this.letterId = letterId;
        this.createdDate = new Timestamp(System.currentTimeMillis());
        this.status = "PENDING";
    }
    
    /**
     * Constructor for FileInfo with complete information.
     */
    public FileInfo(String fileName, String letterId, byte[] fileData, String mimeType, 
                   long fileSize, String filePath) {
        this(fileName, letterId);
        this.fileData = fileData;
        this.mimeType = mimeType;
        this.fileSize = fileSize;
        this.filePath = filePath;
    }
    
    // Existing getters
    public String getFileName() { return fileName; }
    public String getLetterId() { return letterId; }
    
    // New getters and setters
    public byte[] getFileData() { return fileData; }
    public void setFileData(byte[] fileData) { 
        this.fileData = fileData;
        this.fileSize = fileData != null ? fileData.length : 0;
    }
    
    public String getMimeType() { return mimeType; }
    public void setMimeType(String mimeType) { this.mimeType = mimeType; }
    
    public long getFileSize() { return fileSize; }
    public void setFileSize(long fileSize) { this.fileSize = fileSize; }
    
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }
    
    public Timestamp getCreatedDate() { return createdDate; }
    public void setCreatedDate(Timestamp createdDate) { this.createdDate = createdDate; }
    
    public Timestamp getModifiedDate() { return modifiedDate; }
    public void setModifiedDate(Timestamp modifiedDate) { this.modifiedDate = modifiedDate; }
    
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    
    public String getChecksum() { return checksum; }
    public void setChecksum(String checksum) { this.checksum = checksum; }
    
    /**
     * Check if this file info has file data loaded.
     */
    public boolean hasFileData() {
        return fileData != null && fileData.length > 0;
    }
    
    /**
     * Get file size in human readable format.
     */
    public String getFormattedFileSize() {
        return formatFileSize(fileSize);
    }
    
    /**
     * Utility method to format file size.
     */
    private String formatFileSize(long size) {
        if (size < 1024) return size + " B";
        if (size < 1024 * 1024) return String.format("%.1f KB", size / 1024.0);
        if (size < 1024 * 1024 * 1024) return String.format("%.1f MB", size / (1024.0 * 1024.0));
        return String.format("%.1f GB", size / (1024.0 * 1024.0 * 1024.0));
    }
    
    // Existing methods
    public boolean hasValidLetterId() {
        return letterId != null && !letterId.trim().isEmpty();
    }
    
    public String getDisplayString() {
        return String.format("File: %s, Letter ID: %s, Size: %s", 
                           fileName, letterId != null ? letterId : "NONE", getFormattedFileSize());
    }
    
    @Override
    public String toString() {
        return "FileInfo{fileName='" + fileName + "', letterId='" + letterId + 
               "', fileSize=" + fileSize + ", status='" + status + "'}";
    }
    
    // equals and hashCode remain the same...
}