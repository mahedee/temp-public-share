package com.documentImporter.service;

import com.documentImporter.dao.UniqueKeyDao;
import com.documentImporter.dao.UniqueKeyDaoImpl;

import java.util.logging.Logger;

/**
 * Implementation of UniqueKeyService providing business logic for ID generation.
 * Author: Mahedee Hasan
 */
public class UniqueKeyServiceImpl implements UniqueKeyService {
    
    private static final Logger LOGGER = Logger.getLogger(UniqueKeyServiceImpl.class.getName());
    
    private final UniqueKeyDao uniqueKeyDao;
    
    public UniqueKeyServiceImpl() {
        this.uniqueKeyDao = new UniqueKeyDaoImpl();
    }
    
    // Constructor for dependency injection (for testing)
    public UniqueKeyServiceImpl(UniqueKeyDao uniqueKeyDao) {
        this.uniqueKeyDao = uniqueKeyDao;
    }

    @Override
    public Integer getNextId(String tableName) {
        validateTableName(tableName);
        
        LOGGER.info("Generating next ID for table: " + tableName);
        
        // Ensure table is initialized
        if (!uniqueKeyDao.tableExists(tableName)) {
            LOGGER.info("Table " + tableName + " not found in UNIQUE_KEYS, initializing...");
            uniqueKeyDao.initializeTable(tableName, 1);
        }
        
        return uniqueKeyDao.getNextId(tableName);
    }

    @Override
    public Integer getCurrentNextId(String tableName) {
        validateTableName(tableName);
        
        return uniqueKeyDao.getCurrentNextId(tableName);
    }

    @Override
    public boolean initializeIdGeneration(String tableName, Integer startingId) {
        validateTableName(tableName);
        
        if (startingId == null || startingId < 1) {
            startingId = 1;
            LOGGER.info("Using default starting ID of 1 for table: " + tableName);
        }
        
        LOGGER.info("Initializing ID generation for table " + tableName + " with starting ID " + startingId);
        
        return uniqueKeyDao.initializeTable(tableName, startingId);
    }

    @Override
    public boolean isTableConfigured(String tableName) {
        validateTableName(tableName);
        
        return uniqueKeyDao.tableExists(tableName);
    }
    
    /**
     * Validates the table name parameter.
     * 
     * @param tableName The table name to validate
     * @throws IllegalArgumentException if table name is invalid
     */
    private void validateTableName(String tableName) {
        if (tableName == null || tableName.trim().isEmpty()) {
            throw new IllegalArgumentException("Table name cannot be null or empty");
        }
        
        // Additional validation rules can be added here
        if (tableName.length() > 64) {
            throw new IllegalArgumentException("Table name cannot exceed 64 characters");
        }
    }

    @Override
    public boolean updateNextId(String tableName) {
        validateTableName(tableName);
        return uniqueKeyDao.updateNextId(tableName);
    }
}