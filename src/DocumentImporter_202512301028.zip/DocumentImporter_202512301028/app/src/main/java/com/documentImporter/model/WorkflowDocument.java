package com.documentImporter.model;

import java.sql.Timestamp;

/**
 * WorkflowDocument Entity representing the WORKFLOW_DOCUMENT table
 * 
 * Author: Mahedee Hasan
 */
public class WorkflowDocument {
    
    private Integer id;
    private Timestamp documentTimestamp;
    private String description;
    private String fileName;
    private String mimeType;
    private byte[] fileData;
    private String documentUrl;
    private String entityName;
    private String entityKey;
    private Integer entityKeyNum;
    private Integer attachedBy;
    private String documentName;
    private String documentType;
    private String fileDataIndexed;
    private byte[] snapshotContent;
    private String snapshotUrl;

    // Default constructor
    public WorkflowDocument() {
        this.documentTimestamp = new Timestamp(System.currentTimeMillis());
    }

    // Constructor with required fields
    public WorkflowDocument(String fileName, String mimeType, byte[] fileData, 
                          String documentUrl, String entityName, String entityKey) {
        this();
        this.fileName = fileName;
        this.mimeType = mimeType;
        this.fileData = fileData;
        this.documentUrl = documentUrl;
        this.entityName = entityName;
        this.entityKey = entityKey;
    }

    // Full constructor
    public WorkflowDocument(Integer id, Timestamp documentTimestamp, String description, 
                          String fileName, String mimeType, byte[] fileData, String documentUrl,
                          String entityName, String entityKey, Integer entityKeyNum, 
                          Integer attachedBy, String documentName, String documentType,
                          String fileDataIndexed, byte[] snapshotContent, String snapshotUrl) {
        this.id = id;
        this.documentTimestamp = documentTimestamp;
        this.description = description;
        this.fileName = fileName;
        this.mimeType = mimeType;
        this.fileData = fileData;
        this.documentUrl = documentUrl;
        this.entityName = entityName;
        this.entityKey = entityKey;
        this.entityKeyNum = entityKeyNum;
        this.attachedBy = attachedBy;
        this.documentName = documentName;
        this.documentType = documentType;
        this.fileDataIndexed = fileDataIndexed;
        this.snapshotContent = snapshotContent;
        this.snapshotUrl = snapshotUrl;
    }

    // Getters and Setters
    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public Timestamp getDocumentTimestamp() {
        return documentTimestamp;
    }

    public void setDocumentTimestamp(Timestamp documentTimestamp) {
        this.documentTimestamp = documentTimestamp;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getMimeType() {
        return mimeType;
    }

    public void setMimeType(String mimeType) {
        this.mimeType = mimeType;
    }

    public byte[] getFileData() {
        return fileData;
    }

    public void setFileData(byte[] fileData) {
        this.fileData = fileData;
    }

    public String getDocumentUrl() {
        return documentUrl;
    }

    public void setDocumentUrl(String documentUrl) {
        this.documentUrl = documentUrl;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getEntityKey() {
        return entityKey;
    }

    public void setEntityKey(String entityKey) {
        this.entityKey = entityKey;
    }

    public Integer getEntityKeyNum() {
        return entityKeyNum;
    }

    public void setEntityKeyNum(Integer entityKeyNum) {
        this.entityKeyNum = entityKeyNum;
    }

    public Integer getAttachedBy() {
        return attachedBy;
    }

    public void setAttachedBy(Integer attachedBy) {
        this.attachedBy = attachedBy;
    }

    public String getDocumentName() {
        return documentName;
    }

    public void setDocumentName(String documentName) {
        this.documentName = documentName;
    }

    public String getDocumentType() {
        return documentType;
    }

    public void setDocumentType(String documentType) {
        this.documentType = documentType;
    }

    public String getFileDataIndexed() {
        return fileDataIndexed;
    }

    public void setFileDataIndexed(String fileDataIndexed) {
        this.fileDataIndexed = fileDataIndexed;
    }

    public byte[] getSnapshotContent() {
        return snapshotContent;
    }

    public void setSnapshotContent(byte[] snapshotContent) {
        this.snapshotContent = snapshotContent;
    }

    public String getSnapshotUrl() {
        return snapshotUrl;
    }

    public void setSnapshotUrl(String snapshotUrl) {
        this.snapshotUrl = snapshotUrl;
    }

    @Override
    public String toString() {
        return "WorkflowDocument{" +
                "id=" + id +
                ", documentTimestamp=" + documentTimestamp +
                ", description='" + description + '\'' +
                ", fileName='" + fileName + '\'' +
                ", mimeType='" + mimeType + '\'' +
                ", fileDataSize=" + (fileData != null ? fileData.length : 0) + " bytes" +
                ", documentUrl='" + documentUrl + '\'' +
                ", entityName='" + entityName + '\'' +
                ", entityKey='" + entityKey + '\'' +
                ", entityKeyNum=" + entityKeyNum +
                ", attachedBy=" + attachedBy +
                ", documentName='" + documentName + '\'' +
                ", documentType='" + documentType + '\'' +
                ", fileDataIndexed='" + fileDataIndexed + '\'' +
                ", snapshotContentSize=" + (snapshotContent != null ? snapshotContent.length : 0) + " bytes" +
                ", snapshotUrl='" + snapshotUrl + '\'' +
                '}';
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        
        WorkflowDocument that = (WorkflowDocument) o;
        return id != null ? id.equals(that.id) : that.id == null;
    }

    @Override
    public int hashCode() {
        return id != null ? id.hashCode() : 0;
    }
}