package com.documentImporter.service;

import com.documentImporter.dao.WorkflowDocumentDao;
import com.documentImporter.dao.WorkflowDocumentDaoImpl;
import com.documentImporter.model.WorkflowDocument;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Implementation of WorkflowDocumentService providing business logic for document operations.
 * Author: Mahedee Hasan
 */
public class WorkflowDocumentServiceImpl implements WorkflowDocumentService {
    
    private static final Logger LOGGER = Logger.getLogger(WorkflowDocumentServiceImpl.class.getName());
    
    private final WorkflowDocumentDao workflowDocumentDao;
    private final Map<String, String> mimeTypeMap;
    
    public WorkflowDocumentServiceImpl() {
        this.workflowDocumentDao = new WorkflowDocumentDaoImpl();
        this.mimeTypeMap = initializeMimeTypeMap();
    }
    
    // Constructor for dependency injection (if needed for testing)
    public WorkflowDocumentServiceImpl(WorkflowDocumentDao workflowDocumentDao) {
        this.workflowDocumentDao = workflowDocumentDao;
        this.mimeTypeMap = initializeMimeTypeMap();
    }

    @Override
    public WorkflowDocument createDocument(WorkflowDocument document) {
        validateDocument(document);
        
        // Set default values if not provided
        if (document.getDocumentName() == null) {
            document.setDocumentName(document.getFileName());
        }
        
        if (document.getMimeType() == null) {
            document.setMimeType(getMimeType(document.getFileName()));
        }
        
        // Set default entity values if not provided
        if (document.getEntityName() == null) {
            document.setEntityName("DOCUMENT");
        }
        
        if (document.getEntityKey() == null) {
            document.setEntityKey("GENERAL");
        }
        
        // Set document URL (could be file path or storage reference)
        if (document.getDocumentUrl() == null) {
            document.setDocumentUrl("file://" + document.getFileName());
        }
        
        LOGGER.info("Creating new workflow document: " + document.getFileName() + 
                   " (Size: " + (document.getFileData() != null ? document.getFileData().length : 0) + " bytes)");
        
        return workflowDocumentDao.insert(document);
    }

    @Override
    public WorkflowDocument findDocumentById(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("Document ID cannot be null");
        }
        return workflowDocumentDao.findById(id);
    }

    @Override
    public List<WorkflowDocument> findDocumentsByEntity(String entityName, String entityKey) {
        if (entityName == null || entityKey == null) {
            throw new IllegalArgumentException("Entity name and key cannot be null");
        }
        return workflowDocumentDao.findByEntity(entityName, entityKey);
    }

    @Override
    public List<WorkflowDocument> findDocumentsByFileName(String fileNamePattern) {
        if (fileNamePattern == null) {
            throw new IllegalArgumentException("File name pattern cannot be null");
        }
        return workflowDocumentDao.findByFileName(fileNamePattern);
    }

    @Override
    public List<WorkflowDocument> getAllDocuments() {
        return workflowDocumentDao.findAll();
    }

    @Override
    public WorkflowDocument updateDocument(WorkflowDocument document) {
        if (document == null || document.getId() == null) {
            throw new IllegalArgumentException("Document and document ID cannot be null for update");
        }
        
        validateDocument(document);
        
        LOGGER.info("Updating workflow document with ID: " + document.getId());
        return workflowDocumentDao.update(document);
    }

    @Override
    public boolean deleteDocument(Integer id) {
        if (id == null) {
            throw new IllegalArgumentException("Document ID cannot be null");
        }
        
        LOGGER.info("Deleting workflow document with ID: " + id);
        return workflowDocumentDao.delete(id);
    }

    @Override
    public long getDocumentCount() {
        return workflowDocumentDao.count();
    }

    @Override
    public boolean isSupportedFileType(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return false;
        }
        
        String extension = getFileExtension(fileName).toLowerCase();
        return mimeTypeMap.containsKey(extension);
    }

    @Override
    public String getMimeType(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return "application/octet-stream"; // Default binary type
        }
        
        String extension = getFileExtension(fileName).toLowerCase();
        return mimeTypeMap.getOrDefault(extension, "application/octet-stream");
    }
    
    /**
     * Validates a WorkflowDocument before database operations.
     * 
     * @param document The document to validate
     * @throws IllegalArgumentException if validation fails
     */
    private void validateDocument(WorkflowDocument document) {
        if (document == null) {
            throw new IllegalArgumentException("Document cannot be null");
        }
        
        if (document.getFileName() == null || document.getFileName().trim().isEmpty()) {
            throw new IllegalArgumentException("File name is required");
        }
        
        if (document.getFileData() == null || document.getFileData().length == 0) {
            throw new IllegalArgumentException("File data is required");
        }
        
        // Validate file size (50MB limit as per configuration)
        if (document.getFileData().length > 50 * 1024 * 1024) {
            throw new IllegalArgumentException("File size exceeds maximum allowed size of 50MB");
        }
        
        if (!isSupportedFileType(document.getFileName())) {
            throw new IllegalArgumentException("Unsupported file type: " + getFileExtension(document.getFileName()));
        }
    }
    
    /**
     * Extracts file extension from filename.
     * 
     * @param fileName The filename
     * @return The file extension (without dot)
     */
    private String getFileExtension(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return "";
        }
        
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1);
        }
        
        return "";
    }
    
    /**
     * Initializes the MIME type mapping based on file extensions.
     * 
     * @return Map of file extensions to MIME types
     */
    private Map<String, String> initializeMimeTypeMap() {
        Map<String, String> mimeTypes = new HashMap<>();
        
        // Document formats
        mimeTypes.put("pdf", "application/pdf");
        mimeTypes.put("doc", "application/msword");
        mimeTypes.put("docx", "application/vnd.openxmlformats-officedocument.wordprocessingml.document");
        mimeTypes.put("txt", "text/plain");
        mimeTypes.put("xml", "application/xml");
        mimeTypes.put("json", "application/json");
        
        // Image formats
        mimeTypes.put("jpeg", "image/jpeg");
        mimeTypes.put("jpg", "image/jpeg");
        mimeTypes.put("png", "image/png");
        mimeTypes.put("tiff", "image/tiff");
        mimeTypes.put("tif", "image/tiff");
        mimeTypes.put("gif", "image/gif");
        mimeTypes.put("bmp", "image/bmp");
        
        // Archive formats
        mimeTypes.put("zip", "application/zip");
        mimeTypes.put("rar", "application/x-rar-compressed");
        mimeTypes.put("7z", "application/x-7z-compressed");
        
        // Spreadsheet formats
        mimeTypes.put("xls", "application/vnd.ms-excel");
        mimeTypes.put("xlsx", "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet");
        mimeTypes.put("csv", "text/csv");
        
        return mimeTypes;
    }
}