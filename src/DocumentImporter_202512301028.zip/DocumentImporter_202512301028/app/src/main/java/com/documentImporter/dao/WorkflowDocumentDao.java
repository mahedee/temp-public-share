package com.documentImporter.dao;

import com.documentImporter.model.WorkflowDocument;
import java.util.List;

/**
 * Data Access Object interface for WorkflowDocument operations.
 *
 * Author: Mahedee Hasan
 */

public interface WorkflowDocumentDao {
    
    /**
     * Insert a new workflow document into the database.
     * 
     * @param document The WorkflowDocument to insert
     * @return The inserted document with generated ID
     */
    WorkflowDocument insert(WorkflowDocument document);
    
    /**
     * Find a workflow document by its ID.
     * 
     * @param id The document ID
     * @return The WorkflowDocument if found, null otherwise
     */
    WorkflowDocument findById(Integer id);
    
    /**
     * Find all workflow documents by entity name and key.
     * 
     * @param entityName The entity name
     * @param entityKey The entity key
     * @return List of WorkflowDocuments for the entity
     */
    List<WorkflowDocument> findByEntity(String entityName, String entityKey);
    
    /**
     * Find all workflow documents by file name pattern.
     * 
     * @param fileNamePattern The file name pattern (supports wildcards)
     * @return List of matching WorkflowDocuments
     */
    List<WorkflowDocument> findByFileName(String fileNamePattern);
    
    /**
     * Get all workflow documents.
     * 
     * @return List of all WorkflowDocuments
     */
    List<WorkflowDocument> findAll();
    
    /**
     * Update an existing workflow document.
     * 
     * @param document The WorkflowDocument to update
     * @return The updated document
     */
    WorkflowDocument update(WorkflowDocument document);
    
    /**
     * Delete a workflow document by ID.
     * 
     * @param id The document ID to delete
     * @return true if deleted, false if not found
     */
    boolean delete(Integer id);
    
    /**
     * Get count of all workflow documents.
     * 
     * @return Total count of documents
     */
    long count();
}