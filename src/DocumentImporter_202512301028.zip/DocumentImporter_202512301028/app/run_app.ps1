# PowerShell script to run the DocumentImporter application
Set-Location "D:\Projects\GitHub\my-daptorik-apps\professional\current\DocumentImporter\app"
Write-Host "Current Directory: $(Get-Location)"
Write-Host "Running DocumentImporter application..."
# Use input redirection with an input file
mvn exec:java "-Dexec.mainClass=com.documentImporter.App" < input.txt