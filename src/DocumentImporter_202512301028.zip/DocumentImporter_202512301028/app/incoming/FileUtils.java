package com.documentImporter.util;

import java.io.IOException;
import java.nio.file.*;
import java.util.Set;

/**
 * Utility class for file operations.
 * Contains stateless helper methods for file manipulation.
 * Author: Mahedee Hasan
 */
public final class FileUtils {
    
    // Private constructor to prevent instantiation
    private FileUtils() {
        throw new AssertionError("Utility class should not be instantiated");
    }
    
    /**
     * Get file extension without dot.
     * 
     * @param fileName The file name
     * @return File extension or empty string
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return "";
        }
        
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1).toLowerCase();
        }
        
        return "";
    }
    
    /**
     * Get base file name without extension.
     * 
     * @param fileName The file name
     * @return Base file name
     */
    public static String getBaseFileName(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return fileName;
        }
        
        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0) {
            return fileName.substring(0, lastDotIndex);
        }
        
        return fileName;
    }
    
    /**
     * Check if file has valid size (not empty and within limit).
     * 
     * @param filePath The file path to check
     * @param maxSizeBytes Maximum allowed size in bytes
     * @return true if file size is valid
     * @throws IOException If file size cannot be read
     */
    public static boolean isValidFileSize(Path filePath, long maxSizeBytes) throws IOException {
        long fileSize = Files.size(filePath);
        return fileSize > 0 && fileSize <= maxSizeBytes;
    }
    
    /**
     * Check if file extension is supported.
     * 
     * @param fileName The file name
     * @param supportedExtensions Set of supported extensions (lowercase)
     * @return true if extension is supported
     */
    public static boolean isSupportedExtension(String fileName, Set<String> supportedExtensions) {
        if (fileName == null || supportedExtensions == null) {
            return false;
        }
        
        String extension = getFileExtension(fileName);
        return supportedExtensions.contains(extension.toLowerCase());
    }
    
    /**
     * Generate unique file name by appending timestamp if file already exists in target directory.
     * 
     * @param targetPath The target file path
     * @return Unique file path
     */
    public static Path generateUniqueFileName(Path targetPath) {
        if (targetPath == null || !Files.exists(targetPath)) {
            return targetPath;
        }
        
        String fileName = targetPath.getFileName().toString();
        String baseName = getBaseFileName(fileName);
        String extension = getFileExtension(fileName);
        Path parentPath = targetPath.getParent();
        
        // Generate timestamp suffix
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timestamp = now.format(formatter);
        
        String newFileName = baseName + "_" + timestamp + (extension.isEmpty() ? "" : "." + extension);
        Path uniquePath = parentPath.resolve(newFileName);
        
        // If timestamp-based name still exists (very unlikely), add milliseconds
        if (Files.exists(uniquePath)) {
            String millis = String.valueOf(System.currentTimeMillis() % 1000);
            newFileName = baseName + "_" + timestamp + "_" + millis + (extension.isEmpty() ? "" : "." + extension);
            uniquePath = parentPath.resolve(newFileName);
        }
        
        return uniquePath;
    }
    
    /**
     * Create directory if it doesn't exist.
     * 
     * @param directoryPath The directory path to create
     * @throws IOException If directory creation fails
     */
    public static void createDirectoryIfNotExists(String directoryPath) throws IOException {
        if (directoryPath != null && !directoryPath.trim().isEmpty()) {
            Files.createDirectories(Paths.get(directoryPath));
        }
    }
    
    /**
     * Check if path is a valid regular file.
     * 
     * @param filePath The file path to check
     * @return true if path exists and is a regular file
     */
    public static boolean isValidFile(Path filePath) {
        return filePath != null && Files.exists(filePath) && Files.isRegularFile(filePath);
    }
    
    /**
     * Get file size in bytes.
     * 
     * @param filePath The file path
     * @return File size in bytes
     * @throws IOException If file size cannot be read
     */
    public static long getFileSize(Path filePath) throws IOException {
        return Files.size(filePath);
    }
    
    /**
     * Format file size in human readable format.
     * 
     * @param sizeInBytes File size in bytes
     * @return Formatted size string (e.g., "1.5 MB")
     */
    public static String formatFileSize(long sizeInBytes) {
        if (sizeInBytes < 1024) {
            return sizeInBytes + " B";
        } else if (sizeInBytes < 1024 * 1024) {
            return String.format("%.1f KB", sizeInBytes / 1024.0);
        } else if (sizeInBytes < 1024 * 1024 * 1024) {
            return String.format("%.1f MB", sizeInBytes / (1024.0 * 1024));
        } else {
            return String.format("%.1f GB", sizeInBytes / (1024.0 * 1024 * 1024));
        }
    }
}