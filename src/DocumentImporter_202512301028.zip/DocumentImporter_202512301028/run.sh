#!/bin/bash

# Organization Unit Management System Launcher
# This script builds and runs the Document Importer application

echo "=========================================="
echo "Organization Unit Management System"
echo "=========================================="

# Check if Maven is installed
if ! command -v mvn &> /dev/null; then
    echo "Error: Maven is not installed or not in PATH"
    exit 1
fi

# Get the directory where the script is located
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_DIR="$SCRIPT_DIR/app"

# Change to project directory
cd "$PROJECT_DIR" || { echo "Error: Cannot access project directory"; exit 1; }

echo "Building application..."
mvn clean compile

if [ $? -ne 0 ]; then
    echo "Error: Build failed"
    exit 1
fi

echo "Starting Organization Unit Management System..."
echo "=========================================="

# Run the application
mvn exec:java -Dexec.mainClass="com.documentimporter.App"

echo "=========================================="
echo "Application finished."