mvn clean compile
- Uses pure JDBC instead of JPA/Hibernate for database access
- Add seed data