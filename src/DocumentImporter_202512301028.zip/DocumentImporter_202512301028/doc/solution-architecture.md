# Document Importer - Solution Architecture

## Project Overview

The Document Importer is a Java-based enterprise application designed for organization unit management and document processing workflows. It provides a robust system for importing, processing, and managing documents with Oracle database integration.

## System Architecture

### Technology Stack
- **Java Version**: 11
- **Build Tool**: Maven 3.x
- **Database**: Oracle Database (using XEPDB1 instance)
- **Connection Pool**: HikariCP 5.0.1
- **JDBC Driver**: Oracle JDBC 21.5.0.0
- **Logging**: SLF4J Simple 1.7.36
- **Testing**: JUnit 4.13.2

### Application Type
- **Architecture Pattern**: Layered Architecture (N-Tier)
- **Database Access**: Pure JDBC (No ORM framework)
- **Application Type**: Console-based Enterprise Application
- **Deployment**: Standalone JAR with embedded dependencies

## Project Structure

```
DocumentImporter/
├── app/
│   ├── pom.xml                          # Maven configuration
│   ├── run_app.ps1                      # PowerShell startup script
│   ├── input.txt                        # Sample input file
│   ├── README.md                        # Basic project documentation
│   │
│   ├── incoming/                        # File processing directories
│   │   └── archived/                    # Processed files archive
│   ├── backup/                          # Backup directory
│   ├── error/                           # Failed processing files
│   ├── lib/                             # External libraries
│   │
│   ├── src/main/
│   │   ├── java/com/documentImporter/
│   │   │   ├── App.java                 # Main application entry point
│   │   │   ├── StandaloneDocumentProcessor.java  # Batch processing entry
│   │   │   │
│   │   │   ├── console/                 # Presentation Layer
│   │   │   │   └── OrganizationUnitConsole.java
│   │   │   │
│   │   │   ├── service/                 # Business Logic Layer
│   │   │   │   ├── DocumentUploadService.java
│   │   │   │   ├── OrganizationUnitService.java
│   │   │   │   ├── OrganizationUnitServiceImpl.java
│   │   │   │   ├── UniqueKeyService.java
│   │   │   │   ├── UniqueKeyServiceImpl.java
│   │   │   │   ├── WorkflowDocumentService.java
│   │   │   │   └── WorkflowDocumentServiceImpl.java
│   │   │   │
│   │   │   ├── dao/                     # Data Access Layer
│   │   │   │   ├── OrganizationUnitDao.java
│   │   │   │   ├── UniqueKeyDao.java
│   │   │   │   ├── UniqueKeyDaoImpl.java
│   │   │   │   ├── WorkflowDocumentDao.java
│   │   │   │   └── WorkflowDocumentDaoImpl.java
│   │   │   │
│   │   │   ├── model/                   # Domain Models/Entities
│   │   │   │   ├── OrganizationUnit.java
│   │   │   │   ├── UniqueKey.java
│   │   │   │   └── WorkflowDocument.java
│   │   │   │
│   │   │   ├── dto/                     # Data Transfer Objects
│   │   │   │   └── OrganizationUnitDTO.java
│   │   │   │
│   │   │   ├── mapper/                  # Entity-DTO Mapping
│   │   │   │   └── OrganizationUnitMapper.java
│   │   │   │
│   │   │   └── util/                    # Utility Classes
│   │   │       ├── ConfigurationManager.java
│   │   │       ├── DatabaseConnection.java
│   │   │       ├── DataSeeder.java
│   │   │       ├── FileUtils.java
│   │   │       └── MimeTypeUtils.java
│   │   │
│   │   └── resources/
│   │       ├── application.properties   # Configuration file
│   │       └── META-INF/
│   │
│   └── target/                          # Maven build output
│
├── doc/                                 # Documentation
│   ├── readme.md
│   ├── tasks.md
│   ├── workflow_document_table.sql
│   └── solution-architecture.md         # This document
│
├── archive/                             # Project archive/backups
│
├── run.bat                              # Windows startup script
└── run.sh                               # Unix startup script
```

## Architectural Layers

### 1. Presentation Layer (`console/`)
- **Purpose**: User interaction and input/output handling
- **Components**:
  - `OrganizationUnitConsole`: Interactive menu system for CRUD operations
- **Responsibilities**:
  - User input validation
  - Menu navigation
  - Display formatting
  - Command-line interface

### 2. Business Logic Layer (`service/`)
- **Purpose**: Core business logic and workflow orchestration
- **Components**:
  - `DocumentUploadService`: File processing and upload orchestration
  - `OrganizationUnitService/Impl`: Organization unit business logic
  - `UniqueKeyService/Impl`: Unique key generation and management
  - `WorkflowDocumentService/Impl`: Document workflow business rules
- **Responsibilities**:
  - Business rule implementation
  - Data validation
  - Transaction coordination
  - File processing workflows

### 3. Data Access Layer (`dao/`)
- **Purpose**: Database operations and data persistence
- **Components**:
  - `OrganizationUnitDao`: Organization unit data access
  - `UniqueKeyDao/Impl`: Unique key data operations
  - `WorkflowDocumentDao/Impl`: Document data persistence
- **Responsibilities**:
  - SQL query execution
  - Database connection management
  - Data mapping
  - Transaction handling

### 4. Domain Model Layer (`model/`, `dto/`, `mapper/`)
- **Purpose**: Data representation and transformation
- **Components**:
  - `OrganizationUnit`: Core entity model
  - `UniqueKey`: Key management entity
  - `WorkflowDocument`: Document entity with binary data support
  - `OrganizationUnitDTO`: Data transfer object
  - `OrganizationUnitMapper`: Entity-DTO transformation
- **Responsibilities**:
  - Data structure definition
  - Entity relationships
  - Data transfer optimization

### 5. Utility Layer (`util/`)
- **Purpose**: Cross-cutting concerns and helper functions
- **Components**:
  - `ConfigurationManager`: Application configuration management
  - `DatabaseConnection`: HikariCP connection pool management
  - `DataSeeder`: Database initialization and test data
  - `FileUtils`: File system operations
  - `MimeTypeUtils`: MIME type detection for file processing
- **Responsibilities**:
  - Configuration management
  - Database connectivity
  - File operations
  - Common utilities

## Key Components Analysis

### Database Connection Management
- **Technology**: HikariCP Connection Pool
- **Configuration**: Defined in `application.properties`
- **Features**:
  - Connection pooling with configurable pool size (5-20 connections)
  - Connection validation with Oracle-specific test query
  - Automatic connection lifecycle management
  - Connection timeout and retry logic

### File Processing Workflow
- **Incoming Directory**: Monitors for new files
- **Supported Formats**: PDF, DOC, DOCX, TXT, XML, JSON, JPEG, PNG, JPG, TIFF
- **Processing Pipeline**:
  1. File detection and validation
  2. MIME type detection
  3. Binary data storage in database
  4. File archiving to processed directory
  5. Error handling with error directory storage

### Database Schema
- **Primary Tables**:
  - `ORGANIZATION_UNITS`: Organization structure management
  - `WORKFLOW_DOCUMENT`: Document storage with binary data
  - `UNIQUE_KEYS`: System-wide unique key generation
- **Key Features**:
  - Binary large object (BLOB) support for file storage
  - Timestamp tracking for audit trails
  - Soft delete functionality

## Application Entry Points

### 1. Interactive Mode (`App.java`)
- **Purpose**: Full-featured interactive console application
- **Features**:
  - Database connection testing
  - Data seeding capabilities
  - Interactive menu system
  - Organization unit management
  - Document processing workflows

### 2. Batch Mode (`StandaloneDocumentProcessor.java`)
- **Purpose**: Automated batch processing
- **Features**:
  - Streamlined file processing
  - Minimal user interaction
  - Automated error handling
  - Direct file-to-database processing

## Configuration Management

### Database Configuration
```properties
# Oracle Database Connection
database.url=jdbc:oracle:thin:@//localhost:1521/XEPDB1
database.username=EFCM_NETREVEAL
database.password=Test123
database.driver=oracle.jdbc.OracleDriver

# HikariCP Pool Settings
hikari.connection-timeout=20000
hikari.minimum-idle=5
hikari.maximum-pool-size=20
hikari.validation-timeout=5000
```

### File Processing Configuration
```properties
# Directory Configuration
docprocessor.folders.incoming=./incoming
docprocessor.folders.archive=./incoming/archived
docprocessor.folders.error=./incoming/error

# File Validation
docprocessor.file.supported-extensions=pdf,doc,docx,txt,xml,json,jpeg,png,jpg,tiff
```

## Build and Deployment

### Maven Configuration
- **Artifact**: `document-importer`
- **Packaging**: JAR with dependencies (Maven Shade Plugin)
- **Main Class**: `com.documentImporter.App`
- **Java Target**: Version 11

### Dependencies
- **Oracle JDBC**: Enterprise database connectivity
- **HikariCP**: High-performance connection pooling
- **SLF4J**: Standardized logging framework
- **JUnit**: Unit testing framework

### Deployment Scripts
- **Windows**: `run.bat`, `run_app.ps1`
- **Unix/Linux**: `run.sh`
- **Features**: Environment setup, Java path detection, JAR execution

## Design Patterns Used

1. **Repository Pattern**: DAO layer abstracts data access
2. **Service Layer Pattern**: Business logic encapsulation
3. **Data Transfer Object (DTO)**: Optimized data transfer
4. **Factory Pattern**: Database connection creation
5. **Singleton Pattern**: Configuration management
6. **Template Method**: Consistent DAO operations

## Security Considerations

- **Database Authentication**: Username/password based
- **Connection Security**: Encrypted Oracle TNS connections
- **File Validation**: MIME type verification and extension checking
- **SQL Injection Prevention**: Prepared statements throughout DAOs
- **Error Handling**: Secure error logging without credential exposure

## Performance Features

- **Connection Pooling**: HikariCP for optimal database performance
- **Async Processing**: CompletableFuture support for file operations
- **Batch Operations**: Efficient bulk data processing
- **Memory Management**: Streaming for large file processing
- **Query Optimization**: Prepared statements and indexed queries

## Monitoring and Logging

- **Logging Framework**: SLF4J with configurable levels
- **Database Monitoring**: Connection pool metrics
- **File Processing Metrics**: Success/error tracking
- **Performance Logging**: Database operation timing

## Future Enhancement Opportunities

1. **Web Interface**: REST API or web-based UI
2. **Message Queue Integration**: Asynchronous processing
3. **Microservices Migration**: Service decomposition
4. **Cloud Deployment**: Container-based deployment
5. **Advanced Security**: OAuth2/JWT authentication
6. **Monitoring Integration**: APM tools integration
7. **Database Migration**: JPA/Hibernate integration option
8. **File Storage**: External object storage integration

## Conclusion

The Document Importer represents a well-structured enterprise Java application following established architectural patterns. The layered architecture provides clear separation of concerns, making the system maintainable and extensible. The use of pure JDBC ensures optimal performance for database operations, while the comprehensive file processing workflow supports various document types and formats.

The application demonstrates enterprise-grade features including connection pooling, comprehensive error handling, configurable processing workflows, and robust data management capabilities.