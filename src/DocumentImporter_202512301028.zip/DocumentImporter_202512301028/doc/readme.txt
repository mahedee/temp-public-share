Command for help

java -jar .\target\document-importer-1.0.0.jar --help
