## Task list for File Importer Project


- [ ] **Configuration Management**
  - [ ] Fix application.properties file location resolution
  - [ ] Resolve config file directory trade-off issues
  - [ ] Ensure proper configuration loading order

### 🗃️ Database Operations
- [x] ~~Update the next_key after inserting the record~~ ✅ **Done**
- [ ] **ID Generation System**
  - [ ] Implement UNIQUE_KEYS table usage for ID generation
  - [ ] Extract file ID from file name parsing
  - [ ] Generate entity_key based on file ID
  - [ ] Insert entity_name = 'Case' with corresponding entity_key

- [x] ~~Insert blob data into the table~~ ✅ **Done**

### 📁 File Processing & Management
- [ ] **File Type Filtering**
  - [ ] Implement PDF and XML file filtering only
  - [ ] Add file type validation before processing
  - [ ] Reject unsupported file types with proper error handling

- [x] ~~Handle duplicate file names with unique naming~~ ✅ **Done**
  - [x] ~~Implement generateUniqueFileName method~~
  - [x] ~~Append incremental numbers for duplicate names~~

- [ ] **File Archiving System** 🚧 **In Progress**
  - [ ] Create archive folder structure
  - [ ] Move processed files to archive after successful DB upload
  - [ ] Move corresponding XML files along with their data files
  - [ ] Implement rollback mechanism for failed archives
  - [ ] Add archive cleanup policies

### 🧹 Code Quality & Maintenance
- [ ] **Code Cleanup Phase 1**
  - [ ] Add proper author names to all source files
  - [ ] Remove unused methods and variables
  - [ ] Remove commented-out code (green code)
  - [ ] Apply consistent code formatting

- [ ] **Code Cleanup Phase 2**
  - [ ] Refactor complex methods for better readability
  - [ ] Add comprehensive JavaDoc comments
  - [ ] Implement proper exception handling
  - [ ] Add input validation throughout the application

- [x] ~~Test logging functionalities~~ ✅ **Done**

### 🚀 Deployment & Infrastructure
- [ ] **Production Deployment**
  - [ ] Prepare deployment package
  - [ ] Move code to production machine (o-machine)
  - [ ] Verify production environment setup
  - [ ] Conduct production testing
  - [ ] Create deployment documentation

### 🔒 Security & Configuration
- [ ] **Password Encryption Implementation**
  - [X] Implement password encryption for database connection strings
  - [X] Add encryption/decryption utility methods
  - [X] Create flag-based enable/disable mechanism for encryption
  - [X] Follow existing file importer encryption patterns
  - [X] Update application.properties to use encrypted password
  - [X] Test encrypted password functionality