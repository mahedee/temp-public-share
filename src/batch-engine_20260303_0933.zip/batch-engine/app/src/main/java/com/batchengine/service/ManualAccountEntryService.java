package com.batchengine.service;

import com.batchengine.repository.ManualAccountEntryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Business logic for the Manual Account Entry job.
 * Coordinates with ManualAccountEntryRepository and writes execution results
 * to a log file.
 *
 * NOTE: This class is intentionally NOT @Transactional. The transaction boundary
 * lives in ManualAccountEntryRepository.processEntries() so that log file writes
 * (SUCCESS / FAILED) always happen independently of whether the DB transaction
 * committed or rolled back.
 */
@Service
public class ManualAccountEntryService {

    private static final Logger logger = LoggerFactory.getLogger(ManualAccountEntryService.class);
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Value("${batchengine.jobs.configuration.manual-account-entry.log-file:logs/manual-account-entry-job.log}")
    private String logFilePath;

    @Autowired(required = false)
    private ManualAccountEntryRepository manualAccountEntryRepository;

    /**
     * Main processing method called by ManualAccountEntryJob.
     *
     * Transaction lifecycle:
     *   - processEntries() opens a DB transaction (HikariCP borrows a connection).
     *   - On success  → all 5 steps commit, connection is returned to pool.
     *   - On failure  → all 5 steps roll back, connection is returned to pool.
     *   - Either way, the log file write below runs OUTSIDE that transaction so
     *     it always records the outcome regardless of DB commit/rollback.
     */
    public void process() {
        LocalDateTime startTime = LocalDateTime.now();
        logger.info("=== MANUAL ACCOUNT ENTRY JOB STARTED === Start Time: {}", startTime.format(DATE_FORMATTER));

        try {
            if (manualAccountEntryRepository == null) {
                logger.warn("ManualAccountEntryRepository is not available — skipping DB processing (no DataSource configured)");
            } else {
                manualAccountEntryRepository.processEntries();
            }

            LocalDateTime endTime = LocalDateTime.now();
            long durationMs = java.time.Duration.between(startTime, endTime).toMillis();
            logger.info("=== MANUAL ACCOUNT ENTRY JOB COMPLETED === End Time: {}, Duration: {}ms",
                    endTime.format(DATE_FORMATTER), durationMs);

            writeToLogFile(startTime, "SUCCESS");

        } catch (Exception e) {
            LocalDateTime endTime = LocalDateTime.now();
            long durationMs = java.time.Duration.between(startTime, endTime).toMillis();
            logger.error("=== MANUAL ACCOUNT ENTRY JOB FAILED === End Time: {}, Duration: {}ms, Error: {}",
                    endTime.format(DATE_FORMATTER), durationMs, e.getMessage(), e);

            writeToLogFile(startTime, "FAILED");

            throw new RuntimeException("Manual account entry job failed", e);
        }
    }

    private void writeToLogFile(LocalDateTime time, String status) {
        String logMessage = String.format("[%s] Manual account entry job executed - Status: %s%n",
                time.format(DATE_FORMATTER), status);
        try {
            Path path = Paths.get(logFilePath);
            Path parentDir = path.getParent();
            if (parentDir != null && !Files.exists(parentDir)) {
                Files.createDirectories(parentDir);
            }
            try (FileWriter writer = new FileWriter(logFilePath, true)) {
                writer.write(logMessage);
            }
        } catch (IOException e) {
            logger.warn("Failed to write to log file {}: {}", logFilePath, e.getMessage());
        }
    }
}
