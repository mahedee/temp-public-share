param(
    [string]$ReleaseName = "letter-generator",
    [string]$ReleaseVersion = "1.0",
    [string]$OutputDir = "releases"
)

# PowerShell Release Builder for File Generator
# Builds production-ready release packages with configurable JAR names

# Colors for output
$ErrorColor = "Red"
$SuccessColor = "Green" 
$WarningColor = "Yellow"
$InfoColor = "Cyan"

function Write-Status {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor $SuccessColor
}

function Write-Warning {
    param([string]$Message)
    Write-Host "! $Message" -ForegroundColor $WarningColor
}

function Write-Error {
    param([string]$Message)
    Write-Host "✗ $Message" -ForegroundColor $ErrorColor
}

function Write-Info {
    param([string]$Message)
    Write-Host "$Message" -ForegroundColor $InfoColor
}

try {
    # Script header
    Write-Info "========================================"
    Write-Info "File Generator Release Builder (PowerShell)"
    Write-Info "========================================"
    
    # Set up variables
    $finalName = "$ReleaseName-$ReleaseVersion"
    $releaseDir = "$OutputDir\$finalName"
    $jarName = "$finalName.jar"
    
    Write-Warning "Building release: $finalName"
    Write-Host "Release Directory: $releaseDir" -ForegroundColor Gray
    Write-Host "JAR Name: $jarName" -ForegroundColor Gray
    Write-Host ""
    
    # Clean and create release directory
    if (Test-Path $releaseDir) {
        Write-Warning "Cleaning existing release directory..."
        Remove-Item -Path $releaseDir -Recurse -Force
    }
    
    # Create release directory structure
    Write-Warning "Creating release directory structure..."
    New-Item -ItemType Directory -Path "$releaseDir" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\config" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\config\file-templates" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\logs" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\output" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\output\demand" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\output\hold" -Force | Out-Null
    New-Item -ItemType Directory -Path "$releaseDir\output\relationship" -Force | Out-Null
    Write-Status "Created release directory structure"
    
    # Build JAR using Maven
    Write-Warning "Building JAR file with Maven..."
    $mavenResult = & mvn clean package -DskipTests 2>&1
    if ($LASTEXITCODE -ne 0) {
        Write-Error "Maven build failed"
        Write-Host $mavenResult -ForegroundColor $ErrorColor
        exit 1
    }
    Write-Status "Maven build completed successfully"
    
    # Copy JAR file to ROOT directory (not bin/)
    $sourceJar = "target\file-generator-1.0.0-jar-with-dependencies.jar"
    $targetJar = "$releaseDir\$jarName"
    
    if (!(Test-Path $sourceJar)) {
        Write-Error "Source JAR file not found: $sourceJar"
        exit 1
    }
    
    Copy-Item -Path $sourceJar -Destination $targetJar
    Write-Status "JAR file copied to: $targetJar"
    
    # Copy configuration files
    Write-Warning "Copying configuration files..."
    Copy-Item -Path "config\*" -Destination "$releaseDir\config\" -Recurse -Force
    Write-Status "Configuration files copied"
    
    # Generate Windows startup script
    Write-Warning "Generating startup scripts..."
    
    $windowsStartupScript = @"
@echo off
REM File Generator Application - Windows Startup Script
REM Release: $finalName
REM Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

echo Starting File Generator Application...
echo Release: $finalName
echo Working Directory: %CD%

REM Ensure required directories exist
if not exist "logs" mkdir "logs"
if not exist "output" mkdir "output"
if not exist "output\demand" mkdir "output\demand"
if not exist "output\hold" mkdir "output\hold"
if not exist "output\relationship" mkdir "output\relationship"

REM Set Java options
set JAVA_OPTS=-Dlog4j2.configurationFile=file:config\log4j2.xml
set JAVA_OPTS=%JAVA_OPTS% -Dfile.encoding=UTF-8
set JAVA_OPTS=%JAVA_OPTS% -Xms512m -Xmx1024m

echo JAR: $jarName
echo Config: config\log4j2.xml
echo ""

REM Start the application
java %JAVA_OPTS% -jar "$jarName"

echo ""
echo Application finished.
pause
"@
    
    $windowsStartupScript | Out-File -FilePath "$releaseDir\start.bat" -Encoding ASCII
    Write-Status "Windows startup script created: start.bat"
    
    # Generate Unix startup script  
    $unixStartupScript = @"
#!/bin/bash
# File Generator Application - Unix Startup Script
# Release: $finalName
# Generated: $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')

echo "Starting File Generator Application..."
echo "Release: $finalName"
echo "Working Directory: `$(pwd)"

# Ensure required directories exist
mkdir -p logs
mkdir -p output/{demand,hold,relationship}

# Set Java options
JAVA_OPTS="-Dlog4j2.configurationFile=file:config/log4j2.xml"
JAVA_OPTS="`$JAVA_OPTS -Dfile.encoding=UTF-8"
JAVA_OPTS="`$JAVA_OPTS -Xms512m -Xmx1024m"

echo "JAR: $jarName"
echo "Config: config/log4j2.xml"
echo ""

# Start the application
java `$JAVA_OPTS -jar "$jarName"

echo ""
echo "Application finished."
"@
    
    $unixStartupScript | Out-File -FilePath "$releaseDir\start.sh" -Encoding UTF8
    Write-Status "Unix startup script created: start.sh"
    
    # Create README
    $readme = @"
# $finalName Release Package

## Quick Start

### Windows
``````
start.bat
``````

### Linux/Unix
``````
chmod +x start.sh
./start.sh
``````

### Manual Execution
``````
java -Dlog4j2.configurationFile=file:config/log4j2.xml -jar $jarName
``````

## Directory Structure
- **$jarName**     - Main application JAR file (in root directory)
- **config/**      - Configuration files and templates
- **logs/**        - Application logs (auto-created)
- **output/**      - Generated files (auto-created)
  - **demand/**    - Demand letter files
  - **hold/**      - Hold letter files  
  - **relationship/** - Relationship termination letter files
- **start.bat**    - Windows startup script
- **start.sh**     - Unix startup script

## Configuration Files
- **config/application.properties** - Main application configuration
- **config/log4j2.xml** - Logging configuration
- **config/file-templates/** - XML file generation templates

## Important Notes
- Always run the application from this directory (where $jarName is located)
- Configuration files are in the config/ subdirectory
- Log files will be created in the logs/ directory
- Generated files will be created in the output/ directory

## Generated
- **Date:** $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
- **Version:** $ReleaseVersion
- **Build System:** PowerShell Release Builder
"@
    
    $readme | Out-File -FilePath "$releaseDir\README.md" -Encoding UTF8
    Write-Status "README.md created"
    
    # Create release archive (optional)
    Write-Warning "Creating release archive..."
    $archivePath = "$OutputDir\$finalName.zip"
    if (Test-Path $archivePath) { 
        Remove-Item $archivePath 
    }
    Compress-Archive -Path "$releaseDir\*" -DestinationPath $archivePath
    Write-Status "Release archive created: $archivePath"
    
    # Build summary
    Write-Host ""
    Write-Info "========================================"
    Write-Info "Release Build Complete!"
    Write-Info "========================================"
    Write-Host "Release Name: " -NoNewline; Write-Host "$finalName" -ForegroundColor $InfoColor
    Write-Host "Release Directory: " -NoNewline; Write-Host "$releaseDir" -ForegroundColor $InfoColor  
    Write-Host "JAR File: " -NoNewline; Write-Host "$targetJar" -ForegroundColor $InfoColor
    Write-Host "Archive: " -NoNewline; Write-Host "$archivePath" -ForegroundColor $InfoColor
    Write-Host ""
    
    Write-Host "Contents:" -ForegroundColor White
    Get-ChildItem -Path $releaseDir -Recurse | ForEach-Object {
        $relativePath = $_.FullName.Replace((Resolve-Path $releaseDir).Path, "")
        Write-Host "  $relativePath" -ForegroundColor Gray
    }
    
    Write-Host ""
    Write-Info "To run the application:"
    Write-Host "  cd $releaseDir" -ForegroundColor Yellow
    Write-Host "  start.bat" -ForegroundColor Yellow
    
} catch {
    Write-Host ""
    Write-Error "Release build failed: $($_.Exception.Message)"
    Write-Host $_.ScriptStackTrace -ForegroundColor $ErrorColor
    exit 1
}