#!/bin/bash

# Shell Release Builder for File Generator
# Builds production-ready release packages with configurable JAR names

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PROJECT_ROOT="$(dirname "$SCRIPT_DIR")"

# Default values
RELEASE_NAME="letter-generator"
RELEASE_VERSION="1.0"
OUTPUT_DIR="releases"

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
GRAY='\033[0;37m'
NC='\033[0m' # No Color

# Function to print colored output
print_status() {
    echo -e "${GREEN}✓${NC} $1"
}

print_warning() {
    echo -e "${YELLOW}!${NC} $1"
}

print_error() {
    echo -e "${RED}✗${NC} $1"
}

print_info() {
    echo -e "${CYAN}$1${NC}"
}

print_gray() {
    echo -e "${GRAY}$1${NC}"
}

# Function to show usage
show_usage() {
    echo "Usage: $0 [OPTIONS]"
    echo ""
    echo "Options:"
    echo "  -n, --name NAME      Release name (default: letter-generator)"
    echo "  -v, --version VER    Release version (default: 1.0)"
    echo "  -o, --output DIR     Output directory (default: releases)"
    echo "  -h, --help           Show this help"
    echo ""
    echo "Examples:"
    echo "  $0                                    # Default: letter-generator-1.0"
    echo "  $0 -n financial-generator -v 2.1     # financial-generator-2.1"
    echo "  $0 --name efcm-postmail --version 3.0.1"
}

# Parse command line arguments
while [[ $# -gt 0 ]]; do
    case $1 in
        -n|--name)
            RELEASE_NAME="$2"
            shift 2
            ;;
        -v|--version)
            RELEASE_VERSION="$2"
            shift 2
            ;;
        -o|--output)
            OUTPUT_DIR="$2"
            shift 2
            ;;
        -h|--help)
            show_usage
            exit 0
            ;;
        *)
            print_error "Unknown option: $1"
            show_usage
            exit 1
            ;;
    esac
done

# Main execution function
main() {
    print_info "========================================"
    print_info "File Generator Release Builder (Shell)"
    print_info "========================================"
    
    # Set up variables
    local final_name="$RELEASE_NAME-$RELEASE_VERSION"
    local release_dir="$PROJECT_ROOT/$OUTPUT_DIR/$final_name"
    local jar_name="$final_name.jar"
    
    print_warning "Building release: $final_name"
    print_gray "Release Directory: $release_dir"
    print_gray "JAR Name: $jar_name"
    echo ""
    
    # Clean and create release directory
    if [[ -d "$release_dir" ]]; then
        print_warning "Cleaning existing release directory..."
        rm -rf "$release_dir"
    fi
    
    # Create release directory structure
    print_warning "Creating release directory structure..."
    mkdir -p "$release_dir"
    mkdir -p "$release_dir/config/file-templates"
    mkdir -p "$release_dir/logs"
    mkdir -p "$release_dir/output"/{demand,hold,relationship}
    print_status "Created release directory structure"
    
    # Build JAR using Maven
    print_warning "Building JAR file with Maven..."
    cd "$PROJECT_ROOT" || exit 1
    if ! mvn clean package -DskipTests >/dev/null 2>&1; then
        print_error "Maven build failed"
        echo "Running Maven with verbose output:"
        mvn clean package -DskipTests
        exit 1
    fi
    print_status "Maven build completed successfully"
    
    # Copy JAR file to ROOT directory (not bin/)
    local source_jar="target/file-generator-1.0.0-jar-with-dependencies.jar"
    local target_jar="$release_dir/$jar_name"
    
    if [[ ! -f "$source_jar" ]]; then
        print_error "Source JAR file not found: $source_jar"
        exit 1
    fi
    
    cp "$source_jar" "$target_jar"
    print_status "JAR file copied to: $target_jar"
    
    # Copy configuration files
    print_warning "Copying configuration files..."
    cp -r config/* "$release_dir/config/"
    print_status "Configuration files copied"
    
    # Generate startup scripts
    print_warning "Generating startup scripts..."
    
    # Windows startup script
    cat > "$release_dir/start.bat" << EOF
@echo off
REM File Generator Application - Windows Startup Script
REM Release: $final_name
REM Generated: $(date '+%Y-%m-%d %H:%M:%S')

echo Starting File Generator Application...
echo Release: $final_name
echo Working Directory: %CD%

REM Ensure required directories exist
if not exist "logs" mkdir "logs"
if not exist "output" mkdir "output"
if not exist "output\\demand" mkdir "output\\demand"
if not exist "output\\hold" mkdir "output\\hold"
if not exist "output\\relationship" mkdir "output\\relationship"

REM Set Java options
set JAVA_OPTS=-Dlog4j2.configurationFile=file:config\\log4j2.xml
set JAVA_OPTS=%JAVA_OPTS% -Dfile.encoding=UTF-8
set JAVA_OPTS=%JAVA_OPTS% -Xms512m -Xmx1024m

echo JAR: $jar_name
echo Config: config\\log4j2.xml
echo.

REM Start the application
java %JAVA_OPTS% -jar "$jar_name"

echo.
echo Application finished.
pause
EOF
    
    print_status "Windows startup script created: start.bat"
    
    # Unix startup script
    cat > "$release_dir/start.sh" << EOF
#!/bin/bash
# File Generator Application - Unix Startup Script
# Release: $final_name
# Generated: $(date '+%Y-%m-%d %H:%M:%S')

echo "Starting File Generator Application..."
echo "Release: $final_name"
echo "Working Directory: \$(pwd)"

# Ensure required directories exist
mkdir -p logs
mkdir -p output/{demand,hold,relationship}

# Set Java options
JAVA_OPTS="-Dlog4j2.configurationFile=file:config/log4j2.xml"
JAVA_OPTS="\$JAVA_OPTS -Dfile.encoding=UTF-8"
JAVA_OPTS="\$JAVA_OPTS -Xms512m -Xmx1024m"

echo "JAR: $jar_name"
echo "Config: config/log4j2.xml"
echo ""

# Start the application
java \$JAVA_OPTS -jar "$jar_name"

echo ""
echo "Application finished."
EOF
    
    chmod +x "$release_dir/start.sh"
    print_status "Unix startup script created: start.sh"
    
    # Create README
    cat > "$release_dir/README.md" << EOF
# $final_name Release Package

## Quick Start

### Windows
\`\`\`
start.bat
\`\`\`

### Linux/Unix
\`\`\`
chmod +x start.sh
./start.sh
\`\`\`

### Manual Execution
\`\`\`
java -Dlog4j2.configurationFile=file:config/log4j2.xml -jar $jar_name
\`\`\`

## Directory Structure
- **$jar_name**     - Main application JAR file (in root directory)
- **config/**      - Configuration files and templates
- **logs/**        - Application logs (auto-created)
- **output/**      - Generated files (auto-created)
  - **demand/**    - Demand letter files
  - **hold/**      - Hold letter files  
  - **relationship/** - Relationship termination letter files
- **start.bat**    - Windows startup script
- **start.sh**     - Unix startup script

## Configuration Files
- **config/application.properties** - Main application configuration
- **config/log4j2.xml** - Logging configuration
- **config/file-templates/** - XML file generation templates

## Important Notes
- Always run the application from this directory (where $jar_name is located)
- Configuration files are in the config/ subdirectory
- Log files will be created in the logs/ directory
- Generated files will be created in the output/ directory

## Generated
- **Date:** $(date '+%Y-%m-%d %H:%M:%S')
- **Version:** $RELEASE_VERSION
- **Build System:** Shell Release Builder
EOF
    
    print_status "README.md created"
    
    # Create release archive
    print_warning "Creating release archive..."
    local archive_path="$PROJECT_ROOT/$OUTPUT_DIR/$final_name.tar.gz"
    cd "$PROJECT_ROOT/$OUTPUT_DIR" || exit 1
    tar -czf "$final_name.tar.gz" "$final_name/"
    print_status "Release archive created: $archive_path"
    
    # Build summary
    echo ""
    print_info "========================================"
    print_info "Release Build Complete!"
    print_info "========================================"
    echo -e "Release Name: ${CYAN}$final_name${NC}"
    echo -e "Release Directory: ${CYAN}$release_dir${NC}"
    echo -e "JAR File: ${CYAN}$target_jar${NC}"
    echo -e "Archive: ${CYAN}$archive_path${NC}"
    echo ""
    
    echo "Contents:"
    find "$release_dir" -type f | sed "s|$release_dir||" | sed 's/^/  /' | head -20
    if [[ $(find "$release_dir" -type f | wc -l) -gt 20 ]]; then
        echo "  ... and more files"
    fi
    
    echo ""
    print_info "To run the application:"
    echo -e "  ${YELLOW}cd $release_dir${NC}"
    echo -e "  ${YELLOW}./start.sh${NC}"
}

# Error handling
set -e
trap 'print_error "Release build failed at line $LINENO"' ERR

# Execute main function
main "$@"