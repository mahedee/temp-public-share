#!/bin/bash

# File Generator Application Startup Script
# This script runs the application with external configuration files

APP_DIR="$(cd "$(dirname "$0")" && pwd)"
JAR_FILE="$APP_DIR/target/file-generator-1.0.0-jar-with-dependencies.jar"
CONFIG_DIR="$APP_DIR/config"
LOG_CONFIG="$CONFIG_DIR/log4j2.xml"

# Ensure directories exist
mkdir -p "$APP_DIR/logs"
mkdir -p "$APP_DIR/output"

# Check if JAR file exists
if [ ! -f "$JAR_FILE" ]; then
    echo "ERROR: JAR file not found at $JAR_FILE"
    echo "Please build the project first: mvn clean package"
    exit 1
fi

# Check if external log configuration exists
if [ ! -f "$LOG_CONFIG" ]; then
    echo "ERROR: External log4j2.xml not found at $LOG_CONFIG"
    echo "Please ensure config/log4j2.xml exists"
    exit 1
fi

echo "Starting File Generator Application..."
echo "Using external log configuration: $LOG_CONFIG"
echo "JAR file: $JAR_FILE"
echo ""

# Set Java options
JAVA_OPTS="-Dlog4j2.configurationFile=$LOG_CONFIG"
JAVA_OPTS="$JAVA_OPTS -Dfile.encoding=UTF-8"
JAVA_OPTS="$JAVA_OPTS -Xms512m -Xmx1024m"

# Start the application
cd "$APP_DIR"
java $JAVA_OPTS -jar "$JAR_FILE"

EXIT_CODE=$?
if [ $EXIT_CODE -ne 0 ]; then
    echo ""
    echo "Application exited with error code: $EXIT_CODE"
fi