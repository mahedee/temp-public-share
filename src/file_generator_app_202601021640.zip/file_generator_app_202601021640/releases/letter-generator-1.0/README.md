# letter-generator-1.0 Release Package

## Quick Start

### Windows
```
start.bat
```

### Linux/Unix
```
chmod +x start.sh
./start.sh
```

### Manual Execution
```
java -Dlog4j2.configurationFile=file:config/log4j2.xml -jar letter-generator-1.0.jar
```

## Directory Structure
- **letter-generator-1.0.jar**     - Main application JAR file (in root directory)
- **config/**      - Configuration files and templates
- **logs/**        - Application logs (auto-created)
- **output/**      - Generated files (auto-created)
  - **demand/**    - Demand letter files
  - **hold/**      - Hold letter files  
  - **relationship/** - Relationship termination letter files
- **start.bat**    - Windows startup script
- **start.sh**     - Unix startup script

## Configuration Files
- **config/application.properties** - Main application configuration
- **config/log4j2.xml** - Logging configuration
- **config/file-templates/** - XML file generation templates

## Important Notes
- Always run the application from this directory (where letter-generator-1.0.jar is located)
- Configuration files are in the config/ subdirectory
- Log files will be created in the logs/ directory
- Generated files will be created in the output/ directory

## Generated
- **Date:** 2025-12-31 19:28:02
- **Version:** 1.0
- **Build System:** Shell Release Builder
