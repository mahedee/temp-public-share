#!/bin/bash
# File Generator Application - Unix Startup Script
# Release: letter-generator-1.0
# Generated: 2025-12-31 19:28:02

echo "Starting File Generator Application..."
echo "Release: letter-generator-1.0"
echo "Working Directory: $(pwd)"

# Ensure required directories exist
mkdir -p logs
mkdir -p output/{demand,hold,relationship}

# Set Java options
JAVA_OPTS="-Dlog4j2.configurationFile=file:config/log4j2.xml"
JAVA_OPTS="$JAVA_OPTS -Dfile.encoding=UTF-8"
JAVA_OPTS="$JAVA_OPTS -Xms512m -Xmx1024m"

echo "JAR: letter-generator-1.0.jar"
echo "Config: config/log4j2.xml"
echo ""

# Start the application
java $JAVA_OPTS -jar "letter-generator-1.0.jar"

echo ""
echo "Application finished."
