@echo off
REM File Generator Application - Windows Startup Script
REM Release: letter-generator-1.0
REM Generated: 2025-12-31 19:28:02

echo Starting File Generator Application...
echo Release: letter-generator-1.0
echo Working Directory: %CD%

REM Ensure required directories exist
if not exist "logs" mkdir "logs"
if not exist "output" mkdir "output"
if not exist "output\demand" mkdir "output\demand"
if not exist "output\hold" mkdir "output\hold"
if not exist "output\relationship" mkdir "output\relationship"

REM Set Java options
set JAVA_OPTS=-Dlog4j2.configurationFile=file:config\log4j2.xml
set JAVA_OPTS=%JAVA_OPTS% -Dfile.encoding=UTF-8
set JAVA_OPTS=%JAVA_OPTS% -Xms512m -Xmx1024m

echo JAR: letter-generator-1.0.jar
echo Config: config\log4j2.xml
echo.

REM Start the application
java %JAVA_OPTS% -jar "letter-generator-1.0.jar"

echo.
echo Application finished.
pause
