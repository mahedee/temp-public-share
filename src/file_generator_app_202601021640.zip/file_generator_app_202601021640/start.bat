@echo off
REM File Generator Application Startup Script
REM This script runs the application with external configuration files

set APP_DIR=%~dp0
set JAR_FILE=%APP_DIR%target\file-generator-1.0.0-jar-with-dependencies.jar
set CONFIG_DIR=%APP_DIR%config
set LOG_CONFIG=%CONFIG_DIR%\log4j2.xml

REM Ensure directories exist
if not exist "%APP_DIR%logs" mkdir "%APP_DIR%logs"
if not exist "%APP_DIR%output" mkdir "%APP_DIR%output"

REM Check if JAR file exists
if not exist "%JAR_FILE%" (
    echo ERROR: JAR file not found at %JAR_FILE%
    echo Please build the project first: mvn clean package
    pause
    exit /b 1
)

REM Check if external log configuration exists
if not exist "%LOG_CONFIG%" (
    echo ERROR: External log4j2.xml not found at %LOG_CONFIG%
    echo Please ensure config\log4j2.xml exists
    pause
    exit /b 1
)

echo Starting File Generator Application...
echo Using external log configuration: %LOG_CONFIG%
echo JAR file: %JAR_FILE%
echo.

REM Set Java options
set JAVA_OPTS=-Dlog4j2.configurationFile=%LOG_CONFIG%
set JAVA_OPTS=%JAVA_OPTS% -Dfile.encoding=UTF-8
set JAVA_OPTS=%JAVA_OPTS% -Xms512m -Xmx1024m

REM Start the application
cd /d "%APP_DIR%"
java %JAVA_OPTS% -jar "%JAR_FILE%"

if %ERRORLEVEL% neq 0 (
    echo.
    echo Application exited with error code: %ERRORLEVEL%
    pause
)