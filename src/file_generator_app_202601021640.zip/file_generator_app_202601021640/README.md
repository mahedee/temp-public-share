# File Generator Application

Enterprise-grade Java application for generating formatted files from Oracle database queries.

## Overview

The File Generator Application is a flexible, maintainable, and scalable solution that extracts data from Oracle databases and generates formatted output files based on configurable specifications. It supports multiple file formats (TXT, CSV) with customizable delimiters and can execute queries defined in XML configuration files or inline SQL statements.

## Features

### Core Features
- ✅ **Oracle Database Connectivity** - Connect to Oracle 11g and higher using JDBC
- ✅ **Connection Pooling** - Efficient database resource management with HikariCP
- ✅ **Properties + XML Config** - Properties for database/app settings, XML for file definitions
- ✅ **Multiple File Formats** - Support for TXT, CSV, and custom delimited files
- ✅ **Custom Delimiters** - Comma, pipe, tab, semicolon, or custom delimiters
- ✅ **Dynamic File Naming** - Pattern-based file naming with date/time stamps
- ✅ **Query Sources** - XML files or inline SQL queries
- ✅ **Enable/Disable Files** - Control file generation without removing configurations
- ✅ **Comprehensive Logging** - Detailed logging with Log4j2
- ✅ **Error Handling** - Robust exception handling and reporting

### File Naming Pattern
The application supports dynamic file naming with the pattern:
```
{FileName}.{FileSecondPart}.{DATE}{Time}.{extension}
```

Example: `DemandLetter.Monthly.20251206143000.txt`

## Architecture

The application follows a **layered architecture** pattern with clear separation of concerns:

```
├── Presentation Layer    (CLI, Console Output)
├── Service Layer        (Orchestration, Configuration, Query Execution, File Generation)
├── Business Layer       (File Name Generation, Data Transformation)
├── Data Access Layer    (Connection Manager, Query Repository)
└── Infrastructure Layer (Parsers, Writers, Utilities, Exceptions)
```

### Design Patterns
- **Factory Pattern** - File writer creation
- **Strategy Pattern** - Different file writing strategies
- **Repository Pattern** - Data access abstraction
- **Dependency Injection** - Loose coupling throughout

## Prerequisites

- Java Development Kit (JDK) 11 or higher
- Maven 3.6 or higher
- Oracle Database 11g or higher
- Oracle JDBC Driver (included in dependencies)

## Project Structure

```
file-generator/
├── config/
│   ├── application.properties           # Database & app-level settings
│   ├── file-config.xml             # File generation definitions
│   └── queries/
│       ├── DemandLetter.xml        # Query XML files
│       └── CustomerReport.xml
├── doc/
│   ├── Business-Requirements-Document.md
│   ├── High-Level-Solution-Architecture.md
│   └── Feature-List.md
├── logs/                            # Application logs (generated)
├── output/                          # Generated files (generated)
├── src/
│   ├── main/
│   │   ├── java/com/filegenerator/
│   │   │   ├── application/        # Application entry point
│   │   │   ├── business/           # Business logic
│   │   │   ├── infrastructure/     # Infrastructure components
│   │   │   ├── model/              # Domain models
│   │   │   ├── repository/         # Data access
│   │   │   └── service/            # Service layer
│   │   └── resources/
│   │       └── log4j2.xml          # Logging configuration
│   └── test/                        # Unit tests
├── pom.xml                          # Maven configuration
└── README.md                        # This file
```

## Installation

### 1. Clone the Repository
```bash
git clone https://github.com/mahedee/file-generator.git
cd file-generator
```

### 2. Build the Project
```bash
mvn clean package
```

This will create:
- `target/file-generator-1.0.0.jar` - Standalone JAR
- `target/file-generator-1.0.0-jar-with-dependencies.jar` - JAR with all dependencies

## Configuration

### Database & App Configuration (properties)

Edit `config/application.properties`:

```
db.url=jdbc:oracle:thin:@localhost:1521:ORCL
db.username=your_username
db.password=your_password
db.poolSize=10
db.maxPoolSize=20
# db.connectionTimeoutMs=30000
# db.idleTimeoutMs=600000

# Path to XML file definitions
file.config.path=config/file-config.xml
```

### File Configuration (XML)

Each file configuration in `config/file-config.xml` includes:

```xml
<file>
  <fileName>DemandLetter</fileName>
  <fileSecondPart>Monthly</fileSecondPart>
  <enabled>true</enabled>
  <fileFormat>TXT</fileFormat>
  <delimiter>COMMA</delimiter>
  <querySource>XML</querySource>
  <querySourceFile>config/queries/DemandLetter.xml</querySourceFile>
  <exportPath>output/demand_letters</exportPath>
  <includeHeader>true</includeHeader>
  <fileNamePattern>{FileName}.{FileSecondPart}.{DATE}{Time}.{extension}</fileNamePattern>
</file>
```

## Usage

### Run with Default Configuration
```bash
java -jar target/file-generator-1.0.0-jar-with-dependencies.jar
```

### Run with Custom Configuration
```bash
java -jar target/file-generator-1.0.0-jar-with-dependencies.jar --config=myconfig.properties
```

### Command-Line Options

```
Usage: java -jar file-generator.jar [OPTIONS]

Options:
  --config=<path>, -c <path>  Path to configuration properties file
  --help, -h                  Display help message
  --version, -v               Display version information
```

## Documentation

Comprehensive documentation is available in the `doc/` folder:

- **[Business Requirements Document](doc/Business-Requirements-Document.md)** - Business objectives, requirements, and specifications
- **[High-Level Solution Architecture](doc/High-Level-Solution-Architecture.md)** - System architecture, design patterns, and technology stack
- **[Feature List](doc/Feature-List.md)** - Detailed feature list with priorities and acceptance criteria

## Quick Start Example

1. **Update database configuration** in `config/application-config.xml`
2. **Build the project**: `mvn clean package`
3. **Run the application**: `java -jar target/file-generator-1.0.0-jar-with-dependencies.jar`
4. **Check output** in the `output/` directory

## Troubleshooting

**Database Connection Failed**
- Verify Oracle database is running
- Check connection string, username, and password
- Ensure Oracle JDBC driver is in classpath

**File Not Generated**
- Check `enabled` flag in configuration
- Verify export path exists and is writable
- Check logs in `logs/file-generator.log`

## Contributing

Contributions are welcome! Please follow these guidelines:

1. Fork the repository
2. Create a feature branch
3. Follow Java naming conventions
4. Write unit tests
5. Update documentation
6. Submit a pull request

## License

This project is licensed under the MIT License.

## Version History

### Version 1.0.0 (2025-12-06)
- Initial release
- Core file generation functionality
- Support for TXT and CSV formats
- XML and inline query sources
- Connection pooling
- Comprehensive logging

---

**File Generator Application v1.0.0**  
Copyright © 2025 mahedee. All rights reserved.
File generator app using java
