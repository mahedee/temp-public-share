package com.filegenerator.infrastructure.exception;

/**
 * Exception thrown for query execution errors.
 * Author: Mahedee Hasan
 */
public class QueryExecutionException extends DatabaseException {
    
    public QueryExecutionException(String message) {
        super(message);
    }

    public QueryExecutionException(String message, Throwable cause) {
        super(message, cause);
    }
}
