package com.filegenerator.model.dto;

import java.time.LocalDateTime;

/**
 * Author: Mahedee Hasan
 * Purpose: Result object for encryption/decryption operations
 */
public class EncryptionResult {
    private boolean success;
    private String filePath;
    private String message;
    private String errorMessage;
    private long executionTimeMs;
    private LocalDateTime timestamp;

    public EncryptionResult() {
        this.timestamp = LocalDateTime.now();
    }

    public static EncryptionResult success(String filePath, String message) {
        EncryptionResult result = new EncryptionResult();
        result.success = true;
        result.filePath = filePath;
        result.message = message;
        return result;
    }

    public static EncryptionResult failure(String errorMessage) {
        EncryptionResult result = new EncryptionResult();
        result.success = false;
        result.errorMessage = errorMessage;
        return result;
    }

    // Getters and Setters
    public boolean isSuccess() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public long getExecutionTimeMs() {
        return executionTimeMs;
    }

    public void setExecutionTimeMs(long executionTimeMs) {
        this.executionTimeMs = executionTimeMs;
    }

    public LocalDateTime getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(LocalDateTime timestamp) {
        this.timestamp = timestamp;
    }

    @Override
    public String toString() {
        return "EncryptionResult{" +
                "success=" + success +
                ", filePath='" + filePath + '\'' +
                ", message='" + message + '\'' +
                ", errorMessage='" + errorMessage + '\'' +
                ", executionTimeMs=" + executionTimeMs +
                ", timestamp=" + timestamp +
                '}';
    }
}