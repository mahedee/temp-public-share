package com.filegenerator.model.dto;

/**
 * Data Transfer Object for step execution results
 * Author: Mahedee Hasan
 * Purpose: Represents the result of executing a pre or post file generation step
 */
public class StepExecutionResult {
    
    private String stepName;
    private boolean success;
    private boolean skipped;
    private String message;
    private String errorMessage;
    private long executionTimeMs;
    private int affectedRows;
    
    /**
     * Private constructor - use factory methods
     */
    private StepExecutionResult(String stepName, boolean success, boolean skipped, 
                              String message, String errorMessage, long executionTimeMs, int affectedRows) {
        this.stepName = stepName;
        this.success = success;
        this.skipped = skipped;
        this.message = message;
        this.errorMessage = errorMessage;
        this.executionTimeMs = executionTimeMs;
        this.affectedRows = affectedRows;
    }
    
    /**
     * Factory method for successful step execution
     * @param stepName Name of the executed step
     * @param message Success message
     * @param executionTimeMs Execution time in milliseconds
     * @return StepExecutionResult for successful execution
     */
    public static StepExecutionResult success(String stepName, String message, long executionTimeMs) {
        return new StepExecutionResult(stepName, true, false, message, null, executionTimeMs, 0);
    }
    
    /**
     * Factory method for successful step execution with affected rows
     * @param stepName Name of the executed step
     * @param message Success message
     * @param executionTimeMs Execution time in milliseconds
     * @param affectedRows Number of affected rows
     * @return StepExecutionResult for successful execution
     */
    public static StepExecutionResult success(String stepName, String message, long executionTimeMs, int affectedRows) {
        return new StepExecutionResult(stepName, true, false, message, null, executionTimeMs, affectedRows);
    }
    
    /**
     * Factory method for failed step execution
     * @param stepName Name of the executed step
     * @param errorMessage Error message
     * @param executionTimeMs Execution time in milliseconds
     * @return StepExecutionResult for failed execution
     */
    public static StepExecutionResult failure(String stepName, String errorMessage, long executionTimeMs) {
        return new StepExecutionResult(stepName, false, false, null, errorMessage, executionTimeMs, 0);
    }
    
    /**
     * Factory method for skipped step execution
     * @param stepName Name of the skipped step
     * @param reason Reason why the step was skipped
     * @return StepExecutionResult for skipped execution
     */
    public static StepExecutionResult skipped(String stepName, String reason) {
        return new StepExecutionResult(stepName, true, true, reason, null, 0, 0);
    }
    
    // Getters
    public String getStepName() {
        return stepName;
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public boolean isSkipped() {
        return skipped;
    }
    
    public String getMessage() {
        return message;
    }
    
    public String getErrorMessage() {
        return errorMessage;
    }
    
    public long getExecutionTimeMs() {
        return executionTimeMs;
    }
    
    public int getAffectedRows() {
        return affectedRows;
    }
    
    /**
     * Checks if this is a critical failure (not success and not skipped)
     * @return true if this represents a critical failure
     */
    public boolean isCriticalFailure() {
        return !success && !skipped;
    }
    
    @Override
    public String toString() {
        if (skipped) {
            return String.format("Step[%s] SKIPPED: %s", stepName, message);
        } else if (success) {
            String affectedRowsInfo = affectedRows > 0 ? String.format(", rows: %d", affectedRows) : "";
            return String.format("Step[%s] SUCCESS (%dms%s): %s", stepName, executionTimeMs, affectedRowsInfo, message);
        } else {
            return String.format("Step[%s] FAILED (%dms): %s", stepName, executionTimeMs, errorMessage);
        }
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof StepExecutionResult)) return false;
        
        StepExecutionResult that = (StepExecutionResult) o;
        
        return success == that.success &&
               skipped == that.skipped &&
               executionTimeMs == that.executionTimeMs &&
               affectedRows == that.affectedRows &&
               stepName != null ? stepName.equals(that.stepName) : that.stepName == null &&
               message != null ? message.equals(that.message) : that.message == null &&
               errorMessage != null ? errorMessage.equals(that.errorMessage) : that.errorMessage == null;
    }
    
    @Override
    public int hashCode() {
        int result = stepName != null ? stepName.hashCode() : 0;
        result = 31 * result + (success ? 1 : 0);
        result = 31 * result + (skipped ? 1 : 0);
        result = 31 * result + (int) (executionTimeMs ^ (executionTimeMs >>> 32));
        result = 31 * result + affectedRows;
        return result;
    }
}