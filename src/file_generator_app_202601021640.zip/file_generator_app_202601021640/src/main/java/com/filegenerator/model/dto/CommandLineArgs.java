package com.filegenerator.model.dto;

import com.filegenerator.model.enums.OperationType;

/**
 * Author: Mahedee Hasan
 * Purpose: Model to hold parsed command line arguments
 */
public class CommandLineArgs {
    private OperationType operationType;
    private String configFilePath;
    private String text;
    private String secretKey;

    public CommandLineArgs() {
        // Default values
        this.operationType = OperationType.FILE_GENERATION;
        this.configFilePath = "config/application.properties";
    }

    // Getters and Setters
    public OperationType getOperationType() {
        return operationType;
    }

    public void setOperationType(OperationType operationType) {
        this.operationType = operationType;
    }

    public String getConfigFilePath() {
        return configFilePath;
    }

    public void setConfigFilePath(String configFilePath) {
        this.configFilePath = configFilePath;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public String getSecretKey() {
        return secretKey;
    }

    public void setSecretKey(String secretKey) {
        this.secretKey = secretKey;
    }

    @Override
    public String toString() {
        return "CommandLineArgs{" +
                "operationType=" + operationType +
                ", configFilePath='" + configFilePath + '\'' +
                ", text='" + (text != null ? "[HIDDEN]" : null) + '\'' +
                ", secretKey='" + (secretKey != null ? "[HIDDEN]" : null) + '\'' +
                '}';
    }
}