package com.filegenerator.infrastructure.exception;

/**
 * Purpose: This exception class handles file writing and I/O operation errors.
 * It is thrown when file creation, writing, or disk operations fail,
 * providing specific error context for file system-related problems.
 * Author: Mahedee Hasan
 */
public class FileWriteException extends FileGeneratorException {
    
    public FileWriteException(String message) {
        super(message);
    }

    public FileWriteException(String message, Throwable cause) {
        super(message, cause);
    }
}
