package com.filegenerator.infrastructure.writer;

/**
 * Purpose: This class implements CSV file writing functionality following RFC 4180 standards.
 * It handles proper escaping of values, quote handling, and comma-separated value formatting
 * for generating compliant CSV output files.
 * Author: Mahedee Hasan
 */
public class CsvFileWriter extends AbstractDelimitedFileWriter {

    public CsvFileWriter(String filePath) {
        super(filePath, ",");
    }

    @Override
    protected String escapeValue(String value) {
        if (value == null) {
            return "";
        }
        
        // Check if value needs quoting
        boolean needsQuoting = value.contains(",") || 
                              value.contains("\"") || 
                              value.contains("\n") || 
                              value.contains("\r");
        
        if (needsQuoting) {
            // Escape quotes by doubling them
            String escaped = value.replace("\"", "\"\"");
            return "\"" + escaped + "\"";
        }
        
        return value;
    }
}
