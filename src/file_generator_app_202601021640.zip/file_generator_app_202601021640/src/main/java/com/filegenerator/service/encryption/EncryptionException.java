package com.filegenerator.service.encryption;

/**
 * Purpose: Custom exception for encryption/decryption operations
 * Author: Mahedee Hasan
 */
public class EncryptionException extends Exception {
    
    public EncryptionException(String message) {
        super(message);
    }
    
    public EncryptionException(String message, Throwable cause) {
        super(message, cause);
    }
}