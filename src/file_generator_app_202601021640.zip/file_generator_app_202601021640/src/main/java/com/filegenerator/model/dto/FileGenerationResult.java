package com.filegenerator.model.dto;

/**
 * Author: Mahedee Hasan
 * Purpose: This class represents the result of a file generation operation
 * containing success status, file details, and execution metrics.
 */
public class FileGenerationResult {
    private String fileName;
    private String filePath;
    private boolean success;
    private long recordCount;
    private long executionTimeMs;
    private String errorMessage;
    private String message;

    public FileGenerationResult() {
    }

    public FileGenerationResult(String fileName, boolean success) {
        this.fileName = fileName;
        this.success = success;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFilePath() {
        return filePath;
    }

    public void setFilePath(String filePath) {
        this.filePath = filePath;
    }

    public boolean isSuccess() {
        return success;
    }

    public boolean isSuccessful() {
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }

    public void setSuccessful(boolean success) {
        this.success = success;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }

    public long getExecutionTimeMs() {
        return executionTimeMs;
    }

    public void setExecutionTimeMs(long executionTimeMs) {
        this.executionTimeMs = executionTimeMs;
    }

    public String getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
