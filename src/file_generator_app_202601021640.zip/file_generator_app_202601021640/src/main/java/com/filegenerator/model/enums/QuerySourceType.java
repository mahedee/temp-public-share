package com.filegenerator.model.enums;

/**
 * Purpose: This enumeration defines the supported query source types for file generation.
 * It specifies whether SQL queries should be loaded from XML files or provided inline.
 * Used to configure how SQL queries are sourced in file generation configurations.
 * Author: Mahedee Hasan
 */
public enum QuerySourceType {
    XML("XML File"),
    INLINE("Inline SQL");

    private final String description;

    /**
     * Purpose: Constructor to initialize the query source type with its description
     * @param description Human-readable description of the query source type
     */
    QuerySourceType(String description) {
        this.description = description;
    }

    /**
     * Purpose: Retrieves the human-readable description of the query source type
     * @return String The description of this query source type
     */
    public String getDescription() {
        return description;
    }

    /**
     * Purpose: Converts a string representation to the corresponding QuerySourceType enum
     * @param type The string representation of the query source type (case-insensitive)
     * @return QuerySourceType The matching enumeration value
     * @throws IllegalArgumentException If the type string does not match any valid enum value
     */
    public static QuerySourceType fromString(String type) {
        for (QuerySourceType querySourceType : QuerySourceType.values()) {
            if (querySourceType.name().equalsIgnoreCase(type)) {
                return querySourceType;
            }
        }
        throw new IllegalArgumentException("Unknown query source type: " + type);
    }
}
