package com.filegenerator.service.steps;

import com.filegenerator.model.configuration.PreFileGenerationStep;
import com.filegenerator.model.configuration.PostFileGenerationStep;
import com.filegenerator.model.dto.StepExecutionResult;
import com.filegenerator.repository.query.IQueryRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Implementation of step execution service
 * Author: Mahedee Hasan
 * Purpose: Executes pre and post file generation steps with comprehensive error handling
 */
public class StepExecutionServiceImpl implements IStepExecutionService {
    
    private static final Logger logger = LoggerFactory.getLogger(StepExecutionServiceImpl.class);
    
    private final IQueryRepository queryRepository;
    
    /**
     * Constructor
     * @param queryRepository Query repository for executing database operations
     */
    public StepExecutionServiceImpl(IQueryRepository queryRepository) {
        this.queryRepository = queryRepository;
    }
    
    @Override
    public List<StepExecutionResult> executePreFileGenerationSteps(List<PreFileGenerationStep> steps) {
        logger.info("Executing {} pre-file generation steps", steps.size());
        
        List<StepExecutionResult> results = new ArrayList<>();
        
        for (PreFileGenerationStep step : steps) {
            if (!step.isEnable()) {
                logger.debug("Skipping disabled pre-step: {}", step.getName());
                results.add(StepExecutionResult.skipped(step.getName(), "Step is disabled"));
                continue;
            }
            
            if (!validateStep(step.getName(), step.getQuery(), step.getQueryType())) {
                logger.warn("Invalid step configuration: {}", step.getName());
                results.add(StepExecutionResult.failure(step.getName(), "Invalid step configuration", 0));
                continue;
            }
            
            logger.info("Executing pre-step: {} (sequence: {})", step.getName(), step.getSequence());
            StepExecutionResult result = executeStep(step.getName(), step.getQuery(), step.getQueryType());
            results.add(result);
            
            if (result.isCriticalFailure()) {
                logger.error("Critical pre-step failed: {}", step.getName());
                // Continue with other steps but log the failure
            } else {
                logger.debug("Pre-step completed successfully: {}", step.getName());
            }
        }
        
        return results;
    }
    
    @Override
    public List<StepExecutionResult> executePostFileGenerationSteps(List<PostFileGenerationStep> steps) {
        logger.info("Executing {} post-file generation steps", steps.size());
        
        List<StepExecutionResult> results = new ArrayList<>();
        
        for (PostFileGenerationStep step : steps) {
            if (!step.isEnable()) {
                logger.debug("Skipping disabled post-step: {}", step.getName());
                results.add(StepExecutionResult.skipped(step.getName(), "Step is disabled"));
                continue;
            }
            
            if (!validateStep(step.getName(), step.getQuery(), step.getQueryType())) {
                logger.warn("Invalid step configuration: {}", step.getName());
                results.add(StepExecutionResult.failure(step.getName(), "Invalid step configuration", 0));
                continue;
            }
            
            logger.info("Executing post-step: {} (sequence: {})", step.getName(), step.getSequence());
            StepExecutionResult result = executeStep(step.getName(), step.getQuery(), step.getQueryType());
            results.add(result);
            
            if (result.isCriticalFailure()) {
                logger.error("Critical post-step failed: {}", step.getName());
                // Continue with other steps but log the failure
            } else {
                logger.debug("Post-step completed successfully: {}", step.getName());
            }
        }
        
        return results;
    }
    
    @Override
    public StepExecutionResult executeStep(String stepName, String query, String queryType) {
        long startTime = System.currentTimeMillis();
        
        try {
            switch (queryType.toLowerCase()) {
                case "select":
                case "read":
                    ResultSet resultSet = queryRepository.executeQuery(query);
                    // Count rows in result set
                    int rowCount = 0;
                    if (resultSet != null) {
                        resultSet.last();
                        rowCount = resultSet.getRow();
                        resultSet.close();
                    }
                    long selectDuration = System.currentTimeMillis() - startTime;
                    return StepExecutionResult.success(stepName, 
                        String.format("Query executed successfully. Rows returned: %d", rowCount),
                        selectDuration, rowCount);
                
                case "update":
                case "insert":
                case "delete":
                    int affectedRows = queryRepository.executeUpdate(query);
                    long updateDuration = System.currentTimeMillis() - startTime;
                    return StepExecutionResult.success(stepName,
                        String.format("Query executed successfully. Rows affected: %d", affectedRows),
                        updateDuration, affectedRows);
                
                case "procedure":
                case "call":
                    // For procedure calls, use executeUpdate
                    int procedureResult = queryRepository.executeUpdate(query);
                    long procedureDuration = System.currentTimeMillis() - startTime;
                    return StepExecutionResult.success(stepName,
                        "Procedure executed successfully",
                        procedureDuration, procedureResult);
                
                default:
                    return StepExecutionResult.failure(stepName, 
                        "Unknown query type: " + queryType + ". Supported types: select, read, update, insert, delete, procedure, call",
                        System.currentTimeMillis() - startTime);
            }
            
        } catch (Exception e) {
            long duration = System.currentTimeMillis() - startTime;
            logger.error("Step execution failed: {} - Query: {}", stepName, query, e);
            return StepExecutionResult.failure(stepName, 
                "Execution failed: " + e.getMessage(),
                duration);
        }
    }
    
    @Override
    public boolean validateStep(String stepName, String query, String queryType) {
        if (stepName == null || stepName.trim().isEmpty()) {
            logger.warn("Step validation failed: Step name is empty");
            return false;
        }
        
        if (query == null || query.trim().isEmpty()) {
            logger.warn("Step validation failed: Query is empty for step: {}", stepName);
            return false;
        }
        
        if (queryType == null || queryType.trim().isEmpty()) {
            logger.warn("Step validation failed: Query type is empty for step: {}", stepName);
            return false;
        }
        
        // Check if query type is supported
        String lowerCaseType = queryType.toLowerCase();
        if (!lowerCaseType.equals("select") && 
            !lowerCaseType.equals("read") && 
            !lowerCaseType.equals("update") && 
            !lowerCaseType.equals("insert") && 
            !lowerCaseType.equals("delete") && 
            !lowerCaseType.equals("procedure") && 
            !lowerCaseType.equals("call")) {
            
            logger.warn("Step validation failed: Unsupported query type '{}' for step: {}", queryType, stepName);
            return false;
        }
        
        return true;
    }
}