package com.filegenerator.service.security;

/**
 * Service interface for cryptographic operations.
 * Author: Mahedee Hasan
 */

public interface CryptoService {
    String generateKey();
    String generateKeyToFile(String outputDir);
    String encrypt(String plainText, String base64Key) throws Exception;
    String encryptToFile(String plainText, String base64Key, String outputDir) throws Exception;
    String decrypt(String encryptedText, String base64Key) throws Exception;
    String decryptToFile(String encryptedText, String base64Key, String outputDir) throws Exception;
}
