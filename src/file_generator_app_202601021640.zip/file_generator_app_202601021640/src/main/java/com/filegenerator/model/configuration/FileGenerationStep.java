package com.filegenerator.model.configuration;

/**
 * Abstract base class for file generation steps
 * Author: Mahedee Hasan
 * Purpose: Defines common properties and behavior for pre and post file generation steps
 */
public abstract class FileGenerationStep {
    
    private String name;
    private int sequence;
    private boolean enable;
    private String queryType;
    private String query;
    private String description;

    /**
     * Default constructor
     */
    public FileGenerationStep() {
        this.enable = true;
    }
    
    /**
     * Constructor with all parameters
     * @param name Name of the step
     * @param sequence Execution sequence order
     * @param enable Whether the step is enabled
     * @param queryType Type of query (select, update, insert, delete, procedure)
     * @param query SQL query or procedure call
     * @param description Description of what the step does
     */
    public FileGenerationStep(String name, int sequence, boolean enable, 
                            String queryType, String query, String description) {
        this.name = name;
        this.sequence = sequence;
        this.enable = enable;
        this.queryType = queryType;
        this.query = query;
        this.description = description;
    }

    /**
     * Purpose: Gets the step name
     * @return String The name of the step
     */
    public String getName() {
        return name;
    }

    /**
     * Purpose: Sets the step name
     * @param name The step name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Purpose: Gets the execution sequence order
     * @return int The sequence number
     */
    public int getSequence() {
        return sequence;
    }

    /**
     * Purpose: Sets the execution sequence order
     * @param sequence The sequence number
     */
    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    /**
     * Purpose: Checks if the step is enabled
     * @return boolean Whether the step is enabled
     */
    public boolean isEnable() {
        return enable;
    }

    /**
     * Purpose: Sets whether the step is enabled
     * @param enable Whether to enable the step
     */
    public void setEnable(boolean enable) {
        this.enable = enable;
    }

    /**
     * Purpose: Gets the query type (update, delete, etc.)
     * @return String The query type
     */
    public String getQueryType() {
        return queryType;
    }

    /**
     * Purpose: Sets the query type
     * @param queryType The query type (update, delete, etc.)
     */
    public void setQueryType(String queryType) {
        this.queryType = queryType;
    }

    /**
     * Purpose: Gets the SQL query to execute
     * @return String The SQL query
     */
    public String getQuery() {
        return query;
    }

    /**
     * Purpose: Sets the SQL query to execute
     * @param query The SQL query
     */
    public void setQuery(String query) {
        this.query = query;
    }
    
    /**
     * Purpose: Gets the step description
     * @return String The description of what the step does
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Purpose: Sets the step description
     * @param description The description of what the step does
     */
    public void setDescription(String description) {
        this.description = description;
    }
    
    /**
     * Validates if the step configuration is valid
     * @return true if valid, false otherwise
     */
    public boolean isValid() {
        return name != null && !name.trim().isEmpty() &&
               sequence >= 0 &&
               queryType != null && !queryType.trim().isEmpty() &&
               query != null && !query.trim().isEmpty();
    }
    
    @Override
    public String toString() {
        return String.format("Step[name=%s, sequence=%d, enabled=%s, type=%s]", 
                           name, sequence, enable, queryType);
    }
    
    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof FileGenerationStep)) return false;
        
        FileGenerationStep that = (FileGenerationStep) o;
        
        return sequence == that.sequence &&
               enable == that.enable &&
               name != null ? name.equals(that.name) : that.name == null;
    }
    
    @Override
    public int hashCode() {
        int result = name != null ? name.hashCode() : 0;
        result = 31 * result + sequence;
        result = 31 * result + (enable ? 1 : 0);
        return result;
    }
}