package com.filegenerator.model.enums;

/**
 * Purpose: This enumeration defines the supported file formats for file generation.
 * It includes text files with different delimiter configurations and CSV format.
 * Used to specify the output format and file extension for generated files.
 * Author: Mahedee Hasan
 */
public enum FileFormat {
    TXT("txt", "Plain Text"),
    CSV("csv", "Comma-Separated Values"),
    CUSTOM("txt", "Custom Delimiter");

    private final String extension;
    private final String description;

    /**
     * Purpose: Constructor to initialize file format with its extension and description
     * @param extension The file extension for this format (without the dot)
     * @param description Human-readable description of the file format
     */
    FileFormat(String extension, String description) {
        this.extension = extension;
        this.description = description;
    }

    /**
     * Purpose: Retrieves the file extension associated with this format
     * @return String The file extension (without the dot)
     */
    public String getExtension() {
        return extension;
    }

    /**
     * Purpose: Retrieves the human-readable description of the file format
     * @return String The description of this file format
     */
    public String getDescription() {
        return description;
    }

    /**
     * Purpose: Converts a string representation to the corresponding FileFormat enum
     * @param format The string representation of the file format (case-insensitive)
     * @return FileFormat The matching enumeration value
     * @throws IllegalArgumentException If the format string does not match any valid enum value
     */
    public static FileFormat fromString(String format) {
        for (FileFormat fileFormat : FileFormat.values()) {
            if (fileFormat.name().equalsIgnoreCase(format)) {
                return fileFormat;
            }
        }
        throw new IllegalArgumentException("Unknown file format: " + format);
    }
}
