package com.filegenerator.service.query;

import java.sql.ResultSet;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.infrastructure.parser.XmlQueryParser;
import com.filegenerator.model.configuration.FileConfiguration;
import com.filegenerator.repository.query.IQueryRepository;

/**
 * Author: Mahedee Hasan
 * Purpose: This class implements query execution services for both SELECT and UPDATE operations
 * used in file generation and pre/post processing steps.
 */
public class QueryExecutionServiceImpl implements IQueryExecutionService {
    
    private static final Logger logger = LoggerFactory.getLogger(QueryExecutionServiceImpl.class);
    
    private final IQueryRepository queryRepository;
    private final XmlQueryParser xmlQueryParser;

    public QueryExecutionServiceImpl(IQueryRepository queryRepository) {
        this.queryRepository = queryRepository;
        this.xmlQueryParser = new XmlQueryParser();
    }

    @Override
    public ResultSet executeQuery(FileConfiguration fileConfig) throws Exception {
        String sql = getSqlQuery(fileConfig);
        logger.info("Executing query for file: {}", fileConfig.getFileName());
        return queryRepository.executeQuery(sql);
    }

    @Override
    public int executeUpdate(String query) throws Exception {
        logger.debug("Executing update query: {}", query.substring(0, Math.min(50, query.length())) + "...");
        return queryRepository.executeUpdate(query);
    }

    @Override
    public void closeResources() {
        queryRepository.closeResources();
    }
    
    private String getSqlQuery(FileConfiguration fileConfig) throws ConfigurationException {
        // The query is already parsed and available in the FileConfiguration
        String query = fileConfig.getQuery();
        if (query == null || query.trim().isEmpty()) {
            throw new ConfigurationException("No query found in file configuration: " + fileConfig.getFileName());
        }
        logger.debug("Using parsed query from configuration");
        return query;
    }
}
