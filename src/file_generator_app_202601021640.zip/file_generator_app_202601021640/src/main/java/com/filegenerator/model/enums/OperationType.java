package com.filegenerator.model.enums;

/**
 * Author: Mahedee Hasan
 * Purpose: Enum for different operation types supported by the application
 */
public enum OperationType {
    FILE_GENERATION,
    ENCRYPT,
    DECRYPT,
    GENERATE_KEY,
    ENCRYPT_DB_PASSWORD
}