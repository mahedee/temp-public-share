package com.filegenerator.service.query;

import com.filegenerator.model.configuration.FileConfiguration;
import java.sql.ResultSet;

/**
 * Author: Mahedee Hasan
 * Purpose: This interface provides query execution services for both
 * SELECT queries (for file generation) and UPDATE/INSERT/DELETE queries (for pre/post steps).
 */
public interface IQueryExecutionService {
    
    /**
     * Purpose: Executes a query based on file configuration
     * @param fileConfig File configuration containing query details
     * @return ResultSet The query results
     * @throws Exception if execution fails
     */
    ResultSet executeQuery(FileConfiguration fileConfig) throws Exception;
    
    /**
     * Purpose: Executes an update/insert/delete query
     * @param query The SQL query to execute
     * @return int The number of affected rows
     * @throws Exception if execution fails
     */
    int executeUpdate(String query) throws Exception;
    
    /**
     * Purpose: Closes query resources
     */
    void closeResources();
}
