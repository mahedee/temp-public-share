package com.filegenerator.infrastructure.util;

public class CommandHandler {
    /**
     * Parse command string handling quoted arguments properly
     * This method is useful for hardcoded command strings in debugging
     * Author: Mahedee Hasan
     */
    public static String[] parseCommandString(String commandLine) {
        java.util.List<String> arguments = new java.util.ArrayList<>();
        boolean inQuotes = false;
        StringBuilder currentArg = new StringBuilder();

        for (char c : commandLine.toCharArray()) {
            if (c == '"') {
                inQuotes = !inQuotes;
            } else if (c == ' ' && !inQuotes) {
                if (currentArg.length() > 0) {
                    arguments.add(currentArg.toString());
                    currentArg.setLength(0);
                }
            } else {
                currentArg.append(c);
            }
        }

        // Add the last argument
        if (currentArg.length() > 0) {
            arguments.add(currentArg.toString());
        }

        return arguments.toArray(new String[0]);
    }
}
