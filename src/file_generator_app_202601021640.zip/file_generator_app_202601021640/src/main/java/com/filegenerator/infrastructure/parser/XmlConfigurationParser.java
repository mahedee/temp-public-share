package com.filegenerator.infrastructure.parser;

import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.model.configuration.ApplicationConfiguration;
import com.filegenerator.model.configuration.DatabaseConfiguration;
import com.filegenerator.model.configuration.FileConfiguration;
import com.filegenerator.model.enums.DelimiterType;
import com.filegenerator.model.enums.FileFormat;
import com.filegenerator.model.enums.QuerySourceType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

/**
 * Purpose: This class implements XML-based configuration parsing for the file generator.
 * It reads application configuration from XML files, extracting database settings,
 * file generation parameters, and other configuration details into application objects.
 * Author: Mahedee Hasan
 */
public class XmlConfigurationParser implements ConfigurationParser {
    
    private static final Logger logger = LoggerFactory.getLogger(XmlConfigurationParser.class);

    @Override
    public ApplicationConfiguration parse(String configFilePath) throws ConfigurationException {
        logger.info("Parsing configuration file: {}", configFilePath);
        
        try {
            File configFile = new File(configFilePath);
            if (!configFile.exists()) {
                throw new ConfigurationException("Configuration file not found: " + configFilePath);
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(configFile);
            document.getDocumentElement().normalize();

            ApplicationConfiguration appConfig = new ApplicationConfiguration();

            // Parse database configuration if present (optional when using properties)
            DatabaseConfiguration dbConfig = parseDatabaseConfiguration(document);
            if (dbConfig != null) {
                appConfig.setDatabaseConfiguration(dbConfig);
            }

            // Parse file configurations
            NodeList fileNodes = document.getElementsByTagName("file");
            for (int i = 0; i < fileNodes.getLength(); i++) {
                Node fileNode = fileNodes.item(i);
                if (fileNode.getNodeType() == Node.ELEMENT_NODE) {
                    FileConfiguration fileConfig = parseFileConfiguration((Element) fileNode);
                    appConfig.addFileConfiguration(fileConfig);
                }
            }

            logger.info("Successfully parsed configuration with {} file(s)", appConfig.getFileConfigurations().size());
            return appConfig;

        } catch (ConfigurationException e) {
            throw e;
        } catch (Exception e) {
            throw new ConfigurationException("Error parsing configuration file: " + e.getMessage(), e);
        }
    }

    private DatabaseConfiguration parseDatabaseConfiguration(Document document) throws ConfigurationException {
        Element databaseElement = (Element) document.getElementsByTagName("database").item(0);
        if (databaseElement == null) {
            // Database config may be provided via properties; skip if absent
            logger.debug("No <database> section found in XML; skipping database parsing");
            return null;
        }

        DatabaseConfiguration dbConfig = new DatabaseConfiguration();

        dbConfig.setConnectionString(getElementText(databaseElement, "connectionString"));
        dbConfig.setUsername(getElementText(databaseElement, "username"));
        dbConfig.setPassword(getElementText(databaseElement, "password"));

        String poolSize = getElementText(databaseElement, "poolSize");
        if (poolSize != null && !poolSize.isEmpty()) {
            dbConfig.setPoolSize(Integer.parseInt(poolSize));
        }

        String maxPoolSize = getElementText(databaseElement, "maxPoolSize");
        if (maxPoolSize != null && !maxPoolSize.isEmpty()) {
            dbConfig.setMaxPoolSize(Integer.parseInt(maxPoolSize));
        }

        return dbConfig;
    }

    private FileConfiguration parseFileConfiguration(Element fileElement) throws ConfigurationException {
        FileConfiguration fileConfig = new FileConfiguration();

        fileConfig.setFileName(getElementText(fileElement, "fileName"));
        fileConfig.setFileSecondPart(getElementText(fileElement, "fileSecondPart"));
        
        String enabled = getElementText(fileElement, "enabled");
        fileConfig.setEnabled(enabled == null || Boolean.parseBoolean(enabled));

        String fileFormat = getElementText(fileElement, "fileFormat");
        if (fileFormat != null) {
            fileConfig.setFileFormat(FileFormat.fromString(fileFormat));
        }

        String delimiter = getElementText(fileElement, "delimiter");
        if (delimiter != null) {
            try {
                fileConfig.setDelimiterType(DelimiterType.fromString(delimiter));
            } catch (IllegalArgumentException e) {
                // If not a standard delimiter type, treat as custom
                fileConfig.setDelimiterType(DelimiterType.CUSTOM);
                fileConfig.setCustomDelimiter(delimiter);
            }
        }

        String querySource = getElementText(fileElement, "querySource");
        if (querySource != null) {
            fileConfig.setQuerySource(QuerySourceType.fromString(querySource));
        }

        fileConfig.setQuerySourceFile(getElementText(fileElement, "querySourceFile"));
        fileConfig.setQuery(getElementText(fileElement, "query"));
        fileConfig.setExportPath(getElementText(fileElement, "exportPath"));

        String includeHeader = getElementText(fileElement, "includeHeader");
        if (includeHeader != null) {
            fileConfig.setIncludeHeader(Boolean.parseBoolean(includeHeader));
        }

        String fileNamePattern = getElementText(fileElement, "fileNamePattern");
        if (fileNamePattern != null && !fileNamePattern.isEmpty()) {
            fileConfig.setFileNamePattern(fileNamePattern);
        }

        return fileConfig;
    }

    private String getElementText(Element parent, String tagName) {
        NodeList nodeList = parent.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            Node node = nodeList.item(0);
            if (node != null) {
                return node.getTextContent();
            }
        }
        return null;
    }
}
