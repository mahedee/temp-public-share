package com.filegenerator.infrastructure.writer;

import java.io.IOException;
import java.util.List;

/**
 * Interface for file writers.
 */
public interface IFileWriter extends AutoCloseable {
    
    /**
     * Opens the file for writing.
     */
    void open() throws IOException;
    
    /**
     * Writes header row.
     */
    void writeHeader(List<String> headers) throws IOException;
    
    /**
     * Writes a data row.
     */
    void writeRow(List<Object> data) throws IOException;
    
    /**
     * Flushes the writer.
     */
    void flush() throws IOException;
    
    /**
     * Closes the writer and releases resources.
     */
    @Override
    void close() throws IOException;
}
