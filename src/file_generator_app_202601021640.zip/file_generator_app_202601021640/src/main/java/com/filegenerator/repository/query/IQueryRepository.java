package com.filegenerator.repository.query;

import java.sql.ResultSet;

/**
 * Author: Mahedee Hasan
 * Purpose: This interface provides database query operations for both
 * SELECT queries (returning results) and UPDATE/INSERT/DELETE queries (returning affected row counts).
 */
public interface IQueryRepository {
    
    /**
     * Purpose: Executes a SQL query and returns the result set
     * @param sql SQL query to execute
     * @return ResultSet containing query results
     * @throws Exception if query execution fails
     */
    ResultSet executeQuery(String sql) throws Exception;
    
    /**
     * Purpose: Executes an update/insert/delete SQL statement
     * @param sql SQL statement to execute
     * @return int The number of affected rows
     * @throws Exception if query execution fails
     */
    int executeUpdate(String sql) throws Exception;
    
    /**
     * Purpose: Closes resources associated with the repository
     */
    void closeResources();
}
