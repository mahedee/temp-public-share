package com.filegenerator.infrastructure.writer;

import com.filegenerator.model.enums.FileFormat;

/**
 * Factory interface for creating file writers.
 */
public interface FileWriterFactory {
    
    /**
     * Creates a file writer based on format and delimiter.
     * 
     * @param filePath Full path to the file
     * @param format File format
     * @param delimiter Delimiter string
     * @return IFileWriter instance
     */
    IFileWriter createFileWriter(String filePath, FileFormat format, String delimiter);
    public void saveToFile(String filePath, String fileText);
}
