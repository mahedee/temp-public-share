package com.filegenerator.infrastructure.parser;

import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.HashSet;
import java.util.Properties;
import java.util.Set;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.infrastructure.security.AESEncryptionEngine;
import com.filegenerator.model.configuration.ApplicationConfiguration;
import com.filegenerator.model.configuration.DatabaseConfiguration;
import com.filegenerator.model.configuration.DecryptionConfiguration;
import com.filegenerator.model.configuration.EncryptionConfiguration;
import com.filegenerator.model.configuration.FileConfiguration;
import com.filegenerator.model.configuration.FileGenerationSection;
import com.filegenerator.model.configuration.GeneralConfiguration;
import com.filegenerator.model.enums.DelimiterType;
import com.filegenerator.model.enums.FileFormat;
import com.filegenerator.model.enums.QuerySourceType;

/**
 * Purpose: This class parses configuration from properties files and individual XML query files
 * to build a complete ApplicationConfiguration object.
 * Author: Mahedee Hasan
 */
public class PropertiesConfigurationParser implements ConfigurationParser {
    
    private static final Logger logger = LoggerFactory.getLogger(PropertiesConfigurationParser.class);
    private final QueryXmlParser queryXmlParser;

    public PropertiesConfigurationParser() {
        this.queryXmlParser = new QueryXmlParser();
    }

    /**
     * Purpose: Parses configuration from properties file and associated XML query files
     * @param configFilePath Path to the properties configuration file
     * @return ApplicationConfiguration The complete configuration
     * @throws ConfigurationException If parsing fails
     */
    @Override
    public ApplicationConfiguration parse(String configFilePath) throws ConfigurationException {
        logger.info("Parsing properties configuration from: {}", configFilePath);
        
        try {
            Properties properties = loadProperties(configFilePath);
            ApplicationConfiguration appConfig = new ApplicationConfiguration();
            
            // Parse database configuration
            DatabaseConfiguration dbConfig = parseDatabaseConfiguration(properties);
            appConfig.setDatabaseConfiguration(dbConfig);
            
            // Parse file configurations
            parseFileConfigurations(properties, appConfig);
            
            // Parse encryption and decryption configurations
            EncryptionConfiguration encConfig = parseEncryptionConfiguration(properties);
            DecryptionConfiguration decConfig = parseDecryptionConfiguration(properties);
            appConfig.setEncryptionConfiguration(encConfig);
            appConfig.setDecryptionConfiguration(decConfig);

            // Parse general configuration
            GeneralConfiguration generalConfig = parseGeneralConfiguration(properties);
            appConfig.setGeneralConfiguration(generalConfig);
            
            logger.info("Successfully parsed properties configuration");
            return appConfig;
            
        } catch (Exception e) {
            String errorMsg = "Failed to parse properties configuration: " + configFilePath;
            logger.error(errorMsg, e);
            throw new ConfigurationException(errorMsg, e);
        }
    }

    /**
     * Purpose: Loads properties from file
     * @param configFilePath The properties file path
     * @return Properties The loaded properties
     * @throws ConfigurationException If loading fails
     */
    private Properties loadProperties(String configFilePath) throws ConfigurationException {
        Path path = Paths.get(configFilePath);
        Properties properties = new Properties();
        
        try (InputStream inputStream = Files.newInputStream(path)) {
            properties.load(inputStream);
            logger.debug("Loaded {} properties from {}", properties.size(), configFilePath);
            return properties;
        } catch (IOException e) {
            throw new ConfigurationException("Failed to load properties file: " + configFilePath, e);
        }
    }

    /**
     * Purpose: Parses database configuration from properties
     * @param properties The properties object
     * @return DatabaseConfiguration The database configuration
     * @throws ConfigurationException If configuration is invalid
     */
    private DatabaseConfiguration parseDatabaseConfiguration(Properties properties) throws ConfigurationException {
        try {
            String url = properties.getProperty("database.url");
            String user = properties.getProperty("database.user");
            String password = properties.getProperty("database.password");
            boolean isEncryptedPassword = Boolean.parseBoolean(
                properties.getProperty("database.isEncryptedPassword", "false")
            );
            
            if (url == null || url.trim().isEmpty()) {
                throw new ConfigurationException("Database URL is required");
            }
            
            if (user == null || user.trim().isEmpty()) {
                throw new ConfigurationException("Database user is required");
            }
            
            if (password == null || password.trim().isEmpty()) {
                throw new ConfigurationException("Database password is required");
            }
            
            // Validate password encryption flag matches password format
            if (isEncryptedPassword) {
                if (!AESEncryptionEngine.isPasswordEncrypted(password)) {
                    logger.warn("Password is marked as encrypted but doesn't appear to be in encrypted format");
                }
                logger.info("Database configuration loaded with encrypted password");
            } else {
                if (AESEncryptionEngine.isPasswordEncrypted(password)) {
                    logger.warn("Password appears encrypted but encryption flag is false");
                }
                logger.info("Database configuration loaded with plain text password");
            }
            
            DatabaseConfiguration dbConfig = new DatabaseConfiguration();
            dbConfig.setUrl(url);
            dbConfig.setUsername(user);
            dbConfig.setPasswordWithEncryptionFlag(password, isEncryptedPassword);
            
            // Test password decryption if encrypted
            // if (isEncryptedPassword) {
            //     try {
            //         String testDecryption = dbConfig.getPlainPassword();
            //         logger.debug("Password decryption test successful");
            //     } catch (Exception e) {
            //         throw new ConfigurationException("Invalid encrypted password - decryption failed", e);
            //     }
            // }
            
            // Connection pool settings (with defaults)
            dbConfig.setMaxPoolSize(Integer.parseInt(
                properties.getProperty("database.pool.maxPoolSize", "10")));
            dbConfig.setMinPoolSize(Integer.parseInt(
                properties.getProperty("database.pool.minPoolSize", "2")));
            dbConfig.setConnectionTimeout(Long.parseLong(
                properties.getProperty("database.pool.connectionTimeout", "30000")));
            
            return dbConfig;
            
        } catch (Exception e) {
            if (e instanceof ConfigurationException) {
                throw e;
            }
            logger.error("Error loading database configuration", e);
            throw new ConfigurationException("Failed to load database configuration", e);
        }
    }

    /**
     * Purpose: Parses file configurations from properties
     * @param properties The properties object
     * @param appConfig The application configuration to populate
     * @throws ConfigurationException If parsing fails
     */
    private void parseFileConfigurations(Properties properties, ApplicationConfiguration appConfig) 
            throws ConfigurationException {
        
        // Find all file configuration prefixes
        Set<String> fileConfigKeys = findFileConfigurationKeys(properties);
        
        for (String fileKey : fileConfigKeys) {
            if (Boolean.parseBoolean(properties.getProperty("file." + fileKey + ".enabled", "true"))) {
                FileConfiguration fileConfig = parseFileConfiguration(properties, fileKey);
                appConfig.addFileConfiguration(fileConfig);
            }
        }
    }

    /**
     * Purpose: Finds all file configuration keys from properties
     * @param properties The properties object
     * @return Set<String> The file configuration keys
     */
    private Set<String> findFileConfigurationKeys(Properties properties) {
        Set<String> fileKeys = new HashSet<>();
        
        for (String key : properties.stringPropertyNames()) {
            if (key.startsWith("file.") && key.contains(".")) {
                // Extract file type from key like "file.demandLetter.enabled"
                String remainingKey = key.substring(5); // Remove "file." prefix
                
                if (remainingKey.contains(".")) {
                    String fileKey = remainingKey.substring(0, remainingKey.indexOf(".")); // Extract "demandLetter"
                    fileKeys.add(fileKey);
                }
            }
        }
        
        logger.info("Discovered {} file types: {}", fileKeys.size(), fileKeys);
        return fileKeys;
    }

    /**
     * Purpose: Parses a single file configuration
     * @param properties The properties object
     * @param fileKey The file configuration key (e.g., "demandLetter", "holdLetter")
     * @return FileConfiguration The parsed file configuration
     * @throws ConfigurationException If parsing fails
     */
    private FileConfiguration parseFileConfiguration(Properties properties, String fileKey) 
            throws ConfigurationException {
        
        FileConfiguration fileConfig = new FileConfiguration();
        
        String prefix = "file." + fileKey + ".";
        
        // Set the file type identifier
        fileConfig.setFileTypeId(fileKey);
        
        // Basic properties
        fileConfig.setFileName(properties.getProperty(prefix + "fileName"));
        fileConfig.setExportPath(properties.getProperty(prefix + "exportPath", "output/"));
        fileConfig.setEnabled(Boolean.parseBoolean(properties.getProperty(prefix + "enabled", "true")));
        
        // File format
        String fileType = properties.getProperty(prefix + "fileType", "txt");
        fileConfig.setFileFormat(FileFormat.fromString(fileType));
        
        // Delimiter
        String delimiter = properties.getProperty(prefix + "delimiter", ",");
        fileConfig.setDelimiterType(DelimiterType.fromDelimiter(delimiter));
        if (fileConfig.getDelimiterType() == DelimiterType.CUSTOM) {
            fileConfig.setCustomDelimiter(delimiter);
        }
        
        // Query source
        String querySource = properties.getProperty(prefix + "querySource", "xml");
        fileConfig.setQuerySource(QuerySourceType.fromString(querySource));
        
        // If XML source, parse the XML file
        if (fileConfig.getQuerySource() == QuerySourceType.XML) {
            String queryFile = properties.getProperty(prefix + "queryFile");
            if (queryFile != null) {
                String xmlPath = queryFile;
                FileGenerationSection section = queryXmlParser.parseQueryXml(xmlPath);
                fileConfig.setQuery(section.getQuery());
                fileConfig.setQuerySourceFile(xmlPath);
                
                // Store the parsed section for later use
                // This will be used by the orchestrator for pre/post steps
                fileConfig.setFileGenerationSection(section);
                
                // Transfer steps from FileGenerationSection to FileConfiguration
                // This enables the orchestrator to use the FileConfiguration methods
                if (section.getPreFileGenerationSteps() != null) {
                    fileConfig.setPreFileGenerationSteps(section.getPreFileGenerationSteps());
                }
                if (section.getPostFileGenerationSteps() != null) {
                    fileConfig.setPostFileGenerationSteps(section.getPostFileGenerationSteps());
                }
                
                logger.info("Successfully loaded file configuration for: {} from {}", fileKey, xmlPath);
            }
        } else {
            // Direct query from properties
            fileConfig.setQuery(properties.getProperty(prefix + "query"));
        }
        
        return fileConfig;
    }

    /**
     * Purpose: Parses encryption configuration from properties
     * @param properties The properties object
     * @return EncryptionConfiguration The encryption configuration
     */
    private EncryptionConfiguration parseEncryptionConfiguration(Properties properties) {
        EncryptionConfiguration config = new EncryptionConfiguration();
        
        config.setOutputDirectory(properties.getProperty("encryption.output.directory", "output/encrypted"));
        config.setAlgorithm(properties.getProperty("encryption.algorithm", "AES"));
        config.setKeySize(Integer.parseInt(properties.getProperty("encryption.key.size", "256")));
        config.setFileExtension(properties.getProperty("encryption.file.extension", ".enc"));
        
        logger.debug("Parsed encryption configuration: {}", config);
        return config;
    }

    /**
     * Purpose: Parses decryption configuration from properties
     * @param properties The properties object
     * @return DecryptionConfiguration The decryption configuration
     */
    private DecryptionConfiguration parseDecryptionConfiguration(Properties properties) {
        DecryptionConfiguration config = new DecryptionConfiguration();
        
        config.setOutputDirectory(properties.getProperty("decryption.output.directory", "output/decrypted"));
        config.setFileExtension(properties.getProperty("decryption.file.extension", ".dec"));
        
        logger.debug("Parsed decryption configuration: {}", config);
        return config;
    }

    private GeneralConfiguration parseGeneralConfiguration(Properties properties) { 

        GeneralConfiguration config = new GeneralConfiguration();
        config.setAppName(properties.getProperty("app.name", "File Generator"));
        config.setAppVersion(properties.getProperty("app.version", "1.0.0"));
        config.setAppBuildDate(properties.getProperty("app.buildDate", "2025-12-06"));
        return config;
    }
        // This method can be implemented to parse general configuration if needed
}