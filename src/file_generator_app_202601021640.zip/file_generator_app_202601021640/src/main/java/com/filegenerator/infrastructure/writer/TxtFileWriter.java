package com.filegenerator.infrastructure.writer;

/**
 * Purpose: This class implements plain text file writing functionality with minimal escaping.
 * It specializes in generating text files with configurable delimiters for simple
 * data output without complex formatting requirements.
 * Author: Mahedee Hasan
 */
public class TxtFileWriter extends AbstractDelimitedFileWriter {

    public TxtFileWriter(String filePath, String delimiter) {
        super(filePath, delimiter);
    }

    @Override
    protected String escapeValue(String value) {
        // For TXT files, minimal escaping
        if (value == null) {
            return "";
        }
        return value;
    }
}
