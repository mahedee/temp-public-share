package com.filegenerator.service.encryption;

import com.filegenerator.model.dto.EncryptionResult;

/**
 * Author: Mahedee Hasan
 * Purpose: Service interface for encryption operations
 */
public interface IEncryptionService {
    
    /**
     * Encrypts text and saves to file
     * @param text Text to encrypt
     * @param outputDirectory Directory to save encrypted file
     * @param secretKey Secret key for encryption
     * @return EncryptionResult with operation details
     */
    EncryptionResult encryptText(String text, String outputDirectory, String secretKey);
    
    /**
     * Decrypts text and saves to file
     * @param text Text to decrypt
     * @param outputDirectory Directory to save decrypted file
     * @param secretKey Secret key for decryption
     * @return EncryptionResult with operation details
     */
    EncryptionResult decryptText(String text, String outputDirectory, String secretKey);
    
    /**
     * Encrypts content from input file and saves to output file
     * @param inputFilePath Path to input file
     * @param outputDirectory Directory to save encrypted file
     * @param secretKey Secret key for encryption
     * @return EncryptionResult with operation details
     */
    EncryptionResult encryptFromFile(String inputFilePath, String outputDirectory, String secretKey);
    
    /**
     * Decrypts content from input file and saves to output file
     * @param inputFilePath Path to input file
     * @param outputDirectory Directory to save decrypted file
     * @param secretKey Secret key for decryption
     * @return EncryptionResult with operation details
     */
    EncryptionResult decryptFromFile(String inputFilePath, String outputDirectory, String secretKey);
    
    /**
     * Generates a new secret key and saves to file
     * @param outputDirectory Directory to save key file
     * @return EncryptionResult with operation details
     */
    EncryptionResult generateKeyToFile(String outputDirectory);
}