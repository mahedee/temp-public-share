package com.filegenerator.service.orchestration;

import com.filegenerator.model.configuration.ApplicationConfiguration;
import java.util.List;
import com.filegenerator.model.dto.FileGenerationResult;

/**
 * Interface for file generation orchestrator.
 */
public interface IFileGenerationOrchestrator {
    
    /**
     * Orchestrates the file generation process for all configurations.
     * 
     * @param appConfig Application configuration
     * @return List of file generation results
     */
    List<FileGenerationResult> orchestrateFileGeneration(ApplicationConfiguration appConfig);
}
