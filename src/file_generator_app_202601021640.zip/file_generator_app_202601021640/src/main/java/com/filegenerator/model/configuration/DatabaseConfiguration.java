package com.filegenerator.model.configuration;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.infrastructure.security.AESEncryptionEngine;
import com.filegenerator.service.encryption.EncryptionException;

/**
 * Author: Mahedee Hasan
 * Purpose: This class represents database configuration including connection details
 * and connection pool settings for the file generator application.
 */
public class DatabaseConfiguration {
    
    private static final Logger logger = LoggerFactory.getLogger(DatabaseConfiguration.class);
    
    private String url;
    private String username;
    private String password;
    private boolean encryptedPassword;
    private int minPoolSize;
    private int maxPoolSize;
    private long connectionTimeout;
    private long idleTimeout;

    public DatabaseConfiguration() {
        // Default values
        this.encryptedPassword = false;
        this.minPoolSize = 2;
        this.maxPoolSize = 10;
        this.connectionTimeout = 30000; // 30 seconds
        this.idleTimeout = 600000; // 10 minutes
    }

    /**
     * Purpose: Gets the database URL
     * @return String The database connection URL
     */
    public String getUrl() {
        return url;
    }

    /**
     * Purpose: Sets the database URL
     * @param url The database connection URL
     */
    public void setUrl(String url) {
        this.url = url;
    }

    /**
     * Purpose: Gets the database username
     * @return String The database username
     */
    public String getUsername() {
        return username;
    }

    /**
     * Purpose: Sets the database username
     * @param username The database username
     */
    public void setUsername(String username) {
        this.username = username;
    }

    /**
     * Purpose: Gets the database password (plain text or encrypted)
     * @return String The database password as stored in configuration
     */
    public String getPassword() {
        return password;
    }

    /**
     * Gets the plain text password, decrypting if necessary
     * @return Plain text password for database connection
     * @throws Exception 
     * @throws RuntimeException If decryption fails
     */
    public String getPlainPassword() throws Exception {
        if (!encryptedPassword) {
            return password;
        }
        
        try {
            String decryptedPassword = AESEncryptionEngine.decrypt(password);
            //DatabasePasswordService.decryptPassword(password);
            logger.debug("Database password decrypted for connection");
            return decryptedPassword;
        } catch (EncryptionException e) {
            logger.error("Failed to decrypt database password", e);
            throw new RuntimeException("Cannot connect to database: password decryption failed", e);
        }
    }

    /**
     * Purpose: Sets the database password
     * @param password The database password
     */
    public void setPassword(String password) {
        this.password = password;
    }

    /**
     * Sets the password and encryption flag together
     * @param password The password (encrypted or plain)
     * @param isEncrypted Whether the password is encrypted
     */
    public void setPasswordWithEncryptionFlag(String password, boolean isEncrypted) {
        this.password = password;
        this.encryptedPassword = isEncrypted;
    }

    /**
     * Purpose: Checks if password is encrypted
     * @return boolean Whether the password is encrypted
     */
    public boolean isEncryptedPassword() {
        return encryptedPassword;
    }

    /**
     * Purpose: Sets whether password is encrypted
     * @param encryptedPassword Whether the password is encrypted
     */
    public void setEncryptedPassword(boolean encryptedPassword) {
        this.encryptedPassword = encryptedPassword;
    }

    /**
     * Purpose: Gets the minimum pool size
     * @return int The minimum pool size
     */
    public int getMinPoolSize() {
        return minPoolSize;
    }

    /**
     * Purpose: Sets the minimum pool size
     * @param minPoolSize The minimum pool size
     */
    public void setMinPoolSize(int minPoolSize) {
        this.minPoolSize = minPoolSize;
    }

    /**
     * Purpose: Gets the maximum pool size
     * @return int The maximum pool size
     */
    public int getMaxPoolSize() {
        return maxPoolSize;
    }

    /**
     * Purpose: Sets the maximum pool size
     * @param maxPoolSize The maximum pool size
     */
    public void setMaxPoolSize(int maxPoolSize) {
        this.maxPoolSize = maxPoolSize;
    }

    /**
     * Purpose: Gets the connection timeout
     * @return long The connection timeout in milliseconds
     */
    public long getConnectionTimeout() {
        return connectionTimeout;
    }

    /**
     * Purpose: Sets the connection timeout
     * @param connectionTimeout The connection timeout in milliseconds
     */
    public void setConnectionTimeout(long connectionTimeout) {
        this.connectionTimeout = connectionTimeout;
    }

    /**
     * Purpose: Gets the idle timeout
     * @return long The idle timeout in milliseconds
     */
    public long getIdleTimeout() {
        return idleTimeout;
    }

    /**
     * Purpose: Sets the idle timeout
     * @param idleTimeout The idle timeout in milliseconds
     */
    public void setIdleTimeout(long idleTimeout) {
        this.idleTimeout = idleTimeout;
    }

    // Legacy methods for backward compatibility
    /**
     * Purpose: Gets the connection string (alias for URL)
     * @return String The database connection URL
     * @deprecated Use getUrl() instead
     */
    @Deprecated
    public String getConnectionString() {
        return url;
    }

    /**
     * Purpose: Sets the connection string (alias for URL)
     * @param connectionString The database connection URL
     * @deprecated Use setUrl() instead
     */
    @Deprecated
    public void setConnectionString(String connectionString) {
        this.url = connectionString;
    }

    /**
     * Purpose: Gets the pool size (alias for minPoolSize)
     * @return int The minimum pool size
     * @deprecated Use getMinPoolSize() instead
     */
    @Deprecated
    public int getPoolSize() {
        return minPoolSize;
    }

    /**
     * Purpose: Sets the pool size (alias for minPoolSize)
     * @param poolSize The minimum pool size
     * @deprecated Use setMinPoolSize() instead
     */
    @Deprecated
    public void setPoolSize(int poolSize) {
        this.minPoolSize = poolSize;
    }
}
