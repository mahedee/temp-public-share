package com.filegenerator.service.steps;

import com.filegenerator.model.configuration.PreFileGenerationStep;
import com.filegenerator.model.configuration.PostFileGenerationStep;
import com.filegenerator.model.dto.StepExecutionResult;
import java.util.List;

/**
 * Service interface for executing file generation steps
 * Author: Mahedee Hasan
 * Purpose: Provides methods to execute pre and post file generation steps
 */
public interface IStepExecutionService {
    
    /**
     * Executes a list of pre-file generation steps
     * @param steps List of pre-file generation steps to execute
     * @return List of execution results
     */
    List<StepExecutionResult> executePreFileGenerationSteps(List<PreFileGenerationStep> steps);
    
    /**
     * Executes a list of post-file generation steps
     * @param steps List of post-file generation steps to execute
     * @return List of execution results
     */
    List<StepExecutionResult> executePostFileGenerationSteps(List<PostFileGenerationStep> steps);
    
    /**
     * Executes a single step
     * @param stepName Name of the step for logging
     * @param query SQL query or procedure to execute
     * @param queryType Type of query (select, update, insert, delete, procedure)
     * @return Execution result
     */
    StepExecutionResult executeStep(String stepName, String query, String queryType);
    
    /**
     * Validates if a step can be executed based on its configuration
     * @param stepName Name of the step
     * @param query SQL query
     * @param queryType Query type
     * @return true if step is valid and can be executed
     */
    boolean validateStep(String stepName, String query, String queryType);
}