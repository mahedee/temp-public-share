package com.filegenerator.infrastructure.parser;

import java.io.File;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.model.configuration.FileGenerationSection;
import com.filegenerator.model.configuration.FileGenerationStep;
import com.filegenerator.model.configuration.PostFileGenerationStep;
import com.filegenerator.model.configuration.PreFileGenerationStep;

/**
 * Purpose: This class parses individual XML query files (like DemandLetter.xml, HoldLetter.xml)
 * and extracts file generation configuration including pre/post steps and main query.
 * Author: Mahedee Hasan
 */
public class QueryXmlParser {
    
    private static final Logger logger = LoggerFactory.getLogger(QueryXmlParser.class);

    /**
     * Purpose: Parses a query XML file and returns the file generation section
     * @param xmlFilePath The path to the XML query file
     * @return FileGenerationSection The parsed configuration
     * @throws ConfigurationException If parsing fails
     */
    public FileGenerationSection parseQueryXml(String xmlFilePath) throws ConfigurationException {
        logger.info("Parsing query XML file: {}", xmlFilePath);
        
        try {
            File xmlFile = new File(xmlFilePath);
            DocumentBuilderFactory dbFactory = DocumentBuilderFactory.newInstance();
            DocumentBuilder dBuilder = dbFactory.newDocumentBuilder();
            Document doc = dBuilder.parse(xmlFile);
            doc.getDocumentElement().normalize();

            FileGenerationSection section = new FileGenerationSection();
            
            Element root = doc.getDocumentElement();
            
            // Parse global variables
            parseGlobalVariables(root, section);
            
            // Parse pre file generation steps
            parsePreFileGenerationSteps(root, section);
            
            // Parse file header section
            parseFileHeaderSection(root, section);
            
            // Parse main file generation section
            parseFileGenerationSection(root, section);
            
            // Parse post file generation steps
            parsePostFileGenerationSteps(root, section);
            
            logger.info("Successfully parsed query XML file: {}", xmlFilePath);
            return section;
            
        } catch (Exception e) {
            String errorMsg = "Failed to parse query XML file: " + xmlFilePath;
            logger.error(errorMsg, e);
            throw new ConfigurationException(errorMsg, e);
        }
    }

    /**
     * Purpose: Parses global variables from the XML
     * @param root The root element
     * @param section The section to populate
     */
    private void parseGlobalVariables(Element root, FileGenerationSection section) {
        NodeList globalVarsNodeList = root.getElementsByTagName("globalVariables");
        if (globalVarsNodeList.getLength() > 0) {
            Element globalVarsElement = (Element) globalVarsNodeList.item(0);
            NodeList children = globalVarsElement.getChildNodes();
            
            for (int i = 0; i < children.getLength(); i++) {
                Node child = children.item(i);
                if (child.getNodeType() == Node.ELEMENT_NODE) {
                    Element childElement = (Element) child;
                    String key = childElement.getTagName();
                    String value = childElement.getTextContent().trim();
                    section.addGlobalVariable(key, value);
                }
            }
        }
    }

    /**
     * Purpose: Parses pre file generation steps
     * Supports both single preFileGenerationStep and multiple preFileGenerationSteps structure
     * @param root The root element
     * @param section The section to populate
     */
    private void parsePreFileGenerationSteps(Element root, FileGenerationSection section) {
        // First check for new multiple steps structure
        NodeList preStepsContainerList = root.getElementsByTagName("preFileGenerationSteps");
        
        if (preStepsContainerList.getLength() > 0) {
            // New structure with multiple steps container
            Element preStepsContainer = (Element) preStepsContainerList.item(0);
            NodeList stepsList = preStepsContainer.getElementsByTagName("preFileGenerationStep");
            
            for (int i = 0; i < stepsList.getLength(); i++) {
                Element stepElement = (Element) stepsList.item(i);
                PreFileGenerationStep step = parsePreFileGenerationStep(stepElement);
                section.addPreFileGenerationStep(step);
                logger.debug("Added pre-generation step: {} (enabled: {})", step.getName(), step.isEnable());
            }
        } else {
            // Legacy structure - single step directly under root
            NodeList stepsList = root.getElementsByTagName("preFileGenerationStep");
            for (int i = 0; i < stepsList.getLength(); i++) {
                Element stepElement = (Element) stepsList.item(i);
                PreFileGenerationStep step = parsePreFileGenerationStep(stepElement);
                section.addPreFileGenerationStep(step);
                logger.debug("Added legacy pre-generation step: {} (enabled: {})", step.getName(), step.isEnable());
            }
        }
    }

    /**
     * Purpose: Parses post file generation steps
     * Supports both single postFileGenerationStep and multiple postFileGenerationSteps structure
     * @param root The root element
     * @param section The section to populate
     */
    private void parsePostFileGenerationSteps(Element root, FileGenerationSection section) {
        // First check for new multiple steps structure
        NodeList postStepsContainerList = root.getElementsByTagName("postFileGenerationSteps");
        
        if (postStepsContainerList.getLength() > 0) {
            // New structure with multiple steps container
            Element postStepsContainer = (Element) postStepsContainerList.item(0);
            NodeList stepsList = postStepsContainer.getElementsByTagName("postFileGenerationStep");
            
            for (int i = 0; i < stepsList.getLength(); i++) {
                Element stepElement = (Element) stepsList.item(i);
                PostFileGenerationStep step = parsePostFileGenerationStep(stepElement);
                section.addPostFileGenerationStep(step);
                logger.debug("Added post-generation step: {} (enabled: {})", step.getName(), step.isEnable());
            }
        } else {
            // Legacy structure - single step directly under root
            NodeList stepsList = root.getElementsByTagName("postFileGenerationStep");
            for (int i = 0; i < stepsList.getLength(); i++) {
                Element stepElement = (Element) stepsList.item(i);
                PostFileGenerationStep step = parsePostFileGenerationStep(stepElement);
                section.addPostFileGenerationStep(step);
                logger.debug("Added legacy post-generation step: {} (enabled: {})", step.getName(), step.isEnable());
            }
        }
    }

    /**
     * Purpose: Parses file header section
     * @param root The root element
     * @param section The section to populate
     */
    private void parseFileHeaderSection(Element root, FileGenerationSection section) {
        NodeList headerList = root.getElementsByTagName("fileHeaderSection");
        if (headerList.getLength() > 0) {
            Element headerElement = (Element) headerList.item(0);
            FileGenerationStep headerStep = parseStep(headerElement);
            section.setFileHeaderSection(headerStep);
        }
    }

    /**
     * Purpose: Parses a single file generation step (for header sections)
     * @param stepElement The step element
     * @return FileGenerationStep The parsed step
     */
    private FileGenerationStep parseStep(Element stepElement) {
        FileGenerationStep step = new FileGenerationStep() {}; // Anonymous subclass since FileGenerationStep is abstract
        
        step.setName(getElementText(stepElement, "name"));
        step.setSequence(Integer.parseInt(getElementText(stepElement, "sequence", "0")));
        step.setEnable(Boolean.parseBoolean(getElementText(stepElement, "enable", "true")));
        step.setQueryType(getElementText(stepElement, "queryType"));
        step.setQuery(getElementText(stepElement, "query"));
        step.setDescription(getElementText(stepElement, "description", ""));
        
        return step;
    }
    
    /**
     * Purpose: Parses a pre file generation step
     * @param stepElement The step element
     * @return PreFileGenerationStep The parsed step
     */
    private PreFileGenerationStep parsePreFileGenerationStep(Element stepElement) {
        PreFileGenerationStep step = new PreFileGenerationStep();
        
        step.setName(getElementText(stepElement, "name"));
        step.setSequence(Integer.parseInt(getElementText(stepElement, "sequence", "0")));
        step.setEnable(Boolean.parseBoolean(getElementText(stepElement, "enable", "true")));
        step.setQueryType(getElementText(stepElement, "queryType"));
        step.setQuery(getElementText(stepElement, "query"));
        step.setDescription(getElementText(stepElement, "description", ""));
        
        return step;
    }
    
    /**
     * Purpose: Parses a post file generation step
     * @param stepElement The step element
     * @return PostFileGenerationStep The parsed step
     */
    private PostFileGenerationStep parsePostFileGenerationStep(Element stepElement) {
        PostFileGenerationStep step = new PostFileGenerationStep();
        
        step.setName(getElementText(stepElement, "name"));
        step.setSequence(Integer.parseInt(getElementText(stepElement, "sequence", "0")));
        step.setEnable(Boolean.parseBoolean(getElementText(stepElement, "enable", "true")));
        step.setQueryType(getElementText(stepElement, "queryType"));
        step.setQuery(getElementText(stepElement, "query"));
        step.setDescription(getElementText(stepElement, "description", ""));
        
        return step;
    }

    /**
     * Purpose: Parses the main file generation section
     * @param root The root element
     * @param section The section to populate
     */
    private void parseFileGenerationSection(Element root, FileGenerationSection section) {
        NodeList sectionList = root.getElementsByTagName("fileGenerationSection");
        if (sectionList.getLength() > 0) {
            Element sectionElement = (Element) sectionList.item(0);
            
            section.setName(getElementText(sectionElement, "name"));
            section.setSequence(Integer.parseInt(getElementText(sectionElement, "sequence", "20")));
            section.setQuery(getElementText(sectionElement, "query"));
            
            // Parse columns
            NodeList columnsList = sectionElement.getElementsByTagName("columns");
            if (columnsList.getLength() > 0) {
                Element columnsElement = (Element) columnsList.item(0);
                NodeList columnNodes = columnsElement.getElementsByTagName("column");
                
                for (int i = 0; i < columnNodes.getLength(); i++) {
                    Element columnElement = (Element) columnNodes.item(i);
                    section.addColumn(columnElement.getTextContent().trim());
                }
            }
        }
    }

    /**
     * Purpose: Gets text content from a child element
     * @param parent The parent element
     * @param tagName The child tag name
     * @return String The text content, or empty string if not found
     */
    private String getElementText(Element parent, String tagName) {
        return getElementText(parent, tagName, "");
    }

    /**
     * Purpose: Gets text content from a child element with default value
     * @param parent The parent element
     * @param tagName The child tag name
     * @param defaultValue The default value if not found
     * @return String The text content or default value
     */
    private String getElementText(Element parent, String tagName, String defaultValue) {
        NodeList nodeList = parent.getElementsByTagName(tagName);
        if (nodeList.getLength() > 0) {
            return nodeList.item(0).getTextContent().trim();
        }
        return defaultValue;
    }
}