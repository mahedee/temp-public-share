package com.filegenerator.infrastructure.parser;

import com.filegenerator.infrastructure.exception.ConfigurationException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import java.io.File;

/**
 * Purpose: This class parses XML files to extract SQL queries for file generation.
 * It handles XML document parsing, query element extraction, and provides
 * configured SQL queries to the file generation process.
 * Author: Mahedee Hasan
 */
public class XmlQueryParser {
    
    private static final Logger logger = LoggerFactory.getLogger(XmlQueryParser.class);

    /**
     * Parses a query from an XML file.
     * 
     * @param queryFilePath Path to the query XML file
     * @return SQL query string
     * @throws ConfigurationException if parsing fails
     */
    public String parseQuery(String queryFilePath) throws ConfigurationException {
        logger.debug("Parsing query file: {}", queryFilePath);
        
        try {
            File queryFile = new File(queryFilePath);
            if (!queryFile.exists()) {
                throw new ConfigurationException("Query file not found: " + queryFilePath);
            }

            DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
            DocumentBuilder builder = factory.newDocumentBuilder();
            Document document = builder.parse(queryFile);
            document.getDocumentElement().normalize();

            Element root = document.getDocumentElement();
            String query = getElementText(root, "sql");

            if (query == null || query.trim().isEmpty()) {
                throw new ConfigurationException("Query not found in file: " + queryFilePath);
            }

            logger.debug("Successfully parsed query from file: {}", queryFilePath);
            return query.trim();

        } catch (ConfigurationException e) {
            throw e;
        } catch (Exception e) {
            throw new ConfigurationException("Error parsing query file: " + e.getMessage(), e);
        }
    }

    private String getElementText(Element parent, String tagName) {
        org.w3c.dom.NodeList nodeList = parent.getElementsByTagName(tagName);
        if (nodeList != null && nodeList.getLength() > 0) {
            org.w3c.dom.Node node = nodeList.item(0);
            if (node != null) {
                return node.getTextContent();
            }
        }
        return null;
    }
}
