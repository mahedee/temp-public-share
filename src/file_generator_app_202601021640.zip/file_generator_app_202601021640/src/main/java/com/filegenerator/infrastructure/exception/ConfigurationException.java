package com.filegenerator.infrastructure.exception;

/**
 * Purpose: This exception class handles configuration-related errors in the file generator.
 * It is thrown when configuration files are invalid, missing, or contain incorrect
 * parameters that prevent proper application initialization.
 * Author: Mahedee Hasan
 */
public class ConfigurationException extends FileGeneratorException {
    
    public ConfigurationException(String message) {
        super(message);
    }

    public ConfigurationException(String message, Throwable cause) {
        super(message, cause);
    }
}
