// package com.filegenerator.service.configuration;

// import com.filegenerator.infrastructure.exception.ConfigurationException;
// import com.filegenerator.model.configuration.ApplicationConfiguration;

// /**
//  * Interface for configuration service.
//  */
// public interface ConfigurationService {
    
//     /**
//      * Loads application configuration from file.
//      * 
//      * @param configFilePath Path to configuration file
//      * @return ApplicationConfiguration
//      * @throws ConfigurationException if loading fails
//      */
//     ApplicationConfiguration loadConfiguration(String configFilePath) throws ConfigurationException;
    
//     /**
//      * Validates the configuration.
//      * 
//      * @param configuration Application configuration
//      * @throws ConfigurationException if validation fails
//      */
//     void validateConfiguration(ApplicationConfiguration configuration) throws ConfigurationException;
// }
