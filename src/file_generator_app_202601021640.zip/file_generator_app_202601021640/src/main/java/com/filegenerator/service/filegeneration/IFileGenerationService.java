package com.filegenerator.service.filegeneration;

import com.filegenerator.model.configuration.FileConfiguration;
import com.filegenerator.model.dto.FileGenerationResult;

import java.sql.ResultSet;

/**
 * Interface for file generation service.
 */
public interface IFileGenerationService {
    
    /**
     * Generates a file based on configuration.
     * 
     * @param fileConfig File configuration
     * @return FileGenerationResult
     */
    FileGenerationResult generateFile(FileConfiguration fileConfig);
    
    /**
     * Generates a file with optional header data based on configuration.
     * 
     * @param fileConfig File configuration
     * @param headerResultSet Optional header data to write before main data (can be null)
     * @return FileGenerationResult
     */
    FileGenerationResult generateFile(FileConfiguration fileConfig, ResultSet headerResultSet);
}
