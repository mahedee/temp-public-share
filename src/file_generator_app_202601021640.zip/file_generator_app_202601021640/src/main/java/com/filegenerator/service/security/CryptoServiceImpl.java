package com.filegenerator.service.security;

import com.filegenerator.constants.AppConstants;
import com.filegenerator.infrastructure.security.AESEncryptionEngine;
import com.filegenerator.infrastructure.writer.FileWriterFactory;
import com.filegenerator.infrastructure.writer.FileWriterFactoryImpl;

/**
 * Implementation of CryptoService for cryptographic operations.
 * Author: Mahedee Hasan
 */

public class CryptoServiceImpl implements CryptoService {

    // File names for storing key, encrypted text, and decrypted text is configured in AppConstants
    String keyFileName =  AppConstants.KEY_FILE_NAME;
    String encryptedTextFile = AppConstants.ENCRYPTED_TEXT_FILE_NAME;
    String decryptedTextFile = AppConstants.DECRYPTED_TEXT_FILE_NAME;


    private final FileWriterFactory fileWriterFactory;
  
    public CryptoServiceImpl(){
        this.fileWriterFactory = new FileWriterFactoryImpl();
    }

    public CryptoServiceImpl(FileWriterFactory fileWriterFactory){
        this.fileWriterFactory = fileWriterFactory;
    }

    @Override
    public String generateKey() {
        
        String key = "";
        //String encryptedDirPath = "";
        try {
            key = AESEncryptionEngine.generateSecretKey();
            //encryptedDirPath = ConfigurationManager.getEncryptedDirectory();
            //FileUtils.saveToFile(encryptedDirPath + "/" + keyFileName, key);
        } catch (Exception e) {
            // Handle exception
        }
        return "Generated Key: " + key;
    }

    

    @Override
    public String encrypt(String plainText, String base64Key) throws Exception {

        String encryptedDirPath = "";
        // try {
        //     String encrypteText = AESEncryptionEngine.encrypt(plainText, base64Key);
        //     encryptedDirPath = ConfigurationManager.getEncryptedDirectory();
        //     FileUtils.saveToFile(encryptedDirPath + "/" + encryptedTextFile, encrypteText);
        // } catch (Exception e) {
        //     throw new Exception("Encryption failed", e);
        // }
        return "Encrypted text saved in : " + encryptedDirPath + "/" + encryptedTextFile;
    }

    @Override
    public String decrypt(String encryptedText, String base64Key) throws Exception {
        String decryptedDirPath = "";
        try {
            // String decryptedText = AESEncryptionEngine.decrypt(encryptedText, base64Key);
            // decryptedDirPath = ConfigurationManager.getEncryptedDirectory();
            // FileUtils.saveToFile(decryptedDirPath + "/" + decryptedTextFile, decryptedText);
        } catch (Exception e) {
            throw new Exception("Decryption failed", e);
        }
        return "Decrypted text saved in : " + decryptedDirPath + "/" + decryptedTextFile;
    }

    @Override
    public String generateKeyToFile(String outputDir) {
        String key = "";
        String outputFilePath = outputDir + "/" + keyFileName;
        try {
            key = AESEncryptionEngine.generateSecretKey();
            //encryptedDirPath = ConfigurationManager.getEncryptedDirectory();
            //fileWriterFactory.createFileWriter(key, null, encryptedDirPath)
            //FileUtils.saveToFile(outputDir + "/" + keyFileName, key);
            fileWriterFactory.saveToFile(outputFilePath, key);
        } catch (Exception e) {
            // Handle exception
        }
        return "Key generated in : " + outputFilePath ;
    }

    @Override
    public String encryptToFile(String plainText, String base64Key, String outputDir) throws Exception {
        String encryptedFilePath = outputDir + "/" + encryptedTextFile;
        try {
            String encrypteText = AESEncryptionEngine.encrypt(plainText, base64Key);
            fileWriterFactory.saveToFile(encryptedFilePath, encrypteText);
        } catch (Exception e) {
            throw new Exception("Encryption failed", e);
        }
        return "Encrypted text saved in : " + encryptedFilePath;
    }

    @Override
    public String decryptToFile(String encryptedText, String base64Key, String outputDir) throws Exception {
        String decryptedFilePath = outputDir + "/" + decryptedTextFile;
        try {
            String decryptedText = AESEncryptionEngine.decrypt(encryptedText, base64Key);
            fileWriterFactory.saveToFile(decryptedFilePath, decryptedText);
        } catch (Exception e) {
            throw new Exception("Decryption failed", e);
        }
        return "Decrypted text saved in : " + decryptedFilePath;
    }
    
}

