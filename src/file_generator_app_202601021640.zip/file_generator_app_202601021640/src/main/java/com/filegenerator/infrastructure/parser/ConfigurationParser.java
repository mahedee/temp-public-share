package com.filegenerator.infrastructure.parser;

import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.model.configuration.ApplicationConfiguration;

/**
 * Interface for configuration parsers.
 * Author: Mahedee Hasan
 */
public interface ConfigurationParser {
    
    /**
     * Parses configuration from a file.
     * 
     * @param configFilePath Path to the configuration file
     * @return ApplicationConfiguration object
     * @throws ConfigurationException if parsing fails
     */
    ApplicationConfiguration parse(String configFilePath) throws ConfigurationException;
}
