package com.filegenerator.model.enums;

/**
 * Purpose: This enumeration defines the supported delimiter types for file generation.
 * It includes common delimiters like comma, pipe, tab, semicolon, and custom delimiters.
 * Used to specify field separators in generated text files.
 * Author: Mahedee Hasan
 */
public enum DelimiterType {
    COMMA(",", "Comma"),
    PIPE("|", "Pipe"),
    TAB("\t", "Tab"),
    SEMICOLON(";", "Semicolon"),
    CUSTOM("", "Custom");

    private final String delimiter;
    private final String description;

    /**
     * Purpose: Constructor to initialize delimiter type with its character and description
     * @param delimiter The actual delimiter character
     * @param description Human-readable description of the delimiter
     */
    DelimiterType(String delimiter, String description) {
        this.delimiter = delimiter;
        this.description = description;
    }

    /**
     * Purpose: Retrieves the actual delimiter character
     * @return String The delimiter character used for field separation
     */
    public String getDelimiter() {
        return delimiter;
    }

    /**
     * Purpose: Retrieves the human-readable description of the delimiter
     * @return String The description of this delimiter type
     */
    public String getDescription() {
        return description;
    }

    /**
     * Purpose: Converts a string representation to the corresponding DelimiterType enum
     * @param type The string representation of the delimiter type (case-insensitive)
     * @return DelimiterType The matching enumeration value
     * @throws IllegalArgumentException If the type string does not match any valid enum value
     */
    public static DelimiterType fromString(String type) {
        for (DelimiterType delimiterType : DelimiterType.values()) {
            if (delimiterType.name().equalsIgnoreCase(type)) {
                return delimiterType;
            }
        }
        throw new IllegalArgumentException("Unknown delimiter type: " + type);
    }

    /**
     * Purpose: Gets delimiter type from actual delimiter character
     * @param delimiter The delimiter character
     * @return DelimiterType The matching delimiter type, or CUSTOM if not found
     */
    public static DelimiterType fromDelimiter(String delimiter) {
        for (DelimiterType delimiterType : DelimiterType.values()) {
            if (delimiterType != CUSTOM && delimiterType.delimiter.equals(delimiter)) {
                return delimiterType;
            }
        }
        return CUSTOM;
    }
}
