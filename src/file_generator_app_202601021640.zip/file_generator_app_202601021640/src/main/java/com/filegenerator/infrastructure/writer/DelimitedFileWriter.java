package com.filegenerator.infrastructure.writer;

/**
 * Purpose: This class implements custom delimited file writing with configurable separators.
 * It extends the abstract delimited file writer to support any delimiter character
 * for flexible file format generation.
 * Author: Mahedee Hasan
 */
public class DelimitedFileWriter extends AbstractDelimitedFileWriter {

    public DelimitedFileWriter(String filePath, String delimiter) {
        super(filePath, delimiter);
    }

    @Override
    protected String escapeValue(String value) {
        if (value == null) {
            return "";
        }
        
        // For pipe and other delimiters, quote if the value contains the delimiter
        if (value.contains(delimiter)) {
            // Simple quoting strategy - wrap in quotes and escape existing quotes
            String escaped = value.replace("\"", "\"\"");
            return "\"" + escaped + "\"";
        }
        
        return value;
    }
}
