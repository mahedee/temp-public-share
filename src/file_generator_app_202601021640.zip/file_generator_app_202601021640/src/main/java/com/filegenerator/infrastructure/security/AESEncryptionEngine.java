package com.filegenerator.infrastructure.security;

import java.util.Base64;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.constants.AppConstants;

/**
 * AES Encryption Engine for encrypting and decrypting data.
 * Author: Mahedee Hasan
 */

public class AESEncryptionEngine {

    private static final Logger LOGGER = LoggerFactory.getLogger(AESEncryptionEngine.class);
    // private static final String ALGORITHM = "AES";
    // private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
    private static final String ALGORITHM = AppConstants.ENCRYPTION_ALGORITHM;
    private static final String TRANSFORMATION = AppConstants.TRANSFORMATION;
    private static final String SECRET_KEY = AppConstants.DEFAULT_SECRET_KEY;
    private static final int KEY_LENGTH = AppConstants.KEY_LENGTH;

    /**
     * Encrypt text using default secret key
     */
    public static String encrypt(String plainText) throws Exception {
        return encrypt(plainText, SECRET_KEY);
    }

    public static String encrypt(String plainText, String secretKey) throws Exception {
        try {
            LOGGER.debug("Starting encryption process");

            SecretKeySpec keySpec = new SecretKeySpec(
                    Base64.getDecoder().decode(secretKey), ALGORITHM);

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);

            byte[] encrypted = cipher.doFinal(plainText.getBytes());
            String encryptedText = Base64.getEncoder().encodeToString(encrypted);

            LOGGER.debug("Encryption completed successfully");
            return encryptedText;

        } catch (Exception e) {
            LOGGER.error("Encryption failed", e);
            throw new Exception("Failed to encrypt data", e);
        }
    }

    /**
     * Decrypt text using default secret key
     */
    public static String decrypt(String encryptedText) throws Exception {
        return decrypt(encryptedText, SECRET_KEY);
    }

    public static String decrypt(String encryptedText, String secretKey) throws Exception {
        try {
            LOGGER.debug("Starting decryption process");

            SecretKeySpec keySpec = new SecretKeySpec(
                    Base64.getDecoder().decode(secretKey), ALGORITHM);

            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, keySpec);

            byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
            String decryptedText = new String(decrypted);

            LOGGER.debug("Decryption completed successfully");
            return decryptedText;

        } catch (Exception e) {
            LOGGER.error("Decryption failed", e);
            throw new Exception("Failed to decrypt data", e);
        }
    }

    public static String generateSecretKey() throws Exception {
        try {
            LOGGER.debug("Generating new secret key");

            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
            keyGenerator.init(KEY_LENGTH);
            SecretKey secretKey = keyGenerator.generateKey();

            String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());

            LOGGER.debug("Secret key generated successfully");
            return encodedKey;

        } catch (Exception e) {
            LOGGER.error("Key generation failed", e);
            throw new Exception("Failed to generate secret key", e);
        }
    }


       
    /**
     * Validates if a password appears to be encrypted (Base64 format)
     * @param password The password to validate
     * @return true if password appears encrypted, false otherwise
     */
    public static boolean isPasswordEncrypted(String password) {
        try {
            Base64.getDecoder().decode(password);
            return password.length() > 20 && password.matches("^[A-Za-z0-9+/]*={0,2}$");
        } catch (IllegalArgumentException e) {
            return false;
        }
    }

}
