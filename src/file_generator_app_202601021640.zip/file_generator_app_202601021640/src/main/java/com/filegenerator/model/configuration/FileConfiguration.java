package com.filegenerator.model.configuration;

import com.filegenerator.model.enums.DelimiterType;
import com.filegenerator.model.enums.FileFormat;
import com.filegenerator.model.enums.QuerySourceType;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Purpose: This class represents configuration settings for a single file generation operation.
 * It contains file metadata, query specifications, formatting options, and processing steps.
 * Enhanced with dynamic file type support for flexible file generation configurations.
 * Author: Mahedee Hasan
 */
public class FileConfiguration {
    private String fileTypeId;  // New field: demandLetter, holdLetter, etc.
    private String fileName;
    private String fileSecondPart;
    private boolean enabled;
    private FileFormat fileFormat;
    private DelimiterType delimiterType;
    private String customDelimiter;
    private QuerySourceType querySource;
    private String querySourceFile;
    private String query;
    private String exportPath;
    private boolean includeHeader;
    private String fileNamePattern;
    private FileGenerationSection fileGenerationSection;
    
    // Multiple pre and post generation steps
    private List<PreFileGenerationStep> preFileGenerationSteps;
    private List<PostFileGenerationStep> postFileGenerationSteps;

    public FileConfiguration() {
        // Default values
        this.enabled = true;
        this.includeHeader = false;  // Don't include column headers by default
        this.fileNamePattern = "{FileName}.{FileSecondPart}.{DATE}{Time}.{extension}";
        
        // Initialize step lists
        this.preFileGenerationSteps = new ArrayList<>();
        this.postFileGenerationSteps = new ArrayList<>();
    }
    
    /**
     * Gets the file type identifier (e.g., "demandLetter", "holdLetter")
     */
    public String getFileTypeId() {
        return fileTypeId;
    }
    
    /**
     * Sets the file type identifier
     */
    public void setFileTypeId(String fileTypeId) {
        this.fileTypeId = fileTypeId;
    }
    
    /**
     * Gets a display name for this file configuration
     */
    public String getDisplayName() {
        return fileTypeId != null ? fileTypeId : "Unknown File Type";
    }

    /**
     * Gets the actual delimiter to use.
     * If delimiter type is CUSTOM, returns the custom delimiter, otherwise returns the delimiter from the type.
     */
    public String getActualDelimiter() {
        if (delimiterType == DelimiterType.CUSTOM) {
            return customDelimiter != null ? customDelimiter : ",";
        }
        return delimiterType.getDelimiter();
    }

    // Getters and setters
    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileSecondPart() {
        return fileSecondPart;
    }

    public void setFileSecondPart(String fileSecondPart) {
        this.fileSecondPart = fileSecondPart;
    }

    public boolean isEnabled() {
        return enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

    public FileFormat getFileFormat() {
        return fileFormat;
    }

    public void setFileFormat(FileFormat fileFormat) {
        this.fileFormat = fileFormat;
    }

    public DelimiterType getDelimiterType() {
        return delimiterType;
    }

    public void setDelimiterType(DelimiterType delimiterType) {
        this.delimiterType = delimiterType;
    }

    public String getCustomDelimiter() {
        return customDelimiter;
    }

    public void setCustomDelimiter(String customDelimiter) {
        this.customDelimiter = customDelimiter;
    }

    public QuerySourceType getQuerySource() {
        return querySource;
    }

    public void setQuerySource(QuerySourceType querySource) {
        this.querySource = querySource;
    }

    public String getQuerySourceFile() {
        return querySourceFile;
    }

    public void setQuerySourceFile(String querySourceFile) {
        this.querySourceFile = querySourceFile;
    }

    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    public String getExportPath() {
        return exportPath;
    }

    public void setExportPath(String exportPath) {
        this.exportPath = exportPath;
    }

    public boolean isIncludeHeader() {
        return includeHeader;
    }

    public void setIncludeHeader(boolean includeHeader) {
        this.includeHeader = includeHeader;
    }

    public String getFileNamePattern() {
        return fileNamePattern;
    }

    public void setFileNamePattern(String fileNamePattern) {
        this.fileNamePattern = fileNamePattern;
    }

    /**
     * Purpose: Gets the file generation section with pre/post steps
     * @return FileGenerationSection The file generation section
     */
    public FileGenerationSection getFileGenerationSection() {
        return fileGenerationSection;
    }

    /**
     * Purpose: Sets the file generation section
     * @param fileGenerationSection The file generation section
     */
    public void setFileGenerationSection(FileGenerationSection fileGenerationSection) {
        this.fileGenerationSection = fileGenerationSection;
    }
    
    /**
     * Purpose: Gets the list of pre-file generation steps
     * @return List<PreFileGenerationStep> The list of pre-file generation steps
     */
    public List<PreFileGenerationStep> getPreFileGenerationSteps() {
        return preFileGenerationSteps;
    }
    
    /**
     * Purpose: Sets the list of pre-file generation steps
     * @param preFileGenerationSteps The list of pre-file generation steps
     */
    public void setPreFileGenerationSteps(List<PreFileGenerationStep> preFileGenerationSteps) {
        this.preFileGenerationSteps = preFileGenerationSteps;
    }
    
    /**
     * Purpose: Gets the list of post-file generation steps
     * @return List<PostFileGenerationStep> The list of post-file generation steps
     */
    public List<PostFileGenerationStep> getPostFileGenerationSteps() {
        return postFileGenerationSteps;
    }
    
    /**
     * Purpose: Sets the list of post-file generation steps
     * @param postFileGenerationSteps The list of post-file generation steps
     */
    public void setPostFileGenerationSteps(List<PostFileGenerationStep> postFileGenerationSteps) {
        this.postFileGenerationSteps = postFileGenerationSteps;
    }
    
    /**
     * Purpose: Gets only the enabled pre-file generation steps in sequence order
     * @return List<PreFileGenerationStep> Enabled steps sorted by sequence
     */
    public List<PreFileGenerationStep> getEnabledPreSteps() {
        return preFileGenerationSteps.stream()
               .filter(PreFileGenerationStep::isEnable)
               .sorted((s1, s2) -> Integer.compare(s1.getSequence(), s2.getSequence()))
               .collect(Collectors.toList());
    }
    
    /**
     * Purpose: Gets only the enabled post-file generation steps in sequence order
     * @return List<PostFileGenerationStep> Enabled steps sorted by sequence
     */
    public List<PostFileGenerationStep> getEnabledPostSteps() {
        return postFileGenerationSteps.stream()
               .filter(PostFileGenerationStep::isEnable)
               .sorted((s1, s2) -> Integer.compare(s1.getSequence(), s2.getSequence()))
               .collect(Collectors.toList());
    }
    
    /**
     * Purpose: Adds a pre-file generation step
     * @param step The pre-file generation step to add
     */
    public void addPreFileGenerationStep(PreFileGenerationStep step) {
        this.preFileGenerationSteps.add(step);
    }
    
    /**
     * Purpose: Adds a post-file generation step
     * @param step The post-file generation step to add
     */
    public void addPostFileGenerationStep(PostFileGenerationStep step) {
        this.postFileGenerationSteps.add(step);
    }
}
