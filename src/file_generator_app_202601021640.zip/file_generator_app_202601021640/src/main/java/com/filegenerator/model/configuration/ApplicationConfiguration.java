package com.filegenerator.model.configuration;

import java.util.ArrayList;
import java.util.List;

/**
 * Purpose: This class represents the main application configuration model that holds database,
 * file generation, encryption, and decryption configurations. It serves as a container for
 * all configuration settings loaded from properties files and used throughout the application.
 * Author: Mahedee Hasan
 */
public class ApplicationConfiguration {
    private DatabaseConfiguration databaseConfiguration;
    private List<FileConfiguration> fileConfigurations;
    private EncryptionConfiguration encryptionConfiguration;
    private DecryptionConfiguration decryptionConfiguration;
    private GeneralConfiguration generalConfiguration;

    /**
     * Purpose: Default constructor that initializes the configuration with empty collections
     * and default encryption/decryption configurations.
     */
    public ApplicationConfiguration() {
        this.fileConfigurations = new ArrayList<>();
        this.encryptionConfiguration = new EncryptionConfiguration();
        this.decryptionConfiguration = new DecryptionConfiguration();
        this.generalConfiguration = new GeneralConfiguration();
    }

    /**
     * Purpose: Retrieves the database configuration settings
     * @return DatabaseConfiguration containing connection details and settings
     */
    public DatabaseConfiguration getDatabaseConfiguration() {
        return databaseConfiguration;
    }

    /**
     * Purpose: Sets the database configuration settings
     * @param databaseConfiguration The database configuration to set
     */
    public void setDatabaseConfiguration(DatabaseConfiguration databaseConfiguration) {
        this.databaseConfiguration = databaseConfiguration;
    }

    /**
     * Purpose: Retrieves the list of file generation configurations
     * @return List<FileConfiguration> containing all file generation settings
     */
    public List<FileConfiguration> getFileConfigurations() {
        return fileConfigurations;
    }

    /**
     * Purpose: Sets the list of file generation configurations
     * @param fileConfigurations The list of file configurations to set
     */
    public void setFileConfigurations(List<FileConfiguration> fileConfigurations) {
        this.fileConfigurations = fileConfigurations;
    }

    /**
     * Purpose: Adds a single file configuration to the list of configurations
     * @param fileConfiguration The file configuration to add
     */
    public void addFileConfiguration(FileConfiguration fileConfiguration) {
        this.fileConfigurations.add(fileConfiguration);
    }

    /**
     * Purpose: Retrieves the encryption configuration settings
     * @return EncryptionConfiguration containing encryption parameters
     */
    public EncryptionConfiguration getEncryptionConfiguration() {
        return encryptionConfiguration;
    }

    /**
     * Purpose: Sets the encryption configuration settings
     * @param encryptionConfiguration The encryption configuration to set
     */
    public void setEncryptionConfiguration(EncryptionConfiguration encryptionConfiguration) {
        this.encryptionConfiguration = encryptionConfiguration;
    }

    /**
     * Purpose: Retrieves the decryption configuration settings
     * @return DecryptionConfiguration containing decryption parameters
     */
    public DecryptionConfiguration getDecryptionConfiguration() {
        return decryptionConfiguration;
    }

    /**
     * Purpose: Sets the decryption configuration settings
     * @param decryptionConfiguration The decryption configuration to set
     */
    public void setDecryptionConfiguration(DecryptionConfiguration decryptionConfiguration) {
        this.decryptionConfiguration = decryptionConfiguration;
    }

    public void setGeneralConfiguration(GeneralConfiguration generalConfiguration) {   
        this.generalConfiguration = generalConfiguration;
    }

    public GeneralConfiguration getGeneralConfiguration() {
        return generalConfiguration;
    }
}
