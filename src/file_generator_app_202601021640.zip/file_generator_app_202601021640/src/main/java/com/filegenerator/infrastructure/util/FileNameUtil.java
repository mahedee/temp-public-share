package com.filegenerator.infrastructure.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.LinkedHashMap;
import java.util.Map;

public class FileNameUtil {

    private FileNameUtil() {
        // Private constructor to prevent instantiation
    }


        /**
     * Replaces placeholders in filename with actual date/time values.
     * 
     * @param fileName The filename template with placeholders
     * @return Filename with replaced values
     */
    public static String replacePlaceholders(String fileName) {
        LocalDateTime currentTime = LocalDateTime.now();
        
        // Create placeholder replacements map (ordered to handle longer patterns first)
        Map<String, String> replacements = new LinkedHashMap<>();
        
        // New explicit date/time format placeholders
        replacements.put("{YYYYMMDDHHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
        replacements.put("{YYYYMMDD_HHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")));
        replacements.put("{YYYY-MM-DD_HH:MM:SS}", currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")));
        replacements.put("{YYYYMMDD-HHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
        replacements.put("{YYYYMMDD}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
        replacements.put("{YYYY-MM-DD}", currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
        replacements.put("{YYYY_MM_DD}", currentTime.format(DateTimeFormatter.ofPattern("yyyy_MM_dd")));
        replacements.put("{DDMMYYYY}", currentTime.format(DateTimeFormatter.ofPattern("ddMMyyyy")));
        replacements.put("{DD-MM-YYYY}", currentTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        replacements.put("{MM/DD/YYYY}", currentTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        
        // Time-only placeholders
        replacements.put("{HHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("HHmmss")));
        replacements.put("{HH:MM:SS}", currentTime.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
        replacements.put("{HHMM}", currentTime.format(DateTimeFormatter.ofPattern("HHmm")));
        
        // Individual component placeholders
        replacements.put("{YYYY}", currentTime.format(DateTimeFormatter.ofPattern("yyyy")));
        replacements.put("{MM}", currentTime.format(DateTimeFormatter.ofPattern("MM")));
        replacements.put("{DD}", currentTime.format(DateTimeFormatter.ofPattern("dd")));
        replacements.put("{HH}", currentTime.format(DateTimeFormatter.ofPattern("HH")));
        replacements.put("{mm}", currentTime.format(DateTimeFormatter.ofPattern("mm")));
        replacements.put("{SS}", currentTime.format(DateTimeFormatter.ofPattern("ss")));
        
        // Legacy placeholders for backward compatibility (using DateTimeUtil)
        replacements.put("{DATE}", DateTimeUtil.getCurrentDate());
        replacements.put("{DATETIME}", DateTimeUtil.getCurrentDateTime());
        replacements.put("{Time}", DateTimeUtil.getCurrentTime());
        replacements.put("{TIMESTAMP}", DateTimeUtil.getCurrentTimestamp());
        
        // Special placeholders
        replacements.put("{CURRENT_TIMESTAMP}", String.valueOf(System.currentTimeMillis()));
        
        // Apply replacements
        for (Map.Entry<String, String> entry : replacements.entrySet()) {
            fileName = fileName.replace(entry.getKey(), entry.getValue());
        }
        
        return fileName;
    }
}