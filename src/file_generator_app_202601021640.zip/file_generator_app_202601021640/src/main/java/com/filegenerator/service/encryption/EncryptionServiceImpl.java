package com.filegenerator.service.encryption;

import com.filegenerator.infrastructure.writer.FileWriterFactory;
import com.filegenerator.model.dto.EncryptionResult;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Base64;

/**
 * Author: Mahedee Hasan
 * Purpose: Implementation of encryption service with integrated AES encryption business logic
 */
public class EncryptionServiceImpl implements IEncryptionService {
    
    private static final Logger logger = LoggerFactory.getLogger(EncryptionServiceImpl.class);
    private static final String ALGORITHM = "AES";
    private static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
    
    private final FileWriterFactory fileWriterFactory;
    
    public EncryptionServiceImpl(FileWriterFactory fileWriterFactory) {
        this.fileWriterFactory = fileWriterFactory;
    }

    @Override
    public EncryptionResult encryptText(String text, String outputDirectory, String secretKey) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.info("Starting text encryption");
            
            String encryptedText = encrypt(text, secretKey);
            String fileName = generateFileName("encrypted", ".enc");
            String filePath = writeToFile(outputDirectory, fileName, encryptedText);
            
            long executionTime = System.currentTimeMillis() - startTime;
            
            EncryptionResult result = EncryptionResult.success(filePath, "Text encryption completed successfully");
            result.setExecutionTimeMs(executionTime);
            
            logger.info("Text encryption completed in {} ms", executionTime);
            return result;
            
        } catch (EncryptionException | IOException e) {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("Text encryption failed after {} ms", executionTime, e);
            
            EncryptionResult result = EncryptionResult.failure("Text encryption failed: " + e.getMessage());
            result.setExecutionTimeMs(executionTime);
            return result;
        }
    }

    @Override
    public EncryptionResult decryptText(String text, String outputDirectory, String secretKey) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.info("Starting text decryption");
            
            String decryptedText = decrypt(text, secretKey);
            String fileName = generateFileName("decrypted", ".dec");
            String filePath = writeToFile(outputDirectory, fileName, decryptedText);
            
            long executionTime = System.currentTimeMillis() - startTime;
            
            EncryptionResult result = EncryptionResult.success(filePath, "Text decryption completed successfully");
            result.setExecutionTimeMs(executionTime);
            
            logger.info("Text decryption completed in {} ms", executionTime);
            return result;
            
        } catch (EncryptionException | IOException e) {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("Text decryption failed after {} ms", executionTime, e);
            
            EncryptionResult result = EncryptionResult.failure("Text decryption failed: " + e.getMessage());
            result.setExecutionTimeMs(executionTime);
            return result;
        }
    }

    @Override
    public EncryptionResult encryptFromFile(String inputFilePath, String outputDirectory, String secretKey) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.info("Starting file encryption from: {}", inputFilePath);
            
            String content = readFromFile(inputFilePath);
            String encryptedText = encrypt(content, secretKey);
            String fileName = generateFileName("encrypted_file", ".enc");
            String filePath = writeToFile(outputDirectory, fileName, encryptedText);
            
            long executionTime = System.currentTimeMillis() - startTime;
            
            EncryptionResult result = EncryptionResult.success(filePath, "File encryption completed successfully");
            result.setExecutionTimeMs(executionTime);
            
            logger.info("File encryption completed in {} ms", executionTime);
            return result;
            
        } catch (EncryptionException | IOException e) {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("File encryption failed after {} ms", executionTime, e);
            
            EncryptionResult result = EncryptionResult.failure("File encryption failed: " + e.getMessage());
            result.setExecutionTimeMs(executionTime);
            return result;
        }
    }

    @Override
    public EncryptionResult decryptFromFile(String inputFilePath, String outputDirectory, String secretKey) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.info("Starting file decryption from: {}", inputFilePath);
            
            String encryptedContent = readFromFile(inputFilePath);
            String decryptedText = decrypt(encryptedContent, secretKey);
            String fileName = generateFileName("decrypted_file", ".dec");
            String filePath = writeToFile(outputDirectory, fileName, decryptedText);
            
            long executionTime = System.currentTimeMillis() - startTime;
            
            EncryptionResult result = EncryptionResult.success(filePath, "File decryption completed successfully");
            result.setExecutionTimeMs(executionTime);
            
            logger.info("File decryption completed in {} ms", executionTime);
            return result;
            
        } catch (EncryptionException | IOException e) {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("File decryption failed after {} ms", executionTime, e);
            
            EncryptionResult result = EncryptionResult.failure("File decryption failed: " + e.getMessage());
            result.setExecutionTimeMs(executionTime);
            return result;
        }
    }

    @Override
    public EncryptionResult generateKeyToFile(String outputDirectory) {
        long startTime = System.currentTimeMillis();
        
        try {
            logger.info("Generating new secret key");
            
            String secretKey = generateSecretKey();
            String fileName = generateFileName("secret_key", ".key");
            String filePath = writeToFile(outputDirectory, fileName, secretKey);
            
            long executionTime = System.currentTimeMillis() - startTime;
            
            EncryptionResult result = EncryptionResult.success(filePath, "Secret key generated successfully");
            result.setExecutionTimeMs(executionTime);
            
            logger.info("Secret key generation completed in {} ms", executionTime);
            return result;
            
        } catch (EncryptionException | IOException e) {
            long executionTime = System.currentTimeMillis() - startTime;
            logger.error("Secret key generation failed after {} ms", executionTime, e);
            
            EncryptionResult result = EncryptionResult.failure("Secret key generation failed: " + e.getMessage());
            result.setExecutionTimeMs(executionTime);
            return result;
        }
    }

    private String generateFileName(String prefix, String extension) {
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        return String.format("%s_%s%s", prefix, timestamp, extension);
    }

    private String writeToFile(String outputDirectory, String fileName, String content) throws IOException {
        Path dirPath = Paths.get(outputDirectory);
        Files.createDirectories(dirPath);
        
        Path filePath = dirPath.resolve(fileName);
        Files.write(filePath, content.getBytes());
        
        logger.debug("Content written to file: {}", filePath.toString());
        return filePath.toString();
    }

    private String readFromFile(String filePath) throws IOException {
        Path path = Paths.get(filePath);
        if (!Files.exists(path)) {
            throw new IOException("File not found: " + filePath);
        }
        
        byte[] bytes = Files.readAllBytes(path);
        String content = new String(bytes);
        
        logger.debug("Content read from file: {}", filePath);
        return content;
    }

    /**
     * Encrypts plain text using AES algorithm.
     * 
     * @param plainText The text to encrypt
     * @param secretKey The base64 encoded secret key
     * @return Encrypted text encoded in base64
     * @throws EncryptionException If encryption fails
     */
    private String encrypt(String plainText, String secretKey) throws EncryptionException {
        try {
            logger.debug("Starting encryption process");
            
            SecretKeySpec keySpec = new SecretKeySpec(
                Base64.getDecoder().decode(secretKey), ALGORITHM);
            
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.ENCRYPT_MODE, keySpec);
            
            byte[] encrypted = cipher.doFinal(plainText.getBytes());
            String encryptedText = Base64.getEncoder().encodeToString(encrypted);
            
            logger.debug("Encryption completed successfully");
            return encryptedText;
            
        } catch (Exception e) {
            logger.error("Encryption failed", e);
            throw new EncryptionException("Encryption failed: " + e.getMessage(), e);
        }
    }

    /**
     * Decrypts encrypted text using AES algorithm.
     * 
     * @param encryptedText The base64 encoded encrypted text
     * @param secretKey The base64 encoded secret key
     * @return Decrypted plain text
     * @throws EncryptionException If decryption fails
     */
    private String decrypt(String encryptedText, String secretKey) throws EncryptionException {
        try {
            logger.debug("Starting decryption process");
            
            SecretKeySpec keySpec = new SecretKeySpec(
                Base64.getDecoder().decode(secretKey), ALGORITHM);
            
            Cipher cipher = Cipher.getInstance(TRANSFORMATION);
            cipher.init(Cipher.DECRYPT_MODE, keySpec);
            
            byte[] decrypted = cipher.doFinal(Base64.getDecoder().decode(encryptedText));
            String decryptedText = new String(decrypted);
            
            logger.debug("Decryption completed successfully");
            return decryptedText;
            
        } catch (Exception e) {
            logger.error("Decryption failed", e);
            throw new EncryptionException("Decryption failed: " + e.getMessage(), e);
        }
    }

    /**
     * Generates a new AES secret key.
     * 
     * @return Base64 encoded secret key
     * @throws EncryptionException If key generation fails
     */
    private String generateSecretKey() throws EncryptionException {
        try {
            logger.debug("Generating new secret key");
            
            KeyGenerator keyGenerator = KeyGenerator.getInstance(ALGORITHM);
            keyGenerator.init(256);
            SecretKey secretKey = keyGenerator.generateKey();
            
            String encodedKey = Base64.getEncoder().encodeToString(secretKey.getEncoded());
            
            logger.debug("Secret key generated successfully");
            return encodedKey;
            
        } catch (Exception e) {
            logger.error("Key generation failed", e);
            throw new EncryptionException("Key generation failed: " + e.getMessage(), e);
        }
    }
}