package com.filegenerator.infrastructure.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.constants.AppConstants;
import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.infrastructure.parser.ConfigurationParser;
import com.filegenerator.infrastructure.parser.PropertiesConfigurationParser;
import com.filegenerator.model.configuration.ApplicationConfiguration;
import com.filegenerator.model.configuration.DatabaseConfiguration;
import com.filegenerator.model.configuration.FileConfiguration;

public class ConfigurationManager {

    // Path to the configuration file
    public static final String CONFIG_FILE_PATH = AppConstants.APPLICATION_PROPERTIES_FILE_PATH;

    private static final Logger logger = LoggerFactory.getLogger(ConfigurationManager.class);

    private static ConfigurationParser configurationParser = new PropertiesConfigurationParser();

    private ConfigurationManager() {
    }

    public static ApplicationConfiguration geConfiguration() throws ConfigurationException {
        logger.info("Loading configuration from properties file: {}", CONFIG_FILE_PATH);

        // Use the properties configuration parser to load everything
        ApplicationConfiguration config = configurationParser.parse(CONFIG_FILE_PATH);

        // Validate the loaded configuration
        validateConfiguration(config);

        logger.info("Configuration loaded and validated successfully");
        return config;
    }

    public static void validateConfiguration(ApplicationConfiguration configuration) throws ConfigurationException {
        logger.debug("Validating configuration");

        // Validate application configuration
        ValidationUtil.validateNotNull(configuration, "Application configuration");

        // Validate database configuration
        DatabaseConfiguration dbConfig = configuration.getDatabaseConfiguration();
        ValidationUtil.validateNotNull(dbConfig, "Database configuration");
        ValidationUtil.validateNotEmpty(dbConfig.getUrl(), "Database URL");
        ValidationUtil.validateNotEmpty(dbConfig.getUsername(), "Database username");
        ValidationUtil.validateNotEmpty(dbConfig.getPassword(), "Database password");

        // Validate file configurations
        if (configuration.getFileConfigurations() == null || configuration.getFileConfigurations().isEmpty()) {
            throw new ConfigurationException("At least one file configuration is required");
        }

        for (FileConfiguration fileConfig : configuration.getFileConfigurations()) {
            validateFileConfiguration(fileConfig);
        }

        // Validate encryption configuration
        if (configuration.getEncryptionConfiguration() != null) {
            ValidationUtil.validateNotEmpty(configuration.getEncryptionConfiguration().getOutputDirectory(),
                    "Encryption output directory");
        }

        // Validate decryption configuration
        if (configuration.getDecryptionConfiguration() != null) {
            ValidationUtil.validateNotEmpty(configuration.getDecryptionConfiguration().getOutputDirectory(),
                    "Decryption output directory");
        }

        logger.debug("Configuration validation completed successfully");
    }

    /**
     * Purpose: Validates a single file configuration
     * 
     * @param fileConfig The file configuration to validate
     * @throws ConfigurationException If validation fails
     */
    private static void validateFileConfiguration(FileConfiguration fileConfig) throws ConfigurationException {
        ValidationUtil.validateNotEmpty(fileConfig.getFileName(), "File name");
        ValidationUtil.validateNotNull(fileConfig.getFileFormat(), "File format");
        ValidationUtil.validateNotNull(fileConfig.getDelimiterType(), "Delimiter type");
        ValidationUtil.validateNotNull(fileConfig.getQuerySource(), "Query source");
        ValidationUtil.validateNotEmpty(fileConfig.getExportPath(), "Export path");

        // Validate query source specific fields
        switch (fileConfig.getQuerySource()) {
            case XML:
                ValidationUtil.validateNotEmpty(fileConfig.getQuerySourceFile(), "Query source file");
                break;
            case INLINE:
                ValidationUtil.validateNotEmpty(fileConfig.getQuery(), "Inline query");
                break;
        }
    }

}
