package com.filegenerator.infrastructure.util;

import com.filegenerator.infrastructure.exception.ConfigurationException;

/**
 * Purpose: This utility class provides common validation methods for configuration values,
 * parameters, and user inputs. It centralizes validation logic and ensures consistent
 * error handling throughout the application.
 * Author: Mahedee Hasan
 */
public class ValidationUtil {

    private ValidationUtil() {
        // Private constructor to prevent instantiation
    }

    /**
     * Purpose: Validates that a string is not null, empty, or whitespace-only
     * @param value The string value to validate
     * @param fieldName The name of the field being validated (for error messages)
     * @throws ConfigurationException If the value is null, empty, or whitespace-only
     */
    public static void validateNotEmpty(String value, String fieldName) throws ConfigurationException {
        if (value == null || value.trim().isEmpty()) {
            throw new ConfigurationException(fieldName + " cannot be null or empty");
        }
    }

    /**
     * Purpose: Validates that an object reference is not null
     * @param value The object to validate
     * @param fieldName The name of the field being validated (for error messages)
     * @throws ConfigurationException If the value is null
     */
    public static void validateNotNull(Object value, String fieldName) throws ConfigurationException {
        if (value == null) {
            throw new ConfigurationException(fieldName + " cannot be null");
        }
    }

    /**
     * Purpose: Validates that a numeric value is positive (greater than zero)
     * @param value The integer value to validate
     * @param fieldName The name of the field being validated (for error messages)
     * @throws ConfigurationException If the value is zero or negative
     */
    public static void validatePositive(int value, String fieldName) throws ConfigurationException {
        if (value <= 0) {
            throw new ConfigurationException(fieldName + " must be positive");
        }
    }

    /**
     * Purpose: Validates that a numeric value is within the specified range (inclusive)
     * @param value The integer value to validate
     * @param min The minimum allowed value (inclusive)
     * @param max The maximum allowed value (inclusive)
     * @param fieldName The name of the field being validated (for error messages)
     * @throws ConfigurationException If the value is outside the specified range
     */
    public static void validateRange(int value, int min, int max, String fieldName) throws ConfigurationException {
        if (value < min || value > max) {
            throw new ConfigurationException(fieldName + " must be between " + min + " and " + max);
        }
    }
}
