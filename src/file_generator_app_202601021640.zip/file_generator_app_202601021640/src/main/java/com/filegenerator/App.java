package com.filegenerator;

import java.nio.file.Paths;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.application.FileGeneratorApplication;
import com.filegenerator.constants.AppConstants;
import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.infrastructure.util.CommandHandler;
import com.filegenerator.model.dto.CommandLineArgs;
import com.filegenerator.model.enums.OperationType;

/**
 * Purpose: Main entry point for the File Generator Application
 * Author: Mahedee Hasan
 */

public class App {

    // Configure Log4j2 BEFORE any loggers are created
    static {
        configureLogging();
    }

    private static final Logger logger = LoggerFactory.getLogger(App.class);

    /**
     * Purpose: Configure Log4j2 logging before any loggers are created
     * Uses the LOG4J_CONFIG_FILE_PATH constant from AppConstants
     */
    private static void configureLogging() {
        try {
            // Use absolute path for log4j2.xml configuration from AppConstants
            String absoluteLogConfig = Paths.get(AppConstants.LOG4J_CONFIG_FILE_PATH).toAbsolutePath().toString();
            System.setProperty("log4j2.configurationFile", absoluteLogConfig);
            System.out.println("Log4j2 configuration set to: " + absoluteLogConfig);
        } catch (Exception e) {
            System.err.println("Failed to configure log4j2: " + e.getMessage());
        }
    }

    /**
     * Purpose: Main entry point for the File Generator Application
     * 
     * @param args Command line arguments, first argument can be config file path
     */
    public static void main(String[] args) {
        // Create logs directory if it doesn't exist
        try {
            java.nio.file.Files.createDirectories(java.nio.file.Paths.get("logs"));
        } catch (Exception e) {
            System.err.println("Warning: Could not create logs directory: " + e.getMessage());
        }

        logger.info("=== File Generator Application Started ===");

        // For debugging fixed the arguments
        // Comment out the below block for production use

        String cmd = "";
        //cmd = "--help"; // for help
        //cmd = "--generate-key"; // for generating key
        //cmd = "--encrypt \"Hello World\""; // for encrypting text
        //cmd = "--encrypt \"Test123\""; // for encrypting text
        //cmd = "--decrypt Kaqu4fB0gxbiEFbv1j1LHg=="; // for decrypting text
        //cmd = "--version"; // for version


        // Split cmd into args array handling quoted strings
        if (cmd != null && !cmd.trim().isEmpty()) {
            args = CommandHandler.parseCommandString(cmd.trim());
        } else {
            args = new String[0]; // Empty array if cmd is null or empty
        }

        // End of debugging
        // Comment out the above block for production use

        try {
            // Parse command-line arguments for operation type
            CommandLineArgs cmdArgs = parseArguments(args);

            // Run application based on operation type
            FileGeneratorApplication app = new FileGeneratorApplication();
            int exitCode = app.run(cmdArgs);

            logger.info("=== File Generator Application Completed Successfully ===");
            System.exit(exitCode);

        } catch (Exception e) {
            logger.error("Fatal error in application", e);
            System.err.println("Error: " + e.getMessage());
            System.exit(1);
        }
    }

    private static CommandLineArgs parseArguments(String[] args) throws ConfigurationException {
        CommandLineArgs cmdArgs = new CommandLineArgs();
        cmdArgs.setConfigFilePath(AppConstants.APPLICATION_PROPERTIES_FILE_PATH); // Default config path
        cmdArgs.setOperationType(OperationType.FILE_GENERATION); // Default

        for (int i = 0; i < args.length; i++) {
            String arg = args[i];

            if (arg.equals("--help") || arg.equals("-h")) {
                FileGeneratorApplication.printHelp();
                System.exit(0);
            } else if (arg.equals("--version") || arg.equals("-v")) {
                FileGeneratorApplication.printVersion();
                System.exit(0);
            } else if (arg.equals("--encrypt")) {
                cmdArgs.setOperationType(OperationType.ENCRYPT);
                if (i + 1 < args.length) {
                    cmdArgs.setText(args[++i]);
                }
            } else if (arg.equals("--decrypt")) {
                cmdArgs.setOperationType(OperationType.DECRYPT);
                if (i + 1 < args.length) {
                    cmdArgs.setText(args[++i]);
                }
            // } else if (arg.equals("--encrypt-db-password")) {
            //     cmdArgs.setOperationType(OperationType.ENCRYPT_DB_PASSWORD);
            //     if (i + 1 < args.length) {
            //         cmdArgs.setText(args[++i]);
            //     }
            // } else if (arg.equals("--key")) {
            //     if (i + 1 < args.length) {
            //         cmdArgs.setSecretKey(args[++i]);
            //     }
            } else if (arg.equals("--generate-key")) {
                cmdArgs.setOperationType(OperationType.GENERATE_KEY);
            } else if (arg.equals("--config") || arg.equals("-c")) {
                if (i + 1 < args.length) {
                    cmdArgs.setConfigFilePath(args[++i]);
                } else {
                    System.err.println("Error: --config requires a file path");
                    System.exit(1);
                }
            } else if (arg.startsWith("--config=")) {
                cmdArgs.setConfigFilePath(arg.substring("--config=".length()));
            }
        }

        // Validate arguments based on operation type
        // We no longer need text and secret key since we are using deafult secret key from constants

        // if (cmdArgs.getOperationType() == OperationType.ENCRYPT
        //         || cmdArgs.getOperationType() == OperationType.DECRYPT) {
        //     if (cmdArgs.getText() == null) {
        //         System.err
        //                 .println("Error: Text is required for " + cmdArgs.getOperationType().toString().toLowerCase());
        //         FileGeneratorApplication.printHelp();
        //         System.exit(1);
        //     }
        //     if (cmdArgs.getSecretKey() == null) {
        //         System.err.println(
        //                 "Error: Secret key is required for " + cmdArgs.getOperationType().toString().toLowerCase());
        //         FileGeneratorApplication.printHelp();
        //         System.exit(1);
        //     }
        // }

        // if (cmdArgs.getOperationType() == OperationType.ENCRYPT_DB_PASSWORD) {
        //     if (cmdArgs.getText() == null) {
        //         System.err.println("Error: Password is required for database password encryption");
        //         FileGeneratorApplication.printHelp();
        //         System.exit(1);
        //     }
        // }

        return cmdArgs;
    }

}
