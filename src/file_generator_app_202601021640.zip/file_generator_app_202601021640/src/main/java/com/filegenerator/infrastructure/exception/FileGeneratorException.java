package com.filegenerator.infrastructure.exception;

/**
 * Purpose: This class serves as the base exception for all file generator application errors.
 * It provides a common exception hierarchy for consistent error handling throughout
 * the application and enables proper exception categorization.
 * Author: Mahedee Hasan
 */
public class FileGeneratorException extends Exception {
    
    public FileGeneratorException(String message) {
        super(message);
    }

    public FileGeneratorException(String message, Throwable cause) {
        super(message, cause);
    }

    public FileGeneratorException(Throwable cause) {
        super(cause);
    }
}
