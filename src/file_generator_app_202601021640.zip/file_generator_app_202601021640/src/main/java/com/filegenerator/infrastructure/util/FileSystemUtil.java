package com.filegenerator.infrastructure.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Utility class for file system operations.
 * Author: Mahedee Hasan
 */
public class FileSystemUtil {
    
    private static final Logger logger = LoggerFactory.getLogger(FileSystemUtil.class);

    private FileSystemUtil() {
        // Private constructor to prevent instantiation
    }

    /**
     * Creates a directory if it doesn't exist.
     */
    public static void createDirectoryIfNotExists(String directoryPath) throws IOException {
        Path path = Paths.get(directoryPath);
        if (!Files.exists(path)) {
            Files.createDirectories(path);
            logger.info("Created directory: {}", directoryPath);
        }
    }

    /**
     * Checks if a directory is writable.
     */
    public static boolean isDirectoryWritable(String directoryPath) {
        File directory = new File(directoryPath);
        return directory.exists() && directory.isDirectory() && directory.canWrite();
    }

    /**
     * Validates that a path is safe (prevents path traversal).
     */
    public static boolean isPathSafe(String basePath, String targetPath) {
        try {
            Path base = Paths.get(basePath).toAbsolutePath().normalize();
            Path target = Paths.get(targetPath).toAbsolutePath().normalize();
            return target.startsWith(base);
        } catch (Exception e) {
            logger.error("Error validating path safety", e);
            return false;
        }
    }

    /**
     * Gets the size of a file in bytes.
     */
    public static long getFileSize(String filePath) {
        File file = new File(filePath);
        return file.exists() ? file.length() : 0;
    }

    /**
     * Checks if a file exists.
     */
    public static boolean fileExists(String filePath) {
        return Files.exists(Paths.get(filePath));
    }

    /**
     * Gets available disk space in bytes.
     */
    public static long getAvailableDiskSpace(String path) {
        File file = new File(path);
        return file.getUsableSpace();
    }


}
