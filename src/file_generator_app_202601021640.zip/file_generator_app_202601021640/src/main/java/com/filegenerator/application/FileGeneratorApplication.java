package com.filegenerator.application;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.constants.AppConstants;
import com.filegenerator.infrastructure.exception.ConfigurationException;
import com.filegenerator.infrastructure.util.ConfigurationManager;
import com.filegenerator.infrastructure.writer.FileWriterFactory;
import com.filegenerator.infrastructure.writer.FileWriterFactoryImpl;
import com.filegenerator.model.configuration.ApplicationConfiguration;
import com.filegenerator.model.dto.CommandLineArgs;
import com.filegenerator.model.dto.EncryptionResult;
import com.filegenerator.model.dto.FileGenerationResult;
import com.filegenerator.repository.database.DatabaseConnectionManagerImpl;
import com.filegenerator.repository.database.IDatabaseConnectionManager;
import com.filegenerator.repository.query.IQueryRepository;
import com.filegenerator.repository.query.QueryRepositoryImpl;
import com.filegenerator.service.filegeneration.FileGenerationServiceImpl;
import com.filegenerator.service.filegeneration.IFileGenerationService;
import com.filegenerator.service.orchestration.FileGenerationOrchestratorImpl;
import com.filegenerator.service.orchestration.IFileGenerationOrchestrator;
import com.filegenerator.service.query.IQueryExecutionService;
import com.filegenerator.service.query.QueryExecutionServiceImpl;
import com.filegenerator.service.security.CryptoService;
import com.filegenerator.service.security.CryptoServiceImpl;

/**
 * Author: Mahedee Hasan
 * Purpose: This class is the main application class for the File Generator.
 * It initializes all components and orchestrates the file generation process.
 */
public class FileGeneratorApplication {

    private static final Logger logger = LoggerFactory.getLogger(FileGeneratorApplication.class);

    private final CryptoService cryptoService;

    public FileGeneratorApplication() {
        new FileWriterFactoryImpl();
        this.cryptoService = new CryptoServiceImpl();
    }

    public FileGeneratorApplication(FileWriterFactory fileWriterFactory,
            CryptoService cryptoService) {
        this.cryptoService = cryptoService;
    }

    /**
     * Purpose: Runs the application based on command line arguments
     * 
     * @param cmdArgs Command line arguments with operation type
     * @return int Exit code (0 for success, 1 for failure)
     */
    public int run(CommandLineArgs cmdArgs) {
        try {

            ApplicationConfiguration appConfig = ConfigurationManager.geConfiguration();

            // Route to appropriate operation`0
            switch (cmdArgs.getOperationType()) {
                case FILE_GENERATION:
                    return runFileGeneration(appConfig);
                case ENCRYPT:
                    return runEncryption(appConfig, cmdArgs);
                case DECRYPT:
                    return runDecryption(appConfig, cmdArgs);
                case GENERATE_KEY:
                    return runKeyGeneration(appConfig);
                default:
                    throw new IllegalArgumentException("Unknown operation type: " + cmdArgs.getOperationType());
            }

        } catch (Exception e) {
            logger.error("Error during application execution", e);
            System.err.println("Application failed: " + e.getMessage());
            return 1;
        }
    }

    private int runFileGeneration(ApplicationConfiguration appConfig) {
        try {
            logger.info("Starting file generation process");

            // Initialize components
            IDatabaseConnectionManager connectionManager = new DatabaseConnectionManagerImpl(
                    appConfig.getDatabaseConfiguration());

            IQueryRepository queryRepository = new QueryRepositoryImpl(connectionManager);
            IQueryExecutionService queryExecutionService = new QueryExecutionServiceImpl(queryRepository);

            FileWriterFactory fileWriterFactory = new FileWriterFactoryImpl();

            IFileGenerationService fileGenerationService = new FileGenerationServiceImpl(
                    queryExecutionService,
                    fileWriterFactory);

            // Initialize orchestrator with query execution service for pre/post steps
            IFileGenerationOrchestrator orchestrator = new FileGenerationOrchestratorImpl(
                    fileGenerationService,
                    connectionManager,
                    queryExecutionService);

            // Execute file generation
            List<FileGenerationResult> results = orchestrator.orchestrateFileGeneration(appConfig);

            // Print summary
            printSummary(results);

            // Return exit code based on results
            return hasFailures(results) ? 1 : 0;

        } catch (Exception e) {
            logger.error("File generation process failed", e);
            return 1;
        }
    }

    private int runEncryption(ApplicationConfiguration appConfig, CommandLineArgs cmdArgs) {
        try {
            logger.info("Starting encryption process");

            if (cmdArgs.getText() == null || cmdArgs.getText().trim().isEmpty()) {
                System.err.println("Error: No text provided for encryption");
                return 1;
            }

            // Use default secret key
            cmdArgs.setSecretKey(AppConstants.DEFAULT_SECRET_KEY);
            if (cmdArgs.getSecretKey() == null || cmdArgs.getSecretKey().trim().isEmpty()) {
                System.err.println("Error: No secret key provided for encryption");
                return 1;
            }

            String outputDir = appConfig.getEncryptionConfiguration().getOutputDirectory();

            // Encrypt and save to file using CryptoService
            String msg = cryptoService.encryptToFile(cmdArgs.getText(),
                    cmdArgs.getSecretKey(), outputDir);

            EncryptionResult result = EncryptionResult.success(outputDir, msg);

            if (result.isSuccess()) {
                System.out.println("Encryption successful!");
                System.out.println("Output file: " + result.getFilePath());
                System.out.println("Execution time: " + result.getExecutionTimeMs() + " ms");
                return 0;
            } else {
                System.err.println("Encryption failed: " + result.getErrorMessage());
                return 1;
            }

        } catch (Exception e) {
            logger.error("Encryption process failed", e);
            System.err.println("Encryption failed: " + e.getMessage());
            return 1;
        }
    }

    private int runDecryption(ApplicationConfiguration appConfig, CommandLineArgs cmdArgs) {
        try {
            logger.info("Starting decryption process");

            if (cmdArgs.getText() == null || cmdArgs.getText().trim().isEmpty()) {
                System.err.println("Error: No encrypted text provided for decryption");
                return 1;
            }

            // Use default secret key
            cmdArgs.setSecretKey(AppConstants.DEFAULT_SECRET_KEY);

            if (cmdArgs.getSecretKey() == null || cmdArgs.getSecretKey().trim().isEmpty()) {
                System.err.println("Error: No secret key provided for decryption");
                return 1;
            }

            String outputDir = appConfig.getDecryptionConfiguration().getOutputDirectory();

            // Encrypt and save to file using CryptoService
            String msg = cryptoService.decryptToFile(cmdArgs.getText(),
                    cmdArgs.getSecretKey(), outputDir);

            EncryptionResult result = EncryptionResult.success(outputDir, msg);

            if (result.isSuccess()) {
                System.out.println("Decryption successful!");
                System.out.println("Output file: " + result.getFilePath());
                System.out.println("Execution time: " + result.getExecutionTimeMs() + " ms");
                return 0;
            } else {
                System.err.println("Decryption failed: " + result.getErrorMessage());
                return 1;
            }

        } catch (Exception e) {
            logger.error("Decryption process failed", e);
            System.err.println("Decryption failed: " + e.getMessage());
            return 1;
        }
    }

    private int runKeyGeneration(ApplicationConfiguration appConfig) {
        try {
            logger.info("Generating secret key");
            String outputDir = appConfig.getEncryptionConfiguration().getOutputDirectory();
            String msg = cryptoService.generateKeyToFile(outputDir);
            EncryptionResult result = EncryptionResult.success(outputDir, msg);

            if (result.isSuccess()) {
                System.out.println("Secret key generated successfully!");
                System.out.println("Key file: " + result.getFilePath());
                System.out.println("Execution time: " + result.getExecutionTimeMs() + " ms");
                return 0;
            } else {
                System.err.println("Key generation failed: " + result.getErrorMessage());
                return 1;
            }

        } catch (Exception e) {
            logger.error("Key generation failed", e);
            System.err.println("Key generation failed: " + e.getMessage());
            return 1;
        }
    }

    public static void printHelp() {
        System.out.println("File/Letter Generator Application");
        System.out.println();
        System.out.println("Usage: java -jar file-generator.jar [OPTIONS]");
        System.out.println();
        System.out.println("Operations:");
        System.out.println("  (default)                   Generate files from database queries");
        System.out.println("  --encrypt <text>            Encrypt text and save to file");
        System.out.println("  --decrypt <text>            Decrypt text and save to file");
        System.out.println("  --generate-key              Generate a new encryption key");
        System.out.println();
        System.out.println("Options:");
        System.out.println("  --generate-key              Generate a new encryption key");
        System.out.println("  --help, -h                  Display this help message");
        System.out.println("  --version, -v               Display version information");
        System.out.println();
        System.out.println("Examples:");
        System.out.println("  java -jar file-generator.jar");
        System.out.println("  java -jar file-generator.jar --encrypt \"Hello World\"");
        System.out.println("  java -jar file-generator.jar --decrypt YOUR_ENCRYPTED_TEXT_HERE");
        System.out.println("  java -jar file-generator.jar --generate-key");
    }

    public static void printVersion() throws ConfigurationException {
        // System.out.println(appConfig.getGeneralConfiguration().getApplicationName());
        System.out.println(
                "Application Name: " + ConfigurationManager.geConfiguration().getGeneralConfiguration().getAppName());
        System.out.println(
                "Version: " + ConfigurationManager.geConfiguration().getGeneralConfiguration().getAppVersion());
        System.out.println(
                "Build Date: " + ConfigurationManager.geConfiguration().getGeneralConfiguration().getAppBuildDate());
    }

    private void printSummary(List<FileGenerationResult> results) {
        System.out.println();
        System.out.println("=== File Generation Summary ===");

        int total = results.size();
        long successful = results.stream().filter(FileGenerationResult::isSuccess).count();
        long failed = total - successful;

        System.out.println("Total Files: " + total);
        System.out.println("Successful: " + successful);
        System.out.println("Failed: " + failed);
        System.out.println();

        if (successful > 0) {
            System.out.println("Successful Files:");
            for (FileGenerationResult result : results) {
                if (result.isSuccess()) {
                    System.out.printf("  - %s (%,d records in %,d ms)%n",
                            result.getFileName(),
                            result.getRecordCount(),
                            result.getExecutionTimeMs());
                }
            }
            System.out.println();
        }

        if (failed > 0) {
            System.out.println("Failed Files:");
            for (FileGenerationResult result : results) {
                if (!result.isSuccess()) {
                    System.out.printf("  - %s: %s%n",
                            result.getFileName(),
                            result.getErrorMessage());
                }
            }
            System.out.println();
        }

        System.out.println("================================");
    }

    private boolean hasFailures(List<FileGenerationResult> results) {
        return results.stream().anyMatch(r -> !r.isSuccess());
    }
}
