package com.filegenerator.repository.query;

import com.filegenerator.infrastructure.exception.QueryExecutionException;
import com.filegenerator.repository.database.IDatabaseConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * Query repository implementation.
 */
public class QueryRepositoryImpl implements IQueryRepository {
    
    private static final Logger logger = LoggerFactory.getLogger(QueryRepositoryImpl.class);
    private static final int FETCH_SIZE = 1000; // Rows to fetch at a time
    
    private final IDatabaseConnectionManager connectionManager;
    private Connection connection;
    private PreparedStatement statement;
    private ResultSet resultSet;

    public QueryRepositoryImpl(IDatabaseConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public ResultSet executeQuery(String sql) throws QueryExecutionException {
        logger.info("Executing SELECT query");
        logger.debug("SQL: {}", sql);
        
        try {
            // Get connection from pool
            connection = connectionManager.getConnection();
            
            // Prepare statement
            statement = connection.prepareStatement(sql);
            statement.setFetchSize(FETCH_SIZE);
            
            // Execute query
            long startTime = System.currentTimeMillis();
            resultSet = statement.executeQuery();
            long executionTime = System.currentTimeMillis() - startTime;
            
            logger.info("Query executed successfully in {} ms", executionTime);
            
            return resultSet;
            
        } catch (SQLException e) {
            logger.error("Error executing query", e);
            closeResources();
            throw new QueryExecutionException("Error executing query: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Unexpected error executing query", e);
            closeResources();
            throw new QueryExecutionException("Unexpected error executing query: " + e.getMessage(), e);
        }
    }

    @Override
    public int executeUpdate(String sql) throws QueryExecutionException {
        logger.info("Executing UPDATE/INSERT/DELETE query");
        logger.debug("SQL: {}", sql);
        
        Connection updateConnection = null;
        PreparedStatement updateStatement = null;
        
        try {
            // Get connection from pool
            updateConnection = connectionManager.getConnection();
            
            // Verify autocommit is enabled for immediate persistence
            logger.debug("Connection autocommit setting: {}", updateConnection.getAutoCommit());
            
            // Prepare statement
            updateStatement = updateConnection.prepareStatement(sql);
            
            // Execute update
            long startTime = System.currentTimeMillis();
            int affectedRows = updateStatement.executeUpdate();
            long executionTime = System.currentTimeMillis() - startTime;
            
            logger.info("Update executed successfully in {} ms, affected rows: {}", executionTime, affectedRows);
            
            return affectedRows;
            
        } catch (SQLException e) {
            logger.error("Error executing update: {}", e.getMessage(), e);
            throw new QueryExecutionException("Error executing update: " + e.getMessage(), e);
        } catch (Exception e) {
            logger.error("Unexpected error executing update: {}", e.getMessage(), e);
            throw new QueryExecutionException("Unexpected error executing update: " + e.getMessage(), e);
        } finally {
            // Close update resources
            if (updateStatement != null) {
                try {
                    updateStatement.close();
                } catch (SQLException e) {
                    logger.error("Error closing update statement", e);
                }
            }
            if (updateConnection != null) {
                try {
                    connectionManager.releaseConnection(updateConnection);
                } catch (Exception e) {
                    logger.error("Error releasing update connection", e);
                }
            }
        }
    }

    @Override
    public void closeResources() {
        // Close in reverse order
        if (resultSet != null) {
            try {
                resultSet.close();
                logger.debug("Closed ResultSet");
            } catch (SQLException e) {
                logger.error("Error closing ResultSet", e);
            }
        }
        
        if (statement != null) {
            try {
                statement.close();
                logger.debug("Closed PreparedStatement");
            } catch (SQLException e) {
                logger.error("Error closing PreparedStatement", e);
            }
        }
        
        if (connection != null) {
            try {
                connectionManager.releaseConnection(connection);
            } catch (Exception e) {
                logger.error("Error releasing connection", e);
            }
        }
    }
}
