package com.filegenerator.infrastructure.exception;

/**
 * Purpose: This exception class handles database connection and operation errors.
 * It is thrown when database connectivity issues occur or SQL operations fail,
 * providing specific error context for database-related problems.
 * Author: Mahedee Hasan
 */
public class DatabaseException extends FileGeneratorException {
    
    public DatabaseException(String message) {
        super(message);
    }

    public DatabaseException(String message, Throwable cause) {
        super(message, cause);
    }
}
