package com.filegenerator.service.orchestration;

import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.model.configuration.ApplicationConfiguration;
import com.filegenerator.model.configuration.FileConfiguration;
import com.filegenerator.model.configuration.FileGenerationSection;
import com.filegenerator.model.configuration.FileGenerationStep;
import com.filegenerator.model.configuration.PostFileGenerationStep;
import com.filegenerator.model.configuration.PreFileGenerationStep;
import com.filegenerator.model.dto.FileGenerationResult;
import com.filegenerator.repository.database.IDatabaseConnectionManager;
import com.filegenerator.service.filegeneration.IFileGenerationService;
import com.filegenerator.service.query.IQueryExecutionService;

/**
 * Author: Mahedee Hasan
 * Purpose: This class orchestrates the file generation process including pre and post
 * file generation steps for each file configuration.
 */
public class FileGenerationOrchestratorImpl implements IFileGenerationOrchestrator {
    
    private static final Logger logger = LoggerFactory.getLogger(FileGenerationOrchestratorImpl.class);
    
    private final IFileGenerationService fileGenerationService;
    private final IDatabaseConnectionManager connectionManager;
    private final IQueryExecutionService queryExecutionService;

    public FileGenerationOrchestratorImpl(
            IFileGenerationService fileGenerationService,
            IDatabaseConnectionManager connectionManager) {
        this.fileGenerationService = fileGenerationService;
        this.connectionManager = connectionManager;
        this.queryExecutionService = null;
    }

    public FileGenerationOrchestratorImpl(
            IFileGenerationService fileGenerationService,
            IDatabaseConnectionManager connectionManager,
            IQueryExecutionService queryExecutionService) {
        this.fileGenerationService = fileGenerationService;
        this.connectionManager = connectionManager;
        this.queryExecutionService = queryExecutionService;
    }

    /**
     * Purpose: Orchestrates the complete file generation process for all configurations
     * @param appConfig The application configuration containing file configurations
     * @return List<FileGenerationResult> Results of all file generation attempts
     */
    @Override
    public List<FileGenerationResult> orchestrateFileGeneration(ApplicationConfiguration appConfig) {
        logger.info("Starting file generation orchestration");
        
        List<FileGenerationResult> results = new ArrayList<>();
        
        // Initialize database connection pool
        connectionManager.initialize();
        
        try {
            List<FileConfiguration> fileConfigs = appConfig.getFileConfigurations();
            
            for (FileConfiguration fileConfig : fileConfigs) {
                if (!fileConfig.isEnabled()) {
                    logger.info("Skipping disabled file configuration: {}", fileConfig.getFileName());
                    continue;
                }
                
                logger.info("Processing file configuration: {}", fileConfig.getFileName());
                
                try {
                    logger.info("=== Starting processing for: {} ===", fileConfig.getFileName());
                    
                    // Execute pre-file generation steps
                    logger.info("STEP 1: Executing pre-file generation steps");
                    executePreFileGenerationSteps(fileConfig);
                    
                    // Check if file header generation is enabled
                    boolean headerGenerationEnabled = isHeaderGenerationEnabled(fileConfig);
                    FileGenerationResult result;
                    
                    logger.info("STEP 2: Executing file generation");
                    if (headerGenerationEnabled) {
                        // Generate file with header
                        result = executeFileHeaderGeneration(fileConfig);
                    } else {
                        // Generate the file normally
                        result = fileGenerationService.generateFile(fileConfig);
                    }
                    
                    results.add(result);
                    
                    // Execute post-file generation steps (only if file generation was successful)
                    if (result.isSuccessful()) {
                        logger.info("STEP 3: Executing post-file generation steps");
                        executePostFileGenerationSteps(fileConfig);
                    } else {
                        logger.warn("Skipping post-generation steps for {} due to file generation failure", 
                                  fileConfig.getFileName());
                    }
                    
                    logger.info("=== Completed processing for: {} ===", fileConfig.getFileName());
                    
                } catch (Exception e) {
                    logger.error("Error processing file configuration: " + fileConfig.getFileName(), e);
                    FileGenerationResult errorResult = new FileGenerationResult();
                    errorResult.setSuccessful(false);
                    errorResult.setMessage("Error: " + e.getMessage());
                    errorResult.setFilePath(fileConfig.getExportPath() + fileConfig.getFileName());
                    results.add(errorResult);
                }
            }
            
        } finally {
            // Close connection pool
            connectionManager.close();
        }
        
        logger.info("File generation orchestration completed");
        return results;
    }

    /**
     * Purpose: Executes pre-file generation steps for a file configuration
     * @param fileConfig The file configuration
     */
    private void executePreFileGenerationSteps(FileConfiguration fileConfig) {
        List<PreFileGenerationStep> preSteps = fileConfig.getEnabledPreSteps();
        
        if (preSteps == null || preSteps.isEmpty()) {
            logger.debug("No enabled pre-file generation steps found for: {}", fileConfig.getFileName());
            return;
        }

        logger.info("Executing pre-file generation steps for: {} (Found {} steps)", fileConfig.getFileName(), preSteps.size());
        
        for (PreFileGenerationStep step : preSteps) {
            executeStep(step, "Pre");
        }
    }

    /**
     * Purpose: Checks if file header generation is enabled for a file configuration
     * @param fileConfig The file configuration
     * @return true if header generation is enabled, false otherwise
     */
    private boolean isHeaderGenerationEnabled(FileConfiguration fileConfig) {
        FileGenerationSection section = fileConfig.getFileGenerationSection();
        if (section == null || section.getFileHeaderSection() == null) {
            return false;
        }

        FileGenerationStep headerStep = section.getFileHeaderSection();
        return headerStep.isEnable();
    }

    /**
     * Purpose: Executes file header generation for a file configuration
     * @param fileConfig The file configuration
     * @return FileGenerationResult The result of file generation with header
     */
    private FileGenerationResult executeFileHeaderGeneration(FileConfiguration fileConfig) {
        FileGenerationSection section = fileConfig.getFileGenerationSection();
        FileGenerationStep headerStep = section.getFileHeaderSection();

        logger.info("Generating file with header for: {}", fileConfig.getFileName());
        
        try {
            if (queryExecutionService != null && "read".equalsIgnoreCase(headerStep.getQueryType())) {
                logger.info("Executing header query: {} (Sequence: {})", headerStep.getName(), headerStep.getSequence());
                
                // Create a header configuration for query execution
                FileConfiguration headerConfig = createHeaderFileConfig(fileConfig, headerStep);
                
                // Execute the header query to get header data
                try (java.sql.ResultSet headerResultSet = queryExecutionService.executeQuery(headerConfig)) {
                    // Generate the file with header data
                    FileGenerationResult result = fileGenerationService.generateFile(fileConfig, headerResultSet);
                    logger.info("Header query executed and file generated successfully for: {}", fileConfig.getFileName());
                    return result;
                } catch (Exception e) {
                    logger.error("Error executing header query for: {}", fileConfig.getFileName(), e);
                    throw e;
                }
            } else {
                logger.warn("Query execution service not available or invalid query type, generating file without header");
                return fileGenerationService.generateFile(fileConfig);
            }
            
        } catch (Exception e) {
            logger.error("Error executing file header generation for: {}", fileConfig.getFileName(), e);
            
            // Create error result
            FileGenerationResult errorResult = new FileGenerationResult();
            errorResult.setSuccessful(false);
            errorResult.setMessage("Error in header generation: " + e.getMessage());
            errorResult.setFilePath(fileConfig.getExportPath() + fileConfig.getFileName());
            return errorResult;
        }
    }

    /**
     * Purpose: Creates a temporary file configuration for header query execution
     * @param originalConfig The original file configuration
     * @param headerStep The header step configuration
     * @return FileConfiguration A temporary config for header execution
     */
    private FileConfiguration createHeaderFileConfig(FileConfiguration originalConfig, FileGenerationStep headerStep) {
        FileConfiguration headerConfig = new FileConfiguration();
        headerConfig.setFileName(originalConfig.getFileName());
        headerConfig.setQuery(headerStep.getQuery());
        headerConfig.setQuerySource(originalConfig.getQuerySource());
        return headerConfig;
    }

    /**
     * Purpose: Executes post-file generation steps for a file configuration
     * @param fileConfig The file configuration
     */
    private void executePostFileGenerationSteps(FileConfiguration fileConfig) {
        List<PostFileGenerationStep> postSteps = fileConfig.getEnabledPostSteps();
        
        if (postSteps == null || postSteps.isEmpty()) {
            logger.debug("No enabled post-file generation steps found for: {}", fileConfig.getFileName());
            return;
        }

        logger.info("Executing post-file generation steps for: {} (Found {} steps)", fileConfig.getFileName(), postSteps.size());
        
        for (PostFileGenerationStep step : postSteps) {
            executeStep(step, "Post");
        }
    }

    /**
     * Purpose: Executes a single file generation step
     * @param step The step to execute
     * @param stepType The type of step (Pre or Post) for logging
     */
    private void executeStep(FileGenerationStep step, String stepType) {
        try {
            logger.info(">>> EXECUTING {} step: {} (Sequence: {}) at {}", stepType, step.getName(), step.getSequence(), java.time.LocalDateTime.now());
            logger.debug("Step query type: {}, Query: {}", step.getQueryType(), step.getQuery());
            
            if (queryExecutionService == null) {
                logger.error("Query execution service not available, cannot execute step: {}", step.getName());
                throw new RuntimeException("QueryExecutionService is null - cannot execute step: " + step.getName());
            }
            
            if (step.getQuery() == null || step.getQuery().trim().isEmpty()) {
                logger.error("Step query is null or empty for step: {}", step.getName());
                throw new RuntimeException("Step query is null or empty for step: " + step.getName());
            }
            
            // Execute the step based on query type
            String queryType = step.getQueryType();
            if ("update".equalsIgnoreCase(queryType) || "insert".equalsIgnoreCase(queryType) || "delete".equalsIgnoreCase(queryType)) {
                int affectedRows = queryExecutionService.executeUpdate(step.getQuery());
                logger.info("<<< COMPLETED {} step: {} - Affected rows: {} at {}", stepType, step.getName(), affectedRows, java.time.LocalDateTime.now());
                
                // Add small delay for database consistency after UPDATE operations
                if ("update".equalsIgnoreCase(queryType)) {
                    try {
                        Thread.sleep(100); // 100ms delay to ensure transaction is fully committed
                        logger.debug("Added post-update delay for step: {}", step.getName());
                    } catch (InterruptedException ie) {
                        Thread.currentThread().interrupt();
                        logger.warn("Interrupted during post-update delay for step: {}", step.getName());
                    }
                }
            } else if ("read".equalsIgnoreCase(queryType) || "select".equalsIgnoreCase(queryType)) {
                logger.warn("{} step '{}' has read/select query type, which is unusual for pre/post steps", stepType, step.getName());
                int affectedRows = queryExecutionService.executeUpdate(step.getQuery());
                logger.info("{} step completed: {} - Affected rows: {}", stepType, step.getName(), affectedRows);
            } else {
                logger.warn("{} step '{}' has unknown query type '{}', attempting to execute as update", stepType, step.getName(), queryType);
                int affectedRows = queryExecutionService.executeUpdate(step.getQuery());
                logger.info("{} step completed: {} - Affected rows: {}", stepType, step.getName(), affectedRows);
            }
            
        } catch (Exception e) {
            logger.error("Error executing {} step: {} - Error: {}", stepType, step.getName(), e.getMessage(), e);
            throw new RuntimeException("Failed to execute " + stepType.toLowerCase() + " step: " + step.getName() + " - " + e.getMessage(), e);
        }
    }
}
