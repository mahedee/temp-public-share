package com.filegenerator.infrastructure.writer;

import com.filegenerator.model.enums.FileFormat;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Purpose: This factory class creates appropriate file writer instances based
 * on file format.
 * It implements the Factory pattern to instantiate CSV, TXT, or delimited file
 * writers
 * based on configuration parameters.
 * Author: Mahedee Hasan
 */
public class FileWriterFactoryImpl implements FileWriterFactory {

    private static final Logger logger = LoggerFactory.getLogger(FileWriterFactoryImpl.class);

    @Override
    public IFileWriter createFileWriter(String filePath, FileFormat format, String delimiter) {
        logger.debug("Creating file writer for format: {}, delimiter: {}", format, delimiter);

        switch (format) {
            case CSV:
                return new CsvFileWriter(filePath);
            case TXT:
                return new TxtFileWriter(filePath, delimiter);
            case CUSTOM:
                return new DelimitedFileWriter(filePath, delimiter);
            default:
                throw new IllegalArgumentException("Unsupported file format: " + format);
        }
    }

    public void saveToFile(String filePath, String fileText) {
        try {
            Path path = Paths.get(filePath);

            // Create parent directories if they don't exist
            Path parentDir = path.getParent();
            if (parentDir != null) {
                Files.createDirectories(parentDir);
            }

            // Write file
            Files.write(path, fileText.getBytes());

        } catch (IOException e) {
            // Use proper logging instead of printStackTrace
            throw new RuntimeException("Failed to save file: " + filePath, e);
        }
    }

    /**
     * Generate unique file name by appending timestamp if file already exists in
     * target directory.
     * 
     * @param targetPath The target file path
     * @return Unique file path
     */
    public static Path generateUniqueFileName(Path targetPath) {
        if (targetPath == null || !Files.exists(targetPath)) {
            return targetPath;
        }

        String fileName = targetPath.getFileName().toString();
        String baseName = getBaseFileName(fileName);
        String extension = getFileExtension(fileName);
        Path parentPath = targetPath.getParent();

        // Generate timestamp suffix
        java.time.LocalDateTime now = java.time.LocalDateTime.now();
        java.time.format.DateTimeFormatter formatter = java.time.format.DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
        String timestamp = now.format(formatter);

        String newFileName = baseName + "_" + timestamp + (extension.isEmpty() ? "" : "." + extension);
        Path uniquePath = parentPath.resolve(newFileName);

        // If timestamp-based name still exists (very unlikely), add milliseconds
        if (Files.exists(uniquePath)) {
            String millis = String.valueOf(System.currentTimeMillis() % 1000);
            newFileName = baseName + "_" + timestamp + "_" + millis + (extension.isEmpty() ? "" : "." + extension);
            uniquePath = parentPath.resolve(newFileName);
        }

        return uniquePath;
    }

    /**
     * Get base file name without extension.
     * 
     * @param fileName The file name
     * @return Base file name
     */
    public static String getBaseFileName(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return fileName;
        }

        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0) {
            return fileName.substring(0, lastDotIndex);
        }

        return fileName;
    }

    /**
     * Get file extension without dot.
     * 
     * @param fileName The file name
     * @return File extension or empty string
     */
    public static String getFileExtension(String fileName) {
        if (fileName == null || fileName.trim().isEmpty()) {
            return "";
        }

        int lastDotIndex = fileName.lastIndexOf('.');
        if (lastDotIndex > 0 && lastDotIndex < fileName.length() - 1) {
            return fileName.substring(lastDotIndex + 1).toLowerCase();
        }

        return "";
    }

}
