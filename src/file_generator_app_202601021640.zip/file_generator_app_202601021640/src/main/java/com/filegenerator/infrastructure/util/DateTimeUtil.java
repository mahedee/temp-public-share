package com.filegenerator.infrastructure.util;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Author: Mahedee Hasan
 * Purpose: This utility class provides various date and time formatting methods
 * for generating consistent timestamps in file names and application logs.
 */
public class DateTimeUtil {
    
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd");
    private static final DateTimeFormatter TIME_FORMATTER = DateTimeFormatter.ofPattern("HHmmss");
    private static final DateTimeFormatter DATETIME_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss");
    private static final DateTimeFormatter TIMESTAMP_FORMATTER = DateTimeFormatter.ofPattern("yyyyMMddHHmmss");

    private DateTimeUtil() {
        // Private constructor to prevent instantiation
    }

    /**
     * Purpose: Gets current date in YYYYMMDD format
     * @return String Current date in YYYYMMDD format
     */
    public static String getCurrentDate() {
        return LocalDateTime.now().format(DATE_FORMATTER);
    }

    /**
     * Purpose: Gets current time in HHMMSS format
     * @return String Current time in HHMMSS format
     */
    public static String getCurrentTime() {
        return LocalDateTime.now().format(TIME_FORMATTER);
    }

    /**
     * Purpose: Gets current date and time in YYYYMMDD_HHMMSS format
     * @return String Current date and time formatted for file names
     */
    public static String getCurrentDateTime() {
        return LocalDateTime.now().format(DATETIME_FORMATTER);
    }

    /**
     * Purpose: Gets current timestamp in YYYYMMDDHHMMSS format
     * @return String Current timestamp without separators
     */
    public static String getCurrentTimestamp() {
        return LocalDateTime.now().format(TIMESTAMP_FORMATTER);
    }

    /**
     * Purpose: Formats a LocalDateTime to string using specified pattern
     * @param dateTime The LocalDateTime to format
     * @param pattern The pattern string
     * @return String The formatted date time string
     */
    public static String format(LocalDateTime dateTime, String pattern) {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern(pattern);
        return dateTime.format(formatter);
    }
}
