package com.filegenerator.model.configuration;

/**
 * Pre-file generation step configuration
 * Author: Mahedee Hasan
 * Purpose: Represents a step that executes before main file generation
 */
public class PreFileGenerationStep extends FileGenerationStep {
    
    /**
     * Default constructor
     */
    public PreFileGenerationStep() {
        super();
    }
    
    /**
     * Constructor with all parameters
     * @param name Name of the step
     * @param sequence Execution sequence order
     * @param enable Whether the step is enabled
     * @param queryType Type of query (select, update, insert, delete, procedure)
     * @param query SQL query or procedure call
     * @param description Description of what the step does
     */
    public PreFileGenerationStep(String name, int sequence, boolean enable, 
                               String queryType, String query, String description) {
        super(name, sequence, enable, queryType, query, description);
    }
    
    @Override
    public String toString() {
        return String.format("PreStep[name=%s, sequence=%d, enabled=%s, type=%s]", 
                           getName(), getSequence(), isEnable(), getQueryType());
    }
}