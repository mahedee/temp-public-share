package com.filegenerator.model.configuration;

/**
 * Author: Mahedee Hasan
 * Purpose: Configuration settings for decryption operations
 */
public class DecryptionConfiguration {
    private String outputDirectory;
    private String fileExtension;

    public DecryptionConfiguration() {
        // Default values
        this.outputDirectory = "output/decrypted";
        this.fileExtension = ".dec";
    }

    public DecryptionConfiguration(String outputDirectory, String fileExtension) {
        this.outputDirectory = outputDirectory;
        this.fileExtension = fileExtension;
    }

    // Getters and Setters
    public String getOutputDirectory() {
        return outputDirectory;
    }

    public void setOutputDirectory(String outputDirectory) {
        this.outputDirectory = outputDirectory;
    }

    public String getFileExtension() {
        return fileExtension;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    @Override
    public String toString() {
        return "DecryptionConfiguration{" +
                "outputDirectory='" + outputDirectory + '\'' +
                ", fileExtension='" + fileExtension + '\'' +
                '}';
    }
}