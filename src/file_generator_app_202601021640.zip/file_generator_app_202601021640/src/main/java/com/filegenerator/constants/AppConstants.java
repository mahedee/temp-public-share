package com.filegenerator.constants;

/**
 * This class holds application-wide constants
 * Author: Mahedee Hasan
 * 
 */
public class AppConstants {

    private AppConstants() {
        // Private constructor to prevent instantiation
    }

    // Configuration file paths
    public static final String DEFAULT_CONFIG_PATH = "config/application.properties";
    public static final String CONFIG_DIR = "config/";
    public static final String APPLICATION_PROPERTIES_FILE_NAME = "application.properties";
    public static final String LOG4J_CONFIG_FILE_NAME = "log4j2.xml";
    public static final String LOG4J_CONFIG_FILE_PATH = CONFIG_DIR + LOG4J_CONFIG_FILE_NAME;
    public static final String APPLICATION_PROPERTIES_FILE_PATH = CONFIG_DIR + APPLICATION_PROPERTIES_FILE_NAME;

    // Encryption related constants
    public static final String KEY_FILE_NAME = "cryptoKey.key";
    public static final String ENCRYPTED_TEXT_FILE_NAME = "encryptedText.enc";
    public static final String DECRYPTED_TEXT_FILE_NAME = "decryptedText.txt";
    public static final String DEFAULT_SECRET_KEY = "lTgGEDQ/f66H2YDTZ6VoqJFCLM2JLkb2YQ03VQx4eEw=";
    public static final String ENCRYPTION_ALGORITHM = "AES";
    public static final String TRANSFORMATION = "AES/ECB/PKCS5Padding";
    public static final int KEY_LENGTH = 256;
}
