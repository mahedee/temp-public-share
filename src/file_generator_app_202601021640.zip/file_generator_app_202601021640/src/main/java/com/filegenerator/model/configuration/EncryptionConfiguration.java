package com.filegenerator.model.configuration;

/**
 * Author: Mahedee Hasan
 * Purpose: Configuration settings for encryption operations
 */
public class EncryptionConfiguration {
    private String outputDirectory;
    private String algorithm;
    private int keySize;
    private String fileExtension;

    public EncryptionConfiguration() {
        // Default values
        this.outputDirectory = "output/encrypted";
        this.algorithm = "AES";
        this.keySize = 256;
        this.fileExtension = ".enc";
    }

    public EncryptionConfiguration(String outputDirectory, String algorithm, int keySize, String fileExtension) {
        this.outputDirectory = outputDirectory;
        this.algorithm = algorithm;
        this.keySize = keySize;
        this.fileExtension = fileExtension;
    }

    // Getters and Setters
    public String getOutputDirectory() {
        return outputDirectory;
    }

    public void setOutputDirectory(String outputDirectory) {
        this.outputDirectory = outputDirectory;
    }

    public String getAlgorithm() {
        return algorithm;
    }

    public void setAlgorithm(String algorithm) {
        this.algorithm = algorithm;
    }

    public int getKeySize() {
        return keySize;
    }

    public void setKeySize(int keySize) {
        this.keySize = keySize;
    }

    public String getFileExtension() {
        return fileExtension;
    }

    public void setFileExtension(String fileExtension) {
        this.fileExtension = fileExtension;
    }

    @Override
    public String toString() {
        return "EncryptionConfiguration{" +
                "outputDirectory='" + outputDirectory + '\'' +
                ", algorithm='" + algorithm + '\'' +
                ", keySize=" + keySize +
                ", fileExtension='" + fileExtension + '\'' +
                '}';
    }
}