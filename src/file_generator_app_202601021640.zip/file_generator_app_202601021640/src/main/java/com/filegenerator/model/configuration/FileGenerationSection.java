package com.filegenerator.model.configuration;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.HashMap;
import java.util.stream.Collectors;

/**
 * Author: Mahedee Hasan
 * Purpose: This class represents the main file generation section configuration
 * from the XML query files, including columns, query, and pre/post steps.
 */
public class FileGenerationSection {
    private String name;
    private int sequence;
    private String query;
    private List<String> columns;
    private Map<String, String> globalVariables;
    private List<PreFileGenerationStep> preFileGenerationSteps;
    private List<PostFileGenerationStep> postFileGenerationSteps;
    private FileGenerationStep fileHeaderSection;

    public FileGenerationSection() {
        this.columns = new ArrayList<>();
        this.globalVariables = new HashMap<>();
        this.preFileGenerationSteps = new ArrayList<>();
        this.postFileGenerationSteps = new ArrayList<>();
    }

    /**
     * Purpose: Gets the section name
     * @return String The name of the section
     */
    public String getName() {
        return name;
    }

    /**
     * Purpose: Sets the section name
     * @param name The section name
     */
    public void setName(String name) {
        this.name = name;
    }

    /**
     * Purpose: Gets the execution sequence
     * @return int The sequence number
     */
    public int getSequence() {
        return sequence;
    }

    /**
     * Purpose: Sets the execution sequence
     * @param sequence The sequence number
     */
    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    /**
     * Purpose: Gets the main SQL query for file generation
     * @return String The SQL query
     */
    public String getQuery() {
        return query;
    }

    /**
     * Purpose: Sets the main SQL query for file generation
     * @param query The SQL query
     */
    public void setQuery(String query) {
        this.query = query;
    }

    /**
     * Purpose: Gets the list of columns to include in output
     * @return List<String> The column names
     */
    public List<String> getColumns() {
        return columns;
    }

    /**
     * Purpose: Sets the list of columns
     * @param columns The column names
     */
    public void setColumns(List<String> columns) {
        this.columns = columns;
    }

    /**
     * Purpose: Adds a column to the list
     * @param column The column name to add
     */
    public void addColumn(String column) {
        this.columns.add(column);
    }

    /**
     * Purpose: Gets the global variables map
     * @return Map<String, String> The global variables
     */
    public Map<String, String> getGlobalVariables() {
        return globalVariables;
    }

    /**
     * Purpose: Sets the global variables map
     * @param globalVariables The global variables
     */
    public void setGlobalVariables(Map<String, String> globalVariables) {
        this.globalVariables = globalVariables;
    }

    /**
     * Purpose: Adds a global variable
     * @param key The variable name
     * @param value The variable value
     */
    public void addGlobalVariable(String key, String value) {
        this.globalVariables.put(key, value);
    }

    /**
     * Purpose: Gets the pre file generation steps
     * @return List<PreFileGenerationStep> The pre steps
     */
    public List<PreFileGenerationStep> getPreFileGenerationSteps() {
        return preFileGenerationSteps;
    }

    /**
     * Purpose: Sets the pre file generation steps
     * @param preFileGenerationSteps The pre steps
     */
    public void setPreFileGenerationSteps(List<PreFileGenerationStep> preFileGenerationSteps) {
        this.preFileGenerationSteps = preFileGenerationSteps;
    }

    /**
     * Purpose: Adds a pre file generation step
     * @param step The step to add
     */
    public void addPreFileGenerationStep(PreFileGenerationStep step) {
        this.preFileGenerationSteps.add(step);
    }

    /**
     * Purpose: Gets the post file generation steps
     * @return List<PostFileGenerationStep> The post steps
     */
    public List<PostFileGenerationStep> getPostFileGenerationSteps() {
        return postFileGenerationSteps;
    }

    /**
     * Purpose: Sets the post file generation steps
     * @param postFileGenerationSteps The post steps
     */
    public void setPostFileGenerationSteps(List<PostFileGenerationStep> postFileGenerationSteps) {
        this.postFileGenerationSteps = postFileGenerationSteps;
    }

    /**
     * Purpose: Adds a post file generation step
     * @param step The step to add
     */
    public void addPostFileGenerationStep(PostFileGenerationStep step) {
        this.postFileGenerationSteps.add(step);
    }

    /**
     * Purpose: Gets the file header section
     * @return FileGenerationStep The file header section
     */
    public FileGenerationStep getFileHeaderSection() {
        return fileHeaderSection;
    }

    /**
     * Purpose: Sets the file header section
     * @param fileHeaderSection The file header section
     */
    public void setFileHeaderSection(FileGenerationStep fileHeaderSection) {
        this.fileHeaderSection = fileHeaderSection;
    }
    
    /**
     * Purpose: Gets only the enabled pre-file generation steps in sequence order
     * @return List<PreFileGenerationStep> Enabled steps sorted by sequence
     */
    public List<PreFileGenerationStep> getEnabledPreSteps() {
        return preFileGenerationSteps.stream()
               .filter(PreFileGenerationStep::isEnable)
               .sorted((s1, s2) -> Integer.compare(s1.getSequence(), s2.getSequence()))
               .collect(Collectors.toList());
    }
    
    /**
     * Purpose: Gets only the enabled post-file generation steps in sequence order
     * @return List<PostFileGenerationStep> Enabled steps sorted by sequence
     */
    public List<PostFileGenerationStep> getEnabledPostSteps() {
        return postFileGenerationSteps.stream()
               .filter(PostFileGenerationStep::isEnable)
               .sorted((s1, s2) -> Integer.compare(s1.getSequence(), s2.getSequence()))
               .collect(Collectors.toList());
    }
}