package com.filegenerator.model.configuration;

public class GeneralConfiguration {
    private String appName;
    private String appVersion;
    private String appBuildDate;

    public GeneralConfiguration() {
        this.appName = "File Generator Application";
        this.appVersion = "1.0.0";
        this.appBuildDate = "2025-12-06";
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getAppVersion() {
        return appVersion;
    }

    public void setAppVersion(String appVersion) {
        this.appVersion = appVersion;
    }

    public String getAppBuildDate() {
        return appBuildDate;
    }

    public void setAppBuildDate(String appBuildDate) {
        this.appBuildDate = appBuildDate;
    }
}
