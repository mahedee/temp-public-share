package com.filegenerator.infrastructure.writer;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Base implementation for delimited file writers.
 */
public abstract class AbstractDelimitedFileWriter implements IFileWriter {
    
    private static final Logger logger = LoggerFactory.getLogger(AbstractDelimitedFileWriter.class);
    
    protected final String filePath;
    protected final String delimiter;
    protected BufferedWriter writer;

    public AbstractDelimitedFileWriter(String filePath, String delimiter) {
        this.filePath = filePath;
        this.delimiter = delimiter;
    }

    @Override
    public void open() throws IOException {
        logger.debug("Opening file for writing: {}", filePath);
        writer = new BufferedWriter(new FileWriter(filePath));
    }

    @Override
    public void writeHeader(List<String> headers) throws IOException {
        if (headers == null || headers.isEmpty()) {
            return;
        }
        String headerLine = headers.stream()
                .map(this::escapeValue)
                .collect(Collectors.joining(delimiter));
        writer.write(headerLine);
        writer.newLine();
    }

    @Override
    public void writeRow(List<Object> data) throws IOException {
        if (data == null || data.isEmpty()) {
            return;
        }
        String line = data.stream()
                .map(this::formatValue)
                .map(this::escapeValue)
                .collect(Collectors.joining(delimiter));
        writer.write(line);
        writer.newLine();
    }

    @Override
    public void flush() throws IOException {
        if (writer != null) {
            writer.flush();
        }
    }

    @Override
    public void close() throws IOException {
        if (writer != null) {
            writer.close();
            logger.debug("Closed file: {}", filePath);
        }
    }

    /**
     * Formats a value to string.
     */
    protected String formatValue(Object value) {
        if (value == null) {
            return "";
        }
        return value.toString();
    }

    /**
     * Escapes a value if necessary.
     * Subclasses can override for specific escaping rules.
     */
    protected abstract String escapeValue(String value);
}
