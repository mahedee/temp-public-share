package com.filegenerator.repository.database;

import com.filegenerator.infrastructure.exception.DatabaseException;
import com.filegenerator.model.configuration.DatabaseConfiguration;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Database connection manager implementation using HikariCP.
 */
public class DatabaseConnectionManagerImpl implements IDatabaseConnectionManager {
    
    private static final Logger logger = LoggerFactory.getLogger(DatabaseConnectionManagerImpl.class);
    
    private final DatabaseConfiguration configuration;
    private HikariDataSource dataSource;

    public DatabaseConnectionManagerImpl(DatabaseConfiguration configuration) {
        this.configuration = configuration;
    }

    @Override
    public void initialize() {
        logger.info("Initializing database connection pool");
        
        try {
            HikariConfig config = new HikariConfig();
            config.setJdbcUrl(configuration.getConnectionString());
            config.setUsername(configuration.getUsername());
            
            // Use getPlainPassword() which handles decryption if needed
            config.setPassword(configuration.getPlainPassword());
            
            config.setMinimumIdle(configuration.getPoolSize());
            config.setMaximumPoolSize(configuration.getMaxPoolSize());
            config.setConnectionTimeout(configuration.getConnectionTimeout());
            config.setIdleTimeout(configuration.getIdleTimeout());
            
            // Performance settings
            config.setAutoCommit(true);  // Enable autocommit for automatic transaction commit
            // Remove setReadOnly(true) since we need to perform UPDATE operations
            
            // Connection test query
            config.setConnectionTestQuery("SELECT 1 FROM DUAL");
            
            dataSource = new HikariDataSource(config);
            
            if (configuration.isEncryptedPassword()) {
                logger.info("Database connection pool initialized with encrypted password");
            } else {
                logger.info("Database connection pool initialized with plain text password");
            }
            
        } catch (Exception e) {
            logger.error("Failed to initialize database connection pool", e);
            throw new RuntimeException("Failed to initialize database connection pool", e);
        }
    }

    @Override
    public Connection getConnection() throws DatabaseException {
        try {
            if (dataSource == null) {
                throw new DatabaseException("Connection pool not initialized");
            }
            
            Connection connection = dataSource.getConnection();
            logger.debug("Acquired database connection from pool");
            return connection;
            
        } catch (SQLException e) {
            logger.error("Failed to get database connection", e);
            throw new DatabaseException("Failed to get database connection", e);
        }
    }

    @Override
    public void releaseConnection(Connection connection) throws DatabaseException {
        if (connection != null) {
            try {
                connection.close(); // HikariCP returns it to the pool
                logger.debug("Released database connection to pool");
            } catch (SQLException e) {
                logger.error("Error releasing connection", e);
                throw new DatabaseException("Error releasing connection", e);
            }
        }
    }

    @Override
    public HikariDataSource getDataSource() {
        return dataSource;
    }

    @Override
    public void close() {
        if (dataSource != null && !dataSource.isClosed()) {
            logger.info("Closing database connection pool");
            dataSource.close();
        }
    }
}
