package com.batchengine.model;

public class ManualAccount {

    private String accountId;
    private String accountSourceRefId;
    private String accountSourceUniqueId;

    public ManualAccount() {}

    public ManualAccount(String accountId, String accountSourceRefId, String accountSourceUniqueId) {
        this.accountId = accountId;
        this.accountSourceRefId = accountSourceRefId;
        this.accountSourceUniqueId = accountSourceUniqueId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getAccountSourceRefId() {
        return accountSourceRefId;
    }

    public void setAccountSourceRefId(String accountSourceRefId) {
        this.accountSourceRefId = accountSourceRefId;
    }

    public String getAccountSourceUniqueId() {
        return accountSourceUniqueId;
    }

    public void setAccountSourceUniqueId(String accountSourceUniqueId) {
        this.accountSourceUniqueId = accountSourceUniqueId;
    }

    @Override
    public String toString() {
        return "ManualAccount{" +
               "accountId='" + accountId + '\'' +
               ", accountSourceRefId='" + accountSourceRefId + '\'' +
               ", accountSourceUniqueId='" + accountSourceUniqueId + '\'' +
               '}';
    }
}
