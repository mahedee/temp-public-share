package com.batchengine.model;

public class CaseCustomerAccountLink {

    private String accountId;
    private String customerId;
    private String caseKey;
    private long caseKeyNum;

    public CaseCustomerAccountLink() {}

    public CaseCustomerAccountLink(String accountId, String customerId, String caseKey) {
        this.accountId = accountId;
        this.customerId = customerId;
        this.caseKey = caseKey;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public String getCaseKey() {
        return caseKey;
    }

    public void setCaseKey(String caseKey) {
        this.caseKey = caseKey;
    }

    public long getCaseKeyNum() {
        return caseKeyNum;
    }

    public void setCaseKeyNum(long caseKeyNum) {
        this.caseKeyNum = caseKeyNum;
    }

    @Override
    public String toString() {
        return "CaseCustomerAccountLink{" +
               "accountId='" + accountId + '\'' +
               ", customerId='" + customerId + '\'' +
               ", caseKey='" + caseKey + '\'' +
               '}';
    }


}
