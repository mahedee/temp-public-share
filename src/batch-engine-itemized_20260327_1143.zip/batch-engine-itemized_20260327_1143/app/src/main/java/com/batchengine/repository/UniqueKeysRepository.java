package com.batchengine.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import javax.sql.DataSource;

/**
 * Repository for UNIQUE_KEYS table data access.
 * Contains SQL queries related to unique key management.
 */
@Repository
@ConditionalOnBean(DataSource.class)
public class UniqueKeysRepository {

    private static final Logger logger = LoggerFactory.getLogger(UniqueKeysRepository.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Update UNIQUE_KEYS table for a specific TABLE_NAME to set the NEXT_ID value.
     * 
     * @param tableName the name of the table to update in UNIQUE_KEYS
     * @param nextId the next ID value to set
     */
    public void updateUniqueKeysByTableName(String tableName, long nextId) {
        String sql =
            "UPDATE UNIQUE_KEYS " +
            "SET NEXT_ID = ? " +
            "WHERE LOWER(TABLE_NAME) = LOWER(?)";

        try {
            jdbcTemplate.update(sql, nextId, tableName);
        } catch (DataAccessException e) {
            logger.error("Failed to update UNIQUE_KEYS for TABLE_NAME: {}. Error: {}", tableName, e.getMessage(), e);
            throw new RuntimeException("updateUniqueKeysByTableName failed for TABLE_NAME: " + tableName, e);
        }
    }
}