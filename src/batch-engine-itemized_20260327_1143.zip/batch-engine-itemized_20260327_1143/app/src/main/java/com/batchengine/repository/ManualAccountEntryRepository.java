package com.batchengine.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Lazy;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;
import java.util.List;

import com.batchengine.model.CaseCustomerAccountLink;
import com.batchengine.model.ManualAccount;

/**
 * Repository for Manual Account Entry data access.
 * Contains all SQL queries related to manual account entry processing.
 */
@Repository
@ConditionalOnBean(DataSource.class)
public class ManualAccountEntryRepository {

    private static final Logger logger = LoggerFactory.getLogger(ManualAccountEntryRepository.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    @Autowired
    @Lazy
    private ManualAccountEntryRepository self;


    public void processEntries() {
        logger.info("Processing manual account entries...");

        try {

            // Step 1: Mark relevant BMO_ACCOUNTS_MANUAL records as PROCESSING
            int step1Rows = self.markProcessingStatus();
            logger.info("Step 1 completed - BMO_ACCOUNTS_MANUAL marked as PROCESSING: {} row(s)", step1Rows);

            if (step1Rows == 0) {
                logger.info("No records to process. Skipping remaining steps.");
                return;
            }

            // Step 2: Fetch all entries that are now in PROCESSING status
            List<ManualAccount> processingEntries = getProcessingEntries();
            if(processingEntries.isEmpty()) {
                logger.warn("No records found in PROCESSING status after Step 1. This should not happen. Aborting process.");
                return;
            }

            // Step 3-5: Process each entry individually to ensure transactionality and error isolation
            for (ManualAccount manualAccount : processingEntries) {
                try {
                    self.processSingleAccount(manualAccount);
                } catch (RuntimeException e) {
                    logger.error("Failed to process account ACCOUNT_SOURCE_REF_ID: {}. Skipping. Cause: {}",
                        manualAccount.getAccountSourceRefId(), e.getMessage());
                }
            }
            processingEntries.clear(); // release references promptly

            logger.info("Manual account entry processing completed successfully.");

        } catch (RuntimeException e) {
            logger.error("Manual account entry processing aborted. Cause: {}", e.getMessage());
            throw e;
        }
    }

    @Transactional(rollbackFor = Exception.class)
    public void processSingleAccount(ManualAccount manualAccount) {
        String accountId = getAccountIdBySourceRefId(manualAccount.getAccountSourceRefId());

        // update ACCOUNT_DYNAMIC for this account if ACCOUNT_ID is found and does not already exist in ACCOUNT_DYNAMIC
        if (accountId != null && !accountId.equals(manualAccount.getAccountSourceRefId())) {
            int updatedRows = updateAccountDynamicByAccountId(accountId, manualAccount.getAccountSourceRefId());
            logger.info("Updated ACCOUNT_DYNAMIC for ACCOUNT_SOURCE_REF_ID: {} with ACCOUNT_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), accountId, updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping ACCOUNT_DYNAMIC update for this record.", manualAccount.getAccountSourceRefId());
        }

        // update WORKFLOW_WORKITEM_LINK for this account if ACCOUNT_ID is found
        if (accountId != null && !accountId.equals(manualAccount.getAccountSourceRefId())) {
            int updatedRows = updateWorkflowWorkitemLinkByAccountId(accountId, manualAccount.getAccountSourceRefId());
            logger.info("Updated WORKFLOW_WORKITEM_LINK for ACCOUNT_SOURCE_REF_ID: {} with ACCOUNT_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), accountId, updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping WORKFLOW_WORKITEM_LINK update for this record.", manualAccount.getAccountSourceRefId());
        }

        // update BMO_ACC_PH_DETAILS for this account if ACCOUNT_ID is found
        if (accountId != null && !accountId.equals(manualAccount.getAccountSourceRefId())) {
            int updatedRows = updateBmoAccPhDetailsByAccountId(accountId, manualAccount.getAccountSourceRefId());
            logger.info("Updated BMO_ACC_PH_DETAILS for ACCOUNT_SOURCE_REF_ID: {} with ACCOUNT_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), accountId, updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping BMO_ACC_PH_DETAILS update for this record.", manualAccount.getAccountSourceRefId());
        }

        // Get List of CaseCustomerAccountLink for this ACCOUNT_ID if ACCOUNT_ID is found
        // Add customer for corresponding cases in WORKFLOW_WORKITEM_LINK table
        if (accountId != null) {
            List<CaseCustomerAccountLink> caseLinks = getCaseCustomerAccountLinksByAccountId(accountId);
            logger.info("Fetched {} CaseCustomerAccountLink(s) for ACCOUNT_ID: {}", caseLinks.size(), accountId);
            for (CaseCustomerAccountLink link : caseLinks) {
                try {
                    if (!checkCaseCustomerExists(link.getCaseKey(), link.getCustomerId())) {
                        int insertedRows = insertCaseCustomerLink(link.getCaseKey(), link.getCaseKeyNum(), link.getCustomerId());
                        logger.info("Inserted CASE_CUSTOMER link for CASE_KEY: {} and CUSTOMER_ID: {}. Rows affected: {}", link.getCaseKey(), link.getCustomerId(), insertedRows);

                        int updatedRows = updateWorkflowWorkItemLinkUniqueKeys();
                        logger.info("Updated UNIQUE_KEYS for WORKFLOW_WORKITEM_LINK after inserting CASE_CUSTOMER link for CASE_KEY: {} and CUSTOMER_ID: {}. Rows affected: {}", link.getCaseKey(), link.getCustomerId(), updatedRows);
                    } else {
                        logger.info("CASE_CUSTOMER link already exists for CASE_KEY: {} and CUSTOMER_ID: {}. Skipping insert.", link.getCaseKey(), link.getCustomerId());
                    }
                } catch (RuntimeException e) {
                    logger.error("Failed to insert CASE_CUSTOMER link for CASE_KEY: {} and CUSTOMER_ID: {}. Skipping. Cause: {}",
                        link.getCaseKey(), link.getCustomerId(), e.getMessage());
                }
            }

        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping fetch of CaseCustomerAccountLink for this record.", manualAccount.getAccountSourceRefId());
        }

        // soft-delete BMO_ACCOUNTS_MANUAL for this account if ACCOUNT_ID is found
        if (accountId != null) {
            int updatedRows = softDeleteManualEntryByAccountSourceRefId(manualAccount.getAccountSourceRefId());
            logger.info("Soft-deleted BMO_ACCOUNTS_MANUAL for ACCOUNT_SOURCE_REF_ID: {}. Rows affected: {}", manualAccount.getAccountSourceRefId(), updatedRows);
        } else {
            logger.warn("No ACCOUNT_ID found in ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Skipping soft-delete for this record.", manualAccount.getAccountSourceRefId());
        }
    }

    /**
     * Step 1: Mark BMO_ACCOUNTS_MANUAL records as PROCESSING.
     * Targets active, non-deleted manual entries that have a matching record in ACCOUNTS.
     * @Transactional(rollbackFor = Exception.class) ensures that if any error occurs during this update, the transaction will be rolled back to maintain data integrity.
     */

    @Transactional(rollbackFor = Exception.class)
    public int markProcessingStatus() {
        String sql =
            "UPDATE BMO_ACCOUNTS_MANUAL man " +
            "SET STATUS = 'PROCESSING' " +
            "WHERE man.IS_DELETED = 'N' AND man.STATUS = 'ACTIVE' " +
            "  AND EXISTS ( " +
            "        SELECT 1 " +
            "        FROM   ACCOUNTS acc " +
            "        WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID " +
            "      )";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 1 failed - Unable to mark BMO_ACCOUNTS_MANUAL records as PROCESSING. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 1 - markProcessingStatus failed", e);
        }
    }


        /**
     * Fetch all BMO_ACCOUNTS_MANUAL records currently in PROCESSING status.
     *
     * @return list of ManualAccount objects containing ACCOUNT_ID, ACCOUNT_SOURCE_REF_ID, and ACCOUNT_SOURCE_UNIQUE_ID
     */
    public List<ManualAccount> getProcessingEntries() {
        String sql =
            "SELECT ACCOUNT_ID, ACCOUNT_SOURCE_REF_ID, ACCOUNT_SOURCE_UNIQUE_ID " +
            "FROM   BMO_ACCOUNTS_MANUAL " +
            "WHERE  STATUS = 'PROCESSING'";
        try {
            List<ManualAccount> results = jdbcTemplate.query(sql, (rs, rowNum) -> {
                ManualAccount account = new ManualAccount();
                account.setAccountId(rs.getString("ACCOUNT_ID"));
                account.setAccountSourceRefId(rs.getString("ACCOUNT_SOURCE_REF_ID"));
                account.setAccountSourceUniqueId(rs.getString("ACCOUNT_SOURCE_UNIQUE_ID"));
                return account;
            });
            logger.info("Fetched {} PROCESSING record(s) from BMO_ACCOUNTS_MANUAL", results.size());
            return results;
        } catch (DataAccessException e) {
            logger.error("Failed to fetch PROCESSING entries from BMO_ACCOUNTS_MANUAL. Error: {}", e.getMessage(), e);
            throw new RuntimeException("getProcessingEntries failed", e);
        }
    }

    // Get Account Id from ACCOUNTS based on ACCOUNT_SOURCE_REF_ID
    private String getAccountIdBySourceRefId(String accountSourceRefId) {
        String sql =
            "SELECT ACCOUNT_ID " +
            "FROM   ACCOUNTS " +
            "WHERE  ACCOUNT_SOURCE_REF_ID = ? " +
            "AND    ACCOUNT_ID IS NOT NULL " +
            "FETCH FIRST 1 ROW ONLY";
        try {
            return jdbcTemplate.queryForObject(sql, String.class, accountSourceRefId);
        } catch (EmptyResultDataAccessException e) {
            return null; // No matching account found — expected business case
        } catch (DataAccessException e) {
            logger.error("Failed to fetch ACCOUNT_ID from ACCOUNTS for ACCOUNT_SOURCE_REF_ID: {}. Error: {}", accountSourceRefId, e.getMessage(), e);
            throw new RuntimeException("getAccountIdBySourceRefId failed for ACCOUNT_SOURCE_REF_ID: " + accountSourceRefId, e);
        }
    }

    private int updateAccountDynamicByAccountId(String accountId, String accountSourceRefId) {
        if(checkAccountIdExistsInAccountDynamic(accountId)) {
            logger.info("ACCOUNT_ID {} already exists in ACCOUNT_DYNAMIC. Skipping update for ACCOUNT_SOURCE_REF_ID: {}", accountId, accountSourceRefId);
            return 0; // No rows updated since ACCOUNT_ID already exists
        }

        String sql =
            "UPDATE ACCOUNT_DYNAMIC " +
            "SET ACCOUNT_ID = ? " +
            "WHERE ACCOUNT_ID = ?"; // Assuming ACCOUNT_ID is currently set to ACCOUNT_SOURCE_REF_ID

        try {
            return jdbcTemplate.update(sql, accountId, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to update ACCOUNT_DYNAMIC for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("updateAccountDynamicByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }

    // Check if ACCOUNT_ID already exists in ACCOUNT_DYNAMIC to prevent duplicate key issues
   private boolean checkAccountIdExistsInAccountDynamic(String accountId) {
        String sql =
            "SELECT COUNT(1) " +
            "FROM ACCOUNT_DYNAMIC " +
            "WHERE ACCOUNT_ID = ?";
        try {
            Integer count = jdbcTemplate.queryForObject(sql, Integer.class, accountId);
            return count != null && count > 0;
        } catch (DataAccessException e) {
            logger.error("Failed to check if ACCOUNT_ID exists in ACCOUNT_DYNAMIC for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("checkAccountIdExistsInAccountDynamic failed for ACCOUNT_ID: " + accountId, e);
        }
    }


    // Update WORKFLOW_WORKITEM_LINK for a specific ACCOUNT_ID and ACCOUNT_SOURCE_REF_ID
    private int updateWorkflowWorkitemLinkByAccountId(String accountId, String accountSourceRefId) {
        String sql =
            "UPDATE WORKFLOW_WORKITEM_LINK wwl " +
            "SET LINKED_ENTITY_KEY = ? " +
            "WHERE LINKED_ENTITY_KEY = ?"; // Assuming LINKED_ENTITY_KEY is currently set to ACCOUNT_SOURCE_REF_ID

        try {
            return jdbcTemplate.update(sql, accountId, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to update WORKFLOW_WORKITEM_LINK for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("updateWorkflowWorkitemLinkByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }

    // Overloaded method to update BMO_ACC_PH_DETAILS for a specific ACCOUNT_ID and ACCOUNT_SOURCE_REF_ID
    private int updateBmoAccPhDetailsByAccountId(String accountId, String accountSourceRefId) {
        String sql =
            "UPDATE BMO_ACC_PH_DETAILS ph " +
            "SET FCM_CP_ACCOUNT_ID = ? " +
            "WHERE FCM_CP_ACCOUNT_ID = ?"; // Assuming FCM_CP_ACCOUNT_ID is currently set to ACCOUNT_SOURCE_REF_ID

        try {
            return jdbcTemplate.update(sql, accountId, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to update BMO_ACC_PH_DETAILS for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("updateBmoAccPhDetailsByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }   

    /**
     * Step 5: Soft-delete and finalise PROCESSING records in BMO_ACCOUNTS_MANUAL.
     * Sets IS_DELETED = 'Y', STATUS = 'DELETED', and records the canonical ACCOUNT_ID
     * from ACCOUNTS to mark these manual entries as fully processed.
     */
    
    private int softDeleteManualEntryByAccountSourceRefId(String accountSourceRefId) {
        String sql =
            "UPDATE BMO_ACCOUNTS_MANUAL " +
            "SET IS_DELETED = 'Y', STATUS = 'DELETED' " +
            "WHERE ACCOUNT_SOURCE_REF_ID = ?";

        try {
            return jdbcTemplate.update(sql, accountSourceRefId);
        } catch (DataAccessException e) {
            logger.error("Failed to soft-delete BMO_ACCOUNTS_MANUAL for ACCOUNT_SOURCE_REF_ID: {}. Error: {}", accountSourceRefId, e.getMessage(), e);
            throw new RuntimeException("softDeleteManualEntryByAccountSourceRefId failed for ACCOUNT_SOURCE_REF_ID: " + accountSourceRefId, e);
        }
    }

    
    // Get List of CaseCustomerAccountLink by ACCOUNT_ID
    public List<CaseCustomerAccountLink> getCaseCustomerAccountLinksByAccountId(String accountId) {
        String sql =
            "SELECT wwl.ENTITY_KEY AS CASE_KEY, wwl.ENTITY_KEY_NUM AS CASE_KEY_NUM, wwl.LINKED_ENTITY_KEY AS ACCOUNT_ID, acc.PRIMARY_CUSTOMER_ID AS CUSTOMER_ID " +
            "FROM WORKFLOW_WORKITEM_LINK wwl " +
            "JOIN ACCOUNTS acc ON wwl.LINKED_ENTITY_KEY = acc.ACCOUNT_ID " +
            "WHERE wwl.ENTITY_NAME = 'Case' " +
            "AND wwl.LINKED_ENTITY_NAME = 'Account' " +
            "AND wwl.TO_TIMESTAMP = TO_TIMESTAMP('9999-12-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS') " +
            "AND wwl.LINKED_ENTITY_KEY = ?";

        try {
            return jdbcTemplate.query(sql, new Object[]{accountId}, (rs, rowNum) -> {
                CaseCustomerAccountLink link = new CaseCustomerAccountLink();
                link.setCaseKey(rs.getString("CASE_KEY"));
                link.setCaseKeyNum(rs.getLong("CASE_KEY_NUM"));
                link.setAccountId(rs.getString("ACCOUNT_ID"));
                link.setCustomerId(rs.getString("CUSTOMER_ID"));
                return link;
            });
        } catch (DataAccessException e) {
            logger.error("Failed to fetch CaseCustomerAccountLink for ACCOUNT_ID: {}. Error: {}", accountId, e.getMessage(), e);
            throw new RuntimeException("getCaseCustomerAccountLinksByAccountId failed for ACCOUNT_ID: " + accountId, e);
        }
    }


    
    // Check if ACCOUNT_ID already exists in ACCOUNT_DYNAMIC to prevent duplicate key issues
   private boolean checkCaseCustomerExists(String caseKey, String customerId) {
        String sql = "SELECT COUNT(1) FROM WORKFLOW_WORKITEM_LINK " + 
                        "WHERE ENTITY_NAME = 'Case' " + 
                        "AND LINKED_ENTITY_NAME = 'Customer' " + 
                        "AND TO_TIMESTAMP = TO_TIMESTAMP('9999-12-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS') " + 
                        "AND ENTITY_KEY = ? " + 
                        "AND LINKED_ENTITY_KEY = ? " +
                        "AND TO_TIMESTAMP = TO_TIMESTAMP('9999-12-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS') ";
        try {
            Integer count = jdbcTemplate.queryForObject(sql, new Object[]{caseKey, customerId}, Integer.class);
            return count != null && count > 0;
        } catch (DataAccessException e) {
            logger.error("Failed to check if CASE_CUSTOMER exists in WORKFLOW_WORKITEM_LINK for CASE_KEY: {} and CUSTOMER_ID: {}. Error: {}", caseKey, customerId, e.getMessage(), e);
            throw new RuntimeException("checkCaseCustomerExists failed for CASE_KEY: " + caseKey + " and CUSTOMER_ID: " + customerId, e);
        }
    }

    // Insert link between Case and Customer in WORKFLOW_WORKITEM_LINK if it does not already exist
    private int insertCaseCustomerLink(String caseKey, long caseKeyNum, String customerId) {
        String sql = "INSERT INTO WORKFLOW_WORKITEM_LINK (ID, ENTITY_NAME, ENTITY_KEY, ENTITY_KEY_NUM, LINKED_ENTITY_NAME, LINKED_ENTITY_KEY, LINKED_ENTITY_KEY_NUM, FROM_TIMESTAMP, TO_TIMESTAMP, ENTITY_LINK_CODE, LINK_TIME_STATUS) " +
                        "VALUES ((SELECT MAX(ID) + 1 FROM WORKFLOW_WORKITEM_LINK), 'Case', ?, ?, 'Customer', ?, null, CURRENT_TIMESTAMP, TO_TIMESTAMP('9999-12-31 00:00:00', 'YYYY-MM-DD HH24:MI:SS'), 'AC0007', 'C')";
        try {
            return jdbcTemplate.update(sql, caseKey, caseKeyNum, customerId);
        } catch (DataAccessException e) {
            logger.error("Failed to insert CASE_CUSTOMER link in WORKFLOW_WORKITEM_LINK for CASE_KEY: {} and CASE_KEY_NUM: {} and CUSTOMER_ID: {}. Error: {}", caseKey, caseKeyNum, customerId, e.getMessage(), e);
            throw new RuntimeException("insertCaseCustomerLink failed for CASE_KEY: " + caseKey + " and CASE_KEY_NUM: " + caseKeyNum + " and CUSTOMER_ID: " + customerId, e);
        }
    }


    public int updateWorkflowWorkItemLinkUniqueKeys() {
        String sql =
            "UPDATE UNIQUE_KEYS " +
            "SET NEXT_ID = (SELECT MAX(ID) + 1 FROM WORKFLOW_WORKITEM_LINK) " +
            "WHERE LOWER(TABLE_NAME) = LOWER('WORKFLOW_WORKITEM_LINK')";

        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Failed to update UNIQUE_KEYS for TABLE_NAME: {}. Error: {}", "WORKFLOW_WORKITEM_LINK", e.getMessage(), e);
            throw new RuntimeException("updateUniqueKeysByTableName failed for TABLE_NAME: " + "WORKFLOW_WORKITEM_LINK", e);
        }
    }

}
