# Quick Start Guide for Linux Release Preparation

This guide helps you quickly prepare a Linux release of the Letter Generator application using the provided automation scripts.

## Prerequisites

Before starting, ensure you have:
- ✅ Visual Studio Code with Java extensions
- ✅ JDK 11 or higher installed
- ✅ Maven 3.6+ installed  
- ✅ Git for version control
- ✅ All code changes committed

## Option 1: Automated Release (Recommended)

### Using the Automation Script

1. **Navigate to project directory:**
   ```bash
   cd d:\Projects\Github\my-daptorik-apps\professional\current\src\letter-generator-v08
   ```

2. **Run the automated release script:**
   ```bash
   # For Linux/Mac (using Git Bash on Windows)
   bash release-scripts/prepare-release.sh
   
   # For Windows Command Prompt
   release-scripts\prepare-release.bat
   ```

3. **The script will automatically:**
   - Clean previous builds
   - Update version in pom.xml
   - Build the application
   - Create distribution structure
   - Generate all necessary scripts and configs
   - Package everything into a tar.gz archive
   - Create checksums
   - Restore development version

4. **Result:** You'll get `dist/letter-generator-1.0-linux.tar.gz` ready for deployment!

## Option 2: Manual Step-by-Step Process

If you prefer manual control, follow these commands:

### Step 1: Prepare the Build
```bash
# Clean previous builds
mvn clean

# Update version in pom.xml (remove -SNAPSHOT)
# Manually edit: <version>1.0-SNAPSHOT</version> → <version>1.0</version>

# Build application
mvn package
```

### Step 2: Create Distribution Structure
```bash
# Create directories
mkdir -p dist/letter-generator-1.0/{config,docs,scripts}

# Copy application files
cp target/letter-generator-1.0.jar dist/letter-generator-1.0/
cp -r config/* dist/letter-generator-1.0/config/
cp logback.xml dist/letter-generator-1.0/
cp docs/*.md dist/letter-generator-1.0/docs/
```

### Step 3: Create Linux Scripts
```bash
# Create startup script
cat > dist/letter-generator-1.0/start.sh << 'EOF'
#!/bin/bash
APP_NAME="letter-generator"
APP_VERSION="1.0"
JAR_FILE="letter-generator-${APP_VERSION}.jar"
JVM_OPTS="-Xms512m -Xmx1024m -XX:+UseG1GC"

mkdir -p logs

if [ ! -f "${JAR_FILE}" ]; then
    echo "Error: ${JAR_FILE} not found!"
    exit 1
fi

java ${JVM_OPTS} -Dlogback.configurationFile=logback.xml -jar "${JAR_FILE}" "$@"
EOF

# Make executable
chmod +x dist/letter-generator-1.0/start.sh
```

### Step 4: Package for Distribution
```bash
# Create tarball
cd dist
tar -czf letter-generator-1.0-linux.tar.gz letter-generator-1.0/

# Create checksum
sha256sum letter-generator-1.0-linux.tar.gz > letter-generator-1.0-linux.tar.gz.sha256
```

## Testing the Release Package

### Local Testing
```bash
# Extract and test
cd dist
tar -xzf letter-generator-1.0-linux.tar.gz
cd letter-generator-1.0

# Configure database (copy and edit)
cp config/production.properties config/config.properties
# Edit config.properties with your database details

# Test run
./start.sh generate_all_letters
```

### Verify Package Contents
```bash
# Check all files are present
find dist/letter-generator-1.0 -type f | sort
```

Expected files:
```
dist/letter-generator-1.0/
├── letter-generator-1.0.jar
├── start.sh
├── install.sh
├── logback.xml
├── logback-production.xml
├── DEPLOYMENT.md
├── config/
│   ├── config.json
│   ├── config.properties
│   ├── production.properties
│   └── letters/
└── docs/
```

## Deployment to Linux Server

### Upload to Server
```bash
# Upload the release package
scp dist/letter-generator-1.0-linux.tar.gz user@server:/tmp/
scp dist/letter-generator-1.0-linux.tar.gz.sha256 user@server:/tmp/
```

### Install on Server
```bash
# On the Linux server
cd /tmp

# Verify checksum
sha256sum -c letter-generator-1.0-linux.tar.gz.sha256

# Extract
tar -xzf letter-generator-1.0-linux.tar.gz
cd letter-generator-1.0

# Install as system service
sudo ./install.sh

# Configure database
sudo cp config/production.properties config/config.properties
sudo nano /opt/letter-generator/config/config.properties

# Start service
sudo systemctl start letter-generator
sudo systemctl status letter-generator
```

## Troubleshooting

### Common Issues

1. **Script not executable:**
   ```bash
   chmod +x release-scripts/prepare-release.sh
   ```

2. **Maven not found:**
   ```bash
   # Ensure Maven is in PATH
   mvn --version
   ```

3. **Java version mismatch:**
   ```bash
   # Check Java version
   java -version
   # Should be 11 or higher
   ```

4. **Permission denied on Windows:**
   ```bash
   # Run PowerShell/Command Prompt as Administrator
   ```

### Validation Commands

```bash
# Check JAR file
java -jar dist/letter-generator-1.0/letter-generator-1.0.jar --help

# Verify scripts syntax
bash -n dist/letter-generator-1.0/start.sh
bash -n dist/letter-generator-1.0/install.sh

# Check archive integrity
tar -tzf dist/letter-generator-1.0-linux.tar.gz | head -10
```

## Next Steps After Release

1. **Tag the release:**
   ```bash
   git tag -a v1.0 -m "Release version 1.0"
   git push origin v1.0
   ```

2. **Update to next development version:**
   ```bash
   # Edit pom.xml: <version>1.0</version> → <version>1.1-SNAPSHOT</version>
   git commit -am "Prepare next development iteration"
   ```

3. **Document the release:**
   - Update CHANGELOG.md
   - Create release notes
   - Notify deployment teams

## Files Created by This Process

- `dist/letter-generator-1.0-linux.tar.gz` - Main distribution package
- `dist/letter-generator-1.0-linux.tar.gz.sha256` - Checksum verification
- `dist/letter-generator-1.0/` - Extracted distribution directory
- All Linux deployment scripts and configuration templates

Your Letter Generator is now ready for production deployment on Linux! 🚀
