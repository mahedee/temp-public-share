# Letter Generator - New Architecture

This document describes the refactored letter generator application that implements the Open-Closed Principle for letter processing.

## Key Features

### 1. Letter Name Reading from config.json
- The application now reads letter names dynamically from the `config.json` file
- No hardcoded letter types in the code
- New letter types can be added to the configuration without code changes

### 2. Open-Closed Principle Implementation
- **LetterProcessor Interface**: Defines the contract for all letter processors
- **AbstractLetterProcessor**: Base implementation with common functionality
- **Specific Processors**: Individual classes for each letter type (DemandLetter, HoldLetter, etc.)
- **LetterProcessorFactory**: Manages processor registration and retrieval

### 3. Individual Letter Classes with Inline Queries
Each letter type has its own processor class:
- `DemandLetterProcessor`: Handles demand letter queries and columns
- `HoldLetterProcessor`: Handles hold letter queries and columns
- `IDTheftLetterProcessor`: Handles ID theft letter queries and columns
- `RelationshipTermLetterProcessor`: Handles relationship termination letter queries and columns

### 4. Missing Inline Query Logging
- When a new letter type is configured but no inline query processor exists, the system logs appropriate warnings
- Uses Java logging framework for proper error reporting
- Graceful handling of missing processors with informative messages

## Configuration Changes

The `config.json` now supports a new field `useInlineQuery`:

```json
{
  "letters": {
    "DemandLetter": {
      "enabled": true,
      "delimiter": "|",
      "useQueryFromXml": false,
      "useInlineQuery": true,
      "queryFile": "DemandLetter.xml",
      "exportPath": "output/demand/"
    }
  }
}
```

## Architecture Benefits

1. **Extensibility**: Easy to add new letter types by implementing the `LetterProcessor` interface
2. **Maintainability**: Each letter type has its own class with focused responsibilities
3. **Flexibility**: Supports both XML-based queries and inline queries
4. **Error Handling**: Proper logging when processors are missing
5. **Type Safety**: Interface-based design ensures consistent implementation

## Adding New Letter Types

### Step 1: Create a New Processor
```java
public class MyNewLetterProcessor extends AbstractLetterProcessor {
    public MyNewLetterProcessor() {
        super("MyNewLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT * FROM MY_TABLE";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("COLUMN1", "COLUMN2");
    }
}
```

### Step 2: Register the Processor
Add to `LetterProcessorFactory`:
```java
static {
    registerProcessor(new MyNewLetterProcessor());
    // ... other processors
}
```

### Step 3: Update Configuration
Add to `config.json`:
```json
"MyNewLetter": {
    "enabled": true,
    "delimiter": "|",
    "useQueryFromXml": false,
    "useInlineQuery": true,
    "queryFile": "MyNewLetter.xml",
    "exportPath": "output/mynew/"
}
```

## Error Scenarios

The system handles these error scenarios gracefully:

1. **Missing Processor**: Logs warning and returns default processor
2. **Empty Query**: Logs error and skips processing
3. **Database Errors**: Logs error with letter type context
4. **File Generation Errors**: Logs error with full path information

## Logging

The application uses Java's built-in logging framework:
- `INFO`: Normal processing information
- `WARNING`: Non-critical issues (missing processors)
- `SEVERE`: Critical errors that prevent processing

## Demo Classes

- `NewLetterTypeDemo`: Demonstrates how the system handles missing processors
- Shows logging behavior for undefined letter types
- Displays available registered processors

## Running the Application

The application maintains backward compatibility with the existing execution model:
```bash
java -jar letter-generator-1.0-SNAPSHOT.jar
```

The refactored code will:
1. Read all letter configurations from `config.json`
2. Use appropriate processors (XML or inline) based on configuration
3. Log processing status and any issues
4. Generate files as before
