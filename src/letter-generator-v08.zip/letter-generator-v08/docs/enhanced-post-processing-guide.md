# Enhanced Post-Processing Implementation Guide

## Overview

The Letter Generator application now supports post-processing functionality for both **XML-based queries** and **inline queries**. This provides a unified approach to handling database updates after file generation and SFTP transfer.

## Architecture Overview

### Query Source Types

#### 1. XML-Based Queries (`"querySource": "xml"`)
- Configuration stored in XML files (e.g., `DemandLetter.xml`)
- Post-processing steps defined in XML structure
- Uses `LetterDefinition` class for parsing

#### 2. Inline Queries (`"querySource": "inline"`)
- Configuration stored in Java processor classes
- Post-processing steps defined in processor methods
- Uses `LetterProcessor` interface implementation

## Implementation Details

### 1. Enhanced LetterProcessor Interface

The `LetterProcessor` interface now includes methods for post-processing:

```java
public interface LetterProcessor {
    // Existing methods...
    String getInlineQuery();
    List<String> getInlineColumns();
    
    // New post-processing methods
    Map<String, Object> getGlobalVariables();
    boolean hasPostFileGenerationStep();
    String getPostFileGenerationQuery();
    String getPostFileGenerationQueryType();
    boolean hasPostFileSentStep();
    String getPostFileSentQuery();
    String getPostFileSentQueryType();
}
```

### 2. Updated Processor Implementations

#### Example: DemandLetterProcessor (Inline)
```java
public class DemandLetterProcessor extends AbstractLetterProcessor {
    
    @Override
    public String getInlineQuery() {
        return "SELECT CASE_ID, ACCOUNT_NO, CUSTOMER_NAME, " +
               "TO_CHAR({sent_date}, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE, " +
               "STATUS FROM DEMAND_LETTERS WHERE STATUS = 'ACTIVE'";
    }
    
    @Override
    public Map<String, Object> getGlobalVariables() {
        return Map.of("sent_date", "{CURRENT_TIMESTAMP}");
    }
    
    @Override
    public boolean hasPostFileGenerationStep() {
        return true;
    }
    
    @Override
    public String getPostFileGenerationQuery() {
        return "UPDATE DEMAND_LETTERS SET SENT_DATE = {sent_date}, " +
               "STATUS = 'PROCESSED' WHERE STATUS = 'ACTIVE'";
    }
    
    @Override
    public boolean hasPostFileSentStep() {
        return true;
    }
    
    @Override
    public String getPostFileSentQuery() {
        return "UPDATE DEMAND_LETTERS SET STATUS = 'SENT' " +
               "WHERE STATUS = 'PROCESSED' AND SENT_DATE = {sent_date}";
    }
}
```

### 3. Enhanced LetterGenerator

The `LetterGenerator` class now handles both query sources uniformly:

#### Unified Processing Flow:
1. **Determine Query Source**: Check `querySource` in configuration
2. **Load Query and Columns**: From XML file or processor class
3. **Handle Global Variables**: Merge variables from both sources
4. **Execute Main Query**: Generate letter files
5. **Post File Generation Step**: Update database immediately after file generation
6. **Post File Sent Step**: Update database after SFTP transfer (via command line)

## Configuration Examples

### config.json Configuration
```json
{
  "letters": {
    "DemandLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "inline",
      "queryFile": "DemandLetter.xml",
      "exportPath": "output/demand/"
    },
    "IDTheftLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",
      "queryFile": "IDTheftLetter.xml",
      "exportPath": "output/idtheft/"
    }
  }
}
```

### XML Configuration (for XML-based queries)
```xml
<letter>
    <globalVariables>
        <sent_date>{CURRENT_TIMESTAMP}</sent_date>
    </globalVariables>
    <fileName>EFCM.PostMail.IDTheftLetter</fileName>
    <query>
        SELECT ACCOUNT_NO, CUSTOMER_NAME, CASE_DETAIL,
               TO_CHAR({sent_date}, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE,
               STATUS
        FROM ID_THEFT_CASES WHERE STATUS = 'ACTIVE'
    </query>
    <columns>
        <column>ACCOUNT_NO</column>
        <column>CUSTOMER_NAME</column>
        <column>CASE_DETAIL</column>
        <column>SENT_DATE</column>
        <column>STATUS</column>
    </columns>

    <postFileGenerationStep>
        <enable>true</enable>
        <queryType>update</queryType>
        <query>UPDATE ID_THEFT_CASES SET SENT_DATE = {sent_date}, STATUS = 'PROCESSED' WHERE STATUS = 'ACTIVE'</query>
    </postFileGenerationStep>

    <postFileSentStep>
        <enable>true</enable>
        <queryType>update</queryType>
        <query>UPDATE ID_THEFT_CASES SET STATUS = 'SENT' WHERE STATUS = 'PROCESSED' AND SENT_DATE = {sent_date}</query>
    </postFileSentStep>
</letter>
```

## Workflow Comparison

### XML-Based Query Workflow
```
Config.json → XML File → LetterDefinition → Database Query
     ↓              ↓              ↓              ↓
Query Source → Load XML → Parse XML → Execute Query
     ↓              ↓              ↓              ↓
Post Steps → XML Config → LetterDefinition → Execute Updates
```

### Inline Query Workflow
```
Config.json → Processor Class → LetterProcessor → Database Query
     ↓              ↓              ↓              ↓
Query Source → Load Processor → Get Methods → Execute Query
     ↓              ↓              ↓              ↓
Post Steps → Processor Methods → LetterProcessor → Execute Updates
```

## Usage Examples

### 1. Normal Letter Generation
Both XML and inline query sources work the same way:
```bash
# Generate all letters (includes post file generation steps)
java -jar target/letter-generator-1.0-SNAPSHOT.jar

# Generate specific letter type
java -jar target/letter-generator-1.0-SNAPSHOT.jar DemandLetter  # inline
java -jar target/letter-generator-1.0-SNAPSHOT.jar IDTheftLetter # xml
```

### 2. Post File Sent Step Execution
Works for both query sources:
```bash
# Execute post file sent step for all letter types
java -jar target/letter-generator-1.0-SNAPSHOT.jar perform_post_file_sent_step

# Execute for specific letter type (works for both xml and inline)
java -jar target/letter-generator-1.0-SNAPSHOT.jar perform_post_file_sent_step DemandLetter
java -jar target/letter-generator-1.0-SNAPSHOT.jar perform_post_file_sent_step IDTheftLetter
```

### 3. SFTP Integration
The SFTP scripts work with both query sources:
```bash
# Bash script (handles both xml and inline)
./scripts/sftp-transfer-and-post-process.sh

# PowerShell script (handles both xml and inline)
.\scripts\sftp-transfer-and-post-process.ps1
```

## Status Flow Examples

### Both Query Sources Follow the Same Pattern:
```
ACTIVE → (File Generation) → PROCESSED → (SFTP Transfer) → SENT
```

### Database Updates:
1. **Initial State**: `STATUS = 'ACTIVE'`
2. **After File Generation**: `STATUS = 'PROCESSED'`, `SENT_DATE = current_timestamp`
3. **After SFTP Transfer**: `STATUS = 'SENT'`

## Implementation Checklist

### For XML-Based Letters:
- ✅ Update XML files with new structure
- ✅ Add `globalVariables`, `postFileGenerationStep`, `postFileSentStep`
- ✅ Include `SENT_DATE` and `STATUS` columns in queries
- ✅ Add `WHERE STATUS = 'ACTIVE'` condition

### For Inline Query Letters:
- ✅ Update processor classes to extend new interface methods
- ✅ Implement `getGlobalVariables()` method
- ✅ Implement `hasPostFileGenerationStep()` and `getPostFileGenerationQuery()`
- ✅ Implement `hasPostFileSentStep()` and `getPostFileSentQuery()`
- ✅ Update main query to include `SENT_DATE` and `STATUS` columns
- ✅ Add `WHERE STATUS = 'ACTIVE'` condition

## Migration Guide

### Converting from XML to Inline:
1. Create a new processor class extending `AbstractLetterProcessor`
2. Move query from XML to `getInlineQuery()` method
3. Move columns from XML to `getInlineColumns()` method
4. Implement post-processing methods
5. Register processor in `LetterProcessorFactory`
6. Update `config.json` to use `"querySource": "inline"`

### Converting from Inline to XML:
1. Create XML file with letter structure
2. Move query from processor to XML `<query>` element
3. Move columns from processor to XML `<columns>` section
4. Add post-processing steps to XML
5. Update `config.json` to use `"querySource": "xml"`

## Benefits of Unified Approach

### 1. Consistency
- Same post-processing workflow for both query sources
- Uniform command-line interface
- Consistent logging and error handling

### 2. Flexibility
- Choose appropriate query source based on requirements
- Easy migration between XML and inline approaches
- Support for mixed environments

### 3. Maintainability
- Single codebase handles both approaches
- Centralized post-processing logic
- Unified testing and deployment

## Troubleshooting

### Common Issues:

#### 1. Missing Processor Registration
**Error**: "No inline query processor found for letter type"
**Solution**: Register processor in `LetterProcessorFactory.java`

#### 2. Empty Post-Processing Query
**Error**: "Empty query provided for post-processing step"
**Solution**: Implement post-processing methods in processor or XML

#### 3. Variable Replacement Issues
**Error**: Query contains unreplaced `{sent_date}` placeholders
**Solution**: Ensure `getGlobalVariables()` returns correct mappings

### Debug Commands:
```bash
# Test specific letter type
java -jar target/letter-generator-1.0-SNAPSHOT.jar TestLetter

# Check configuration
java -cp target/letter-generator-1.0-SNAPSHOT.jar com.efcm.lettergen.demo.ConfigurationDemo
```

This unified implementation provides enterprise-grade post-processing capabilities for both XML and inline query sources while maintaining consistency and flexibility.
