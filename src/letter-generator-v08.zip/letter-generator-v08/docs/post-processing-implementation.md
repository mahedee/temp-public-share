# Post-Processing Implementation Guide

## Overview

This document describes the implementation of post-processing steps for the Letter Generator application, including support for both XML-based and inline queries, and automated execution after file generation and SFTP transfer.

## Features Implemented

### 1. XML Structure Enhancements

The letter XML files now support:
- **Global Variables**: Define variables like `sent_date` that can be used throughout queries
- **Post File Generation Step**: Executed immediately after file generation
- **Post File Sent Step**: Executed after files are sent to SFTP server

#### Example XML Structure:
```xml
<letter>
    <globalVariables>
        <sent_date>{CURRENT_TIMESTAMP}</sent_date>
    </globalVariables>
    <fileName>EFCM.PostMail.DemandLetter</fileName>
    <query>
        SELECT 
            CASE_ID,
            ACCOUNT_NO, 
            CUSTOMER_NAME, 
            DUE_AMOUNT, 
            TO_CHAR(DUE_DATE, 'YYYY-MM-DD') AS DUE_DATE,
            REASON,
            TO_CHAR({sent_date}, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE,
            STATUS
        FROM DEMAND_LETTERS
        WHERE STATUS = 'ACTIVE'
    </query>
    <columns>
        <column>CASE_ID</column>
        <column>ACCOUNT_NO</column>
        <column>CUSTOMER_NAME</column>
        <column>DUE_AMOUNT</column>
        <column>DUE_DATE</column>
        <column>REASON</column>
        <column>SENT_DATE</column>
        <column>STATUS</column>
    </columns>

    <postFileGenerationStep>
        <enable>true</enable>
        <queryType>update</queryType>
        <query>UPDATE DEMAND_LETTERS SET SENT_DATE = {sent_date}, STATUS = 'PROCESSED' WHERE STATUS = 'ACTIVE'</query>
    </postFileGenerationStep>

    <postFileSentStep>
        <enable>true</enable>
        <queryType>update</queryType>
        <query>UPDATE DEMAND_LETTERS SET STATUS = 'SENT' WHERE STATUS = 'PROCESSED' AND SENT_DATE = {sent_date}</query>
    </postFileSentStep>
</letter>
```

### 2. Application Enhancements

#### New Classes Added:
- **`QueryProcessor`**: Handles variable replacement and post-processing step execution
- Enhanced **`LetterDefinition`**: Supports new XML structure with global variables and post-processing steps

#### Enhanced Methods in `LetterGenerator`:
- **`executePostFileSentStep(String letterType)`**: Execute post file sent step for specific letter type
- **`executePostFileSentStepForAll()`**: Execute post file sent steps for all enabled letter types
- Enhanced **`processLetter()`**: Now handles global variables and post file generation steps

#### Enhanced `App.java`:
- Supports new command-line parameter: `perform_post_file_sent_step`
- Can execute post file sent step for all letters or specific letter type

## Usage

### 1. Normal Letter Generation
```bash
# Generate all letters (includes post file generation steps)
java -jar target/letter-generator-1.0-SNAPSHOT.jar

# Generate specific letter type
java -jar target/letter-generator-1.0-SNAPSHOT.jar DemandLetter
```

### 2. Post File Sent Step Execution
```bash
# Execute post file sent step for all letter types
java -jar target/letter-generator-1.0-SNAPSHOT.jar perform_post_file_sent_step

# Execute post file sent step for specific letter type
java -jar target/letter-generator-1.0-SNAPSHOT.jar perform_post_file_sent_step DemandLetter
```

### 3. SFTP Integration Scripts

#### Bash Script (Linux/Git Bash):
```bash
./scripts/sftp-transfer-and-post-process.sh
```

#### PowerShell Script (Windows):
```powershell
.\scripts\sftp-transfer-and-post-process.ps1
```

Both scripts:
1. Transfer generated files to SFTP server
2. Execute post file sent steps for each letter type
3. Provide colored logging output
4. Handle errors gracefully

## Configuration

### SFTP Script Configuration
Edit the script files to configure your SFTP settings:

#### Bash Script:
```bash
SFTP_HOST="your-sftp-server.com"
SFTP_USER="your-username"
SFTP_PASSWORD="your-password"
SFTP_REMOTE_DIR="/remote/letters"
```

#### PowerShell Script:
```powershell
param(
    [string]$SftpHost = "your-sftp-server.com",
    [string]$SftpUser = "your-username", 
    [string]$SftpPassword = "your-password",
    [string]$SftpRemoteDir = "/remote/letters"
)
```

### XML Letter Configuration
Update your letter XML files to include:
1. Global variables section
2. Post file generation step configuration
3. Post file sent step configuration

## Workflow

### Complete Letter Processing Workflow:
1. **Letter Generation**: Application generates letters based on XML/inline queries
2. **Post File Generation Step**: Immediately updates database (e.g., mark as PROCESSED)
3. **File Transfer**: SFTP script transfers files to remote server
4. **Post File Sent Step**: Updates database after successful transfer (e.g., mark as SENT)

### Status Flow Example:
```
ACTIVE → (File Generation) → PROCESSED → (SFTP Transfer) → SENT
```

## Query Variable Replacement

The `QueryProcessor` class handles variable replacement:
- `{sent_date}` → Current timestamp
- `{CURRENT_TIMESTAMP}` → Oracle CURRENT_TIMESTAMP function
- Custom variables can be added as needed

## Error Handling

- Each letter type is processed independently
- Failed transfers don't prevent post-processing of other letters
- Comprehensive logging for troubleshooting
- Database connection management with proper cleanup

## Dependencies

### For SFTP Functionality:
- **Linux/Git Bash**: Standard SSH/SFTP client
- **Windows**: WinSCP (preferred) or PuTTY PSFTP

### For Application:
- Java 11+
- Oracle Database JDBC driver
- Maven for building

## Security Considerations

1. **Database**: Use secure connection strings and proper authentication
2. **SFTP**: Consider using key-based authentication instead of passwords
3. **Logging**: Ensure sensitive information is not logged
4. **File Permissions**: Set appropriate permissions on generated files

## Troubleshooting

### Common Issues:
1. **Database Connection**: Verify database URL, credentials, and network connectivity
2. **SFTP Transfer**: Check SFTP server settings and authentication
3. **File Permissions**: Ensure write permissions on output directories
4. **Java Path**: Verify Java is available in system PATH

### Log Files:
Check the following log files for detailed information:
- `logs/letter-generator.log`: Application logs
- `logs/letter-generator-errors.log`: Error-specific logs

## Example Integration

### Complete Automation Script:
```bash
#!/bin/bash

# 1. Generate all letters
echo "Generating letters..."
java -jar target/letter-generator-1.0-SNAPSHOT.jar

# 2. Transfer files and execute post file sent steps
echo "Transferring files and executing post-processing..."
./scripts/sftp-transfer-and-post-process.sh

echo "Letter processing workflow completed."
```

This implementation provides a robust, enterprise-grade solution for letter generation with automated post-processing capabilities.
