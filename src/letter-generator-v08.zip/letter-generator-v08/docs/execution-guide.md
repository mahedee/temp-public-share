# Letter Generator Application - Execution Guide

## Overview
The Letter Generator Application is a Java-based system that generates various types of letters using Oracle database queries. It supports both inline queries and XML-based queries, follows Open-Closed Principle architecture, and includes enterprise-grade logging.

## Prerequisites
- Java 11 or higher
- Oracle Database connectivity
- Git Bash (for Windows) or Bash shell (for Linux)
- Maven 3.6+ for building

## Application Execution Methods

### 1. Shell Script Execution (Recommended for Production)

#### Command:
```bash
# For Windows with Git Bash:
& "C:\Program Files\Git\bin\bash.exe" scripts/letter-generator-main.sh

# For Linux/Unix systems:
bash scripts/letter-generator-main.sh

# Or make executable and run directly:
chmod +x scripts/letter-generator-main.sh
./scripts/letter-generator-main.sh
```

#### What the Shell Script Does:
1. **Letter Generation**: Processes all enabled letter types from configuration
2. **SFTP Transfer**: Attempts to transfer generated files to remote server
3. **Log Cleanup**: Removes log files older than 5 days (configurable)
4. **Temporary Cleanup**: Cleans up temporary files and directories

### 2. Direct Java Execution

#### Commands:
```bash
# Generate all letters:
java -jar target/letter-generator-1.0-SNAPSHOT.jar

# Generate specific letter type:
java -jar target/letter-generator-1.0-SNAPSHOT.jar DemandLetter
java -jar target/letter-generator-1.0-SNAPSHOT.jar HoldLetter
java -jar target/letter-generator-1.0-SNAPSHOT.jar IDTheftLetter

# Encryption mode:
java -jar target/letter-generator-1.0-SNAPSHOT.jar "text to encrypt"
```

### 3. PowerShell Script (Windows Alternative)

#### Command:
```powershell
powershell -ExecutionPolicy Bypass -File scripts\letter-generator-main.ps1
```

## Configuration Files

### Main Configuration
- **Location**: `config/config.json`
- **Purpose**: Database connection, letter types, file naming patterns

### Letter Definitions (XML)
- **Location**: `config/letters/*.xml`
- **Files**: 
  - `DemandLetter.xml`
  - `HoldLetter.xml`
  - `IDTheftLetter.xml`
  - `RelationshipTermLetter.xml`
  - `TestLetter.xml`

### Logging Configuration
- **Location**: `src/main/resources/logback.xml`
- **Features**: 
  - 5-day log retention
  - Multiple log files (general, errors, letter-specific)
  - Rolling file policies

### Shell Script Configuration
- **Location**: `scripts/letter-generator-config.sh`
- **Purpose**: Environment variables, paths, SFTP settings

## Generated Output

### File Structure:
```
output/
├── demand/EFCM.PostMail.DemandLetter.YYYYMMDD.txt
├── hold/EFCM.PostMail.HoldLetter.YYYYMMDD.txt
├── idtheft/EFCM.PostMail.IDTheftLetter.YYYYMMDD.txt
├── relationship-term/EFCM.PostMail.RelationshipTermLetter.YYYYMMDD.txt
└── welcome/EFCM.PostMail.WelcomeLetter.YYYYMMDD.txt
```

### Log Files:
```
logs/
├── letter-generator.log                    # General application logs
├── letter-generator-errors.log             # Warnings and errors only
├── letter-generation.log                   # Letter generation specific
├── main_execution_YYYYMMDD_HHMMSS.log     # Shell script execution logs
├── letter_gen_YYYYMMDD_HHMMSS.log         # Individual letter generation
└── cleanup_YYYYMMDD_HHMMSS.log            # Log cleanup process
```

## Letter Types and Query Sources

| Letter Type | Query Source | Processor Class | Status |
|-------------|--------------|-----------------|---------|
| DemandLetter | Inline | DemandLetterProcessor | ✅ Active |
| HoldLetter | Inline | HoldLetterProcessor | ✅ Active |
| IDTheftLetter | XML | IDTheftLetterProcessor | ✅ Active |
| RelationshipTermLetter | XML | RelationshipTermLetterProcessor | ✅ Active |
| WelcomeLetter | Inline | WelcomeLetterProcessor | ✅ Active |
| TestLetter | Inline | ❌ Not Implemented | ⚠️ Error Handling |

## Error Handling

### TestLetter Example:
When TestLetter is processed, the application logs:
```
ERROR [c.e.l.generator.LetterGenerator] - Inline query not found for letter type: TestLetter. 
Please implement a processor for this letter type or change querySource to 'xml'.

WARN [c.e.l.generator.LetterGenerator] - TestLetter cannot be generated because inline query 
is missing. You have to add inline query in the code or you have to switch to xml query source.
```

## Building the Application

### Maven Commands:
```bash
# Clean and compile:
mvn clean compile

# Package JAR:
mvn clean compile package

# Skip tests during build:
mvn clean compile package -DskipTests

# Quiet mode (less verbose):
mvn clean compile package -q
```

## Deployment for Linux Server

### File Transfer:
1. Copy entire project directory to Linux server
2. Ensure Java 11+ is installed
3. Update `scripts/letter-generator-config.sh` with production paths
4. Set up Oracle database connectivity
5. Configure SFTP settings for file transfer

### Permissions:
```bash
chmod +x scripts/*.sh
```

### Cron Job Setup:
```bash
# Edit crontab
crontab -e

# Add daily execution at 2 AM
0 2 * * * /opt/letter-generator/scripts/letter-generator-main.sh
```

## Troubleshooting

### Database Connection Issues:
- Verify Oracle database is running
- Check connection parameters in `config/config.json`
- Ensure JDBC driver is included in classpath

### Permission Errors:
- Make shell scripts executable: `chmod +x scripts/*.sh`
- Check file permissions for log directories
- Verify write permissions for output directories

### Log File Issues:
- Check disk space for log directory
- Verify logback.xml configuration
- Ensure proper file rotation settings

## Monitoring and Maintenance

### Log Monitoring:
```bash
# View real-time logs:
tail -f logs/letter-generator.log

# Check error logs:
grep ERROR logs/letter-generator-errors.log

# Monitor letter generation:
tail -f logs/letter-generation.log
```

### Cleanup:
- Log cleanup runs automatically with shell script
- Manual cleanup: `bash scripts/cleanup-old-logs.sh`
- Configurable retention period (default: 5 days)

## Support

For issues or questions:
1. Check log files in `logs/` directory
2. Review configuration files
3. Verify database connectivity
4. Check file permissions and disk space

---
**Last Updated**: August 15, 2025  
**Version**: 1.0-SNAPSHOT  
**Architecture**: Open-Closed Principle with SLF4J/Logback Logging
