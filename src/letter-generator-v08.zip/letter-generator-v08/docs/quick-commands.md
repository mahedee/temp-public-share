# Letter Generator - Quick Command Reference

## Primary Execution Command

### Windows (Git Bash):
```bash
& "C:\Program Files\Git\bin\bash.exe" scripts/letter-generator-main.sh
```

### Linux/Unix:
```bash
bash scripts/letter-generator-main.sh
```

### Make Executable and Run (Linux):
```bash
chmod +x scripts/letter-generator-main.sh
./scripts/letter-generator-main.sh
```

## Alternative Commands

### Direct Java Execution:
```bash
# All letters:
java -jar target/letter-generator-1.0-SNAPSHOT.jar

# Specific letter:
java -jar target/letter-generator-1.0-SNAPSHOT.jar DemandLetter
```

### PowerShell (Windows):
```powershell
powershell -ExecutionPolicy Bypass -File scripts\letter-generator-main.ps1
```

## Build Commands:
```bash
mvn clean compile package -q
```

## Quick Status Check:
```bash
# View latest logs:
tail -5 logs/letter-generator.log

# Check generated files:
ls -la output/*/
```
