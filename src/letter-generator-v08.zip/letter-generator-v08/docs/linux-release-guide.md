# Linux Release Preparation Guide for Letter Generator

## Overview
This guide provides step-by-step instructions for preparing a production release of the Letter Generator application for Linux environments using Visual Studio Code.

## Prerequisites

### Development Environment
- Visual Studio Code with Java extensions
- JDK 11 or higher
- Maven 3.6+
- Git for version control
- Access to target Linux environment for testing

### Linux Target Environment
- Linux distribution (Ubuntu 18.04+, CentOS 7+, RHEL 7+, etc.)
- JRE 11 or higher
- Database connectivity (Oracle Database)
- Sufficient disk space for application and logs

## Step 1: Pre-Release Code Preparation

### 1.1 Clean and Validate Codebase
```bash
# Clean any existing build artifacts
mvn clean

# Validate project structure and dependencies
mvn validate

# Run tests (if available)
mvn test

# Check for security vulnerabilities
mvn dependency:check
```

### 1.2 Version Management
```bash
# Update version in pom.xml (remove -SNAPSHOT for release)
# Change from: <version>1.0-SNAPSHOT</version>
# To: <version>1.0</version>

# Commit version change
git add pom.xml
git commit -m "Prepare release version 1.0"
git tag -a v1.0 -m "Release version 1.0"
```

### 1.3 Configuration Review
Review and update configuration files for production:

- `config/config.properties` - Database connections, file paths
- `config/config.json` - Application settings
- `logback.xml` - Logging configuration for production

## Step 2: Build Production Artifacts

### 2.1 Clean Build
```bash
# Perform clean build with production profile
mvn clean compile

# Package with all dependencies
mvn package

# Verify the packaged JAR
ls -la target/letter-generator-*.jar
```

### 2.2 Create Distribution Package
```bash
# Create distribution directory
mkdir -p dist/letter-generator-1.0

# Copy application JAR
cp target/letter-generator-1.0.jar dist/letter-generator-1.0/

# Copy configuration files
cp -r config/ dist/letter-generator-1.0/
cp logback.xml dist/letter-generator-1.0/

# Copy documentation
mkdir -p dist/letter-generator-1.0/docs
cp docs/*.md dist/letter-generator-1.0/docs/
cp README.md dist/letter-generator-1.0/ 2>/dev/null || true
```

## Step 3: Create Linux Deployment Scripts

### 3.1 Create Startup Script
Create `dist/letter-generator-1.0/start.sh`:

```bash
#!/bin/bash

# Letter Generator Startup Script
# Usage: ./start.sh [arguments]

# Configuration
APP_NAME="letter-generator"
APP_VERSION="1.0"
JAR_FILE="letter-generator-${APP_VERSION}.jar"
JVM_OPTS="-Xms512m -Xmx1024m -XX:+UseG1GC"
LOG_DIR="logs"
CONFIG_DIR="config"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Check if JAR file exists
if [ ! -f "${JAR_FILE}" ]; then
    echo "Error: ${JAR_FILE} not found!"
    exit 1
fi

# Check Java installation
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in PATH"
    exit 1
fi

# Check Java version
JAVA_VERSION=$(java -version 2>&1 | grep -oP 'version "?(1\.)?\K\d+' | head -1)
if [ "${JAVA_VERSION}" -lt 11 ]; then
    echo "Error: Java 11 or higher is required. Found: ${JAVA_VERSION}"
    exit 1
fi

# Start the application
echo "Starting ${APP_NAME} v${APP_VERSION}..."
echo "Java Version: $(java -version 2>&1 | head -1)"
echo "Arguments: $@"
echo "Log directory: ${LOG_DIR}"
echo "Starting at: $(date)"

java ${JVM_OPTS} \
    -Dlogback.configurationFile=logback.xml \
    -Djava.awt.headless=true \
    -jar "${JAR_FILE}" "$@"

echo "Application finished at: $(date)"
```

### 3.2 Create Installation Script
Create `dist/letter-generator-1.0/install.sh`:

```bash
#!/bin/bash

# Letter Generator Installation Script

APP_NAME="letter-generator"
INSTALL_DIR="/opt/${APP_NAME}"
SERVICE_USER="lettergen"
LOG_DIR="/var/log/${APP_NAME}"

echo "Installing Letter Generator..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Create service user
if ! id "${SERVICE_USER}" &>/dev/null; then
    echo "Creating service user: ${SERVICE_USER}"
    useradd -r -s /bin/false -d "${INSTALL_DIR}" "${SERVICE_USER}"
fi

# Create directories
echo "Creating directories..."
mkdir -p "${INSTALL_DIR}"
mkdir -p "${LOG_DIR}"

# Copy application files
echo "Copying application files..."
cp -r ./* "${INSTALL_DIR}/"

# Set permissions
echo "Setting permissions..."
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${LOG_DIR}"
chmod +x "${INSTALL_DIR}/start.sh"

# Create systemd service
echo "Creating systemd service..."
cat > "/etc/systemd/system/${APP_NAME}.service" << EOF
[Unit]
Description=Letter Generator Service
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/start.sh generate_all_letters
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Reload systemd and enable service
systemctl daemon-reload
systemctl enable "${APP_NAME}"

echo "Installation completed!"
echo "Service user: ${SERVICE_USER}"
echo "Install directory: ${INSTALL_DIR}"
echo "Log directory: ${LOG_DIR}"
echo ""
echo "To start the service: sudo systemctl start ${APP_NAME}"
echo "To check status: sudo systemctl status ${APP_NAME}"
echo "To view logs: sudo journalctl -u ${APP_NAME} -f"
```

### 3.3 Create Systemd Service Template
Create `dist/letter-generator-1.0/letter-generator.service`:

```ini
[Unit]
Description=Letter Generator Service
Documentation=file:///opt/letter-generator/docs/
After=network.target

[Service]
Type=simple
User=lettergen
Group=lettergen
WorkingDirectory=/opt/letter-generator
ExecStart=/opt/letter-generator/start.sh generate_all_letters
ExecReload=/bin/kill -HUP $MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

# Security settings
NoNewPrivileges=true
PrivateTmp=true
ProtectSystem=strict
ReadWritePaths=/opt/letter-generator/logs /opt/letter-generator/output /var/log/letter-generator

[Install]
WantedBy=multi-user.target
```

## Step 4: Create Configuration Templates

### 4.1 Environment-Specific Configuration
Create `dist/letter-generator-1.0/config/production.properties`:

```properties
# Production Configuration Template
# Copy to config.properties and modify for your environment

# Database Configuration
db.url=jdbc:oracle:thin:@//your-prod-db-host:1521/YOURDB
db.username=your_username
db.password=your_encrypted_password
db.driver=oracle.jdbc.OracleDriver

# Application Settings
app.environment=production
app.batch.size=1000
app.max.retries=3

# File Output Settings
output.base.directory=/opt/letter-generator/output
log.directory=/var/log/letter-generator

# Encryption Settings
encryption.enabled=true
encryption.key.file=/opt/letter-generator/config/encryption.key
```

### 4.2 Create Production Logback Configuration
Create `dist/letter-generator-1.0/logback-production.xml`:

```xml
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    
    <property name="LOG_DIR" value="/var/log/letter-generator"/>
    
    <!-- Console Appender for systemd journal -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- File Appender for application logs -->
    <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOG_DIR}/letter-generator.log</file>
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <fileNamePattern>${LOG_DIR}/letter-generator.%d{yyyy-MM-dd}.log</fileNamePattern>
            <maxHistory>30</maxHistory>
            <totalSizeCap>1GB</totalSizeCap>
        </rollingPolicy>
        <encoder>
            <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- Error File Appender -->
    <appender name="ERROR_FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOG_DIR}/letter-generator-errors.log</file>
        <filter class="ch.qos.logback.classic.filter.ThresholdFilter">
            <level>ERROR</level>
        </filter>
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <fileNamePattern>${LOG_DIR}/letter-generator-errors.%d{yyyy-MM-dd}.log</fileNamePattern>
            <maxHistory>90</maxHistory>
        </rollingPolicy>
        <encoder>
            <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- Root Logger -->
    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="FILE"/>
        <appender-ref ref="ERROR_FILE"/>
    </root>
    
    <!-- Application Logger -->
    <logger name="com.efcm.lettergen" level="INFO" additivity="false">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="FILE"/>
        <appender-ref ref="ERROR_FILE"/>
    </logger>
    
</configuration>
```

## Step 5: Package for Distribution

### 5.1 Create Release Archive
```bash
# Navigate to distribution directory
cd dist

# Create tarball
tar -czf letter-generator-1.0-linux.tar.gz letter-generator-1.0/

# Create checksum
sha256sum letter-generator-1.0-linux.tar.gz > letter-generator-1.0-linux.tar.gz.sha256

# Verify archive
tar -tzf letter-generator-1.0-linux.tar.gz | head -20
```

### 5.2 Make Scripts Executable
```bash
# Ensure all shell scripts are executable
chmod +x dist/letter-generator-1.0/*.sh
```

## Step 6: Create Deployment Documentation

### 6.1 Create Deployment Guide
Create `dist/letter-generator-1.0/DEPLOYMENT.md`:

```markdown
# Deployment Instructions for Letter Generator v1.0

## Quick Start

1. Extract the archive:
   ```bash
   tar -xzf letter-generator-1.0-linux.tar.gz
   cd letter-generator-1.0
   ```

2. Install as system service (requires root):
   ```bash
   sudo ./install.sh
   ```

3. Configure database connection:
   ```bash
   sudo cp config/production.properties config/config.properties
   sudo nano /opt/letter-generator/config/config.properties
   ```

4. Start the service:
   ```bash
   sudo systemctl start letter-generator
   sudo systemctl status letter-generator
   ```

## Manual Installation

If you prefer manual installation:

1. Create user and directories:
   ```bash
   sudo useradd -r lettergen
   sudo mkdir -p /opt/letter-generator
   sudo mkdir -p /var/log/letter-generator
   ```

2. Copy files and set permissions:
   ```bash
   sudo cp -r ./* /opt/letter-generator/
   sudo chown -R lettergen:lettergen /opt/letter-generator
   sudo chown -R lettergen:lettergen /var/log/letter-generator
   ```

3. Run manually:
   ```bash
   cd /opt/letter-generator
   ./start.sh generate_all_letters
   ```

## Configuration

### Database Setup
1. Update `config/config.properties` with your database details
2. Ensure Oracle JDBC connectivity
3. Test connection before starting service

### Logging
- Application logs: `/var/log/letter-generator/letter-generator.log`
- Error logs: `/var/log/letter-generator/letter-generator-errors.log`
- System logs: `journalctl -u letter-generator`

### Output Files
Generated letters are saved to `/opt/letter-generator/output/`

## Monitoring

### Service Status
```bash
sudo systemctl status letter-generator
```

### View Logs
```bash
# Real-time logs
sudo journalctl -u letter-generator -f

# Application logs
sudo tail -f /var/log/letter-generator/letter-generator.log

# Error logs only
sudo tail -f /var/log/letter-generator/letter-generator-errors.log
```

### Check Output
```bash
ls -la /opt/letter-generator/output/
```

## Troubleshooting

### Common Issues
1. **Java not found**: Install JRE 11+ (`sudo apt install openjdk-11-jre`)
2. **Database connection**: Check credentials and network connectivity
3. **Permission denied**: Ensure proper file ownership and permissions
4. **Service won't start**: Check `journalctl -u letter-generator` for errors

### Support Commands
```bash
# Check Java version
java -version

# Test database connectivity (if tools available)
telnet your-db-host 1521

# Check service logs
sudo journalctl -u letter-generator --since "1 hour ago"

# Restart service
sudo systemctl restart letter-generator
```
```

## Step 7: Testing the Release Package

### 7.1 Validate Package Contents
```bash
# Check all files are present
cd dist/letter-generator-1.0
find . -type f -name "*.sh" -exec echo "Script: {}" \;
find . -name "*.jar" -exec echo "JAR: {}" \;
find . -name "*.xml" -exec echo "Config: {}" \;
find . -name "*.properties" -exec echo "Properties: {}" \;
```

### 7.2 Test Scripts
```bash
# Test startup script syntax
bash -n start.sh

# Test installation script syntax  
bash -n install.sh

# Verify JAR file
java -jar letter-generator-1.0.jar --help 2>/dev/null || echo "JAR validation complete"
```

## Step 8: Final Release Checklist

### Pre-Release Verification
- [ ] All source code committed and tagged
- [ ] Version number updated (removed -SNAPSHOT)
- [ ] Configuration templates created
- [ ] Scripts are executable and syntax-validated
- [ ] Documentation is complete and accurate
- [ ] JAR file includes all dependencies
- [ ] Archive created and checksummed

### Release Artifacts
- [ ] `letter-generator-1.0-linux.tar.gz` - Main distribution package
- [ ] `letter-generator-1.0-linux.tar.gz.sha256` - Checksum file
- [ ] Git tag `v1.0` created
- [ ] Release notes prepared

### Post-Release
- [ ] Update version to next development version (e.g., 1.1-SNAPSHOT)
- [ ] Update documentation with release information
- [ ] Notify deployment teams
- [ ] Prepare deployment timeline

## Usage Examples

### Running Different Commands
```bash
# Generate all letters (default)
./start.sh

# Generate all letters (explicit)
./start.sh generate_all_letters

# Run post-processing only
./start.sh postFileSentStep_all

# Encrypt text
./start.sh "sensitive data" "output/encrypted"
```

### Automation Integration
```bash
# Scheduled execution via cron
0 2 * * * /opt/letter-generator/start.sh generate_all_letters >> /var/log/letter-generator/cron.log 2>&1

# Integration with monitoring
./start.sh generate_all_letters && echo "SUCCESS" || echo "FAILED"
```

---

**This release package is ready for deployment to Linux production environments.**
