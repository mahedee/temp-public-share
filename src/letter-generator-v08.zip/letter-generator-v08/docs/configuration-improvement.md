# Improved Configuration - Single Query Source Field

## ✅ **Problem Solved**

**Issue**: The previous configuration had two boolean fields (`useQueryFromXml` and `useInlineQuery`) which was confusing and could potentially lead to conflicting states.

**Solution**: Replaced with a single `querySource` field that clearly indicates the source of the query.

## New Configuration Schema

### Before (Confusing - Two Fields):
```json
{
  "DemandLetter": {
    "enabled": true,
    "delimiter": "|",
    "useQueryFromXml": false,    // ❌ Confusing when both are present
    "useInlineQuery": true,      // ❌ Could conflict with above
    "queryFile": "DemandLetter.xml",
    "exportPath": "output/demand/"
  }
}
```

### After (Clear - Single Field):
```json
{
  "DemandLetter": {
    "enabled": true,
    "delimiter": "|",
    "querySource": "inline",     // ✅ Clear and unambiguous
    "queryFile": "DemandLetter.xml",
    "exportPath": "output/demand/"
  }
}
```

## Valid Values for querySource

- **`"xml"`** - Use query from XML file specified in `queryFile`
- **`"inline"`** - Use inline query from the corresponding letter processor class

## Current Configuration Example

```json
{
  "letters": {
    "DemandLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "inline",          // Uses DemandLetterProcessor
      "queryFile": "DemandLetter.xml",
      "exportPath": "output/demand/"
    },
    
    "HoldLetter": {
      "enabled": true,
      "delimiter": ",",
      "querySource": "inline",          // Uses HoldLetterProcessor
      "queryFile": "HoldLetter.xml",
      "exportPath": "output/hold/"
    },

    "IDTheftLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",             // Uses IDTheftLetter.xml
      "queryFile": "IDTheftLetter.xml",
      "exportPath": "output/idtheft/"
    },

    "RelationshipTermLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",             // Uses RelationshipTermLetter.xml
      "queryFile": "RelationshipTermLetter.xml",
      "exportPath": "output/relationship-term/"
    },

    "WelcomeLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "inline",          // Uses WelcomeLetterProcessor
      "queryFile": "WelcomeLetter.xml",
      "exportPath": "output/welcome/"
    }
  }
}
```

## Benefits of New Approach

### ✅ **Clarity**
- Single source of truth for query source selection
- No ambiguity about which query method to use
- Self-documenting configuration

### ✅ **Error Prevention**
- Impossible to have conflicting boolean values
- Clear validation with helpful error messages
- Case-insensitive validation (`"XML"`, `"xml"`, `"Xml"` all work)

### ✅ **Maintainability**
- Easier to understand for new developers
- Less prone to configuration errors
- Cleaner code in LetterGenerator class

## Error Handling

The system now provides clear error messages for invalid configurations:

```
SEVERE: Invalid querySource 'invalid' for letter type: WelcomeLetter. 
Valid values are 'xml' or 'inline'.
```

## Backward Compatibility

This change **breaks backward compatibility** intentionally to improve the design. The old configuration with two boolean fields will no longer work and must be updated to use the new `querySource` field.

## Testing Results

✅ **Inline Query Processing**: Letters with `"querySource": "inline"` successfully use processor classes  
✅ **XML Query Processing**: Letters with `"querySource": "xml"` successfully use XML files  
✅ **Error Validation**: Invalid querySource values are properly caught and logged  
✅ **Case Insensitive**: Both `"xml"` and `"XML"` work correctly  

## Implementation Details

### Updated Classes:
- **LetterConfig.java**: Replaced two boolean fields with single String field
- **LetterGenerator.java**: Updated logic to use single field with proper validation
- **ConfigurationDemo.java**: Updated to display new field format

### Code Changes:
```java
// Old approach
if (letterConfig.useQueryFromXml) {
    // XML logic
} else {
    // Inline logic  
}

// New approach  
if ("xml".equalsIgnoreCase(letterConfig.querySource)) {
    // XML logic
} else if ("inline".equalsIgnoreCase(letterConfig.querySource)) {
    // Inline logic
} else {
    // Error handling
}
```

This improvement makes the configuration more intuitive and less error-prone while maintaining all the functionality of the previous implementation.
