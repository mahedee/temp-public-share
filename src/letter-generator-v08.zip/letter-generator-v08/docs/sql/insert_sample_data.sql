-- Sample Data Insert Script for POSTAL_MAIL_LETTERS Table
-- This script inserts realistic sample data for all letter types: DEMAND, HOLD_NOTICE, ID_THEFT, RELATIONSHIP_TERM

-- ============================================================================= 
-- DEMAND LETTERS - Require ACCOUNT_SOURCE_REF_ID and BALANCE
-- =============================================================================

-- DEMAND Letter #1
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID, 
    BALANCE, ADDITIONAL_NAME1, ADDITIONAL_NAME2, RECORD_STATUS
) VALUES (
    'DEMAND',
    'John Smith',
    CURRENT_TIMESTAMP - INTERVAL '2' DAY,
    '123 Main Street|Apt 4B|New York|NY|10001|USA',
    '1234',
    15750.50,
    'FINAL NOTICE',
    'Payment Due Within 30 Days',
    'ACTIVE'
);

-- DEMAND Letter #2
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID, 
    BALANCE, ADDITIONAL_NAME1, RECORD_STATUS
) VALUES (
    'DEMAND',
    'Alice Johnson',
    CURRENT_TIMESTAMP - INTERVAL '1' DAY,
    '456 Oak Avenue|Suite 200|Chicago|IL|60601|USA',
    '2468',
    22300.75,
    'OVERDUE BALANCE NOTICE',
    'PROCESSED'
);

-- DEMAND Letter #3
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID, 
    BALANCE, ADDITIONAL_NAME1, ADDITIONAL_NAME2, RECORD_STATUS
) VALUES (
    'DEMAND',
    'Michael Brown',
    '789 Pine Street|Unit 15|Los Angeles|CA|90210|USA',
    '3691',
    8950.25,
    'PAYMENT REQUIRED',
    'Contact Customer Service',
    'ACTIVE'
);

-- ============================================================================= 
-- HOLD_NOTICE LETTERS - Require ACCOUNT_SOURCE_REF_ID and HOLD_REASON
-- =============================================================================

-- HOLD_NOTICE Letter #1
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID,
    HOLD_REASON, HOLD_AMOUNT, DEPOSIT_AMOUNT, DEPOSIT_DATE,
    ADDITIONAL_NAME1, RECORD_STATUS
) VALUES (
    'HOLD_NOTICE',
    'Sarah Davis',
    CURRENT_TIMESTAMP - INTERVAL '3' DAY,
    '321 Elm Street|Floor 3|Boston|MA|02101|USA',
    '5678',
    'Suspicious transaction activity detected requiring verification',
    35000.00,
    8500.00,
    CURRENT_TIMESTAMP - INTERVAL '7' DAY,
    'SECURITY HOLD - CALL IMMEDIATELY',
    'ACTIVE'
);

-- HOLD_NOTICE Letter #2
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID,
    HOLD_REASON, HOLD_AMOUNT, ADDITIONAL_NAME1, ADDITIONAL_NAME2, RECORD_STATUS
) VALUES (
    'HOLD_NOTICE',
    'Robert Wilson',
    CURRENT_TIMESTAMP - INTERVAL '5' DAY,
    '654 Cedar Lane|Apt 7C|Miami|FL|33101|USA',
    '9012',
    'Account under regulatory review pending documentation',
    18750.00,
    'COMPLIANCE HOLD',
    'Submit required documents',
    'SENT'
);

-- HOLD_NOTICE Letter #3
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID,
    HOLD_REASON, HOLD_AMOUNT, DEPOSIT_AMOUNT, DEPOSIT_DATE,
    ADDITIONAL_NAME1, RECORD_STATUS
) VALUES (
    'HOLD_NOTICE',
    'Jennifer Martinez',
    '987 Maple Drive|Building B|Denver|CO|80202|USA',
    '3456',
    'Large deposit verification required per banking regulations',
    42500.00,
    15000.00,
    CURRENT_TIMESTAMP - INTERVAL '2' DAY,
    'DEPOSIT VERIFICATION HOLD',
    'ACTIVE'
);

-- ============================================================================= 
-- ID_THEFT LETTERS - No ACCOUNT_SOURCE_REF_ID required
-- =============================================================================

-- ID_THEFT Letter #1
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS,
    ADDITIONAL_NAME1, ADDITIONAL_NAME2, ADDITIONAL_NAME3, RECORD_STATUS
) VALUES (
    'ID_THEFT',
    'David Garcia',
    CURRENT_TIMESTAMP - INTERVAL '1' DAY,
    '147 Sunset Boulevard|Apt 12A|San Francisco|CA|94102|USA',
    'IDENTITY PROTECTION ALERT',
    'Immediate verification required',
    'Call fraud hotline: 1-800-FRAUD-01',
    'ACTIVE'
);

-- ID_THEFT Letter #2
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS,
    ADDITIONAL_NAME1, ADDITIONAL_NAME2, RECORD_STATUS
) VALUES (
    'ID_THEFT',
    'Maria Rodriguez',
    CURRENT_TIMESTAMP - INTERVAL '4' DAY,
    '258 Valley Road|Suite 500|Seattle|WA|98101|USA',
    'SECURITY BREACH NOTIFICATION',
    'Your personal information may have been compromised',
    'PROCESSED'
);

-- ID_THEFT Letter #3
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, FULL_ADDRESS,
    ADDITIONAL_NAME1, ADDITIONAL_NAME2, ADDITIONAL_NAME3, ADDITIONAL_NAME4, RECORD_STATUS
) VALUES (
    'ID_THEFT',
    'Thomas Anderson',
    '369 River Street|Unit 8D|Portland|OR|97201|USA',
    'IDENTITY THEFT VICTIM ASSISTANCE',
    'We are here to help you recover',
    'Free credit monitoring included',
    'Contact victim services department',
    'ACTIVE'
);

-- ============================================================================= 
-- RELATIONSHIP_TERM LETTERS - Require ACCOUNT_SOURCE_REF_ID, ACC_CLOSE_DT, INBOUND_PHONE
-- =============================================================================

-- RELATIONSHIP_TERM Letter #1
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID,
    ACC_CLOSE_DT, ANALYST_NAME, INBOUND_PHONE,
    ADDITIONAL_NAME1, ADDITIONAL_NAME2, RECORD_STATUS
) VALUES (
    'RELATIONSHIP_TERM',
    'Lisa Thompson',
    CURRENT_TIMESTAMP - INTERVAL '2' DAY,
    '741 Commerce Street|Suite 1200|Austin|TX|78701|USA',
    '7890',
    CURRENT_TIMESTAMP + INTERVAL '30' DAY,
    'Sarah Johnson',
    '888-340-2265',
    'ACCOUNT CLOSURE NOTICE',
    'Please contact us to discuss options',
    'ACTIVE'
);

-- RELATIONSHIP_TERM Letter #2
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID,
    ACC_CLOSE_DT, ANALYST_NAME, INBOUND_PHONE,
    ADDITIONAL_NAME1, ADDITIONAL_NAME2, ADDITIONAL_NAME3, RECORD_STATUS
) VALUES (
    'RELATIONSHIP_TERM',
    'Kevin Lee',
    CURRENT_TIMESTAMP - INTERVAL '6' DAY,
    '852 Highland Avenue|Floor 5|Atlanta|GA|30309|USA',
    '4567',
    CURRENT_TIMESTAMP + INTERVAL '45' DAY,
    'Michael Chen',
    '888-340-2266',
    'BANKING RELATIONSHIP TERMINATION',
    'Final notice - 45 days to close',
    'Alternative banking options available',
    'SENT'
);

-- RELATIONSHIP_TERM Letter #3
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID,
    ACC_CLOSE_DT, ANALYST_NAME, INBOUND_PHONE,
    ADDITIONAL_NAME1, RECORD_STATUS
) VALUES (
    'RELATIONSHIP_TERM',
    'Nancy White',
    '963 Park Avenue|Penthouse A|Phoenix|AZ|85001|USA',
    '8901',
    CURRENT_TIMESTAMP + INTERVAL '60' DAY,
    'Jennifer Davis',
    '888-340-2267',
    'RELATIONSHIP CLOSURE - 60 DAY NOTICE',
    'ACTIVE'
);

-- Additional mixed status examples
INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS, ACCOUNT_SOURCE_REF_ID, 
    BALANCE, ADDITIONAL_NAME1, RECORD_STATUS
) VALUES (
    'DEMAND',
    'Christopher Taylor',
    CURRENT_TIMESTAMP - INTERVAL '7' DAY,
    '159 Broadway|Apt 22B|Nashville|TN|37201|USA',
    '2580',
    12400.00,
    'SECOND NOTICE',
    'SENT'
);

INSERT INTO POSTAL_MAIL_LETTERS (
    LETTER_TYPE, CUSTOMER_NAME, SENT_DATE, FULL_ADDRESS,
    ADDITIONAL_NAME1, RECORD_STATUS
) VALUES (
    'ID_THEFT',
    'Amanda Clark',
    CURRENT_TIMESTAMP - INTERVAL '8' DAY,
    '753 State Street|Unit 45|Salt Lake City|UT|84101|USA',
    'FRAUD ALERT NOTIFICATION',
    'INACTIVE'
);

COMMIT;

-- ============================================================================= 
-- VERIFICATION QUERIES
-- =============================================================================

-- Show summary by letter type and status
SELECT 
    LETTER_TYPE,
    RECORD_STATUS,
    COUNT(*) as RECORD_COUNT
FROM POSTAL_MAIL_LETTERS 
GROUP BY LETTER_TYPE, RECORD_STATUS
ORDER BY LETTER_TYPE, RECORD_STATUS;

-- Show field usage by letter type
SELECT 
    LETTER_TYPE,
    COUNT(*) as TOTAL_RECORDS,
    COUNT(BALANCE) as HAS_BALANCE,
    COUNT(HOLD_REASON) as HAS_HOLD_REASON,
    COUNT(ACC_CLOSE_DT) as HAS_CLOSE_DATE,
    COUNT(ACCOUNT_SOURCE_REF_ID) as HAS_ACCOUNT_REF,
    COUNT(SENT_DATE) as HAS_SENT_DATE
FROM POSTAL_MAIL_LETTERS
GROUP BY LETTER_TYPE
ORDER BY LETTER_TYPE;

-- Show recent records (last 5)
SELECT 
    ID, LETTER_TYPE, CUSTOMER_NAME, 
    SUBSTR(FULL_ADDRESS, 1, 30) || '...' as ADDRESS_PREVIEW,
    RECORD_STATUS, CREATED_DATE
FROM POSTAL_MAIL_LETTERS
ORDER BY CREATED_DATE DESC
FETCH FIRST 10 ROWS ONLY;

-- Show all status values in use
SELECT DISTINCT RECORD_STATUS, COUNT(*) as COUNT
FROM POSTAL_MAIL_LETTERS 
GROUP BY RECORD_STATUS
ORDER BY RECORD_STATUS;

-- Sample query for each letter type
SELECT 'DEMAND LETTERS:' as SECTION FROM DUAL
UNION ALL
SELECT CUSTOMER_NAME || ' - $' || TO_CHAR(BALANCE, '999,999.99') || ' - ' || RECORD_STATUS
FROM POSTAL_MAIL_LETTERS 
WHERE LETTER_TYPE = 'DEMAND'
UNION ALL
SELECT '' FROM DUAL
UNION ALL
SELECT 'HOLD_NOTICE LETTERS:' as SECTION FROM DUAL
UNION ALL
SELECT CUSTOMER_NAME || ' - ' || SUBSTR(HOLD_REASON, 1, 50) || '... - ' || RECORD_STATUS
FROM POSTAL_MAIL_LETTERS 
WHERE LETTER_TYPE = 'HOLD_NOTICE'
UNION ALL
SELECT '' FROM DUAL
UNION ALL
SELECT 'ID_THEFT LETTERS:' as SECTION FROM DUAL
UNION ALL
SELECT CUSTOMER_NAME || ' - ' || ADDITIONAL_NAME1 || ' - ' || RECORD_STATUS
FROM POSTAL_MAIL_LETTERS 
WHERE LETTER_TYPE = 'ID_THEFT'
UNION ALL
SELECT '' FROM DUAL
UNION ALL
SELECT 'RELATIONSHIP_TERM LETTERS:' as SECTION FROM DUAL
UNION ALL
SELECT CUSTOMER_NAME || ' - Analyst: ' || ANALYST_NAME || ' - ' || RECORD_STATUS
FROM POSTAL_MAIL_LETTERS 
WHERE LETTER_TYPE = 'RELATIONSHIP_TERM';

SELECT 'Sample data insertion completed successfully!' as STATUS FROM DUAL;
