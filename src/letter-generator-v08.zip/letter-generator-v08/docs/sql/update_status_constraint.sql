-- Update POSTAL_MAIL_LETTERS table constraint to include 'SENT' status
-- This script drops the existing constraint and creates a new one with the additional status

-- Drop the existing constraint
ALTER TABLE POSTAL_MAIL_LETTERS DROP CONSTRAINT CHK_POSTAL_LETTERS_STATUS;

-- Add the updated constraint with 'SENT' status included
ALTER TABLE POSTAL_MAIL_LETTERS ADD CONSTRAINT CHK_POSTAL_LETTERS_STATUS 
    CHECK (RECORD_STATUS IN ('ACTIVE', 'INACTIVE', 'PROCESSED', 'SENT'));

-- Verify the constraint was created successfully
SELECT CONSTRAINT_NAME, CONSTRAINT_TYPE, SEARCH_CONDITION 
FROM USER_CONSTRAINTS 
WHERE TABLE_NAME = 'POSTAL_MAIL_LETTERS' 
AND CONSTRAINT_NAME = 'CHK_POSTAL_LETTERS_STATUS';

-- Show current status values in the table (if any data exists)
SELECT DISTINCT RECORD_STATUS, COUNT(*) as COUNT
FROM POSTAL_MAIL_LETTERS 
GROUP BY RECORD_STATUS
ORDER BY RECORD_STATUS;

COMMIT;
