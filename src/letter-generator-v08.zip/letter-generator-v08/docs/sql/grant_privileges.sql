-- Run this script as SYSTEM or SYS user

-- Grant basic privileges to create tables and other objects
GRANT CREATE SESSION TO EFCM_NETREVEAL;
GRANT CREATE TABLE TO EFCM_NETREVEAL;
GRANT CREATE SEQUENCE TO EFCM_NETREVEAL;
GRANT CREATE TRIGGER TO EFCM_NETREVEAL;
GRANT CREATE VIEW TO EFCM_NETREVEAL;
-- Optional if you plan to add stored procedures/functions later
GRANT CREATE PROCEDURE TO EFCM_NETREVEAL;

-- Grant resource role (includes CREATE TABLE, CREATE SEQUENCE, etc.)
GRANT RESOURCE TO EFCM_NETREVEAL;

-- Grant connect role
GRANT CONNECT TO EFCM_NETREVEAL;

-- Grant unlimited tablespace quota (or specific quota)
-- Ensure the user has tablespace quota in XEPDB1 (adjust tablespace name if different)
ALTER USER EFCM_NETREVEAL QUOTA UNLIMITED ON USERS;

-- Optional: Grant DBA role if full administrative access is needed
-- GRANT DBA TO EFCM_NETREVEAL;

-- Verify grants
-- Verification (requires DBA views)
SELECT * FROM DBA_SYS_PRIVS WHERE GRANTEE = 'EFCM_NETREVEAL';
SELECT * FROM DBA_ROLE_PRIVS WHERE GRANTEE = 'EFCM_NETREVEAL';
SELECT * FROM DBA_TS_QUOTAS WHERE USERNAME = 'EFCM_NETREVEAL';

COMMIT;
