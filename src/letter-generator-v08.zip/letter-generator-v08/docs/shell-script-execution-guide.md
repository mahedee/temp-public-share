# Letter Generator - Shell Script Execution Guide

## Overview

This comprehensive guide explains how to run the Letter Generator application using shell scripts on both Windows and Linux environments. The application uses bash scripts to orchestrate the complete letter generation workflow including database queries, file generation, SFTP transfers, and post-processing operations.

## Prerequisites

### Common Requirements (Both Windows & Linux)
- **Java 11 or higher** - Must be accessible via command line
- **Maven** - For building the application (if needed)
- **Database Access** - Oracle database with POSTAL_MAIL_LETTERS table
- **Git** - For cloning repository and shell script execution

### Windows-Specific Requirements
- **Git Bash** (recommended) or **WSL (Windows Subsystem for Linux)**
- **PowerShell** (for Java execution through script)
- Windows 10/11 with developer features enabled

### Linux-Specific Requirements
- **Bash shell** (version 4.0 or higher)
- **Standard Unix utilities** (find, grep, awk, sed)
- **SSH client** (for SFTP operations)

## Environment Setup

### Windows Local Environment Setup

#### Option 1: Git Bash (Recommended)
1. **Install Git for Windows**
   ```bash
   # Download from: https://git-scm.com/download/win
   # Ensure "Git Bash Here" is selected during installation
   ```

2. **Configure Environment Variables**
   ```bash
   # Add to Windows PATH or .bashrc
   export JAVA_HOME="C:/Program Files/Eclipse Adoptium/jdk-11.0.19.7-hotspot"
   export PATH="$JAVA_HOME/bin:$PATH"
   ```

3. **Verify Installation**
   ```bash
   # Open Git Bash and test
   java -version
   mvn -version
   ```

#### Option 2: WSL (Windows Subsystem for Linux)
1. **Install WSL**
   ```powershell
   # Run in PowerShell as Administrator
   wsl --install -d Ubuntu
   ```

2. **Configure WSL Environment**
   ```bash
   # Inside WSL terminal
   sudo apt update
   sudo apt install default-jdk maven
   
   # Add to ~/.bashrc
   export JAVA_HOME=/usr/lib/jvm/default-java
   export PATH="$JAVA_HOME/bin:$PATH"
   ```

### Linux Environment Setup

#### Ubuntu/Debian
```bash
# Update package manager
sudo apt update

# Install Java 11
sudo apt install openjdk-11-jdk

# Install Maven
sudo apt install maven

# Install additional utilities
sudo apt install openssh-client curl wget

# Verify installation
java -version
mvn -version
```

#### CentOS/RHEL
```bash
# Update package manager
sudo yum update

# Install Java 11
sudo yum install java-11-openjdk-devel

# Install Maven
sudo yum install maven

# Install additional utilities
sudo yum install openssh-clients curl wget
```

#### Environment Variables (Linux)
```bash
# Add to ~/.bashrc or ~/.profile
export JAVA_HOME=/usr/lib/jvm/java-11-openjdk
export PATH="$JAVA_HOME/bin:$PATH"
export MAVEN_HOME=/usr/share/maven

# Reload environment
source ~/.bashrc
```

### Directory Structure
```
letter-generator-v07/
├── scripts/                    # Shell scripts directory
│   └── letter-generator-main.sh       # Main execution script (cross-platform)
├── target/
│   └── letter-generator-1.0-SNAPSHOT.jar
├── config/
│   ├── config.json            # Main configuration file
│   ├── config.properties      # Database configuration
│   └── letters/               # Letter definition XML files
│       ├── DemandLetter.xml
│       ├── HoldLetter.xml
│       ├── IDTheftLetter.xml
│       └── RelationshipTermLetter.xml
├── output/                    # Generated letter files
│   ├── demand/
│   ├── hold/
│   ├── idtheft/
│   └── relationship-term/
├── logs/                      # Application and execution logs
└── temp/                      # Temporary files
```

## Running the Application

### Windows Local Environment

#### Using Git Bash
```bash
# Navigate to project directory
cd "D:\Projects\Github\my-daptorik-apps\professional\current\src\letter-generator-v07"

# Make script executable (first time only)
chmod +x scripts/letter-generator-main.sh

# Check system status
bash scripts/letter-generator-main.sh --status

# Generate letters only
bash scripts/letter-generator-main.sh --generate

# Run complete workflow
bash scripts/letter-generator-main.sh --full

# Post-processing only
bash scripts/letter-generator-main.sh --post-process
```

#### Using WSL
```bash
# Navigate to Windows drive from WSL
cd /mnt/d/Projects/Github/my-daptorik-apps/professional/current/src/letter-generator-v07

# Make script executable
chmod +x scripts/letter-generator-main.sh

# Run commands (same as Git Bash)
bash scripts/letter-generator-main.sh --full
```

#### Using PowerShell (Alternative)
```powershell
# Navigate to project directory
Set-Location "D:\Projects\Github\my-daptorik-apps\professional\current\src\letter-generator-v07"

# Run through bash
bash scripts/letter-generator-main.sh --full
```

### Linux Environment

#### Standard Linux Execution
```bash
# Navigate to project directory
cd /home/user/projects/letter-generator-v07

# Make script executable (first time only)
chmod +x scripts/letter-generator-main.sh

# Check system status
./scripts/letter-generator-main.sh --status

# Generate letters only
./scripts/letter-generator-main.sh --generate

# Run complete workflow
./scripts/letter-generator-main.sh --full

# Post-processing only
./scripts/letter-generator-main.sh --post-process
```

#### Using absolute paths
```bash
# From any directory
/full/path/to/letter-generator-v07/scripts/letter-generator-main.sh --full
```

#### Background execution
```bash
# Run in background with nohup
nohup ./scripts/letter-generator-main.sh --full > execution.log 2>&1 &

# Check background process
ps aux | grep letter-generator
```

## Available Script Commands

### Primary Script: `letter-generator-main.sh`

This is the main cross-platform script for letter generation operations.

#### Available Commands:
- `--status` - Check system requirements and status
- `--generate` - Generate letters from database only
- `--post-process` - Execute post-file-sent processing only
- `--full` - Run complete workflow (generate → SFTP → post-process)
- `--help` - Show help information

#### Command Examples:

**Windows (Git Bash/WSL):**
```bash
# Check system status
bash scripts/letter-generator-main.sh --status

# Generate letters only
bash scripts/letter-generator-main.sh --generate

# Complete workflow
bash scripts/letter-generator-main.sh --full

# Show help
bash scripts/letter-generator-main.sh --help
```

**Linux:**
```bash
# Check system status
./scripts/letter-generator-main.sh --status

# Generate letters only  
./scripts/letter-generator-main.sh --generate

# Complete workflow
./scripts/letter-generator-main.sh --full

# Show help
./scripts/letter-generator-main.sh --help
```

## Configuration Files and Variables

### 1. Script Configuration (letter-generator-main.sh)

#### Windows Configuration Example:
```bash
# Windows paths in script (lines 6-12)
JAVA_CMD="java"
BASE_DIR="/mnt/d/Projects/Github/my-daptorik-apps/professional/current/src/letter-generator-v07"
JAR_FILE="$BASE_DIR/target/letter-generator-1.0-SNAPSHOT.jar"
CONFIG_DIR="$BASE_DIR/config"
OUTPUT_DIR="$BASE_DIR/output"
LOG_DIR="$BASE_DIR/logs"
TEMP_DIR="$BASE_DIR/temp"
```

#### Linux Configuration Example:
```bash
# Linux paths in script (lines 6-12)
JAVA_CMD="java"
BASE_DIR="/home/user/projects/letter-generator-v07"
JAR_FILE="$BASE_DIR/target/letter-generator-1.0-SNAPSHOT.jar"
CONFIG_DIR="$BASE_DIR/config"
OUTPUT_DIR="$BASE_DIR/output"
LOG_DIR="$BASE_DIR/logs"
TEMP_DIR="$BASE_DIR/temp"
```

**Variables to modify for your environment:**
- `BASE_DIR` - Full path to your project directory
- `JAVA_CMD` - Java command (can be full path if not in PATH)

### 2. Application Configuration (config.json)

#### Windows Environment Example:
```json
{
  "isEncryptedPassword": false,
  "database": {
    "url": "jdbc:oracle:thin:@//localhost:1521/XEPDB1",
    "user": "EFCM_NETREVEAL",
    "password": "Test123"
  },
  "fileNamePattern": "EFCM.PostMail.{LETTER_TYPE}.{DATE}.txt",
  "sftp": {
    "enabled": false,
    "host": "sftp.example.com",
    "port": 22,
    "username": "windows_user",
    "keyPath": "C:\\keys\\sftp_key.pem",
    "keyPassphrase": "",
    "remoteDirectory": "/inbound/letters/windows",
    "timeout": 30000,
    "retries": 3,
    "postTransferProcessing": true
  },
  "letters": {
    "DemandLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",
      "queryFile": "DemandLetter.xml",
      "exportPath": "output/demand/"
    },
    "HoldLetter": {
      "enabled": true,
      "delimiter": ",",
      "querySource": "xml", 
      "queryFile": "HoldLetter.xml",
      "exportPath": "output/hold/"
    },
    "IDTheftLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",
      "queryFile": "IDTheftLetter.xml", 
      "exportPath": "output/idtheft/"
    },
    "RelationshipTermLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",
      "queryFile": "RelationshipTermLetter.xml",
      "exportPath": "output/relationship-term/"
    }
  }
}
```

#### Linux Environment Example:
```json
{
  "isEncryptedPassword": false,
  "database": {
    "url": "jdbc:oracle:thin:@//db-server.company.com:1521/PROD",
    "user": "EFCM_PROD_USER",
    "password": "SecurePassword123"
  },
  "fileNamePattern": "EFCM.PostMail.{LETTER_TYPE}.{DATE}.txt",
  "sftp": {
    "enabled": true,
    "host": "sftp.production.com",
    "port": 22,
    "username": "prod_user",
    "keyPath": "/home/user/.ssh/sftp_production_key",
    "keyPassphrase": "",
    "remoteDirectory": "/data/inbound/letters",
    "timeout": 30000,
    "retries": 3,
    "postTransferProcessing": true
  },
  "letters": {
    "DemandLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml",
      "queryFile": "DemandLetter.xml",
      "exportPath": "output/demand/"
    },
    "HoldLetter": {
      "enabled": true,
      "delimiter": ",",
      "querySource": "xml",
      "queryFile": "HoldLetter.xml", 
      "exportPath": "output/hold/"
    },
    "IDTheftLetter": {
      "enabled": false,
      "delimiter": "|",
      "querySource": "xml",
      "queryFile": "IDTheftLetter.xml",
      "exportPath": "output/idtheft/"
    },
    "RelationshipTermLetter": {
      "enabled": true,
      "delimiter": "|",
      "querySource": "xml", 
      "queryFile": "RelationshipTermLetter.xml",
      "exportPath": "output/relationship-term/"
    }
  }
}
```

**Key Variables to Modify by Environment:**

| Variable | Windows Example | Linux Example | Description |
|----------|----------------|---------------|-------------|
| `database.url` | `jdbc:oracle:thin:@//localhost:1521/XEPDB1` | `jdbc:oracle:thin:@//prod-db:1521/PROD` | Database connection URL |
| `database.user` | `DEV_USER` | `PROD_USER` | Database username |
| `database.password` | `dev123` | `SecureProd456` | Database password |
| `sftp.enabled` | `false` | `true` | Enable/disable SFTP |
| `sftp.host` | `dev-sftp.local` | `sftp.production.com` | SFTP server hostname |
| `sftp.keyPath` | `C:\\keys\\sftp_key.pem` | `/home/user/.ssh/id_rsa` | SSH key file path |
| `sftp.remoteDirectory` | `/dev/letters` | `/prod/inbound/letters` | Remote directory path |

### 3. Database Configuration (config.properties)

#### Windows Environment Example:
```properties
# Database Configuration - Windows Development
db.url=jdbc:oracle:thin:@//localhost:1521/XEPDB1
db.username=EFCM_NETREVEAL
db.password=Test123
db.driver=oracle.jdbc.OracleDriver

# Connection Pool Settings
db.maxPoolSize=10
db.minPoolSize=2
db.connectionTimeout=30000

# Windows-specific paths
log.directory=D:\\Projects\\letter-generator-v07\\logs
temp.directory=D:\\Projects\\letter-generator-v07\\temp
```

#### Linux Environment Example:
```properties
# Database Configuration - Linux Production
db.url=jdbc:oracle:thin:@//prod-oracle.company.com:1521/PRODDB
db.username=EFCM_PRODUCTION
db.password=SecureProductionPassword123
db.driver=oracle.jdbc.OracleDriver

# Connection Pool Settings
db.maxPoolSize=20
db.minPoolSize=5
db.connectionTimeout=30000

# Linux-specific paths
log.directory=/opt/letter-generator/logs
temp.directory=/tmp/letter-generator
```

## Execution Process Flow

### Complete Workflow (`--full` command)

#### Windows Environment
```bash
# Windows execution flow
bash scripts/letter-generator-main.sh --full

# Process:
# 1. System Validation
#    - Check JAR file: /mnt/d/Projects/.../letter-generator-1.0-SNAPSHOT.jar
#    - Verify directories: config/, output/, logs/
#    - Test Java via PowerShell: powershell.exe -Command "java -version"
#
# 2. Letter Generation  
#    - Execute: powershell.exe -Command "java -jar 'JAR_PATH' generate_all_letters"
#    - Convert Unix paths to Windows format for PowerShell
#    - Generate files in output/ subdirectories
#
# 3. SFTP Transfer (if enabled)
#    - Simulate or execute actual SFTP transfer
#    - Source: configured output directories
#    - Destination: configured remote server
#
# 4. Post-File-Sent Processing
#    - Execute: powershell.exe -Command "java -jar 'JAR_PATH' postFileSentStep_all"
#    - Update database record status
```

#### Linux Environment
```bash
# Linux execution flow  
./scripts/letter-generator-main.sh --full

# Process:
# 1. System Validation
#    - Check JAR file: /home/user/projects/.../letter-generator-1.0-SNAPSHOT.jar
#    - Verify directories: config/, output/, logs/
#    - Test Java directly: java -version
#
# 2. Letter Generation
#    - Execute: java -jar JAR_PATH generate_all_letters
#    - Native Linux path handling
#    - Generate files in output/ subdirectories
#
# 3. SFTP Transfer (if enabled)
#    - Execute actual SFTP commands using SSH client
#    - Use SSH keys for authentication
#    - Transfer files to remote server
#
# 4. Post-File-Sent Processing  
#    - Execute: java -jar JAR_PATH postFileSentStep_all
#    - Update database record status
```

### Individual Steps

#### 1. System Validation Process
**Windows:**
```bash
bash scripts/letter-generator-main.sh --status

# Checks performed:
# - JAR file existence at Windows-style path
# - Directory accessibility via /mnt/ mount points
# - Java accessibility through PowerShell wrapper
# - Database connectivity test
```

**Linux:**
```bash
./scripts/letter-generator-main.sh --status

# Checks performed:
# - JAR file existence at native Linux path
# - Directory permissions and accessibility  
# - Java accessibility directly
# - Database connectivity test
```

#### 2. Letter Generation Only
**Windows:**
```bash
bash scripts/letter-generator-main.sh --generate

# Executes:
# powershell.exe -Command "java -jar 'D:\Projects\...\jar' generate_all_letters"
```

**Linux:**
```bash
./scripts/letter-generator-main.sh --generate

# Executes:
# java -jar /home/user/projects/.../jar generate_all_letters
```

#### 3. Post-Processing Only
**Windows:**
```bash
bash scripts/letter-generator-main.sh --post-process

# Executes:
# powershell.exe -Command "java -jar 'D:\Projects\...\jar' postFileSentStep_all"
```

**Linux:**
```bash
./scripts/letter-generator-main.sh --post-process

# Executes:  
# java -jar /home/user/projects/.../jar postFileSentStep_all
```

## Output Structure and Results

### Generated Files Structure
**Windows:**
```
D:\Projects\Github\my-daptorik-apps\professional\current\src\letter-generator-v07\output\
├── demand\
│   └── EFCM.PostMail.DemandLetter.20250818.txt       # Pipe-delimited (|)
├── hold\
│   └── EFCM.PostMail.HoldLetter.20250818.txt         # Comma-delimited (,)
├── idtheft\
│   └── EFCM.PostMail.IDTheftLetter.20250818.txt      # Pipe-delimited (|)
└── relationship-term\
    └── EFCM.PostMail.RelationshipTermLetter.20250818.txt  # Pipe-delimited (|)
```

**Linux:**
```
/home/user/projects/letter-generator-v07/output/
├── demand/
│   └── EFCM.PostMail.DemandLetter.20250818.txt       # Pipe-delimited (|)
├── hold/
│   └── EFCM.PostMail.HoldLetter.20250818.txt         # Comma-delimited (,)
├── idtheft/
│   └── EFCM.PostMail.IDTheftLetter.20250818.txt      # Pipe-delimited (|)
└── relationship-term/
    └── EFCM.PostMail.RelationshipTermLetter.20250818.txt  # Pipe-delimited (|)
```

### Log Files Structure
**Windows:**
```
D:\Projects\Github\my-daptorik-apps\professional\current\src\letter-generator-v07\logs\
├── letter_gen_20250818_143802.log          # Letter generation execution log
├── post_file_sent_20250818_143810.log      # Post-processing execution log
├── letter-generation.log                   # Application-level letter generation log
├── letter-generator.log                    # Main application log
└── letter-generator-errors.log             # Error logs
```

**Linux:**
```
/home/user/projects/letter-generator-v07/logs/
├── letter_gen_20250818_143802.log          # Letter generation execution log  
├── post_file_sent_20250818_143810.log      # Post-processing execution log
├── letter-generation.log                   # Application-level letter generation log
├── letter-generator.log                    # Main application log
└── letter-generator-errors.log             # Error logs
```

### Sample Generated Content

#### DemandLetter Output (Pipe-delimited):
```
19|DEMAND|John Smith|123 Main Street|Apt 4B|New York|NY|10001|USA|1234|15751|FINAL NOTICE|Payment Due Within 30 Days|2025-08-18 14:48:18.738000|ACTIVE
20|DEMAND|Alice Johnson|456 Oak Avenue|Suite 200|Chicago|IL|60601|USA|2468|22301|OVERDUE BALANCE NOTICE||2025-08-18 14:48:18.738000|ACTIVE
```

#### HoldLetter Output (Comma-delimited):
```
22,HOLD_NOTICE,Sarah Davis,321 Elm Street|Floor 3|Boston|MA|02101|USA,5678,Suspicious transaction activity detected requiring verification,35000,8500,2025-08-09,SECURITY HOLD - CALL IMMEDIATELY,2025-08-18 14:48:18.838000,ACTIVE
```

## Troubleshooting by Environment

### Windows-Specific Issues

#### 1. PowerShell Execution Errors
```
ERROR: Java application failed with exit code 1
Log contents: Import-PowerShellDataFile : The term 'Import-PowerShellDataFile' is not recognized...
```
**Solution:**
```bash
# This is a PowerShell profile issue, application still works
# Ignore PowerShell profile errors in logs, focus on actual Java execution results
```

#### 2. Path Conversion Issues
```
ERROR: JAR file not found: /mnt/d/Projects/.../letter-generator-1.0-SNAPSHOT.jar
```
**Solution:**
```bash
# Verify Windows drive mounting in Git Bash/WSL
ls /mnt/d/Projects/

# Or update BASE_DIR in script to correct Windows path format
BASE_DIR="/mnt/d/Your/Actual/Project/Path/letter-generator-v07"
```

#### 3. Java Not Found in PowerShell
```
ERROR: Java not accessible: java
```
**Solution:**
```bash
# Add Java to Windows PATH environment variable
# Or specify full path in script:
JAVA_CMD="C:/Program Files/Eclipse Adoptium/jdk-11.0.19.7-hotspot/bin/java"
```

#### 4. Directory Access Permissions
```
ERROR: Directory not found: /mnt/d/Projects/.../output
```
**Solution:**
```bash
# Create missing directories
mkdir -p output/{demand,hold,idtheft,relationship-term}
mkdir -p logs temp

# Or run script once to auto-create directories
```

#### 5. Line Ending Issues (CRLF vs LF)
```
bash: $'\r': command not found
```
**Solution:**
```bash
# Convert Windows line endings to Unix in Git Bash
dos2unix scripts/letter-generator-main.sh

# Or configure Git to handle line endings
git config core.autocrlf true
```

### Linux-Specific Issues

#### 1. Java Not Found
```
ERROR: Java not accessible: java
```
**Solution:**
```bash
# Install Java
sudo apt install openjdk-11-jdk     # Ubuntu/Debian
sudo yum install java-11-openjdk    # CentOS/RHEL

# Or specify full path:
JAVA_CMD="/usr/lib/jvm/java-11-openjdk/bin/java"
```

#### 2. Permission Denied
```
bash: ./scripts/letter-generator-main.sh: Permission denied
```
**Solution:**
```bash
# Make script executable
chmod +x scripts/letter-generator-main.sh

# Or run with bash explicitly
bash scripts/letter-generator-main.sh --full
```

#### 3. Database Connection Issues
```
ERROR: Could not connect to database
```
**Solution:**
```bash
# Check network connectivity
telnet database-server 1521

# Verify database credentials in config.json
# Check firewall settings
sudo ufw status
```

#### 4. SFTP Key Issues
```
ERROR: SFTP authentication failed
```
**Solution:**
```bash
# Check SSH key permissions
chmod 600 ~/.ssh/id_rsa

# Test SFTP connection manually
sftp -i ~/.ssh/id_rsa user@sftp-server

# Verify key path in config.json
"keyPath": "/home/user/.ssh/id_rsa"
```

### Common Issues (Both Environments)

#### 1. JAR File Missing
```
ERROR: JAR file not found: target/letter-generator-1.0-SNAPSHOT.jar
```
**Solution:**
```bash
# Build the application using Maven
mvn clean package

# Or download pre-built JAR if available
```

#### 2. Database Table Missing
```
ERROR: Table 'POSTAL_MAIL_LETTERS' doesn't exist
```
**Solution:**
```sql
-- Run the SQL script to create required tables
-- Check docs/postal-mail-tables.sql for table creation script
```

#### 3. Empty Output Files (0 bytes)
```
Generated 4 letter files
- EFCM.PostMail.DemandLetter.20250818.txt (0 bytes)
```
**Solution:**
```bash
# Check if database has data with RECORD_STATUS = 'ACTIVE'
# Insert test data or modify query criteria in XML files
```

#### 4. Configuration File Issues
```
ERROR: Unrecognized field "sourceDirectory" in JSON
```
**Solution:**
```bash
# Remove deprecated fields from config.json
# Ensure JSON syntax is valid
# Use proper field names as per application requirements
```

### Debugging Steps

#### Windows Debugging:
```bash
# 1. Check system status
bash scripts/letter-generator-main.sh --status

# 2. Verify Java through PowerShell
powershell.exe -Command "java -version"

# 3. Check paths
ls -la /mnt/d/Projects/.../letter-generator-v07/

# 4. Review recent logs
tail -20 logs/letter_gen_*.log

# 5. Test database connectivity
powershell.exe -Command "java -jar target/letter-generator-1.0-SNAPSHOT.jar test_connection"
```

#### Linux Debugging:
```bash
# 1. Check system status
./scripts/letter-generator-main.sh --status

# 2. Verify Java installation
java -version
which java

# 3. Check file permissions
ls -la scripts/letter-generator-main.sh
ls -la target/letter-generator-1.0-SNAPSHOT.jar

# 4. Review recent logs
tail -20 logs/letter_gen_*.log

# 5. Test database connectivity
java -jar target/letter-generator-1.0-SNAPSHOT.jar test_connection
```

## Advanced Features and Automation

### Scheduled Execution

#### Windows Task Scheduler
1. **Create Batch Wrapper (run-letter-generator.bat):**
```batch
@echo off
cd /d "D:\Projects\Github\my-daptorik-apps\professional\current\src\letter-generator-v07"
bash scripts/letter-generator-main.sh --full >> logs/scheduled-execution.log 2>&1
echo Exit Code: %ERRORLEVEL% >> logs/scheduled-execution.log
```

2. **Schedule in Task Scheduler:**
   - Open Task Scheduler → Create Basic Task
   - Name: "Letter Generator Daily"
   - Trigger: Daily at 2:00 AM
   - Action: Start Program → Browse to run-letter-generator.bat
   - Settings: Enable "Run whether user is logged on or not"

#### Linux Cron Jobs
```bash
# Edit crontab
crontab -e

# Add daily execution at 2:00 AM
0 2 * * * /home/user/projects/letter-generator-v07/scripts/letter-generator-main.sh --full >> /home/user/projects/letter-generator-v07/logs/cron.log 2>&1

# Add weekly full workflow on Sundays at 3:00 AM
0 3 * * 0 /home/user/projects/letter-generator-v07/scripts/letter-generator-main.sh --full

# View scheduled jobs
crontab -l
```

### SFTP Integration

#### Windows SFTP Configuration:
```json
{
  "sftp": {
    "enabled": true,
    "host": "sftp.example.com", 
    "port": 22,
    "username": "windows_user",
    "keyPath": "C:\\Users\\username\\.ssh\\id_rsa",
    "keyPassphrase": "",
    "remoteDirectory": "/inbound/letters/windows",
    "timeout": 30000,
    "retries": 3,
    "postTransferProcessing": true
  }
}
```

#### Linux SFTP Configuration:
```json
{
  "sftp": {
    "enabled": true,
    "host": "sftp.production.com",
    "port": 22, 
    "username": "prod_user",
    "keyPath": "/home/user/.ssh/production_key",
    "keyPassphrase": "optional_passphrase",
    "remoteDirectory": "/data/inbound/letters",
    "timeout": 30000,
    "retries": 3,
    "postTransferProcessing": true
  }
}
```

### Performance Optimization

#### Large Dataset Handling
**Windows:**
```bash
# Increase Java heap size in script
JAVA_OPTS="-Xmx2G -Xms512m"
powershell.exe -Command "java $JAVA_OPTS -jar '$win_jar_file' $command_args"
```

**Linux:**
```bash
# Increase Java heap size in script  
JAVA_OPTS="-Xmx4G -Xms1G"
java $JAVA_OPTS -jar "$JAR_FILE" "$command_args"
```

#### Parallel Processing Configuration:
```json
{
  "processing": {
    "threadPoolSize": 4,
    "batchSize": 1000,
    "enableParallelProcessing": true
  }
}
```

### Monitoring and Alerts

#### Windows PowerShell Monitoring Script:
```powershell
# monitor-letter-generation.ps1
$LogFile = "D:\Projects\letter-generator-v07\logs\letter_gen_*.log"
$LatestLog = Get-ChildItem $LogFile | Sort-Object LastWriteTime | Select-Object -Last 1

if ((Get-Date) - $LatestLog.LastWriteTime -gt (New-TimeSpan -Hours 25)) {
    Send-MailMessage -SmtpServer "smtp.company.com" -From "monitor@company.com" -To "admin@company.com" -Subject "Letter Generation Alert" -Body "Letter generation has not run in the last 25 hours"
}
```

#### Linux Bash Monitoring Script:
```bash
#!/bin/bash
# monitor-letter-generation.sh

LOG_DIR="/home/user/projects/letter-generator-v07/logs"
LATEST_LOG=$(find $LOG_DIR -name "letter_gen_*.log" -type f -printf '%T@ %p\n' | sort -n | tail -1 | cut -d' ' -f2-)

if [[ -n "$LATEST_LOG" ]]; then
    LAST_MODIFIED=$(stat -c %Y "$LATEST_LOG")
    CURRENT_TIME=$(date +%s)
    HOURS_DIFF=$(( (CURRENT_TIME - LAST_MODIFIED) / 3600 ))
    
    if [[ $HOURS_DIFF -gt 25 ]]; then
        echo "Letter generation has not run in the last 25 hours" | mail -s "Letter Generation Alert" admin@company.com
    fi
fi
```

## Security Best Practices

### Windows Security:
1. **File Permissions:**
   ```batch
   # Restrict access to config files
   icacls "config\config.json" /grant:r "%USERNAME%:R" /inheritance:r
   icacls "config\config.properties" /grant:r "%USERNAME%:R" /inheritance:r
   ```

2. **Encrypted Passwords:**
   ```json
   {
     "isEncryptedPassword": true,
     "database": {
       "password": "encrypted_password_hash_here"
     }
   }
   ```

### Linux Security:
1. **File Permissions:**
   ```bash
   # Restrict access to sensitive files
   chmod 600 config/config.json
   chmod 600 config/config.properties
   chmod 700 scripts/
   
   # SSH key security
   chmod 600 ~/.ssh/id_rsa
   chmod 644 ~/.ssh/id_rsa.pub
   ```

2. **Environment Variables:**
   ```bash
   # Use environment variables for sensitive data
   export DB_PASSWORD="secure_password"
   export SFTP_KEY_PASSPHRASE="ssh_key_passphrase"
   ```

### Database Security:
```json
{
  "database": {
    "url": "jdbc:oracle:thin:@//db-server:1521/prod?oracle.net.encryption_client=REQUIRED",
    "connectionProperties": {
      "ssl": "true",
      "sslMode": "REQUIRED"
    }
  }
}
```

## Maintenance and Support

### Log Rotation

#### Windows (PowerShell script):
```powershell
# cleanup-logs.ps1
$LogDir = "D:\Projects\letter-generator-v07\logs"
$DaysToKeep = 30
Get-ChildItem $LogDir -Filter "*.log" | Where-Object {$_.LastWriteTime -lt (Get-Date).AddDays(-$DaysToKeep)} | Remove-Item -Force
```

#### Linux (cron job):
```bash
# Add to crontab - cleanup logs older than 30 days every Sunday
0 1 * * 0 find /home/user/projects/letter-generator-v07/logs -name "*.log" -type f -mtime +30 -delete
```

### Health Checks

#### Windows Health Check:
```bash
# health-check-windows.sh
bash scripts/letter-generator-main.sh --status
if [[ $? -eq 0 ]]; then
    echo "$(date): System healthy" >> logs/health-check.log
else
    echo "$(date): System issues detected" >> logs/health-check.log
fi
```

#### Linux Health Check:
```bash
# health-check-linux.sh
./scripts/letter-generator-main.sh --status
if [[ $? -eq 0 ]]; then
    echo "$(date): System healthy" >> logs/health-check.log
    # Optional: Send success notification
else
    echo "$(date): System issues detected" >> logs/health-check.log
    # Send alert email
    echo "Health check failed at $(date)" | mail -s "Letter Generator Health Alert" admin@company.com
fi
```

---

## Summary

This guide provides comprehensive instructions for running the Letter Generator application using shell scripts on both **Windows** and **Linux** environments. Key points:

### Windows Environment:
- Use **Git Bash** or **WSL** for script execution
- Modify `BASE_DIR` in script to Windows path format (`/mnt/d/...`)
- Java execution uses **PowerShell** wrapper for compatibility
- Configure Windows-specific paths in `config.json`

### Linux Environment:  
- Use native **bash** shell execution
- Modify `BASE_DIR` to Linux path format (`/home/user/...`)
- Direct Java execution without wrappers
- Configure Linux-specific paths and SSH keys

### Configuration Files:
- **Script paths**: Modify `BASE_DIR` in `letter-generator-main.sh`
- **Application config**: Update `config.json` for database, SFTP, and letter settings
- **Database config**: Update `config.properties` for environment-specific database settings

Both environments support the same command-line arguments (`--status`, `--generate`, `--post-process`, `--full`) with platform-specific execution differences handled internally by the script.

---

*Last Updated: August 18, 2025*  
*Version: 2.0*  
*Supports: letter-generator-v07*
