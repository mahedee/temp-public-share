package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;
import java.util.Map;

/**
 * Letter processor for Welcome Letters using new structured approach
 * This demonstrates how to add a new letter type following the Open-Closed Principle
 */
public class WelcomeLetterProcessor extends AbstractLetterProcessor {
    
    public WelcomeLetterProcessor() {
        super("WelcomeLetter");
    }
    
    @Override
    public boolean hasPreFileGenerationStep() {
        return false;
    }
    
    @Override
    public String getPreFileGenerationQuery() {
        // No pre-file generation step needed for welcome letters
        return null;
    }
    
    @Override
    public String getPreFileGenerationQueryType() {
        return "insert";
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT " +
               "ID, " +
               "LETTER_TYPE, " +
               "CUSTOMER_NAME, " +
               "FULL_ADDRESS, " +
               "ADDITIONAL_NAME1, " +
               "ADDITIONAL_NAME2, " +
               "TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE, " +
               "RECORD_STATUS " +
               "FROM POSTAL_MAIL_LETTERS WHERE LETTER_TYPE = 'WELCOME' AND RECORD_STATUS = 'ACTIVE'";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("ID", "LETTER_TYPE", "CUSTOMER_NAME", "FULL_ADDRESS", "ADDITIONAL_NAME1", "ADDITIONAL_NAME2", "SENT_DATE", "RECORD_STATUS");
    }
    
    @Override
    public Map<String, Object> getGlobalVariables() {
        return Map.of("sent_date", "{CURRENT_TIMESTAMP}");
    }
    
    @Override
    public boolean hasPostFileGenerationStep() {
        return true;
    }
    
    @Override
    public String getPostFileGenerationQuery() {
        return "UPDATE POSTAL_MAIL_LETTERS SET RECORD_STATUS = 'PROCESSED' " +
               "WHERE LETTER_TYPE = 'WELCOME' AND RECORD_STATUS = 'ACTIVE'";
    }
    
    @Override
    public String getPostFileGenerationQueryType() {
        return "update";
    }
    
    @Override
    public boolean hasPostFileSentStep() {
        return true;
    }
    
    @Override
    public String getPostFileSentQuery() {
        return "UPDATE POSTAL_MAIL_LETTERS SET RECORD_STATUS = 'SENT', SENT_DATE = CURRENT_TIMESTAMP " +
               "WHERE LETTER_TYPE = 'WELCOME' AND RECORD_STATUS = 'PROCESSED'";
    }
    
    @Override
    public String getPostFileSentQueryType() {
        return "update";
    }
}
