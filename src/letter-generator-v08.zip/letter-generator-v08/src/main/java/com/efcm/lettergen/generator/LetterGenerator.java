package com.efcm.lettergen.generator;

import com.efcm.lettergen.config.*;
import com.efcm.lettergen.model.LetterDefinition;
import com.efcm.lettergen.util.EncryptionUtil;
import com.efcm.lettergen.util.FileUtil;
import com.efcm.lettergen.util.QueryProcessor;

import jakarta.xml.bind.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.*;
import java.sql.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;

public class LetterGenerator {
    
    private static final Logger logger = LoggerFactory.getLogger(LetterGenerator.class);
    
    public void generateAll() throws Exception {
        Config config = AppConfig.getConfig();
        String password = config.isEncryptedPassword
                ? EncryptionUtil.decrypt(config.database.password.replace("ENCRYPTED(", "").replace(")", ""))
                : config.database.password;

        Connection conn = DriverManager.getConnection(
                config.database.url,
                config.database.user,
                password
        );

        // Read letter names from config.json and process each one
        for (Map.Entry<String, LetterConfig> entry : config.letters.entrySet()) {
            String letterType = entry.getKey();
            LetterConfig letterConfig = entry.getValue();
            
            if (!letterConfig.enabled) {
                logger.info("Skipping disabled letter type: " + letterType);
                continue;
            }

            try {
                processLetter(conn, letterType, letterConfig, config.fileNamePattern);
            } catch (Exception e) {
                logger.error("Error processing letter type {}: {}", letterType, e.getMessage(), e);
            }
        }
        
        conn.close();
    }
    
    public void generateLetter(String letterType) throws Exception {
        Config config = AppConfig.getConfig();
        String password = config.isEncryptedPassword
                ? EncryptionUtil.decrypt(config.database.password.replace("ENCRYPTED(", "").replace(")", ""))
                : config.database.password;

        Connection conn = DriverManager.getConnection(
                config.database.url,
                config.database.user,
                password
        );

        // Find the specific letter configuration
        LetterConfig letterConfig = config.letters.get(letterType);
        if (letterConfig == null) {
            logger.error("Letter type '{}' not found in configuration. Available types: {}", letterType, config.letters.keySet());
            conn.close();
            return;
        }
        
        if (!letterConfig.enabled) {
            logger.info("Letter type '{}' is disabled in configuration", letterType);
            conn.close();
            return;
        }

        try {
            processLetter(conn, letterType, letterConfig, config.fileNamePattern);
        } catch (Exception e) {
            logger.error("Error processing letter type {}: {}", letterType, e.getMessage(), e);
        }
        
        conn.close();
    }
    
    private void processLetter(Connection conn, String letterType, LetterConfig letterConfig, String fileNamePattern) throws Exception {
        logger.info("Processing letter type: " + letterType);
        
        String query;
        List<String> columns;
        LetterDefinition letterDefinition = null;
        LetterProcessor processor = null;
        Map<String, Object> globalVariables = QueryProcessor.createGlobalVariables();

        // Determine query source based on configuration
        if ("xml".equalsIgnoreCase(letterConfig.querySource)) {
            logger.info("Using XML query for letter type: " + letterType);
            letterDefinition = loadDefinition("config/letters/" + letterConfig.queryFile);
            
            // Execute pre-file generation step first
            executePreFileGenerationStep(conn, letterType, letterDefinition, processor, globalVariables);
            
            query = letterDefinition.getQuery();
            columns = letterDefinition.getColumns();
            
            // Merge global variables from XML definition if they exist
            if (letterDefinition.getGlobalVariables() != null) {
                // The XML GlobalVariables currently has sent_date field
                if (letterDefinition.getGlobalVariables().getSentDate() != null) {
                    globalVariables.put("sent_date", letterDefinition.getGlobalVariables().getSentDate());
                }
            }
            
            // Always replace variables in XML query (including default variables like sent_date)
            query = QueryProcessor.replaceVariables(query, globalVariables);
        } else if ("inline".equalsIgnoreCase(letterConfig.querySource)) {
            // Use inline query from letter processor
            logger.info("Using inline query for letter type: " + letterType);
            processor = LetterProcessorFactory.getProcessor(letterType);
            
            if (!processor.supportsInlineQuery()) {
                logger.error("Inline query not found for letter type: {}. Please implement a processor for this letter type or change querySource to 'xml'.", letterType);
                logger.warn("TestLetter cannot be generated because inline query is missing. You have to add inline query in the code or you have to switch to xml query source.");
                return;
            }
            
            query = processor.getInlineQuery();
            columns = processor.getInlineColumns();
            
            if (query.isEmpty() || columns.isEmpty()) {
                logger.error("Empty inline query or columns for letter type: {}. Please check the processor implementation.", letterType);
                return;
            }
            
            // Merge global variables from processor
            Map<String, Object> processorVariables = processor.getGlobalVariables();
            globalVariables.putAll(processorVariables);
            
            // Replace variables in inline query
            query = QueryProcessor.replaceVariables(query, globalVariables);
        } else {
            logger.error("Invalid querySource '{}' for letter type: {}. Valid values are 'xml' or 'inline'.", letterConfig.querySource, letterType);
            return;
        }

        // Execute query and generate file
        executeQueryAndGenerateFile(conn, letterType, letterConfig, query, columns, fileNamePattern, letterDefinition, processor, globalVariables);
    }
    
    /**
     * Execute post file sent step for a specific letter type
     * This method is called after files are sent to SFTP server
     */
    public void executePostFileSentStep(String letterType) throws Exception {
        Config config = AppConfig.getConfig();
        String password = config.isEncryptedPassword
                ? EncryptionUtil.decrypt(config.database.password.replace("ENCRYPTED(", "").replace(")", ""))
                : config.database.password;

        Connection conn = DriverManager.getConnection(
                config.database.url,
                config.database.user,
                password
        );

        try {
            // Find the specific letter configuration
            LetterConfig letterConfig = config.letters.get(letterType);
            if (letterConfig == null) {
                logger.error("Letter type '{}' not found in configuration for post file sent step. Available types: {}", letterType, config.letters.keySet());
                return;
            }
            
            if (!letterConfig.enabled) {
                logger.info("Letter type '{}' is disabled, skipping post file sent step", letterType);
                return;
            }

            Map<String, Object> globalVariables = QueryProcessor.createGlobalVariables();
            boolean hasStep = false;
            String query = "";
            String queryType = "update";

            if ("xml".equalsIgnoreCase(letterConfig.querySource)) {
                // Handle XML-based post file sent step
                LetterDefinition letterDefinition = loadDefinition("config/letters/" + letterConfig.queryFile);
                
                if (letterDefinition.getPostFileSentStep() != null && letterDefinition.getPostFileSentStep().isEnabled()) {
                    hasStep = true;
                    query = letterDefinition.getPostFileSentStep().getQuery();
                    queryType = letterDefinition.getPostFileSentStep().getQueryType();
                }
            } else if ("inline".equalsIgnoreCase(letterConfig.querySource)) {
                // Handle inline processor-based post file sent step
                LetterProcessor processor = LetterProcessorFactory.getProcessor(letterType);
                
                if (processor.hasPostFileSentStep()) {
                    hasStep = true;
                    query = processor.getPostFileSentQuery();
                    queryType = processor.getPostFileSentQueryType();
                    
                    // Merge global variables from processor
                    Map<String, Object> processorVariables = processor.getGlobalVariables();
                    globalVariables.putAll(processorVariables);
                }
            }
            
            if (hasStep && !query.isEmpty()) {
                logger.info("Executing post file sent step for letter type: " + letterType);
                QueryProcessor.executePostProcessingStep(conn, queryType, query, globalVariables);
            } else {
                logger.info("No post file sent step configured for letter type: " + letterType);
            }
        } finally {
            conn.close();
        }
    }
    
    /**
     * Execute post file sent steps for all enabled letter types
     */
    public void executePostFileSentStepForAll() throws Exception {
        Config config = AppConfig.getConfig();
        
        for (String letterType : config.letters.keySet()) {
            LetterConfig letterConfig = config.letters.get(letterType);
            if (letterConfig.enabled) {
                try {
                    executePostFileSentStep(letterType);
                } catch (Exception e) {
                    logger.error("Error executing post file sent step for letter type {}: {}", letterType, e.getMessage(), e);
                }
            }
        }
    }
    
    private void executeQueryAndGenerateFile(Connection conn, String letterType, LetterConfig letterConfig, 
                                           String query, List<String> columns, String fileNamePattern) throws Exception {
        executeQueryAndGenerateFile(conn, letterType, letterConfig, query, columns, fileNamePattern, null, null, QueryProcessor.createGlobalVariables());
    }
    
    private void executeQueryAndGenerateFile(Connection conn, String letterType, LetterConfig letterConfig, 
                                           String query, List<String> columns, String fileNamePattern, 
                                           LetterDefinition letterDefinition, LetterProcessor processor, 
                                           Map<String, Object> globalVariables) throws Exception {
        
        logger.info("Executing query for letter type: " + letterType);
        
        // Replace variables in query
        String processedQuery = QueryProcessor.replaceVariables(query, globalVariables);
        logger.info("Query: " + processedQuery);
        
        ResultSet rs = conn.createStatement().executeQuery(processedQuery);
        String date = LocalDate.now().format(DateTimeFormatter.BASIC_ISO_DATE);
        
        // Handle null fileNamePattern to prevent NullPointerException
        String safeFileNamePattern = fileNamePattern != null ? fileNamePattern : "{LETTER_TYPE}_{DATE}.txt";
        String fileName = safeFileNamePattern
                .replace("{LETTER_TYPE}", letterType != null ? letterType : "UNKNOWN")
                .replace("{DATE}", date);

        // Log column information
        logger.info(columns.size() + " columns found for letter type: " + letterType);
        logger.info("Columns: " + String.join(", ", columns));

        // Ensure output directory exists
        new File(letterConfig.exportPath).mkdirs();
        
        // Generate the file
        String fullPath = letterConfig.exportPath + fileName;
        FileUtil.writeResultSetToFile(rs, columns, letterConfig.delimiter, fullPath);
        
        logger.info("Generated file for letter type " + letterType + ": " + fullPath);
        rs.close();
        
        // Execute post file generation step
        executePostFileGenerationStep(conn, letterType, letterDefinition, processor, globalVariables);
    }
    
    /**
     * Execute pre file generation step for both XML and inline query sources
     */
    private void executePreFileGenerationStep(Connection conn, String letterType, 
                                             LetterDefinition letterDefinition, LetterProcessor processor, 
                                             Map<String, Object> globalVariables) {
        try {
            boolean hasStep = false;
            String query = "";
            String queryType = "update";
            
            // Check XML-based pre file generation step
            if (letterDefinition != null && letterDefinition.getPreFileGenerationStep() != null && 
                letterDefinition.getPreFileGenerationStep().isEnabled()) {
                hasStep = true;
                query = letterDefinition.getPreFileGenerationStep().getQuery();
                queryType = letterDefinition.getPreFileGenerationStep().getQueryType();
            }
            // Check inline processor-based pre file generation step
            else if (processor != null && processor.hasPreFileGenerationStep()) {
                hasStep = true;
                query = processor.getPreFileGenerationQuery();
                queryType = processor.getPreFileGenerationQueryType();
            }
            
            if (hasStep && !query.isEmpty()) {
                logger.info("Executing pre file generation step for letter type: " + letterType);
                QueryProcessor.executePostProcessingStep(conn, queryType, query, globalVariables);
            }
        } catch (Exception e) {
            logger.error("Error executing pre file generation step for letter type {}: {}", letterType, e.getMessage(), e);
        }
    }

    /**
     * Execute post file generation step for both XML and inline query sources
     */
    private void executePostFileGenerationStep(Connection conn, String letterType, 
                                              LetterDefinition letterDefinition, LetterProcessor processor, 
                                              Map<String, Object> globalVariables) {
        try {
            boolean hasStep = false;
            String query = "";
            String queryType = "update";
            
            // Check XML-based post file generation step
            if (letterDefinition != null && letterDefinition.getPostFileGenerationStep() != null && 
                letterDefinition.getPostFileGenerationStep().isEnabled()) {
                hasStep = true;
                query = letterDefinition.getPostFileGenerationStep().getQuery();
                queryType = letterDefinition.getPostFileGenerationStep().getQueryType();
            }
            // Check inline processor-based post file generation step
            else if (processor != null && processor.hasPostFileGenerationStep()) {
                hasStep = true;
                query = processor.getPostFileGenerationQuery();
                queryType = processor.getPostFileGenerationQueryType();
            }
            
            if (hasStep && !query.isEmpty()) {
                logger.info("Executing post file generation step for letter type: " + letterType);
                QueryProcessor.executePostProcessingStep(conn, queryType, query, globalVariables);
            }
        } catch (Exception e) {
            logger.error("Error executing post file generation step for letter type {}: {}", letterType, e.getMessage(), e);
        }
    }

    private LetterDefinition loadDefinition(String filePath) throws Exception {
        logger.info("Loading letter definition from: " + filePath);
        JAXBContext context = JAXBContext.newInstance(LetterDefinition.class);
        Unmarshaller unmarshaller = context.createUnmarshaller();
        return (LetterDefinition) unmarshaller.unmarshal(new File(filePath));
    }
}
