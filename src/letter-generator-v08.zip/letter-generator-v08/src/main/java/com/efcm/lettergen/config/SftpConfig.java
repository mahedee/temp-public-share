package com.efcm.lettergen.config;

public class SftpConfig {
    public boolean enabled;
    public String host;
    public int port;
    public String username;
    public String keyPath;  // SSH private key file path
    public String keyPassphrase;  // Optional passphrase for the key
    public String remoteDirectory;
    public int timeout;
    public int retries;
    public boolean postTransferProcessing;
}
