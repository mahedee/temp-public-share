package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;
import java.util.Map;

/**
 * Letter processor for ID Theft Letters using new structured approach
 */
public class IDTheftLetterProcessor extends AbstractLetterProcessor {
    
    public IDTheftLetterProcessor() {
        super("IDTheftLetter");
    }
    
    @Override
    public boolean hasPreFileGenerationStep() {
        return true;
    }
    
    @Override
    public String getPreFileGenerationQuery() {
        return "UPDATE POSTAL_MAIL_LETTERS SET SENT_DATE = CURRENT_TIMESTAMP " +
               "WHERE LETTER_TYPE = 'ID_THEFT' AND RECORD_STATUS = 'ACTIVE'";
    }
    
    @Override
    public String getPreFileGenerationQueryType() {
        return "update";
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT " +
               "ID, " +
               "LETTER_TYPE, " +
               "CUSTOMER_NAME, " +
               "FULL_ADDRESS, " +
               "ADDITIONAL_NAME1, " +
               "ADDITIONAL_NAME2, " +
               "ADDITIONAL_NAME3, " +
               "ADDITIONAL_NAME4, " +
               "TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE, " +
               "RECORD_STATUS " +
               "FROM POSTAL_MAIL_LETTERS " +
               "WHERE LETTER_TYPE = 'ID_THEFT' AND RECORD_STATUS = 'ACTIVE'";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("ID", "LETTER_TYPE", "CUSTOMER_NAME", "FULL_ADDRESS", 
                      "ADDITIONAL_NAME1", "ADDITIONAL_NAME2", "ADDITIONAL_NAME3", 
                      "ADDITIONAL_NAME4", "SENT_DATE", "RECORD_STATUS");
    }
    
    @Override
    public Map<String, Object> getGlobalVariables() {
        return Map.of("sent_date", "{CURRENT_TIMESTAMP}");
    }
    
    @Override
    public boolean hasPostFileGenerationStep() {
        return true;
    }
    
    @Override
    public String getPostFileGenerationQuery() {
        return "UPDATE POSTAL_MAIL_LETTERS SET RECORD_STATUS = 'PROCESSED' " +
               "WHERE LETTER_TYPE = 'ID_THEFT' AND RECORD_STATUS = 'ACTIVE'";
    }
    
    @Override
    public String getPostFileGenerationQueryType() {
        return "update";
    }
    
    @Override
    public boolean hasPostFileSentStep() {
        return true;
    }
    
    @Override
    public String getPostFileSentQuery() {
        return "UPDATE POSTAL_MAIL_LETTERS SET RECORD_STATUS = 'SENT' " +
               "WHERE LETTER_TYPE = 'ID_THEFT' AND RECORD_STATUS = 'PROCESSED' AND SENT_DATE IS NOT NULL";
    }
    
    @Override
    public String getPostFileSentQueryType() {
        return "update";
    }
}
