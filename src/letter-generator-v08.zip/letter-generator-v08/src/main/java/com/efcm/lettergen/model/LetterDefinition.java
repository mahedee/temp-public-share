package com.efcm.lettergen.model;

import jakarta.xml.bind.annotation.*;
import java.util.List;

@XmlRootElement(name = "letter")
@XmlAccessorType(XmlAccessType.FIELD)
public class LetterDefinition {
    private String fileName;
    private String query; // For backward compatibility
    
    @XmlElementWrapper(name = "columns")
    @XmlElement(name = "column")
    private List<String> columns; // For backward compatibility
    
    @XmlElement(name = "globalVariables")
    private GlobalVariables globalVariables;
    
    @XmlElement(name = "preFileGenerationStep")
    private PostProcessingStep preFileGenerationStep;
    
    @XmlElement(name = "fileGenerationSection")
    private FileGenerationSection fileGenerationSection;
    
    @XmlElement(name = "postFileGenerationStep")
    private PostProcessingStep postFileGenerationStep;
    
    @XmlElement(name = "postFileSentStep")
    private PostProcessingStep postFileSentStep;

    public String getFileName() { return fileName; }
    public void setFileName(String fileName) { this.fileName = fileName; }

    public String getQuery() { 
        // For backward compatibility, first check fileGenerationSection, then query field
        if (fileGenerationSection != null && fileGenerationSection.getQuery() != null) {
            return fileGenerationSection.getQuery();
        }
        return query; 
    }
    public void setQuery(String query) { this.query = query; }

    public List<String> getColumns() { 
        // For backward compatibility, first check fileGenerationSection, then columns field
        if (fileGenerationSection != null && fileGenerationSection.getColumns() != null) {
            return fileGenerationSection.getColumns();
        }
        return columns; 
    }
    public void setColumns(List<String> columns) { this.columns = columns; }
    
    public GlobalVariables getGlobalVariables() { return globalVariables; }
    public void setGlobalVariables(GlobalVariables globalVariables) { this.globalVariables = globalVariables; }
    
    public PostProcessingStep getPreFileGenerationStep() { return preFileGenerationStep; }
    public void setPreFileGenerationStep(PostProcessingStep preFileGenerationStep) { this.preFileGenerationStep = preFileGenerationStep; }
    
    public FileGenerationSection getFileGenerationSection() { return fileGenerationSection; }
    public void setFileGenerationSection(FileGenerationSection fileGenerationSection) { this.fileGenerationSection = fileGenerationSection; }
    
    public PostProcessingStep getPostFileGenerationStep() { return postFileGenerationStep; }
    public void setPostFileGenerationStep(PostProcessingStep postFileGenerationStep) { this.postFileGenerationStep = postFileGenerationStep; }
    
    public PostProcessingStep getPostFileSentStep() { return postFileSentStep; }
    public void setPostFileSentStep(PostProcessingStep postFileSentStep) { this.postFileSentStep = postFileSentStep; }
    
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class FileGenerationSection {
        private String name;
        private int sequence;
        private String query;
        
        @XmlElementWrapper(name = "columns")
        @XmlElement(name = "column")
        private List<String> columns;
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public int getSequence() { return sequence; }
        public void setSequence(int sequence) { this.sequence = sequence; }
        
        public String getQuery() { return query; }
        public void setQuery(String query) { this.query = query; }
        
        public List<String> getColumns() { return columns; }
        public void setColumns(List<String> columns) { this.columns = columns; }
    }
    
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class GlobalVariables {
        @XmlElement(name = "sent_date")
        private String sentDate;
        
        public String getSentDate() { return sentDate; }
        public void setSentDate(String sentDate) { this.sentDate = sentDate; }
    }
    
    @XmlAccessorType(XmlAccessType.FIELD)
    public static class PostProcessingStep {
        private String name;
        private int sequence;
        private boolean enable;
        private String queryType;
        private String query;
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public int getSequence() { return sequence; }
        public void setSequence(int sequence) { this.sequence = sequence; }
        
        public boolean isEnabled() { return enable; }
        public void setEnabled(boolean enable) { this.enable = enable; }
        
        public String getQueryType() { return queryType; }
        public void setQueryType(String queryType) { this.queryType = queryType; }
        
        public String getQuery() { return query; }
        public void setQuery(String query) { this.query = query; }
    }
}
