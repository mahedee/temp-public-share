package com.efcm.lettergen.generator;

import java.util.List;
import java.util.Map;

/**
 * Abstract base class for letter processors
 */
public abstract class AbstractLetterProcessor implements LetterProcessor {
    
    protected final String letterType;
    
    protected AbstractLetterProcessor(String letterType) {
        this.letterType = letterType;
    }
    
    @Override
    public String getLetterType() {
        return letterType;
    }
    
    @Override
    public boolean supportsInlineQuery() {
        return true; // Default implementation supports inline queries
    }
    
    /**
     * Default implementation returns empty query - subclasses should override
     */
    @Override
    public String getInlineQuery() {
        return "";
    }
    
    /**
     * Default implementation returns empty list - subclasses should override
     */
    @Override
    public List<String> getInlineColumns() {
        return List.of();
    }
    
    /**
     * Default implementation returns empty map - subclasses can override
     */
    @Override
    public Map<String, Object> getGlobalVariables() {
        return Map.of();
    }
    
    /**
     * Default implementation returns false - subclasses can override
     */
    @Override
    public boolean hasPostFileGenerationStep() {
        return false;
    }
    
    /**
     * Default implementation returns empty query - subclasses can override
     */
    @Override
    public String getPostFileGenerationQuery() {
        return "";
    }
    
    /**
     * Default implementation returns update - subclasses can override
     */
    @Override
    public String getPostFileGenerationQueryType() {
        return "update";
    }
    
    /**
     * Default implementation returns false - subclasses can override
     */
    @Override
    public boolean hasPostFileSentStep() {
        return false;
    }
    
    /**
     * Default implementation returns empty query - subclasses can override
     */
    @Override
    public String getPostFileSentQuery() {
        return "";
    }
    
    /**
     * Default implementation returns update - subclasses can override
     */
    @Override
    public String getPostFileSentQueryType() {
        return "update";
    }
}
