package com.efcm.lettergen.demo;

import com.efcm.lettergen.generator.LetterProcessorFactory;
import com.efcm.lettergen.generator.LetterProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Demonstration class showing how to add new letter types
 * and handle missing inline query processors
 */
public class NewLetterTypeDemo {
    
    private static final Logger logger = LoggerFactory.getLogger(NewLetterTypeDemo.class);
    
    public static void main(String[] args) {
        // Demonstrate checking for a new letter type that doesn't have a processor
        String newLetterType = "WelcomeLetter";
        
        logger.info("Checking for processor for new letter type: {}", newLetterType);
        
        if (LetterProcessorFactory.hasProcessor(newLetterType)) {
            logger.info("Processor found for: {}", newLetterType);
        } else {
            logger.warn("No processor found for: {}", newLetterType);
            
            // This will return a default processor and log appropriate warnings
            LetterProcessor processor = LetterProcessorFactory.getProcessor(newLetterType);
            
            // Attempting to get inline query will log an error
            processor.getInlineQuery(); // This will log an error message
            processor.getInlineColumns(); // This will log an error message
            
            logger.info("Supports inline query: {}", processor.supportsInlineQuery());
        }
        
        // Show available processors
        logger.info("Available letter processors: {}", LetterProcessorFactory.getRegisteredLetterTypes());
    }
}
