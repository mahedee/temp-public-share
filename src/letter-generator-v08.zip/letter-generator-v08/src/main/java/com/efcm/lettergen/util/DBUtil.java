
// package com.efcm.lettergen.util;

// import com.efcm.lettergen.config.AppConfig;

// import java.sql.Connection;
// import java.sql.DriverManager;
// import java.sql.SQLException;

// public class DBUtil {
//     public static Connection getConnection() throws SQLException {
//         // return DriverManager.getConnection(
//         //     AppConfig.getDbUrl(),
//         //     AppConfig.getDbUser(),
//         //     AppConfig.getDbPassword()
//         // );
//     }
// }
