package com.efcm.lettergen;

import com.efcm.lettergen.generator.LetterGenerator;
import com.efcm.lettergen.util.EncryptionUtil;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class App {
    public static void main(String[] args) throws Exception {
        LetterGenerator letterGenerator = new LetterGenerator();
        
        if (args.length == 0) {
            // No arguments - execute complete letter generation workflow
            executeCompleteLetterWorkflow(letterGenerator);
        } else if (args.length == 1) {
            String argument = args[0];
            
            if ("generate_all_letters".equals(argument)) {
                // Execute complete letter generation workflow
                executeCompleteLetterWorkflow(letterGenerator);
            } else if ("postFileSentStep_all".equals(argument)) {
                // Execute post file sent step from common-steps.xml
                letterGenerator.executePostFileSentStepForAll();
            } else {
                // Treat as encryption text with default output directory
                encryptText(argument, "output/encrypted");
            }
        } else if (args.length == 2) {
            String textToEncrypt = args[0];
            String outputDirectory = args[1];
            
            // Encrypt the text to specified output directory
            encryptText(textToEncrypt, outputDirectory);
        } else {
            // Invalid number of arguments
            printUsage();
            System.exit(1);
        }
    }
    
    /**
     * Execute complete letter generation workflow:
     * 1. preFileGenerationStep
     * 2. fileGenerationSection
     * 3. postFileGenerationStep
     */
    private static void executeCompleteLetterWorkflow(LetterGenerator letterGenerator) throws Exception {
        System.out.println("Executing complete letter generation workflow...");
        
        // Execute all three steps in sequence
        letterGenerator.generateAll(); // This internally handles preFileGenerationStep, fileGenerationSection, and postFileGenerationStep
        
        System.out.println("Complete letter generation workflow finished successfully.");
    }
    
    /**
     * Encrypt the provided text and save to specified output directory
     */
    private static void encryptText(String textToEncrypt, String outputDirectory) throws Exception {
        System.out.println("Encrypting text to output directory: " + outputDirectory);
        
        Path outputPath = Paths.get(outputDirectory);
        Files.createDirectories(outputPath);
        
        Path encryptedFilePath = outputPath.resolve("encryptedtext.txt");
        
        EncryptionUtil.encryptToFile(textToEncrypt, encryptedFilePath.toString());
        
        System.out.println("Encrypted text written to: " + encryptedFilePath.toAbsolutePath());
    }
    
    /**
     * Print usage information
     */
    private static void printUsage() {
        System.out.println("Usage:");
        System.out.println("  java -jar letter-generator.jar                              # Execute complete letter workflow");
        System.out.println("  java -jar letter-generator.jar generate_all_letters        # Execute complete letter workflow");
        System.out.println("  java -jar letter-generator.jar postFileSentStep_all        # Execute post file sent step only");
        System.out.println("  java -jar letter-generator.jar \"text\"                       # Encrypt text to default directory");
        System.out.println("  java -jar letter-generator.jar \"text\" \"output/directory\"   # Encrypt text to specified directory");
        System.out.println();
        System.out.println("Letter Generation Workflow includes:");
        System.out.println("  1. preFileGenerationStep   - Database preparation");
        System.out.println("  2. fileGenerationSection   - Generate letter files");
        System.out.println("  3. postFileGenerationStep  - Update database records");
    }
}