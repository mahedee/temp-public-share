package com.efcm.lettergen.generator;

import com.efcm.lettergen.generator.processors.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.HashMap;
import java.util.Map;

/**
 * Factory class for creating letter processors following Open-Closed Principle
 */
public class LetterProcessorFactory {
    
    private static final Logger logger = LoggerFactory.getLogger(LetterProcessorFactory.class);
    private static final Map<String, LetterProcessor> processors = new HashMap<>();
    
    static {
        // Register all available letter processors
        registerProcessor(new DemandLetterProcessor());
        registerProcessor(new HoldLetterProcessor());
        registerProcessor(new IDTheftLetterProcessor());
        registerProcessor(new RelationshipTermLetterProcessor());
        registerProcessor(new WelcomeLetterProcessor());
        registerProcessor(new TestLetterProcessor());
    }
    
    /**
     * Register a letter processor
     */
    public static void registerProcessor(LetterProcessor processor) {
        processors.put(processor.getLetterType(), processor);
        logger.info("Registered letter processor for: {}", processor.getLetterType());
    }
    
    /**
     * Get a letter processor by type
     */
    public static LetterProcessor getProcessor(String letterType) {
        LetterProcessor processor = processors.get(letterType);
        
        if (processor == null) {
            logger.warn("No inline query processor found for letter type: {}. Available processors: {}", letterType, processors.keySet());
            // Return a default processor that doesn't support inline queries
            return new DefaultLetterProcessor(letterType);
        }
        
        return processor;
    }
    
    /**
     * Check if a processor exists for the given letter type
     */
    public static boolean hasProcessor(String letterType) {
        return processors.containsKey(letterType);
    }
    
    /**
     * Get all registered letter types
     */
    public static java.util.Set<String> getRegisteredLetterTypes() {
        return processors.keySet();
    }
    
    /**
     * Default processor for unknown letter types
     */
    private static class DefaultLetterProcessor extends AbstractLetterProcessor {
        
        public DefaultLetterProcessor(String letterType) {
            super(letterType);
        }
        
        @Override
        public boolean supportsInlineQuery() {
            return false;
        }
        
        @Override
        public String getInlineQuery() {
            logger.error("Inline query not found for letter type: {}. Please implement a processor for this letter type or use XML query file.", letterType);
            logger.warn("{} cannot be generated because inline query is missing. You have to add inline query in the code or you have to switch to xml query source.", letterType);
            return "";
        }
        
        @Override
        public java.util.List<String> getInlineColumns() {
            logger.error("Inline columns not found for letter type: {}. Please implement a processor for this letter type or use XML query file.", letterType);
            return java.util.List.of();
        }
    }
}
