package com.efcm.lettergen.config;

public class LetterConfig {
    public boolean enabled;
    public String delimiter;
    public String querySource; // "xml" or "inline" - single source of truth
    public String queryFile;
    public String exportPath;
}
