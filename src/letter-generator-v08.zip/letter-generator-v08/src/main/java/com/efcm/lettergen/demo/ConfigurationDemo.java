package com.efcm.lettergen.demo;

import com.efcm.lettergen.config.AppConfig;
import com.efcm.lettergen.config.Config;
import com.efcm.lettergen.config.LetterConfig;
import com.efcm.lettergen.generator.LetterProcessorFactory;
import com.efcm.lettergen.generator.LetterProcessor;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Demo class to test configuration reading and processor checking
 */
public class ConfigurationDemo {
    
    private static final Logger logger = LoggerFactory.getLogger(ConfigurationDemo.class);
    
    public static void main(String[] args) throws Exception {
        logger.info("Loading configuration...");
        
        Config config = AppConfig.getConfig();
        
        logger.info("Found {} letter types in configuration:", config.letters.size());
        
        for (String letterType : config.letters.keySet()) {
            LetterConfig letterConfig = config.letters.get(letterType);
            
            logger.info("Letter Type: {}", letterType);
            logger.info("  - Enabled: {}", letterConfig.enabled);
            logger.info("  - Query Source: {}", letterConfig.querySource);
            
            if (letterConfig.enabled && "inline".equalsIgnoreCase(letterConfig.querySource)) {
                // Check if processor exists for inline queries
                if (LetterProcessorFactory.hasProcessor(letterType)) {
                    logger.info("  - Inline Query Processor: AVAILABLE");
                } else {
                    logger.warn("  - Inline Query Processor: MISSING - {} is configured for inline queries but no processor found!", letterType);
                    
                    // Demonstrate what happens when getting the processor
                    LetterProcessor processor = LetterProcessorFactory.getProcessor(letterType);
                    logger.info("  - Supports Inline Query: {}", processor.supportsInlineQuery());
                }
            }
            
            logger.info(""); // Empty line for readability
        }
        
        logger.info("Available processors: {}", LetterProcessorFactory.getRegisteredLetterTypes());
    }
}
