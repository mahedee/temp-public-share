package com.efcm.lettergen.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

/**
 * Utility class for processing queries with variable replacement and executing post-processing steps
 */
public class QueryProcessor {
    
    private static final Logger logger = LoggerFactory.getLogger(QueryProcessor.class);
    
    /**
     * Replace variables in query string with actual values
     * @param query The query string with placeholders
     * @param variables Map of variable name to value
     * @return Processed query string
     */
    public static String replaceVariables(String query, Map<String, Object> variables) {
        if (query == null || variables == null) {
            return query;
        }
        
        String processedQuery = query;
        for (Map.Entry<String, Object> entry : variables.entrySet()) {
            String placeholder = "{" + entry.getKey() + "}";
            String value = convertValueToString(entry.getValue());
            processedQuery = processedQuery.replace(placeholder, value);
        }
        
        // Handle special variables
        processedQuery = processedQuery.replace("{CURRENT_TIMESTAMP}", "CURRENT_TIMESTAMP");
        
        logger.debug("Original query: {}", query);
        logger.debug("Processed query: {}", processedQuery);
        
        return processedQuery;
    }
    
    /**
     * Create a map of global variables with current timestamp
     * @return Map containing global variables
     */
    public static Map<String, Object> createGlobalVariables() {
        Map<String, Object> variables = new HashMap<>();
        Timestamp currentTimestamp = Timestamp.valueOf(LocalDateTime.now());
        variables.put("sent_date", currentTimestamp);
        return variables;
    }
    
    /**
     * Execute a post-processing step (update/delete query)
     * @param connection Database connection
     * @param queryType Type of query (update/delete)
     * @param query The SQL query to execute
     * @param variables Variables for replacement
     * @return Number of rows affected
     */
    public static int executePostProcessingStep(Connection connection, String queryType, 
                                              String query, Map<String, Object> variables) {
        if (query == null || query.trim().isEmpty()) {
            logger.warn("Empty query provided for post-processing step");
            return 0;
        }
        
        try {
            String processedQuery = replaceVariables(query, variables);
            logger.info("Executing {} query: {}", queryType, processedQuery);
            
            try (PreparedStatement stmt = connection.prepareStatement(processedQuery)) {
                int rowsAffected = stmt.executeUpdate();
                logger.info("{} query executed successfully. Rows affected: {}", queryType, rowsAffected);
                return rowsAffected;
            }
        } catch (Exception e) {
            logger.error("Error executing {} query: {}", queryType, e.getMessage(), e);
            return 0;
        }
    }
    
    /**
     * Convert value to string representation for SQL
     * @param value The value to convert
     * @return String representation
     */
    private static String convertValueToString(Object value) {
        if (value == null) {
            return "NULL";
        } else if (value instanceof String) {
            return "'" + value.toString().replace("'", "''") + "'";
        } else if (value instanceof Timestamp) {
            return "TIMESTAMP '" + value.toString() + "'";
        } else {
            return value.toString();
        }
    }
}
