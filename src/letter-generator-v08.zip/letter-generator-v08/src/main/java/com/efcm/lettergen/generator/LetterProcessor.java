package com.efcm.lettergen.generator;

import java.util.List;
import java.util.Map;

/**
 * Interface for letter processors following Open-Closed Principle
 */
public interface LetterProcessor {
    
    /**
     * Get the inline query for this letter type
     * @return SQL query string
     */
    String getInlineQuery();
    
    /**
     * Get the columns for this letter type
     * @return List of column names
     */
    List<String> getInlineColumns();
    
    /**
     * Get the letter type name
     * @return Letter type name
     */
    String getLetterType();
    
    /**
     * Check if this processor supports inline queries
     * @return true if inline queries are supported
     */
    boolean supportsInlineQuery();
    
    /**
     * Get global variables for this letter type
     * @return Map of variable names to values
     */
    default Map<String, Object> getGlobalVariables() {
        return Map.of();
    }
    
    /**
     * Check if pre file generation step is enabled
     * @return true if enabled
     */
    default boolean hasPreFileGenerationStep() {
        return false;
    }
    
    /**
     * Get pre file generation step query
     * @return SQL query for pre file generation step
     */
    default String getPreFileGenerationQuery() {
        return "";
    }
    
    /**
     * Get pre file generation step query type
     * @return Query type (update/delete)
     */
    default String getPreFileGenerationQueryType() {
        return "update";
    }
    
    /**
     * Check if post file generation step is enabled
     * @return true if enabled
     */
    default boolean hasPostFileGenerationStep() {
        return false;
    }
    
    /**
     * Get post file generation step query
     * @return SQL query for post file generation step
     */
    default String getPostFileGenerationQuery() {
        return "";
    }
    
    /**
     * Get post file generation step query type
     * @return Query type (update/delete)
     */
    default String getPostFileGenerationQueryType() {
        return "update";
    }
    
    /**
     * Check if post file sent step is enabled
     * @return true if enabled
     */
    default boolean hasPostFileSentStep() {
        return false;
    }
    
    /**
     * Get post file sent step query
     * @return SQL query for post file sent step
     */
    default String getPostFileSentQuery() {
        return "";
    }
    
    /**
     * Get post file sent step query type
     * @return Query type (update/delete)
     */
    default String getPostFileSentQueryType() {
        return "update";
    }
}
