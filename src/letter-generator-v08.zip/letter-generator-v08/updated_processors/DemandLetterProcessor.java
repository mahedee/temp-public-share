package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;

/**
 * Letter processor for Demand Letters
 */
public class DemandLetterProcessor extends AbstractLetterProcessor {
    
    public DemandLetterProcessor() {
        super("DemandLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT " +
               "CASE_ID, " +
               "ACCOUNT_NO, " +
               "CUSTOMER_NAME, " +
               "DUE_AMOUNT, " +
               "TO_CHAR(DUE_DATE, 'YYYY-MM-DD') AS DUE_DATE, " +
               "REASON, " +
               "TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE, " +
               "STATUS " +
               "FROM DEMAND_LETTERS " +
               "WHERE STATUS = 'ACTIVE'";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("CASE_ID", "ACCOUNT_NO", "CUSTOMER_NAME", "DUE_AMOUNT", "DUE_DATE", "REASON", "SENT_DATE", "STATUS");
    }
}
