package com.efcm.lettergen.generator.processors;

import com.efcm.lettergen.generator.AbstractLetterProcessor;
import java.util.List;

/**
 * Letter processor for Welcome Letters
 */
public class WelcomeLetterProcessor extends AbstractLetterProcessor {
    
    public WelcomeLetterProcessor() {
        super("WelcomeLetter");
    }
    
    @Override
    public String getInlineQuery() {
        return "SELECT " +
               "'WEL' || ROWNUM AS WELCOME_ID, " +
               "'ACC' || (200 + ROWNUM) AS ACCOUNT_NO, " +
               "'Welcome Customer ' || ROWNUM AS CUSTOMER_NAME, " +
               "SYSDATE AS WELCOME_DATE, " +
               "TO_CHAR(CURRENT_TIMESTAMP, 'YYYY-MM-DD HH24:MI:SS.FF6') AS SENT_DATE, " +
               "'ACTIVE' AS STATUS " +
               "FROM DUAL CONNECT BY LEVEL <= 3";
    }
    
    @Override
    public List<String> getInlineColumns() {
        return List.of("WELCOME_ID", "ACCOUNT_NO", "CUSTOMER_NAME", "WELCOME_DATE", "SENT_DATE", "STATUS");
    }
}
