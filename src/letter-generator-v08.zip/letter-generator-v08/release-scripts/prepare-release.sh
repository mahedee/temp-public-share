#!/bin/bash

# Letter Generator Release Preparation Script
# This script automates the release preparation process

set -e

# Configuration
APP_NAME="letter-generator"
CURRENT_VERSION="1.0-SNAPSHOT"
RELEASE_VERSION="1.0"
DIST_DIR="dist"
RELEASE_DIR="${DIST_DIR}/${APP_NAME}-${RELEASE_VERSION}"

echo "=== Letter Generator Release Preparation ==="
echo "Release Version: ${RELEASE_VERSION}"
echo "Distribution Directory: ${RELEASE_DIR}"
echo ""

# Step 1: Clean previous builds
echo "Step 1: Cleaning previous builds..."
mvn clean
rm -rf "${DIST_DIR}"

# Step 2: Update version in POM
echo "Step 2: Updating version in pom.xml..."
sed -i.bak "s/<version>${CURRENT_VERSION}<\/version>/<version>${RELEASE_VERSION}<\/version>/g" pom.xml
echo "Version updated from ${CURRENT_VERSION} to ${RELEASE_VERSION}"

# Step 3: Build application
echo "Step 3: Building application..."
mvn compile package

# Step 4: Create distribution structure
echo "Step 4: Creating distribution structure..."
mkdir -p "${RELEASE_DIR}/config"
mkdir -p "${RELEASE_DIR}/docs"
mkdir -p "${RELEASE_DIR}/scripts"

# Step 5: Copy application files
echo "Step 5: Copying application files..."
cp "target/${APP_NAME}-${RELEASE_VERSION}.jar" "${RELEASE_DIR}/"
cp -r config/* "${RELEASE_DIR}/config/"
cp logback.xml "${RELEASE_DIR}/"
cp docs/*.md "${RELEASE_DIR}/docs/" 2>/dev/null || true

# Step 6: Create startup script
echo "Step 6: Creating startup script..."
cat > "${RELEASE_DIR}/start.sh" << 'EOF'
#!/bin/bash

# Letter Generator Startup Script
# Usage: ./start.sh [arguments]

# Configuration
APP_NAME="letter-generator"
APP_VERSION="1.0"
JAR_FILE="letter-generator-${APP_VERSION}.jar"
JVM_OPTS="-Xms512m -Xmx1024m -XX:+UseG1GC"
LOG_DIR="logs"
CONFIG_DIR="config"

# Create log directory if it doesn't exist
mkdir -p "${LOG_DIR}"

# Check if JAR file exists
if [ ! -f "${JAR_FILE}" ]; then
    echo "Error: ${JAR_FILE} not found!"
    exit 1
fi

# Check Java installation
if ! command -v java &> /dev/null; then
    echo "Error: Java is not installed or not in PATH"
    exit 1
fi

# Check Java version
JAVA_VERSION=$(java -version 2>&1 | grep -oP 'version "?(1\.)?\K\d+' | head -1)
if [ "${JAVA_VERSION}" -lt 11 ]; then
    echo "Error: Java 11 or higher is required. Found: ${JAVA_VERSION}"
    exit 1
fi

# Start the application
echo "Starting ${APP_NAME} v${APP_VERSION}..."
echo "Java Version: $(java -version 2>&1 | head -1)"
echo "Arguments: $@"
echo "Log directory: ${LOG_DIR}"
echo "Starting at: $(date)"

java ${JVM_OPTS} \
    -Dlogback.configurationFile=logback.xml \
    -Djava.awt.headless=true \
    -jar "${JAR_FILE}" "$@"

echo "Application finished at: $(date)"
EOF

# Step 7: Create installation script
echo "Step 7: Creating installation script..."
cat > "${RELEASE_DIR}/install.sh" << 'EOF'
#!/bin/bash

# Letter Generator Installation Script

APP_NAME="letter-generator"
INSTALL_DIR="/opt/${APP_NAME}"
SERVICE_USER="lettergen"
LOG_DIR="/var/log/${APP_NAME}"

echo "Installing Letter Generator..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Create service user
if ! id "${SERVICE_USER}" &>/dev/null; then
    echo "Creating service user: ${SERVICE_USER}"
    useradd -r -s /bin/false -d "${INSTALL_DIR}" "${SERVICE_USER}"
fi

# Create directories
echo "Creating directories..."
mkdir -p "${INSTALL_DIR}"
mkdir -p "${LOG_DIR}"

# Copy application files
echo "Copying application files..."
cp -r ./* "${INSTALL_DIR}/"

# Set permissions
echo "Setting permissions..."
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${INSTALL_DIR}"
chown -R "${SERVICE_USER}:${SERVICE_USER}" "${LOG_DIR}"
chmod +x "${INSTALL_DIR}/start.sh"

# Create systemd service
echo "Creating systemd service..."
cat > "/etc/systemd/system/${APP_NAME}.service" << EOSERVICE
[Unit]
Description=Letter Generator Service
After=network.target

[Service]
Type=simple
User=${SERVICE_USER}
WorkingDirectory=${INSTALL_DIR}
ExecStart=${INSTALL_DIR}/start.sh generate_all_letters
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOSERVICE

# Reload systemd and enable service
systemctl daemon-reload
systemctl enable "${APP_NAME}"

echo "Installation completed!"
echo "Service user: ${SERVICE_USER}"
echo "Install directory: ${INSTALL_DIR}"
echo "Log directory: ${LOG_DIR}"
echo ""
echo "To start the service: sudo systemctl start ${APP_NAME}"
echo "To check status: sudo systemctl status ${APP_NAME}"
echo "To view logs: sudo journalctl -u ${APP_NAME} -f"
EOF

# Step 8: Create production configuration template
echo "Step 8: Creating production configuration template..."
cat > "${RELEASE_DIR}/config/production.properties" << 'EOF'
# Production Configuration Template
# Copy to config.properties and modify for your environment

# Database Configuration
db.url=jdbc:oracle:thin:@//your-prod-db-host:1521/YOURDB
db.username=your_username
db.password=your_encrypted_password
db.driver=oracle.jdbc.OracleDriver

# Application Settings
app.environment=production
app.batch.size=1000
app.max.retries=3

# File Output Settings
output.base.directory=/opt/letter-generator/output
log.directory=/var/log/letter-generator

# Encryption Settings
encryption.enabled=true
encryption.key.file=/opt/letter-generator/config/encryption.key

# Letter Type Configuration
UseQueryFromXML.DemandLetter=true
UseQueryFromXML.HoldLetter=true
UseQueryFromXML.IDTheftLetter=true
UseQueryFromXML.RelationshipTermLetter=true
UseQueryFromXML.WelcomeLetter=false
UseQueryFromXML.TestLetter=false
EOF

# Step 9: Create production logback configuration
echo "Step 9: Creating production logback configuration..."
cat > "${RELEASE_DIR}/logback-production.xml" << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<configuration>
    
    <property name="LOG_DIR" value="/var/log/letter-generator"/>
    
    <!-- Console Appender for systemd journal -->
    <appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender">
        <encoder>
            <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- File Appender for application logs -->
    <appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOG_DIR}/letter-generator.log</file>
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <fileNamePattern>${LOG_DIR}/letter-generator.%d{yyyy-MM-dd}.log</fileNamePattern>
            <maxHistory>30</maxHistory>
            <totalSizeCap>1GB</totalSizeCap>
        </rollingPolicy>
        <encoder>
            <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- Error File Appender -->
    <appender name="ERROR_FILE" class="ch.qos.logback.core.rolling.RollingFileAppender">
        <file>${LOG_DIR}/letter-generator-errors.log</file>
        <filter class="ch.qos.logback.classic.filter.ThresholdFilter">
            <level>ERROR</level>
        </filter>
        <rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy">
            <fileNamePattern>${LOG_DIR}/letter-generator-errors.%d{yyyy-MM-dd}.log</fileNamePattern>
            <maxHistory>90</maxHistory>
        </rollingPolicy>
        <encoder>
            <pattern>%d{ISO8601} [%thread] %-5level %logger{36} - %msg%n</pattern>
        </encoder>
    </appender>
    
    <!-- Root Logger -->
    <root level="INFO">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="FILE"/>
        <appender-ref ref="ERROR_FILE"/>
    </root>
    
    <!-- Application Logger -->
    <logger name="com.efcm.lettergen" level="INFO" additivity="false">
        <appender-ref ref="CONSOLE"/>
        <appender-ref ref="FILE"/>
        <appender-ref ref="ERROR_FILE"/>
    </logger>
    
</configuration>
EOF

# Step 10: Create deployment documentation
echo "Step 10: Creating deployment documentation..."
cat > "${RELEASE_DIR}/DEPLOYMENT.md" << 'EOF'
# Deployment Instructions for Letter Generator v1.0

## Quick Start

1. Extract the archive:
   ```bash
   tar -xzf letter-generator-1.0-linux.tar.gz
   cd letter-generator-1.0
   ```

2. Install as system service (requires root):
   ```bash
   sudo ./install.sh
   ```

3. Configure database connection:
   ```bash
   sudo cp config/production.properties config/config.properties
   sudo nano /opt/letter-generator/config/config.properties
   ```

4. Start the service:
   ```bash
   sudo systemctl start letter-generator
   sudo systemctl status letter-generator
   ```

## Manual Installation

If you prefer manual installation:

1. Create user and directories:
   ```bash
   sudo useradd -r lettergen
   sudo mkdir -p /opt/letter-generator
   sudo mkdir -p /var/log/letter-generator
   ```

2. Copy files and set permissions:
   ```bash
   sudo cp -r ./* /opt/letter-generator/
   sudo chown -R lettergen:lettergen /opt/letter-generator
   sudo chown -R lettergen:lettergen /var/log/letter-generator
   ```

3. Run manually:
   ```bash
   cd /opt/letter-generator
   ./start.sh generate_all_letters
   ```

## Configuration

### Database Setup
1. Update `config/config.properties` with your database details
2. Ensure Oracle JDBC connectivity
3. Test connection before starting service

### Logging
- Application logs: `/var/log/letter-generator/letter-generator.log`
- Error logs: `/var/log/letter-generator/letter-generator-errors.log`
- System logs: `journalctl -u letter-generator`

### Output Files
Generated letters are saved to `/opt/letter-generator/output/`

## Monitoring

### Service Status
```bash
sudo systemctl status letter-generator
```

### View Logs
```bash
# Real-time logs
sudo journalctl -u letter-generator -f

# Application logs
sudo tail -f /var/log/letter-generator/letter-generator.log

# Error logs only
sudo tail -f /var/log/letter-generator/letter-generator-errors.log
```

### Check Output
```bash
ls -la /opt/letter-generator/output/
```

## Troubleshooting

### Common Issues
1. **Java not found**: Install JRE 11+ (`sudo apt install openjdk-11-jre`)
2. **Database connection**: Check credentials and network connectivity
3. **Permission denied**: Ensure proper file ownership and permissions
4. **Service won't start**: Check `journalctl -u letter-generator` for errors

### Support Commands
```bash
# Check Java version
java -version

# Test database connectivity (if tools available)
telnet your-db-host 1521

# Check service logs
sudo journalctl -u letter-generator --since "1 hour ago"

# Restart service
sudo systemctl restart letter-generator
```
EOF

# Step 11: Make scripts executable
echo "Step 11: Making scripts executable..."
chmod +x "${RELEASE_DIR}/start.sh"
chmod +x "${RELEASE_DIR}/install.sh"

# Step 12: Create release archive
echo "Step 12: Creating release archive..."
cd "${DIST_DIR}"
tar -czf "${APP_NAME}-${RELEASE_VERSION}-linux.tar.gz" "${APP_NAME}-${RELEASE_VERSION}/"

# Step 13: Create checksum
echo "Step 13: Creating checksum..."
sha256sum "${APP_NAME}-${RELEASE_VERSION}-linux.tar.gz" > "${APP_NAME}-${RELEASE_VERSION}-linux.tar.gz.sha256"

# Step 14: Restore original POM version for development
echo "Step 14: Restoring development version..."
cd ..
mv pom.xml.bak pom.xml.release
cp pom.xml.release pom.xml
sed -i "s/<version>${RELEASE_VERSION}<\/version>/<version>1.1-SNAPSHOT<\/version>/g" pom.xml

echo ""
echo "=== Release Preparation Complete ==="
echo "Release archive: ${DIST_DIR}/${APP_NAME}-${RELEASE_VERSION}-linux.tar.gz"
echo "Checksum file: ${DIST_DIR}/${APP_NAME}-${RELEASE_VERSION}-linux.tar.gz.sha256"
echo "Distribution directory: ${RELEASE_DIR}"
echo ""
echo "Next steps:"
echo "1. Test the release package"
echo "2. Tag the release: git tag -a v${RELEASE_VERSION} -m 'Release version ${RELEASE_VERSION}'"
echo "3. Deploy to target environment"
echo ""
echo "To test locally:"
echo "  cd ${RELEASE_DIR}"
echo "  ./start.sh generate_all_letters"
