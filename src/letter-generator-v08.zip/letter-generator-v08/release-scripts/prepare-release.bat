@echo off
REM Letter Generator Release Preparation Script for Windows
REM This script automates the release preparation process

setlocal enabledelayedexpansion

REM Configuration
set APP_NAME=letter-generator
set CURRENT_VERSION=1.0-SNAPSHOT
set RELEASE_VERSION=1.0
set DIST_DIR=dist
set RELEASE_DIR=%DIST_DIR%\%APP_NAME%-%RELEASE_VERSION%

echo === Letter Generator Release Preparation ===
echo Release Version: %RELEASE_VERSION%
echo Distribution Directory: %RELEASE_DIR%
echo.

REM Step 1: Clean previous builds
echo Step 1: Cleaning previous builds...
call mvn clean
if exist "%DIST_DIR%" rmdir /s /q "%DIST_DIR%"

REM Step 2: Update version in POM (manual step for Windows)
echo Step 2: Updating version in pom.xml...
echo NOTE: Please manually update pom.xml version from %CURRENT_VERSION% to %RELEASE_VERSION%
echo Press any key after updating the version...
pause

REM Step 3: Build application
echo Step 3: Building application...
call mvn compile package

REM Step 4: Create distribution structure
echo Step 4: Creating distribution structure...
mkdir "%RELEASE_DIR%\config"
mkdir "%RELEASE_DIR%\docs"
mkdir "%RELEASE_DIR%\scripts"

REM Step 5: Copy application files
echo Step 5: Copying application files...
copy "target\%APP_NAME%-%RELEASE_VERSION%.jar" "%RELEASE_DIR%\"
xcopy /s "config\*" "%RELEASE_DIR%\config\"
copy "logback.xml" "%RELEASE_DIR%\"
if exist "docs\*.md" xcopy "docs\*.md" "%RELEASE_DIR%\docs\"

REM Step 6: Create Windows startup script
echo Step 6: Creating Windows startup script...
(
echo @echo off
echo REM Letter Generator Startup Script
echo REM Usage: start.bat [arguments]
echo.
echo REM Configuration
echo set APP_NAME=letter-generator
echo set APP_VERSION=1.0
echo set JAR_FILE=%APP_NAME%-%APP_VERSION%.jar
echo set JVM_OPTS=-Xms512m -Xmx1024m -XX:+UseG1GC
echo set LOG_DIR=logs
echo set CONFIG_DIR=config
echo.
echo REM Create log directory if it doesn't exist
echo if not exist "%LOG_DIR%" mkdir "%LOG_DIR%"
echo.
echo REM Check if JAR file exists
echo if not exist "%JAR_FILE%" (
echo     echo Error: %JAR_FILE% not found!
echo     exit /b 1
echo ^)
echo.
echo REM Check Java installation
echo java -version >nul 2>&1
echo if errorlevel 1 (
echo     echo Error: Java is not installed or not in PATH
echo     exit /b 1
echo ^)
echo.
echo REM Start the application
echo echo Starting %APP_NAME% v%APP_VERSION%...
echo echo Arguments: %*
echo echo Log directory: %LOG_DIR%
echo echo Starting at: %date% %time%
echo.
echo java %JVM_OPTS% -Dlogback.configurationFile=logback.xml -Djava.awt.headless=true -jar "%JAR_FILE%" %*
echo.
echo echo Application finished at: %date% %time%
) > "%RELEASE_DIR%\start.bat"

REM Step 7: Create production configuration template
echo Step 7: Creating production configuration template...
(
echo # Production Configuration Template
echo # Copy to config.properties and modify for your environment
echo.
echo # Database Configuration
echo db.url=jdbc:oracle:thin:@//your-prod-db-host:1521/YOURDB
echo db.username=your_username
echo db.password=your_encrypted_password
echo db.driver=oracle.jdbc.OracleDriver
echo.
echo # Application Settings
echo app.environment=production
echo app.batch.size=1000
echo app.max.retries=3
echo.
echo # File Output Settings
echo output.base.directory=./output
echo log.directory=./logs
echo.
echo # Encryption Settings
echo encryption.enabled=true
echo encryption.key.file=./config/encryption.key
echo.
echo # Letter Type Configuration
echo UseQueryFromXML.DemandLetter=true
echo UseQueryFromXML.HoldLetter=true
echo UseQueryFromXML.IDTheftLetter=true
echo UseQueryFromXML.RelationshipTermLetter=true
echo UseQueryFromXML.WelcomeLetter=false
echo UseQueryFromXML.TestLetter=false
) > "%RELEASE_DIR%\config\production.properties"

REM Step 8: Create production logback configuration
echo Step 8: Creating production logback configuration...
(
echo ^<?xml version="1.0" encoding="UTF-8"?^>
echo ^<configuration^>
echo     ^<property name="LOG_DIR" value="logs"/^>
echo     ^<appender name="CONSOLE" class="ch.qos.logback.core.ConsoleAppender"^>
echo         ^<encoder^>
echo             ^<pattern^>%%d{ISO8601} [%%thread] %%-5level %%logger{36} - %%msg%%n^</pattern^>
echo         ^</encoder^>
echo     ^</appender^>
echo     ^<appender name="FILE" class="ch.qos.logback.core.rolling.RollingFileAppender"^>
echo         ^<file^>${LOG_DIR}/letter-generator.log^</file^>
echo         ^<rollingPolicy class="ch.qos.logback.core.rolling.TimeBasedRollingPolicy"^>
echo             ^<fileNamePattern^>${LOG_DIR}/letter-generator.%%d{yyyy-MM-dd}.log^</fileNamePattern^>
echo             ^<maxHistory^>30^</maxHistory^>
echo             ^<totalSizeCap^>1GB^</totalSizeCap^>
echo         ^</rollingPolicy^>
echo         ^<encoder^>
echo             ^<pattern^>%%d{ISO8601} [%%thread] %%-5level %%logger{36} - %%msg%%n^</pattern^>
echo         ^</encoder^>
echo     ^</appender^>
echo     ^<root level="INFO"^>
echo         ^<appender-ref ref="CONSOLE"/^>
echo         ^<appender-ref ref="FILE"/^>
echo     ^</root^>
echo ^</configuration^>
) > "%RELEASE_DIR%\logback-production.xml"

REM Step 9: Create deployment documentation
echo Step 9: Creating deployment documentation...
(
echo # Windows Deployment Instructions for Letter Generator v1.0
echo.
echo ## Quick Start
echo.
echo 1. Extract the archive to your desired location
echo 2. Copy `config\production.properties` to `config\config.properties`
echo 3. Edit `config\config.properties` with your database details
echo 4. Run: `start.bat generate_all_letters`
echo.
echo ## Configuration
echo.
echo ### Database Setup
echo 1. Update `config\config.properties` with your database details
echo 2. Ensure Oracle JDBC connectivity
echo 3. Test connection before running
echo.
echo ### Output Files
echo Generated letters are saved to `output\` directory
echo.
echo ## Usage
echo.
echo ```
echo REM Generate all letters
echo start.bat generate_all_letters
echo.
echo REM Run post-processing only
echo start.bat postFileSentStep_all
echo.
echo REM Encrypt text
echo start.bat "sensitive data" "output\encrypted"
echo ```
echo.
echo ## Monitoring
echo.
echo - Application logs: `logs\letter-generator.log`
echo - Check output: `dir output\`
echo.
echo ## Troubleshooting
echo.
echo 1. **Java not found**: Install JRE 11+ and add to PATH
echo 2. **Database connection**: Check credentials and network connectivity
echo 3. **Permission denied**: Run as administrator if needed
) > "%RELEASE_DIR%\DEPLOYMENT-WINDOWS.md"

REM Step 10: Create release archive (using PowerShell)
echo Step 10: Creating release archive...
powershell -command "Compress-Archive -Path '%RELEASE_DIR%' -DestinationPath '%DIST_DIR%\%APP_NAME%-%RELEASE_VERSION%-windows.zip'"

REM Step 11: Create checksum (using PowerShell)
echo Step 11: Creating checksum...
powershell -command "Get-FileHash '%DIST_DIR%\%APP_NAME%-%RELEASE_VERSION%-windows.zip' -Algorithm SHA256 | Select-Object Hash | Out-File '%DIST_DIR%\%APP_NAME%-%RELEASE_VERSION%-windows.zip.sha256' -Encoding ASCII"

echo.
echo === Release Preparation Complete ===
echo Release archive: %DIST_DIR%\%APP_NAME%-%RELEASE_VERSION%-windows.zip
echo Checksum file: %DIST_DIR%\%APP_NAME%-%RELEASE_VERSION%-windows.zip.sha256
echo Distribution directory: %RELEASE_DIR%
echo.
echo Next steps:
echo 1. Test the release package
echo 2. Update version back to development version (e.g., 1.1-SNAPSHOT)
echo 3. Deploy to target environment
echo.
echo To test locally:
echo   cd %RELEASE_DIR%
echo   start.bat generate_all_letters

pause
