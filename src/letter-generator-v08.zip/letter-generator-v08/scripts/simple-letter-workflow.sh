#!/bin/bash

# Simple Letter Generator Execution Script
# Uses centralized configuration for all parameters

# Load configuration
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/letter-generator.conf"

# Simple logging function
log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Simple Java execution function
execute_java() {
    local command_args="$1"
    local log_file="$2"
    
    log_msg "Executing: $JAVA_CMD -jar $JAR_FILE $command_args"
    
    if [[ -n "$log_file" ]]; then
        powershell.exe -Command "$JAVA_CMD -jar '$JAR_FILE' $command_args" > "$log_file" 2>&1
        local result=$?
        if [[ $result -eq 0 ]]; then
            log_msg "SUCCESS: Java application completed"
        else
            log_msg "ERROR: Java application failed with exit code $result"
            cat "$log_file"
        fi
        return $result
    else
        powershell.exe -Command "$JAVA_CMD -jar '$JAR_FILE' $command_args"
        return $?
    fi
}

# Validate basic requirements
validate_system() {
    local errors=0
    
    log_msg "Validating system requirements..."
    
    # Check JAR file
    if [[ ! -f "$JAR_FILE" ]]; then
        log_msg "ERROR: JAR file not found: $JAR_FILE"
        ((errors++))
    else
        log_msg "✓ JAR file found: $JAR_FILE"
    fi
    
    # Check directories
    for dir in "$CONFIG_DIR" "$OUTPUT_DIR" "$LOG_DIR"; do
        if [[ ! -d "$dir" ]]; then
            log_msg "ERROR: Directory not found: $dir"
            ((errors++))
        else
            log_msg "✓ Directory found: $dir"
        fi
    done
    
    # Test Java
    if powershell.exe -Command "$JAVA_CMD -version" > /dev/null 2>&1; then
        log_msg "✓ Java is accessible"
    else
        log_msg "ERROR: Java not accessible: $JAVA_CMD"
        ((errors++))
    fi
    
    return $errors
}

# Execute letter generation
execute_letter_generation() {
    log_msg "Starting letter generation..."
    
    # Ensure directories exist
    mkdir -p "$OUTPUT_DIR" "$LOG_DIR" "$TEMP_DIR"
    
    # Generate timestamp for log file
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local log_file="$LOG_DIR/letter_gen_${timestamp}.log"
    
    # Execute letter generation
    if execute_java "generate_letters" "$log_file"; then
        log_msg "✓ Letter generation completed successfully"
        
        # Show generated files
        if [[ -d "$OUTPUT_DIR" ]]; then
            local file_count=$(find "$OUTPUT_DIR" -name "*.txt" -type f | wc -l)
            log_msg "Generated $file_count letter files"
            find "$OUTPUT_DIR" -name "*.txt" -type f -newer "$log_file" | head -5 | while read file; do
                log_msg "  - $(basename "$file")"
            done
        fi
        
        return 0
    else
        log_msg "✗ Letter generation failed"
        return 1
    fi
}

# Execute post-file-sent processing
execute_post_processing() {
    log_msg "Starting post-file-sent processing..."
    
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local log_file="$LOG_DIR/post_file_sent_${timestamp}.log"
    
    if execute_java "perform_post_file_sent_step" "$log_file"; then
        log_msg "✓ Post-file-sent processing completed"
        return 0
    else
        log_msg "✗ Post-file-sent processing failed"
        return 1
    fi
}

# Show help
show_help() {
    echo "Usage: $(basename "$0") [OPTIONS]"
    echo ""
    echo "Simple Letter Generator Script"
    echo ""
    echo "Options:"
    echo "  --generate          Generate letters only"
    echo "  --post-process      Execute post-file-sent processing only"
    echo "  --full              Execute full workflow (generate + post-process)"
    echo "  --status            Check system status"
    echo "  --help              Show this help"
    echo ""
    echo "Examples:"
    echo "  $(basename "$0") --generate        # Generate letters"
    echo "  $(basename "$0") --full           # Full workflow"
    echo "  $(basename "$0") --status         # Check status"
}

# Check status
check_status() {
    log_msg "Checking system status..."
    
    if validate_system; then
        log_msg "✓ System validation passed"
    else
        log_msg "✗ System validation failed"
        return 1
    fi
    
    # Check recent files
    if [[ -d "$OUTPUT_DIR" ]]; then
        local recent_files=$(find "$OUTPUT_DIR" -name "*.txt" -mmin -60 | wc -l)
        log_msg "Recent output files (last hour): $recent_files"
    fi
    
    if [[ -d "$LOG_DIR" ]]; then
        local recent_logs=$(find "$LOG_DIR" -name "*.log" -mmin -60 | wc -l)
        log_msg "Recent log files (last hour): $recent_logs"
    fi
    
    return 0
}

# Main execution
main() {
    case "${1:-}" in
        "--generate")
            if validate_system; then
                execute_letter_generation
            else
                log_msg "System validation failed"
                exit 1
            fi
            ;;
        "--post-process")
            if validate_system; then
                execute_post_processing
            else
                log_msg "System validation failed"
                exit 1
            fi
            ;;
        "--full")
            if validate_system; then
                execute_letter_generation && execute_post_processing
            else
                log_msg "System validation failed"
                exit 1
            fi
            ;;
        "--status")
            check_status
            ;;
        "--help"|"-h"|"")
            show_help
            ;;
        *)
            log_msg "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
}

# Execute main function
main "$@"
