#!/bin/bash

# Simple Letter Generator - Working Version
# Hardcoded paths for Windows/bash compatibility

# Configuration
JAVA_CMD="java"
BASE_DIR="/mnt/d/Projects/Github/my-daptorik-apps/professional/current/src/letter-generator-v07"
JAR_FILE="$BASE_DIR/target/letter-generator-1.0-SNAPSHOT.jar"
CONFIG_DIR="$BASE_DIR/config"
OUTPUT_DIR="$BASE_DIR/output"
LOG_DIR="$BASE_DIR/logs"
TEMP_DIR="$BASE_DIR/temp"

# Letter types
LETTER_TYPES=("DemandLetter" "HoldLetter" "IDTheftLetter" "RelationshipTermLetter" "TestLetter")

# Simple logging function
log_msg() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

# Execute Java application using PowerShell
execute_java() {
    local command_args="$1"
    local log_file="$2"
    
    log_msg "Executing: $JAVA_CMD -jar $JAR_FILE $command_args"
    
    # Convert paths to Windows format for PowerShell
    local win_jar_file=$(echo "$JAR_FILE" | sed 's|/mnt/d|D:|' | sed 's|/|\\|g')
    local win_log_file=""
    if [[ -n "$log_file" ]]; then
        win_log_file=$(echo "$log_file" | sed 's|/mnt/d|D:|' | sed 's|/|\\|g')
    fi
    
    if [[ -n "$log_file" ]]; then
        powershell.exe -Command "$JAVA_CMD -jar '$win_jar_file' $command_args" > "$log_file" 2>&1
        local result=$?
        if [[ $result -eq 0 ]]; then
            log_msg "SUCCESS: Java application completed"
        else
            log_msg "ERROR: Java application failed with exit code $result"
            if [[ -f "$log_file" ]]; then
                echo "Log contents:"
                cat "$log_file"
            fi
        fi
        return $result
    else
        powershell.exe -Command "$JAVA_CMD -jar '$win_jar_file' $command_args"
        return $?
    fi
}

# Validate basic requirements
validate_system() {
    local errors=0
    
    log_msg "Validating system requirements..."
    
    # Check JAR file
    if [[ ! -f "$JAR_FILE" ]]; then
        log_msg "ERROR: JAR file not found: $JAR_FILE"
        ((errors++))
    else
        log_msg "✓ JAR file found: $JAR_FILE"
    fi
    
    # Check directories
    for dir in "$CONFIG_DIR" "$OUTPUT_DIR" "$LOG_DIR"; do
        if [[ ! -d "$dir" ]]; then
            log_msg "ERROR: Directory not found: $dir"
            ((errors++))
        else
            log_msg "✓ Directory found: $dir"
        fi
    done
    
    # Test Java
    if powershell.exe -Command "$JAVA_CMD -version" > /dev/null 2>&1; then
        local java_version=$(powershell.exe -Command "$JAVA_CMD -version" 2>&1 | head -1)
        log_msg "✓ Java is accessible: $java_version"
    else
        log_msg "ERROR: Java not accessible: $JAVA_CMD"
        ((errors++))
    fi
    
    return $errors
}

# Execute letter generation
execute_letter_generation() {
    log_msg "Starting letter generation..."
    
    # Ensure directories exist
    mkdir -p "$OUTPUT_DIR" "$LOG_DIR" "$TEMP_DIR"
    
    # Generate timestamp for log file
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local log_file="$LOG_DIR/letter_gen_${timestamp}.log"
    
    # Execute letter generation
    if execute_java "generate_all_letters" "$log_file"; then
        log_msg "✓ Letter generation completed successfully"
        
        # Show generated files
        if [[ -d "$OUTPUT_DIR" ]]; then
            local file_count=$(find "$OUTPUT_DIR" -name "*.txt" -type f 2>/dev/null | wc -l)
            log_msg "Generated $file_count letter files"
            
            # List recent files
            find "$OUTPUT_DIR" -name "*.txt" -type f -mmin -5 2>/dev/null | head -5 | while read file; do
                if [[ -f "$file" ]]; then
                    local size=$(stat -c%s "$file" 2>/dev/null || echo "unknown")
                    log_msg "  - $(basename "$file") (${size} bytes)"
                fi
            done
        fi
        
        return 0
    else
        log_msg "✗ Letter generation failed"
        return 1
    fi
}

# Execute post-file-sent processing
execute_post_processing() {
    log_msg "Starting post-file-sent processing..."
    
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local log_file="$LOG_DIR/post_file_sent_${timestamp}.log"
    
    if execute_java "postFileSentStep_all" "$log_file"; then
        log_msg "✓ Post-file-sent processing completed"
        return 0
    else
        log_msg "✗ Post-file-sent processing failed"
        return 1
    fi
}

# Execute SFTP transfer
execute_sftp_transfer() {
    log_msg "Starting SFTP transfer..."
    
    if [[ "$ENABLE_SFTP_TRANSFER" != "true" ]]; then
        log_msg "SFTP transfer is disabled, skipping"
        return 0
    fi
    
    local timestamp=$(date +%Y%m%d_%H%M%S)
    local log_file="$LOG_DIR/sftp_transfer_${timestamp}.log"
    
    # Create SFTP key directory if it doesn't exist
    if [[ -n "$SFTP_KEY_FILE" ]]; then
        local key_dir=$(dirname "$SFTP_KEY_FILE")
        mkdir -p "$key_dir"
    fi
    
    # Check if source directory exists
    if [[ ! -d "$SFTP_SOURCE_DIR" ]]; then
        log_msg "✗ SFTP source directory not found: $SFTP_SOURCE_DIR"
        return 1
    fi
    
    # Count files to transfer
    local file_count=$(find "$SFTP_SOURCE_DIR" -name "*.txt" -type f 2>/dev/null | wc -l)
    
    if [[ $file_count -eq 0 ]]; then
        log_msg "No files found to transfer in $SFTP_SOURCE_DIR"
        return 0
    fi
    
    log_msg "Transferring $file_count file(s) from $SFTP_SOURCE_DIR to $SFTP_HOST:$SFTP_REMOTE_DIR"
    
    # For now, simulate SFTP transfer (since we don't have actual SFTP server)
    simulate_sftp_transfer "$log_file"
    local transfer_result=$?
    
    if [[ $transfer_result -eq 0 ]]; then
        log_msg "✓ SFTP transfer completed successfully"
        return 0
    else
        log_msg "✗ SFTP transfer failed"
        return 1
    fi
}

# Simulate SFTP transfer (for testing without actual SFTP server)
simulate_sftp_transfer() {
    local log_file="$1"
    
    {
        echo "Simulating SFTP transfer..."
        echo "Source directory: $SFTP_SOURCE_DIR"
        echo "Remote host: $SFTP_HOST:$SFTP_PORT"
        echo "Remote directory: $SFTP_REMOTE_DIR"
        echo "SSH Key: $SFTP_KEY_FILE"
        echo ""
        
        # List files that would be transferred
        echo "Files to transfer:"
        find "$SFTP_SOURCE_DIR" -name "*.txt" -type f | while read file; do
            echo "  - $(basename "$file") ($(stat -c%s "$file" 2>/dev/null || echo "unknown") bytes)"
        done
        
        echo ""
        echo "Transfer simulation completed successfully"
        
    } | tee -a "$log_file"
    
    return 0
}

# Show help
show_help() {
    echo "Usage: $(basename "$0") [OPTIONS]"
    echo ""
    echo "Simple Letter Generator Script"
    echo ""
    echo "Options:"
    echo "  --generate          Generate letters only"
    echo "  --post-process      Execute post-file-sent processing only"
    echo "  --full              Execute full workflow (generate + post-process)"
    echo "  --status            Check system status"
    echo "  --help              Show this help"
    echo ""
    echo "Configuration:"
    echo "  JAR File: $JAR_FILE"
    echo "  Output Dir: $OUTPUT_DIR"
    echo "  Log Dir: $LOG_DIR"
    echo ""
    echo "Examples:"
    echo "  $(basename "$0") --generate        # Generate letters"
    echo "  $(basename "$0") --full           # Full workflow"
    echo "  $(basename "$0") --status         # Check status"
}

# Check status
check_status() {
    log_msg "Checking system status..."
    
    if validate_system; then
        log_msg "✓ System validation passed"
    else
        log_msg "✗ System validation failed"
        return 1
    fi
    
    # Check recent files
    if [[ -d "$OUTPUT_DIR" ]]; then
        local recent_files=$(find "$OUTPUT_DIR" -name "*.txt" -mmin -60 2>/dev/null | wc -l)
        log_msg "Recent output files (last hour): $recent_files"
        
        local total_files=$(find "$OUTPUT_DIR" -name "*.txt" 2>/dev/null | wc -l)
        log_msg "Total output files: $total_files"
    fi
    
    if [[ -d "$LOG_DIR" ]]; then
        local recent_logs=$(find "$LOG_DIR" -name "*.log" -mmin -60 2>/dev/null | wc -l)
        log_msg "Recent log files (last hour): $recent_logs"
    fi
    
    return 0
}

# Main execution
main() {
    case "${1:-}" in
        "--generate")
            if validate_system; then
                execute_letter_generation
            else
                log_msg "System validation failed"
                exit 1
            fi
            ;;
        "--post-process")
            if validate_system; then
                execute_post_processing
            else
                log_msg "System validation failed"
                exit 1
            fi
            ;;
        "--full")
            if validate_system; then
                if execute_letter_generation; then
                    if execute_sftp_transfer; then
                        execute_post_processing
                    else
                        log_msg "SFTP transfer failed, skipping post-processing"
                        exit 1
                    fi
                else
                    log_msg "Letter generation failed, skipping SFTP transfer and post-processing"
                    exit 1
                fi
            else
                log_msg "System validation failed"
                exit 1
            fi
            ;;
        "--status")
            check_status
            ;;
        "--help"|"-h"|"")
            show_help
            ;;
        *)
            log_msg "Unknown option: $1"
            show_help
            exit 1
            ;;
    esac
}

# Execute main function
main "$@"
