#!/bin/bash

# Get script directory
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# Load configuration
source "$SCRIPT_DIR/letter-generator-config.sh"

# Initialize cleanup logging
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
CLEANUP_LOG="$LOG_DIR/cleanup_$TIMESTAMP.log"

{
    echo "=============================================="
    echo "Log Cleanup Process - Started"
    echo "Timestamp: $(date)"
    echo "=============================================="

    # Create logs directory if it doesn't exist
    mkdir -p "$LOG_DIR"

    # Define log file patterns to cleanup
    LOG_PATTERNS=(
        "$LOG_DIR/letter-generator*.log"
        "$LOG_DIR/letter-generation*.log"
        "$LOG_DIR/main_execution*.log"
        "$LOG_DIR/letter_gen*.log"
        "$LOG_DIR/cleanup*.log"
        "$LOG_DIR/sftp_transfer*.log"
    )

    echo "Searching for log files older than 5 days..."
    
    # Counter for deleted files
    DELETED_COUNT=0
    TOTAL_SIZE_DELETED=0

    # Clean up files older than 5 days for each pattern
    for pattern in "${LOG_PATTERNS[@]}"; do
        echo "Checking pattern: $pattern"
        
        # Find and process files older than 5 days
        if ls $pattern 2>/dev/null | head -1 > /dev/null; then
            for file in $pattern; do
                if [ -f "$file" ]; then
                    # Check if file is older than 5 days
                    if [ $(find "$file" -mtime +5 2>/dev/null | wc -l) -gt 0 ]; then
                        # Get file size before deletion
                        FILE_SIZE=$(stat -f%z "$file" 2>/dev/null || stat -c%s "$file" 2>/dev/null || echo "0")
                        
                        echo "Deleting old log file: $file ($(date -r "$file" 2>/dev/null || echo "unknown date"))"
                        
                        # Delete the file
                        if rm -f "$file"; then
                            DELETED_COUNT=$((DELETED_COUNT + 1))
                            TOTAL_SIZE_DELETED=$((TOTAL_SIZE_DELETED + FILE_SIZE))
                            echo "  ✓ Successfully deleted: $file"
                        else
                            echo "  ✗ Failed to delete: $file"
                        fi
                    fi
                fi
            done
        else
            echo "  No files found matching pattern: $pattern"
        fi
    done

    echo "=============================================="
    echo "Cleanup Summary:"
    echo "Files deleted: $DELETED_COUNT"
    echo "Total size freed: $TOTAL_SIZE_DELETED bytes"
    echo "Cleanup completed at: $(date)"
    echo "=============================================="

    # Also clean up temporary files if they exist
    if [ -d "$TEMP_DIR" ]; then
        echo "Cleaning temporary directory: $TEMP_DIR"
        find "$TEMP_DIR" -type f -mtime +1 -delete 2>/dev/null || true
        echo "Temporary files cleanup completed"
    fi

} > "$CLEANUP_LOG" 2>&1

# Display completion message
echo "Log cleanup completed. Details in: $CLEANUP_LOG"

exit 0
