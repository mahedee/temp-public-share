#!/bin/bash

# ==============================================================================
# Letter Generator - Main Workflow Script
# ==============================================================================
# This script orchestrates the complete letter processing workflow:
# 1. Generate letters from database
# 2. Transfer files via SFTP (if enabled)
# 3. Execute post-file-sent processing
# 4. Cleanup and reporting
# ==============================================================================

# Script identification
SCRIPT_NAME="letter-generator-workflow"

# Load configuration and common functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/letter-generator.conf"
source "$SCRIPT_DIR/letter-generator-functions.sh"

# ==============================================================================
# WORKFLOW FUNCTIONS
# ==============================================================================

# Step 1: Generate letter files
execute_letter_generation() {
    log_step "Step 1: Generating letter files"
    
    if [[ "$ENABLE_FILE_GENERATION" != "true" ]]; then
        log_info "Letter generation is disabled, skipping"
        return 0
    fi
    
    # Execute letter generation
    if execute_java_application "" "$LETTER_GEN_LOG_FILE" "Letter generation"; then
        log_info "✓ Letter generation completed successfully"
        
        # Count and report generated files
        local total_files=$(count_output_files)
        log_info "Generated $total_files letter files"
        
        return 0
    else
        log_error "✗ Letter generation failed"
        
        if [[ "$STOP_ON_GENERATION_ERROR" == "true" ]]; then
            log_error "Stopping workflow due to generation failure"
            return 1
        else
            log_warn "Continuing workflow despite generation failure"
            return 0
        fi
    fi
}

# Step 2: Transfer files via SFTP
execute_sftp_transfer() {
    log_step "Step 2: Transferring files via SFTP"
    
    if [[ "$ENABLE_SFTP_TRANSFER" != "true" ]]; then
        log_info "SFTP transfer is disabled, skipping"
        return 0
    fi
    
    # Check if SFTP script exists
    local sftp_script="$SCRIPT_DIR/sftp-transfer.sh"
    if [[ ! -f "$sftp_script" ]]; then
        log_warn "SFTP transfer script not found: $sftp_script"
        return 0
    fi
    
    # Execute SFTP transfer
    log_info "Executing SFTP transfer"
    if bash "$sftp_script" 2>&1 | tee -a "$SFTP_LOG_FILE"; then
        log_info "✓ SFTP transfer completed successfully"
        return 0
    else
        log_error "✗ SFTP transfer failed"
        
        if [[ "$CONTINUE_ON_TRANSFER_ERROR" == "true" ]]; then
            log_warn "Continuing workflow despite transfer failure"
            return 0
        else
            log_error "Stopping workflow due to transfer failure"
            return 1
        fi
    fi
}

# Step 3: Execute post-file-sent processing
execute_post_file_sent_processing() {
    log_step "Step 3: Executing post-file-sent processing"
    
    if [[ "$ENABLE_POST_FILE_SENT" != "true" ]]; then
        log_info "Post-file-sent processing is disabled, skipping"
        return 0
    fi
    
    # Execute post-file-sent step
    if execute_java_application "perform_post_file_sent_step" "$POST_SENT_LOG_FILE" "Post-file-sent processing"; then
        log_info "✓ Post-file-sent processing completed successfully"
        return 0
    else
        log_error "✗ Post-file-sent processing failed"
        
        if [[ "$STOP_ON_POST_PROCESSING_ERROR" == "true" ]]; then
            log_error "Stopping workflow due to post-processing failure"
            return 1
        else
            log_warn "Continuing workflow despite post-processing failure"
            return 0
        fi
    fi
}

# Step 4: Cleanup and maintenance
execute_cleanup() {
    log_step "Step 4: Cleanup and maintenance"
    
    if [[ "$ENABLE_CLEANUP" != "true" ]]; then
        log_info "Cleanup is disabled, skipping"
        return 0
    fi
    
    # Clean old log files
    log_info "Cleaning up old log files"
    cleanup_old_files "$LOG_DIR" "$LOG_RETENTION_DAYS" "*.log"
    
    # Clean temporary files
    if [[ -d "$TEMP_DIR" ]]; then
        log_info "Cleaning temporary files"
        rm -f "$TEMP_DIR"/*
    fi
    
    # Archive old output files (optional)
    if [[ "$ARCHIVE_OUTPUT_FILES" == "true" ]]; then
        log_info "Archiving old output files"
        for output_subdir in "$OUTPUT_DIR"/*; do
            if [[ -d "$output_subdir" ]]; then
                cleanup_old_files "$output_subdir" "1" "*.txt"
            fi
        done
    fi
    
    log_info "✓ Cleanup completed"
    return 0
}

# ==============================================================================
# WORKFLOW ORCHESTRATION
# ==============================================================================

# Execute complete workflow
run_complete_workflow() {
    local start_time=$(date '+%Y-%m-%d %H:%M:%S')
    local step_count=0
    local failed_steps=0
    
    log_info "Starting complete letter processing workflow"
    log_info "Execution ID: $EXECUTION_TIMESTAMP"
    
    # Step 1: Letter Generation
    if execute_letter_generation; then
        step_count=$((step_count + 1))
    else
        failed_steps=$((failed_steps + 1))
        if [[ "$STOP_ON_GENERATION_ERROR" == "true" ]]; then
            generate_summary_report "$start_time" "$(date '+%Y-%m-%d %H:%M:%S')" "FAILED"
            return 1
        fi
    fi
    
    # Step 2: SFTP Transfer
    if execute_sftp_transfer; then
        step_count=$((step_count + 1))
    else
        failed_steps=$((failed_steps + 1))
        if [[ "$CONTINUE_ON_TRANSFER_ERROR" != "true" ]]; then
            generate_summary_report "$start_time" "$(date '+%Y-%m-%d %H:%M:%S')" "FAILED"
            return 1
        fi
    fi
    
    # Step 3: Post-file-sent Processing
    if execute_post_file_sent_processing; then
        step_count=$((step_count + 1))
    else
        failed_steps=$((failed_steps + 1))
        if [[ "$STOP_ON_POST_PROCESSING_ERROR" == "true" ]]; then
            generate_summary_report "$start_time" "$(date '+%Y-%m-%d %H:%M:%S')" "FAILED"
            return 1
        fi
    fi
    
    # Step 4: Cleanup
    if execute_cleanup; then
        step_count=$((step_count + 1))
    else
        failed_steps=$((failed_steps + 1))
    fi
    
    # Final summary
    local status="COMPLETED"
    if [[ $failed_steps -gt 0 ]]; then
        status="COMPLETED WITH WARNINGS ($failed_steps failed steps)"
    fi
    
    log_info "Workflow finished: $step_count steps completed, $failed_steps steps failed"
    generate_summary_report "$start_time" "$(date '+%Y-%m-%d %H:%M:%S')" "$status"
    
    return 0
}

# Execute individual workflow steps
run_individual_step() {
    local step="$1"
    
    case "$step" in
        "generate"|"generation")
            execute_letter_generation
            ;;
        "transfer"|"sftp")
            execute_sftp_transfer
            ;;
        "post-process"|"post-sent")
            execute_post_file_sent_processing
            ;;
        "cleanup")
            execute_cleanup
            ;;
        *)
            log_error "Unknown workflow step: $step"
            return 1
            ;;
    esac
}

# ==============================================================================
# COMMAND LINE INTERFACE
# ==============================================================================

# Show help information
show_help() {
    show_script_help "$(basename "$0")" "Complete letter processing workflow orchestration"
    
    echo "Workflow Options:"
    echo "  --full              Execute complete workflow (default)"
    echo "  --generate-only     Only execute letter generation"
    echo "  --transfer-only     Only execute SFTP transfer"
    echo "  --post-process-only Only execute post-file-sent processing"
    echo "  --cleanup-only      Only execute cleanup"
    echo ""
    echo "Workflow Steps:"
    echo "  1. Letter Generation    - Generate letters from database"
    echo "  2. SFTP Transfer       - Transfer files to remote server"
    echo "  3. Post-file-sent      - Update database after transfer"
    echo "  4. Cleanup             - Clean logs and temporary files"
    echo ""
    echo "Examples:"
    echo "  $(basename "$0")                    # Run complete workflow"
    echo "  $(basename "$0") --generate-only   # Only generate letters"
    echo "  $(basename "$0") --status          # Check system status"
}

# Parse command line arguments
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --full)
                WORKFLOW_MODE="full"
                shift
                ;;
            --generate-only)
                WORKFLOW_MODE="generate"
                shift
                ;;
            --transfer-only)
                WORKFLOW_MODE="transfer"
                shift
                ;;
            --post-process-only)
                WORKFLOW_MODE="post-process"
                shift
                ;;
            --cleanup-only)
                WORKFLOW_MODE="cleanup"
                shift
                ;;
            --status)
                WORKFLOW_MODE="status"
                shift
                ;;
            --verbose)
                VERBOSE_MODE="true"
                shift
                ;;
            --quiet)
                QUIET_MODE="true"
                shift
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Default to full workflow if no mode specified
    if [[ -z "$WORKFLOW_MODE" ]]; then
        WORKFLOW_MODE="full"
    fi
}

# ==============================================================================
# MAIN EXECUTION
# ==============================================================================

main() {
    # Parse command line arguments
    parse_arguments "$@"
    
    # Validate system before execution
    if [[ "$WORKFLOW_MODE" != "status" ]]; then
        if ! validate_system; then
            log_error "System validation failed, aborting"
            exit 1
        fi
    fi
    
    # Execute based on mode
    case "$WORKFLOW_MODE" in
        "full")
            run_complete_workflow
            ;;
        "status")
            check_application_status
            ;;
        *)
            run_individual_step "$WORKFLOW_MODE"
            ;;
    esac
    
    local exit_code=$?
    
    if [[ $exit_code -eq 0 ]]; then
        log_info "Script execution completed successfully"
    else
        log_error "Script execution failed with exit code: $exit_code"
    fi
    
    exit $exit_code
}

# Execute main function with all arguments
main "$@"
