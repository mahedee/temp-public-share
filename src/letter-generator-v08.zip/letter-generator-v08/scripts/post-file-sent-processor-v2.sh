#!/bin/bash

# ==============================================================================
# Letter Generator - Post File Sent Processor
# ==============================================================================
# This script executes post-file-sent processing to update database records
# after successful SFTP transfer
# ==============================================================================

# Script identification
SCRIPT_NAME="post-file-sent-processor"

# Load configuration and common functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/letter-generator.conf"
source "$SCRIPT_DIR/letter-generator-functions.sh"

# ==============================================================================
# POST-FILE-SENT FUNCTIONS
# ==============================================================================

# Execute post-file-sent processing for specific letter type
execute_post_sent_for_letter() {
    local letter_type="$1"
    
    log_info "Executing post-file-sent processing for: $letter_type"
    
    if execute_java_application "perform_post_file_sent_step '$letter_type'" "$POST_SENT_LOG_FILE" "Post-file-sent for $letter_type"; then
        log_info "✓ Post-file-sent processing completed for: $letter_type"
        return 0
    else
        log_error "✗ Post-file-sent processing failed for: $letter_type"
        return 1
    fi
}

# Execute post-file-sent processing for all letter types
execute_post_sent_for_all() {
    log_info "Executing post-file-sent processing for all letters"
    
    if execute_java_application "perform_post_file_sent_step" "$POST_SENT_LOG_FILE" "Post-file-sent for all letters"; then
        log_info "✓ Post-file-sent processing completed for all letters"
        return 0
    else
        log_error "✗ Post-file-sent processing failed for all letters"
        return 1
    fi
}

# Validate common steps configuration
validate_common_steps() {
    if [[ ! -f "$COMMON_STEPS_FILE" ]]; then
        log_error "Common steps file not found: $COMMON_STEPS_FILE"
        return 1
    fi
    
    # Check if postFileSentStep is enabled
    if grep -q "<enable>true</enable>" "$COMMON_STEPS_FILE" && grep -q "postFileSentStep" "$COMMON_STEPS_FILE"; then
        log_info "✓ Post-file-sent step is enabled in configuration"
        return 0
    else
        log_warn "Post-file-sent step is not enabled in configuration"
        return 1
    fi
}

# ==============================================================================
# MAIN PROCESSING LOGIC
# ==============================================================================

# Execute post-file-sent processing
execute_post_file_sent_processing() {
    local mode="$1"
    local letter_type="$2"
    
    log_step "Starting post-file-sent processing"
    
    # Validate configuration
    if ! validate_common_steps; then
        log_warn "Configuration validation failed, but continuing"
    fi
    
    # Execute based on mode
    case "$mode" in
        "all")
            execute_post_sent_for_all
            ;;
        "single")
            if [[ -z "$letter_type" ]]; then
                log_error "Letter type is required for single mode"
                return 1
            fi
            execute_post_sent_for_letter "$letter_type"
            ;;
        *)
            log_error "Unknown processing mode: $mode"
            return 1
            ;;
    esac
    
    local result=$?
    
    if [[ $result -eq 0 ]]; then
        log_info "✓ Post-file-sent processing completed successfully"
    else
        log_error "✗ Post-file-sent processing failed"
    fi
    
    return $result
}

# ==============================================================================
# STATUS AND REPORTING
# ==============================================================================

# Check post-file-sent processor status
check_processor_status() {
    log_step "Checking post-file-sent processor status"
    
    # Check JAR file
    if [[ -f "$JAR_FILE" ]]; then
        log_info "✓ JAR file found: $JAR_FILE"
    else
        log_error "✗ JAR file not found: $JAR_FILE"
        return 1
    fi
    
    # Check common steps configuration
    if validate_common_steps; then
        log_info "✓ Common steps configuration is valid"
    else
        log_warn "✗ Common steps configuration issue"
    fi
    
    # Check recent executions
    local recent_logs=$(find "$LOG_DIR" -name "${POST_SENT_LOG_PREFIX}_*.log" -mmin -60 | wc -l)
    log_info "Recent post-file-sent executions (last hour): $recent_logs"
    
    log_info "✓ Status check completed"
    return 0
}

# ==============================================================================
# COMMAND LINE INTERFACE
# ==============================================================================

# Show help
show_help() {
    show_script_help "$(basename "$0")" "Post-file-sent processing for letter database updates"
    
    echo "Processing Options:"
    echo "  --all               Process all letters (default)"
    echo "  --letter TYPE       Process specific letter type"
    echo ""
    echo "Letter Types:"
    for letter_type in "${LETTER_TYPES[@]}"; do
        echo "    $letter_type"
    done
    echo ""
    echo "Examples:"
    echo "  $(basename "$0")                        # Process all letters"
    echo "  $(basename "$0") --letter DemandLetter  # Process only demand letters"
    echo "  $(basename "$0") --status               # Check processor status"
}

# Parse command line arguments
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --all)
                PROCESSING_MODE="all"
                shift
                ;;
            --letter)
                PROCESSING_MODE="single"
                LETTER_TYPE="$2"
                shift 2
                ;;
            --status)
                PROCESSING_MODE="status"
                shift
                ;;
            --verbose)
                VERBOSE_MODE="true"
                shift
                ;;
            --quiet)
                QUIET_MODE="true"
                shift
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Default to processing all letters
    if [[ -z "$PROCESSING_MODE" ]]; then
        PROCESSING_MODE="all"
    fi
}

# ==============================================================================
# MAIN EXECUTION
# ==============================================================================

main() {
    # Parse arguments
    parse_arguments "$@"
    
    # Validate system
    if [[ "$PROCESSING_MODE" != "status" ]]; then
        if ! validate_system; then
            log_error "System validation failed"
            exit 1
        fi
    fi
    
    # Execute based on mode
    case "$PROCESSING_MODE" in
        "all")
            execute_post_file_sent_processing "all"
            ;;
        "single")
            execute_post_file_sent_processing "single" "$LETTER_TYPE"
            ;;
        "status")
            check_processor_status
            ;;
        *)
            log_error "Unknown processing mode: $PROCESSING_MODE"
            exit 1
            ;;
    esac
    
    exit $?
}

# Execute main function
main "$@"
