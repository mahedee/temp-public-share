#!/bin/bash

# ==============================================================================
# Letter Generator - Common Functions Library
# ==============================================================================
# This file contains reusable functions for the letter generation system.
# ==============================================================================

# Source configuration if not already loaded
if [[ -z "$APP_HOME" ]]; then
    SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
    source "$SCRIPT_DIR/letter-generator.conf"
fi

# ==============================================================================
# LOGGING FUNCTIONS
# ==============================================================================

# Enhanced logging function with colors and levels
log_message() {
    local level="$1"
    local message="$2"
    local log_file="${3:-$MAIN_LOG_FILE}"
    local timestamp=$(date '+%Y-%m-%d %H:%M:%S')
    local colored_message=""
    
    case "$level" in
        "INFO")
            colored_message="${COLOR_INFO}[INFO] $timestamp $message${COLOR_RESET}"
            ;;
        "WARN")
            colored_message="${COLOR_WARN}[WARN] $timestamp $message${COLOR_RESET}"
            ;;
        "ERROR")
            colored_message="${COLOR_ERROR}[ERROR] $timestamp $message${COLOR_RESET}"
            ;;
        "DEBUG")
            colored_message="${COLOR_DEBUG}[DEBUG] $timestamp $message${COLOR_RESET}"
            ;;
        "STEP")
            colored_message="${COLOR_STEP}[STEP] $timestamp $message${COLOR_RESET}"
            ;;
        *)
            colored_message="[$level] $timestamp $message"
            ;;
    esac
    
    # Output to console (unless quiet mode)
    if [[ "$QUIET_MODE" != "true" ]]; then
        echo -e "$colored_message"
    fi
    
    # Output to log file
    echo "[$level] $timestamp $message" >> "$log_file"
}

# Convenience functions for different log levels
log_info() {
    log_message "INFO" "$1" "$2"
}

log_warn() {
    log_message "WARN" "$1" "$2"
}

log_error() {
    log_message "ERROR" "$1" "$2"
}

log_debug() {
    if [[ "$VERBOSE_MODE" == "true" ]]; then
        log_message "DEBUG" "$1" "$2"
    fi
}

log_step() {
    log_message "STEP" "$1" "$2"
}

# ==============================================================================
# SYSTEM VALIDATION FUNCTIONS
# ==============================================================================

# Validate system prerequisites
validate_system() {
    log_info "Validating system prerequisites"
    
    local errors=0
    
    # Validate configuration
    if ! validate_configuration; then
        errors=$((errors + 1))
    fi
    
    # Test Java execution
    if ! test_java_execution; then
        log_error "Java execution test failed"
        errors=$((errors + 1))
    fi
    
    # Check disk space (basic check)
    if ! check_disk_space; then
        log_warn "Disk space check failed"
    fi
    
    if [[ $errors -eq 0 ]]; then
        log_info "✓ System validation passed"
        return 0
    else
        log_error "✗ System validation failed with $errors errors"
        return 1
    fi
}

# Test Java command execution
test_java_execution() {
    log_debug "Testing Java execution"
    
    if [[ "$JAVA_CMD" == *"powershell.exe"* ]]; then
        # Test PowerShell Java execution
        $JAVA_CMD -version >/dev/null 2>&1
    else
        # Test direct Java execution
        $JAVA_CMD -version >/dev/null 2>&1
    fi
    
    return $?
}

# Check available disk space
check_disk_space() {
    local available_space
    if command -v df >/dev/null 2>&1; then
        available_space=$(df "$APP_HOME" | awk 'NR==2 {print $4}')
        if [[ $available_space -lt 100000 ]]; then  # Less than ~100MB
            log_warn "Low disk space available: ${available_space}KB"
            return 1
        fi
    fi
    return 0
}

# ==============================================================================
# FILE MANAGEMENT FUNCTIONS
# ==============================================================================

# Create timestamped backup of a file
backup_file() {
    local file_path="$1"
    local backup_dir="${2:-$ARCHIVE_DIR}"
    
    if [[ -f "$file_path" ]]; then
        local filename=$(basename "$file_path")
        local backup_name="${filename}.backup.$(date +%Y%m%d_%H%M%S)"
        local backup_path="$backup_dir/$backup_name"
        
        mkdir -p "$backup_dir"
        cp "$file_path" "$backup_path"
        log_debug "Created backup: $backup_path"
        echo "$backup_path"
    fi
}

# Clean old files based on age
cleanup_old_files() {
    local directory="$1"
    local days="${2:-$LOG_RETENTION_DAYS}"
    local pattern="${3:-*}"
    
    if [[ -d "$directory" ]]; then
        local count=$(find "$directory" -name "$pattern" -type f -mtime +$days | wc -l)
        if [[ $count -gt 0 ]]; then
            log_info "Cleaning up $count old files from $directory"
            find "$directory" -name "$pattern" -type f -mtime +$days -delete
        fi
    fi
}

# Count files in output directories
count_output_files() {
    local total=0
    for dir in "${REQUIRED_DIRS[@]}"; do
        if [[ -d "$dir" && "$dir" == *"/output/"* ]]; then
            local count=$(find "$dir" -name "*.txt" -type f | wc -l)
            if [[ $count -gt 0 ]]; then
                local letter_type=$(basename "$dir")
                log_info "$letter_type: $count files"
                total=$((total + count))
            fi
        fi
    done
    echo "$total"
}

# ==============================================================================
# PROCESS EXECUTION FUNCTIONS
# ==============================================================================

# Execute Java application with proper logging
execute_java_application() {
    local args="$1"
    local log_file="${2:-$LETTER_GEN_LOG_FILE}"
    local description="${3:-Java application}"
    
    log_info "Executing $description"
    log_debug "Command: $JAVA_CMD -jar '$JAR_FILE' $args"
    
    # Execute with proper logging
    if [[ "$JAVA_CMD" == *"powershell.exe"* ]]; then
        $JAVA_CMD -jar "'$JAR_FILE'" $args 2>&1 | tee -a "$log_file"
    else
        $JAVA_CMD -jar "$JAR_FILE" $args 2>&1 | tee -a "$log_file"
    fi
    
    local exit_code=${PIPESTATUS[0]}
    
    if [[ $exit_code -eq 0 ]]; then
        log_info "✓ $description completed successfully"
        return 0
    else
        log_error "✗ $description failed (exit code: $exit_code)"
        return $exit_code
    fi
}

# Execute with retry logic
execute_with_retry() {
    local command="$1"
    local max_retries="${2:-$SFTP_MAX_RETRIES}"
    local delay="${3:-$SFTP_RETRY_DELAY}"
    local description="${4:-Command}"
    
    local attempt=1
    
    while [[ $attempt -le $max_retries ]]; do
        log_info "Attempt $attempt/$max_retries: $description"
        
        if eval "$command"; then
            log_info "✓ $description succeeded on attempt $attempt"
            return 0
        else
            if [[ $attempt -lt $max_retries ]]; then
                log_warn "✗ Attempt $attempt failed, retrying in ${delay}s..."
                sleep "$delay"
            else
                log_error "✗ $description failed after $max_retries attempts"
                return 1
            fi
        fi
        
        attempt=$((attempt + 1))
    done
}

# ==============================================================================
# STATUS AND REPORTING FUNCTIONS
# ==============================================================================

# Generate execution summary
generate_summary_report() {
    local start_time="$1"
    local end_time="${2:-$(date '+%Y-%m-%d %H:%M:%S')}"
    local status="${3:-COMPLETED}"
    
    echo ""
    echo "======================================================================"
    echo "                    LETTER PROCESSING SUMMARY"
    echo "======================================================================"
    echo "  Status: $status"
    echo "  Start Time: $start_time"
    echo "  End Time: $end_time"
    echo ""
    
    # Count generated files
    local total_files=$(count_output_files)
    echo "  Total files generated: $total_files"
    echo ""
    
    # Log file locations
    echo "  Log Files:"
    echo "    Main Log: $MAIN_LOG_FILE"
    echo "    Letter Generation: $LETTER_GEN_LOG_FILE"
    echo "    Post File Sent: $POST_SENT_LOG_FILE"
    echo ""
    
    # Configuration summary
    echo "  Configuration:"
    echo "    SFTP Enabled: $SFTP_ENABLED"
    echo "    JAR File: $JAR_FILE"
    echo "    Output Directory: $OUTPUT_DIR"
    echo ""
    echo "======================================================================"
}

# Check application status
check_application_status() {
    log_step "Checking application status"
    
    # Check if application is running
    local java_processes=$(pgrep -f "letter-generator" | wc -l)
    if [[ $java_processes -gt 0 ]]; then
        log_warn "Found $java_processes running letter-generator processes"
    fi
    
    # Check recent files
    local recent_files=$(find "$OUTPUT_DIR" -name "*.txt" -type f -mmin -60 | wc -l)
    log_info "Recent output files (last hour): $recent_files"
    
    # Check log file sizes
    if [[ -f "$MAIN_LOG_FILE" ]]; then
        local log_size=$(stat -f%z "$MAIN_LOG_FILE" 2>/dev/null || stat -c%s "$MAIN_LOG_FILE" 2>/dev/null || echo "0")
        log_debug "Main log file size: ${log_size} bytes"
    fi
}

# Display help information
show_script_help() {
    local script_name="$1"
    local description="$2"
    
    echo "Usage: $script_name [OPTIONS]"
    echo ""
    echo "$description"
    echo ""
    echo "Common Options:"
    echo "  --help              Show this help message"
    echo "  --status            Check system status"
    echo "  --verbose           Enable verbose output"
    echo "  --quiet             Suppress non-essential output"
    echo "  --dry-run           Show what would be done without executing"
    echo ""
    echo "Configuration:"
    echo "  Config File: $(basename "$0" .sh).conf"
    echo "  Log Directory: $LOG_DIR"
    echo "  Output Directory: $OUTPUT_DIR"
    echo ""
}

# ==============================================================================
# INITIALIZATION
# ==============================================================================

# Initialize common functions (called when sourced)
initialize_common_functions() {
    # Ensure required directories exist
    validate_configuration >/dev/null 2>&1
    
    # Set script name for logging
    if [[ -z "$SCRIPT_NAME" ]]; then
        SCRIPT_NAME=$(basename "${BASH_SOURCE[1]}" .sh)
    fi
    
    log_debug "Common functions library initialized for $SCRIPT_NAME"
}

# Auto-initialize when sourced
if [[ "${BASH_SOURCE[0]}" != "${0}" ]]; then
    initialize_common_functions
fi
