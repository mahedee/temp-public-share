#!/bin/bash

# ==============================================================================
# Letter Generator - SFTP Transfer Script
# ==============================================================================
# This script handles SFTP transfer of generated letter files
# ==============================================================================

# Script identification
SCRIPT_NAME="sftp-transfer"

# Load configuration and common functions
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
source "$SCRIPT_DIR/letter-generator.conf"
source "$SCRIPT_DIR/letter-generator-functions.sh"

# ==============================================================================
# SFTP FUNCTIONS
# ==============================================================================

# Transfer files for a specific letter type
transfer_letter_type() {
    local letter_type="$1"
    local local_dir=""
    
    # Map letter type to directory
    case "$letter_type" in
        "DemandLetter")
            local_dir="$DEMAND_OUTPUT_DIR"
            ;;
        "HoldLetter")
            local_dir="$HOLD_OUTPUT_DIR"
            ;;
        "IDTheftLetter")
            local_dir="$IDTHEFT_OUTPUT_DIR"
            ;;
        "RelationshipTermLetter")
            local_dir="$RELATIONSHIP_OUTPUT_DIR"
            ;;
        "WelcomeLetter")
            local_dir="$WELCOME_OUTPUT_DIR"
            ;;
        "TestLetter")
            local_dir="$TEST_OUTPUT_DIR"
            ;;
        *)
            log_error "Unknown letter type: $letter_type"
            return 1
            ;;
    esac
    
    if [[ ! -d "$local_dir" ]]; then
        log_warn "Directory $local_dir does not exist, skipping $letter_type"
        return 1
    fi
    
    # Count files to transfer
    local file_count=$(find "$local_dir" -name "*.txt" -type f | wc -l)
    
    if [[ $file_count -eq 0 ]]; then
        log_warn "No files found in $local_dir for $letter_type"
        return 1
    fi
    
    log_info "Transferring $file_count file(s) for $letter_type from $local_dir"
    
    # Prepare SFTP batch commands
    local sftp_commands="cd $SFTP_REMOTE_DIR
lcd $local_dir
mput *.txt
quit"
    
    # Execute SFTP transfer with authentication
    if [[ -n "$SFTP_KEY" && -f "$SFTP_KEY" ]]; then
        # Use SSH key authentication
        log_debug "Using SSH key authentication: $SFTP_KEY"
        echo "$sftp_commands" | sftp -o BatchMode=yes -o StrictHostKeyChecking=no -i "$SFTP_KEY" -P "$SFTP_PORT" "$SFTP_USER@$SFTP_HOST"
    elif [[ -n "$SFTP_PASSWORD" ]]; then
        # Use password authentication (less secure)
        log_debug "Using password authentication"
        echo "$sftp_commands" | sshpass -p "$SFTP_PASSWORD" sftp -o BatchMode=no -o StrictHostKeyChecking=no -P "$SFTP_PORT" "$SFTP_USER@$SFTP_HOST"
    else
        log_error "No SFTP authentication method configured"
        return 1
    fi
    
    local transfer_result=$?
    
    if [[ $transfer_result -eq 0 ]]; then
        log_info "✓ Successfully transferred files for $letter_type"
        
        # Archive transferred files (optional)
        if [[ "$ARCHIVE_TRANSFERRED_FILES" == "true" ]]; then
            archive_transferred_files "$local_dir" "$letter_type"
        fi
        
        return 0
    else
        log_error "✗ Failed to transfer files for $letter_type"
        return 1
    fi
}

# Archive successfully transferred files
archive_transferred_files() {
    local source_dir="$1"
    local letter_type="$2"
    local archive_subdir="$ARCHIVE_DIR/$letter_type"
    
    mkdir -p "$archive_subdir"
    
    # Move files to archive
    find "$source_dir" -name "*.txt" -type f -exec mv {} "$archive_subdir/" \;
    
    log_info "Archived transferred files to $archive_subdir"
}

# Test SFTP connection
test_sftp_connection() {
    log_info "Testing SFTP connection to $SFTP_HOST:$SFTP_PORT"
    
    local test_command="ls $SFTP_REMOTE_DIR
quit"
    
    if [[ -n "$SFTP_KEY" && -f "$SFTP_KEY" ]]; then
        echo "$test_command" | sftp -o BatchMode=yes -o StrictHostKeyChecking=no -i "$SFTP_KEY" -P "$SFTP_PORT" "$SFTP_USER@$SFTP_HOST" >/dev/null 2>&1
    elif [[ -n "$SFTP_PASSWORD" ]]; then
        echo "$test_command" | sshpass -p "$SFTP_PASSWORD" sftp -o BatchMode=no -o StrictHostKeyChecking=no -P "$SFTP_PORT" "$SFTP_USER@$SFTP_HOST" >/dev/null 2>&1
    else
        log_error "No SFTP authentication configured"
        return 1
    fi
    
    local result=$?
    
    if [[ $result -eq 0 ]]; then
        log_info "✓ SFTP connection test successful"
    else
        log_error "✗ SFTP connection test failed"
    fi
    
    return $result
}

# ==============================================================================
# MAIN TRANSFER LOGIC
# ==============================================================================

# Execute SFTP transfer for all enabled letter types
execute_sftp_transfer() {
    log_step "Starting SFTP transfer process"
    
    # Check if SFTP is enabled
    if [[ "$SFTP_ENABLED" != "true" ]]; then
        log_info "SFTP transfer is disabled in configuration"
        return 0
    fi
    
    # Test connection first
    if ! test_sftp_connection; then
        log_error "SFTP connection test failed, aborting transfer"
        return 1
    fi
    
    local successful_transfers=0
    local failed_transfers=0
    
    # Transfer each enabled letter type
    for letter_type in "${ENABLED_LETTER_TYPES[@]}"; do
        log_info "Processing transfer for $letter_type"
        
        if execute_with_retry "transfer_letter_type '$letter_type'" "$SFTP_MAX_RETRIES" "$SFTP_RETRY_DELAY" "SFTP transfer for $letter_type"; then
            successful_transfers=$((successful_transfers + 1))
        else
            failed_transfers=$((failed_transfers + 1))
        fi
        
        echo "" # Empty line for readability
    done
    
    # Summary
    log_info "SFTP transfer completed: $successful_transfers successful, $failed_transfers failed"
    
    if [[ $failed_transfers -eq 0 ]]; then
        log_info "✓ All SFTP transfers completed successfully"
        return 0
    else
        log_warn "✗ Some SFTP transfers failed"
        return 1
    fi
}

# ==============================================================================
# COMMAND LINE INTERFACE
# ==============================================================================

# Show help
show_help() {
    show_script_help "$(basename "$0")" "SFTP transfer of letter files"
    
    echo "Transfer Options:"
    echo "  --all               Transfer all enabled letter types (default)"
    echo "  --letter TYPE       Transfer specific letter type"
    echo "  --test-connection   Test SFTP connection only"
    echo ""
    echo "Letter Types:"
    for letter_type in "${LETTER_TYPES[@]}"; do
        echo "    $letter_type"
    done
    echo ""
    echo "Examples:"
    echo "  $(basename "$0")                        # Transfer all enabled types"
    echo "  $(basename "$0") --letter DemandLetter  # Transfer only demand letters"
    echo "  $(basename "$0") --test-connection      # Test SFTP connection"
}

# Parse command line arguments
parse_arguments() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --all)
                TRANSFER_MODE="all"
                shift
                ;;
            --letter)
                TRANSFER_MODE="single"
                LETTER_TYPE="$2"
                shift 2
                ;;
            --test-connection)
                TRANSFER_MODE="test"
                shift
                ;;
            --status)
                TRANSFER_MODE="status"
                shift
                ;;
            --verbose)
                VERBOSE_MODE="true"
                shift
                ;;
            --quiet)
                QUIET_MODE="true"
                shift
                ;;
            --help|-h)
                show_help
                exit 0
                ;;
            *)
                log_error "Unknown option: $1"
                show_help
                exit 1
                ;;
        esac
    done
    
    # Default to all transfers
    if [[ -z "$TRANSFER_MODE" ]]; then
        TRANSFER_MODE="all"
    fi
}

# ==============================================================================
# MAIN EXECUTION
# ==============================================================================

main() {
    # Parse arguments
    parse_arguments "$@"
    
    # Validate system
    if ! validate_system; then
        log_error "System validation failed"
        exit 1
    fi
    
    # Execute based on mode
    case "$TRANSFER_MODE" in
        "all")
            execute_sftp_transfer
            ;;
        "single")
            if [[ -z "$LETTER_TYPE" ]]; then
                log_error "Letter type is required with --letter option"
                exit 1
            fi
            transfer_letter_type "$LETTER_TYPE"
            ;;
        "test")
            test_sftp_connection
            ;;
        "status")
            check_application_status
            ;;
        *)
            log_error "Unknown transfer mode: $TRANSFER_MODE"
            exit 1
            ;;
    esac
    
    exit $?
}

# Execute main function
main "$@"
