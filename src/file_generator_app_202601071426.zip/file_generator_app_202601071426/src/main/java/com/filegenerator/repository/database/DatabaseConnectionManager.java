package com.filegenerator.repository.database;

import com.zaxxer.hikari.HikariDataSource;
import java.sql.Connection;

/**
 * Interface for database connection management.
 */
public interface DatabaseConnectionManager {
    
    /**
     * Initializes the connection pool.
     */
    void initialize();
    
    /**
     * Gets a connection from the pool.
     */
    Connection getConnection() throws Exception;
    
    /**
     * Releases a connection back to the pool.
     */
    void releaseConnection(Connection connection) throws Exception;
    
    /**
     * Gets the data source.
     */
    HikariDataSource getDataSource();
    
    /**
     * Closes the connection pool.
     */
    void close();
}
