package com.filegenerator.service.filegeneration;

import java.io.File;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.filegenerator.infrastructure.util.FileNameUtil;
import com.filegenerator.infrastructure.util.FileSystemUtil;
import com.filegenerator.infrastructure.writer.FileWriterFactory;
import com.filegenerator.infrastructure.writer.IFileWriter;
import com.filegenerator.model.configuration.FileConfiguration;
import com.filegenerator.model.dto.FileGenerationResult;
import com.filegenerator.service.query.QueryExecutionService;

/**
 * File generation service implementation with integrated business logic.
 */
public class FileGenerationServiceImpl implements FileGenerationService {
    
    private static final Logger logger = LoggerFactory.getLogger(FileGenerationServiceImpl.class);
    
    private final QueryExecutionService queryExecutionService;
    private final FileWriterFactory fileWriterFactory;

    public FileGenerationServiceImpl(
            QueryExecutionService queryExecutionService,
            FileWriterFactory fileWriterFactory) {
        this.queryExecutionService = queryExecutionService;
        this.fileWriterFactory = fileWriterFactory;
    }

    @Override
    public FileGenerationResult generateFile(FileConfiguration fileConfig) {
        return generateFile(fileConfig, null);
    }

    @Override
    public FileGenerationResult generateFile(FileConfiguration fileConfig, ResultSet headerResultSet) {
        String fileName = generateFileName(fileConfig);
        FileGenerationResult result = new FileGenerationResult(fileName, false);
        long startTime = System.currentTimeMillis();
        
        IFileWriter fileWriter = null;
        
        try {
            logger.info("Starting file generation: {}", fileName);
            
            // Create output directory if needed
            FileSystemUtil.createDirectoryIfNotExists(fileConfig.getExportPath());
            
            // Generate full file path
            String fullPath = fileConfig.getExportPath() + File.separator + fileName;
            
            // Execute query for main data
            logger.info(">>> EXECUTING FILE GENERATION QUERY for: {} at {}", fileConfig.getFileName(), java.time.LocalDateTime.now());
            ResultSet mainResultSet = queryExecutionService.executeQuery(fileConfig);
            logger.info(">>> FILE GENERATION QUERY COMPLETED for: {} at {}", fileConfig.getFileName(), java.time.LocalDateTime.now());
            ResultSetMetaData metaData = mainResultSet.getMetaData();
            int columnCount = metaData.getColumnCount();
            
            // Create file writer
            fileWriter = fileWriterFactory.createFileWriter(
                    fullPath,
                    fileConfig.getFileFormat(),
                    fileConfig.getActualDelimiter()
            );
            
            fileWriter.open();
            
            long recordCount = 0;
            
            // Write header data first if provided
            if (headerResultSet != null) {
                recordCount += writeHeaderData(fileWriter, headerResultSet);
            }
            
            // Write column headers if configured
            if (fileConfig.isIncludeHeader()) {
                List<String> headers = extractColumnNames(mainResultSet);
                fileWriter.writeHeader(headers);
            }
            
            // Write main data rows
            while (mainResultSet.next()) {
                List<Object> rowData = extractRowData(mainResultSet, columnCount);
                fileWriter.writeRow(rowData);
                recordCount++;
                
                // Log progress every 1000 rows
                if (recordCount % 1000 == 0) {
                    logger.debug("Processed {} records", recordCount);
                }
            }
            
            fileWriter.flush();
            
            // Set success result
            result.setSuccess(true);
            result.setRecordCount(recordCount);
            result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
            
            logger.info("File generation completed: {} ({} records in {} ms)", 
                    fileName, recordCount, result.getExecutionTimeMs());
            
        } catch (Exception e) {
            logger.error("Error generating file: {}", fileName, e);
            result.setSuccess(false);
            result.setErrorMessage(e.getMessage());
            result.setExecutionTimeMs(System.currentTimeMillis() - startTime);
        } finally {
            // Close resources
            if (fileWriter != null) {
                try {
                    fileWriter.close();
                } catch (Exception e) {
                    logger.error("Error closing file writer", e);
                }
            }
            queryExecutionService.closeResources();
        }
        
        return result;
    }
    
    /**
     * Purpose: Writes header data to the file
     * @param fileWriter The file writer
     * @param headerResultSet The header result set
     * @return Number of header records written
     * @throws Exception If writing fails
     */
    private long writeHeaderData(IFileWriter fileWriter, ResultSet headerResultSet) throws Exception {
        long headerRecordCount = 0;
        
        try {
            ResultSetMetaData headerMetaData = headerResultSet.getMetaData();
            int headerColumnCount = headerMetaData.getColumnCount();
            
            // Write header data rows
            while (headerResultSet.next()) {
                List<Object> headerRowData = extractRowData(headerResultSet, headerColumnCount);
                fileWriter.writeRow(headerRowData);
                headerRecordCount++;
            }
            
            logger.info("Written {} header records", headerRecordCount);
            
        } catch (Exception e) {
            logger.error("Error writing header data", e);
            throw e;
        }
        
        return headerRecordCount;
    }

    /**
     * Generates file name based on configuration and replaces placeholders with actual date/time values.
     * Integrated from business layer logic.
     * 
     * @param fileConfig File configuration
     * @return Generated file name
     */
    private String generateFileName(FileConfiguration fileConfig) {
        // Use the fileName from configuration directly
        String fileName = fileConfig.getFileName();
        
        if (fileName == null || fileName.trim().isEmpty()) {
            fileName = "output.txt";
        }
        
        // Replace date/time placeholders with enhanced support
        fileName = FileNameUtil.replacePlaceholders(fileName);
        
        logger.debug("Generated file name: {}", fileName);
        return fileName;
    }
    
    // /**
    //  * Replaces placeholders in filename with actual date/time values.
    //  * 
    //  * @param fileName The filename template with placeholders
    //  * @return Filename with replaced values
    //  */
    // private String replacePlaceholders(String fileName) {
    //     LocalDateTime currentTime = LocalDateTime.now();
        
    //     // Create placeholder replacements map (ordered to handle longer patterns first)
    //     Map<String, String> replacements = new LinkedHashMap<>();
        
    //     // New explicit date/time format placeholders
    //     replacements.put("{YYYYMMDDHHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss")));
    //     replacements.put("{YYYYMMDD_HHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss")));
    //     replacements.put("{YYYY-MM-DD_HH:MM:SS}", currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd_HH:mm:ss")));
    //     replacements.put("{YYYYMMDD-HHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd-HHmmss")));
    //     replacements.put("{YYYYMMDD}", currentTime.format(DateTimeFormatter.ofPattern("yyyyMMdd")));
    //     replacements.put("{YYYY-MM-DD}", currentTime.format(DateTimeFormatter.ofPattern("yyyy-MM-dd")));
    //     replacements.put("{YYYY_MM_DD}", currentTime.format(DateTimeFormatter.ofPattern("yyyy_MM_dd")));
    //     replacements.put("{DDMMYYYY}", currentTime.format(DateTimeFormatter.ofPattern("ddMMyyyy")));
    //     replacements.put("{DD-MM-YYYY}", currentTime.format(DateTimeFormatter.ofPattern("dd-MM-yyyy")));
    //     replacements.put("{MM/DD/YYYY}", currentTime.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
        
    //     // Time-only placeholders
    //     replacements.put("{HHMMSS}", currentTime.format(DateTimeFormatter.ofPattern("HHmmss")));
    //     replacements.put("{HH:MM:SS}", currentTime.format(DateTimeFormatter.ofPattern("HH:mm:ss")));
    //     replacements.put("{HHMM}", currentTime.format(DateTimeFormatter.ofPattern("HHmm")));
        
    //     // Individual component placeholders
    //     replacements.put("{YYYY}", currentTime.format(DateTimeFormatter.ofPattern("yyyy")));
    //     replacements.put("{MM}", currentTime.format(DateTimeFormatter.ofPattern("MM")));
    //     replacements.put("{DD}", currentTime.format(DateTimeFormatter.ofPattern("dd")));
    //     replacements.put("{HH}", currentTime.format(DateTimeFormatter.ofPattern("HH")));
    //     replacements.put("{mm}", currentTime.format(DateTimeFormatter.ofPattern("mm")));
    //     replacements.put("{SS}", currentTime.format(DateTimeFormatter.ofPattern("ss")));
        
    //     // Legacy placeholders for backward compatibility (using DateTimeUtil)
    //     replacements.put("{DATE}", DateTimeUtil.getCurrentDate());
    //     replacements.put("{DATETIME}", DateTimeUtil.getCurrentDateTime());
    //     replacements.put("{Time}", DateTimeUtil.getCurrentTime());
    //     replacements.put("{TIMESTAMP}", DateTimeUtil.getCurrentTimestamp());
        
    //     // Special placeholders
    //     replacements.put("{CURRENT_TIMESTAMP}", String.valueOf(System.currentTimeMillis()));
        
    //     // Apply replacements
    //     for (Map.Entry<String, String> entry : replacements.entrySet()) {
    //         fileName = fileName.replace(entry.getKey(), entry.getValue());
    //     }
        
    //     return fileName;
    // }

    /**
     * Transforms a single database value for output formatting.
     * Integrated from business layer logic.
     * 
     * @param value The raw value from database result set
     * @return Object The transformed value, empty string if input is null
     */
    private Object transformValue(Object value) {
        // Basic transformation - can be extended for complex formatting
        if (value == null) {
            return "";
        }
        return value;
    }

    /**
     * Extracts column names from a ResultSet metadata for header generation.
     * Integrated from business layer logic.
     * 
     * @param resultSet The database result set to extract column names from
     * @return List<String> List of column names in order
     * @throws SQLException If database metadata access fails
     */
    private List<String> extractColumnNames(ResultSet resultSet) throws SQLException {
        List<String> columnNames = new ArrayList<>();
        ResultSetMetaData metaData = resultSet.getMetaData();
        int columnCount = metaData.getColumnCount();
        
        for (int i = 1; i <= columnCount; i++) {
            columnNames.add(metaData.getColumnName(i));
        }
        
        logger.debug("Extracted {} column names", columnNames.size());
        return columnNames;
    }

    /**
     * Extracts and transforms data from a single result set row.
     * Integrated from business layer logic.
     * 
     * @param resultSet The database result set positioned at current row
     * @param columnCount The number of columns to extract
     * @return List<Object> List of transformed values from the current row
     * @throws SQLException If database row data access fails
     */
    private List<Object> extractRowData(ResultSet resultSet, int columnCount) throws SQLException {
        List<Object> rowData = new ArrayList<>();
        
        for (int i = 1; i <= columnCount; i++) {
            Object value = resultSet.getObject(i);
            Object transformedValue = transformValue(value);
            rowData.add(transformedValue);
        }
        
        return rowData;
    }
}
