// package com.filegenerator.infrastructure.util;

// import com.filegenerator.infrastructure.exception.DatabaseException;
// import com.filegenerator.model.configuration.DatabaseConfiguration;
// import com.filegenerator.repository.database.DatabaseConnectionManagerImpl;
// import com.filegenerator.repository.database.IDatabaseConnectionManager;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;

// import java.sql.Connection;
// import java.sql.SQLException;
// import java.util.concurrent.ConcurrentHashMap;
// import java.util.concurrent.locks.ReentrantLock;

// /**
//  * Centralized database connection utility for managing database connections across the application.
//  * This utility provides a singleton-like approach to database connection management with support
//  * for multiple database configurations and connection pooling.
//  * 
//  * Author: Mahedee Hasan
//  * Purpose: Centralized database connection management utility
//  */
// public class DatabaseConnection {
    
//     private static final Logger logger = LoggerFactory.getLogger(DatabaseConnection.class);
    
//     // Thread-safe map to store connection managers for different database configurations
//     private static final ConcurrentHashMap<String, IDatabaseConnectionManager> connectionManagers = 
//             new ConcurrentHashMap<>();
    
//     private static final ReentrantLock lock = new ReentrantLock();
//     private static volatile DatabaseConfiguration defaultConfiguration;
//     private static volatile String defaultConfigKey = "default";

//     /**
//      * Private constructor to prevent instantiation
//      */
//     private DatabaseConnection() {
//         throw new IllegalStateException("Utility class cannot be instantiated");
//     }

//     /**
//      * Initialize the default database configuration
//      * 
//      * @param configuration The default database configuration
//      */
//     public static void initialize(DatabaseConfiguration configuration) {
//         lock.lock();
//         try {
//             if (defaultConfiguration == null) {
//                 logger.info("Initializing default database configuration");
//                 defaultConfiguration = configuration;
                
//                 // Create and initialize default connection manager
//                 IDatabaseConnectionManager manager = new DatabaseConnectionManagerImpl(configuration);
//                 manager.initialize();
//                 connectionManagers.put(defaultConfigKey, manager);
                
//                 logger.info("Default database configuration initialized successfully");
//             } else {
//                 logger.warn("Default database configuration already initialized. Skipping initialization.");
//             }
//         } finally {
//             lock.unlock();
//         }
//     }

//     /**
//      * Initialize a named database configuration
//      * 
//      * @param configKey Unique key for this configuration
//      * @param configuration The database configuration
//      */
//     public static void initialize(String configKey, DatabaseConfiguration configuration) {
//         if (configKey == null || configKey.trim().isEmpty()) {
//             throw new IllegalArgumentException("Configuration key cannot be null or empty");
//         }
        
//         lock.lock();
//         try {
//             if (!connectionManagers.containsKey(configKey)) {
//                 logger.info("Initializing database configuration for key: {}", configKey);
                
//                 IDatabaseConnectionManager manager = new DatabaseConnectionManagerImpl(configuration);
//                 manager.initialize();
//                 connectionManagers.put(configKey, manager);
                
//                 logger.info("Database configuration for key '{}' initialized successfully", configKey);
//             } else {
//                 logger.warn("Database configuration for key '{}' already exists. Skipping initialization.", configKey);
//             }
//         } finally {
//             lock.unlock();
//         }
//     }

//     /**
//      * Get a connection using the default configuration
//      * 
//      * @return Database connection
//      * @throws DatabaseException If connection cannot be obtained
//      */
//     public static Connection getConnection() throws DatabaseException {
//         return getConnection(defaultConfigKey);
//     }

//     /**
//      * Get a connection using a named configuration
//      * 
//      * @param configKey The configuration key to use
//      * @return Database connection
//      * @throws DatabaseException If connection cannot be obtained
//      */
//     public static Connection getConnection(String configKey) throws DatabaseException {
//         IDatabaseConnectionManager manager = connectionManagers.get(configKey);
//         if (manager == null) {
//             throw new DatabaseException("No database configuration found for key: " + configKey + 
//                     ". Please initialize the configuration first.");
//         }

//         try {
//             Connection connection = manager.getConnection();
//             logger.debug("Database connection obtained for configuration: {}", configKey);
//             return connection;
//         } catch (Exception e) {
//             logger.error("Failed to obtain database connection for configuration: {}", configKey, e);
//             throw new DatabaseException("Failed to obtain database connection: " + e.getMessage(), e);
//         }
//     }

//     /**
//      * Release a connection back to the pool using the default configuration
//      * 
//      * @param connection The connection to release
//      * @throws DatabaseException If connection cannot be released
//      */
//     public static void releaseConnection(Connection connection) throws DatabaseException {
//         releaseConnection(defaultConfigKey, connection);
//     }

//     /**
//      * Release a connection back to the pool using a named configuration
//      * 
//      * @param configKey The configuration key
//      * @param connection The connection to release
//      * @throws DatabaseException If connection cannot be released
//      */
//     public static void releaseConnection(String configKey, Connection connection) throws DatabaseException {
//         if (connection == null) {
//             logger.debug("Connection is null, skipping release");
//             return;
//         }

//         IDatabaseConnectionManager manager = connectionManagers.get(configKey);
//         if (manager == null) {
//             logger.warn("No database configuration found for key: {}. Closing connection directly.", configKey);
//             try {
//                 connection.close();
//             } catch (SQLException e) {
//                 throw new DatabaseException("Failed to close connection: " + e.getMessage(), e);
//             }
//             return;
//         }

//         try {
//             manager.releaseConnection(connection);
//             logger.debug("Database connection released for configuration: {}", configKey);
//         } catch (Exception e) {
//             logger.error("Failed to release database connection for configuration: {}", configKey, e);
//             throw new DatabaseException("Failed to release database connection: " + e.getMessage(), e);
//         }
//     }

//     /**
//      * Execute a database operation with automatic connection management using default configuration
//      * 
//      * @param operation The database operation to execute
//      * @param <T> Return type of the operation
//      * @return Result of the operation
//      * @throws DatabaseException If operation fails
//      */
//     public static <T> T execute(DatabaseOperation<T> operation) throws DatabaseException {
//         return execute(defaultConfigKey, operation);
//     }

//     /**
//      * Execute a database operation with automatic connection management using named configuration
//      * 
//      * @param configKey The configuration key
//      * @param operation The database operation to execute
//      * @param <T> Return type of the operation
//      * @return Result of the operation
//      * @throws DatabaseException If operation fails
//      */
//     public static <T> T execute(String configKey, DatabaseOperation<T> operation) throws DatabaseException {
//         Connection connection = null;
//         try {
//             connection = getConnection(configKey);
//             T result = operation.execute(connection);
//             logger.debug("Database operation completed successfully for configuration: {}", configKey);
//             return result;
//         } catch (Exception e) {
//             logger.error("Database operation failed for configuration: {}", configKey, e);
//             throw new DatabaseException("Database operation failed: " + e.getMessage(), e);
//         } finally {
//             if (connection != null) {
//                 releaseConnection(configKey, connection);
//             }
//         }
//     }

//     /**
//      * Check if a configuration is initialized
//      * 
//      * @param configKey The configuration key to check
//      * @return true if configuration exists, false otherwise
//      */
//     public static boolean isInitialized(String configKey) {
//         return connectionManagers.containsKey(configKey);
//     }

//     /**
//      * Check if default configuration is initialized
//      * 
//      * @return true if default configuration exists, false otherwise
//      */
//     public static boolean isInitialized() {
//         return isInitialized(defaultConfigKey);
//     }

//     /**
//      * Shutdown a specific database configuration
//      * 
//      * @param configKey The configuration key to shutdown
//      */
//     public static void shutdown(String configKey) {
//         lock.lock();
//         try {
//             IDatabaseConnectionManager manager = connectionManagers.remove(configKey);
//             if (manager != null) {
//                 try {
//                     manager.close();
//                     logger.info("Database configuration '{}' shutdown successfully", configKey);
//                 } catch (Exception e) {
//                     logger.error("Error shutting down database configuration '{}'", configKey, e);
//                 }
//             }
//         } finally {
//             lock.unlock();
//         }
//     }

//     /**
//      * Shutdown all database configurations
//      */
//     public static void shutdownAll() {
//         lock.lock();
//         try {
//             logger.info("Shutting down all database configurations");
//             for (String configKey : connectionManagers.keySet()) {
//                 shutdown(configKey);
//             }
//             connectionManagers.clear();
//             defaultConfiguration = null;
//             logger.info("All database configurations shutdown successfully");
//         } finally {
//             lock.unlock();
//         }
//     }

//     /**
//      * Get the number of initialized configurations
//      * 
//      * @return Number of active configurations
//      */
//     public static int getActiveConfigurationCount() {
//         return connectionManagers.size();
//     }

//     /**
//      * Functional interface for database operations
//      * 
//      * @param <T> Return type of the operation
//      */
//     @FunctionalInterface
//     public interface DatabaseOperation<T> {
//         T execute(Connection connection) throws Exception;
//     }
// }