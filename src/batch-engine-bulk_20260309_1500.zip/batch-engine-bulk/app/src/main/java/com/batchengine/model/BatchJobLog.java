package com.batchengine.model;

import java.time.LocalDateTime;

/**
 * POJO representing a record in the batch_job_log table.
 */
public class BatchJobLog {

    private Long id;
    private String jobName;
    private LocalDateTime executionTime;
    private String status;
    private String message;
    private String hostname;

    public BatchJobLog() {}

    public BatchJobLog(String jobName, String status, String message, String hostname) {
        this.jobName = jobName;
        this.executionTime = LocalDateTime.now();
        this.status = status;
        this.message = message;
        this.hostname = hostname;
    }

    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getJobName() { return jobName; }
    public void setJobName(String jobName) { this.jobName = jobName; }

    public LocalDateTime getExecutionTime() { return executionTime; }
    public void setExecutionTime(LocalDateTime executionTime) { this.executionTime = executionTime; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getHostname() { return hostname; }
    public void setHostname(String hostname) { this.hostname = hostname; }

    @Override
    public String toString() {
        return "BatchJobLog{" +
                "jobName='" + jobName + '\'' +
                ", executionTime=" + executionTime +
                ", status='" + status + '\'' +
                ", message='" + message + '\'' +
                ", hostname='" + hostname + '\'' +
                '}';
    }
}
