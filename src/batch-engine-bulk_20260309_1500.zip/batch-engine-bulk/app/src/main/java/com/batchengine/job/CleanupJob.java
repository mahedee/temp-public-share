package com.batchengine.job;

import com.batchengine.service.CleanupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Scheduled trigger for Cleanup job.
 * Delegates all business logic to CleanupService.
 */
@Component
@ConditionalOnProperty(name = "batchengine.jobs.configuration.cleanup.enabled", havingValue = "true", matchIfMissing = true)
public class CleanupJob {

    private static final Logger logger = LoggerFactory.getLogger(CleanupJob.class);

    @Autowired
    private CleanupService cleanupService;

    @Scheduled(cron = "${batchengine.jobs.configuration.cleanup.cron:*/5 * * * * *}")
    public void execute() {
        logger.info("CleanupJob triggered");
        try {
            cleanupService.process();
            logger.info("CleanupJob finished successfully");
        } catch (Exception e) {
            logger.error("CleanupJob encountered an unhandled error: {}", e.getMessage(), e);
        }
    }
}
