package com.batchengine;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.orm.jpa.HibernateJpaAutoConfiguration;
import org.springframework.retry.annotation.EnableRetry;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * BatchEngine - Multi-job batch processing application
 *
 * Features:
 * - Multiple configurable scheduled jobs
 * - Oracle database integration via DatabaseConfig
 * - Automatic retry mechanisms
 * - Comprehensive logging and monitoring
 * - Systemd service integration
 */
@SpringBootApplication(exclude = {
    HibernateJpaAutoConfiguration.class
})
@EnableScheduling
@EnableRetry
public class BatchEngineApplication {

    public static void main(String[] args) {
        System.setProperty("spring.application.name", "BatchEngine");
        SpringApplication.run(BatchEngineApplication.class, args);
        System.out.println("=================================");
        System.out.println("   BatchEngine Started Successfully");
        System.out.println("=================================");
    }
}