package com.batchengine.config;

import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;
import java.util.Map;
import java.util.HashMap;

/**
 * Configuration properties for all batch jobs.
 * Each job can be individually enabled/disabled and scheduled via application.properties.
 */
@Component
@ConfigurationProperties(prefix = "batchengine.jobs")
public class BatchJobProperties {

    private Map<String, JobConfig> configuration = new HashMap<>();

    public Map<String, JobConfig> getConfiguration() {
        return configuration;
    }

    public void setConfiguration(Map<String, JobConfig> configuration) {
        this.configuration = configuration;
    }

    /**
     * Individual job configuration properties.
     */
    public static class JobConfig {
        private boolean enabled = true;
        private String cron;
        private String description;
        private int retryAttempts = 3;
        private long retryDelay = 5000;

        public boolean isEnabled() { return enabled; }
        public void setEnabled(boolean enabled) { this.enabled = enabled; }

        public String getCron() { return cron; }
        public void setCron(String cron) { this.cron = cron; }

        public String getDescription() { return description; }
        public void setDescription(String description) { this.description = description; }

        public int getRetryAttempts() { return retryAttempts; }
        public void setRetryAttempts(int retryAttempts) { this.retryAttempts = retryAttempts; }

        public long getRetryDelay() { return retryDelay; }
        public void setRetryDelay(long retryDelay) { this.retryDelay = retryDelay; }

        @Override
        public String toString() {
            return "JobConfig{" +
                    "enabled=" + enabled +
                    ", cron='" + cron + '\'' +
                    ", description='" + description + '\'' +
                    ", retryAttempts=" + retryAttempts +
                    ", retryDelay=" + retryDelay +
                    '}';
        }
    }
}
