package com.batchengine.job;

import com.batchengine.service.ManualAccountEntryService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * Scheduled trigger for Manual Account Entry job.
 * Delegates all business logic to ManualAccountEntryService.
 */
@Component
@ConditionalOnProperty(name = "batchengine.jobs.configuration.manual-account-entry.enabled", havingValue = "true", matchIfMissing = true)
public class ManualAccountEntryJob {

    private static final Logger logger = LoggerFactory.getLogger(ManualAccountEntryJob.class);

    @Autowired
    private ManualAccountEntryService manualAccountEntryService;

    @Scheduled(cron = "${batchengine.jobs.configuration.manual-account-entry.cron:*/30 * * * * *}")
    public void execute() {
        logger.info("ManualAccountEntryJob triggered");
        try {
            manualAccountEntryService.process();
            logger.info("ManualAccountEntryJob finished successfully");
        } catch (Exception e) {
            logger.error("ManualAccountEntryJob encountered an unhandled error: {}", e.getMessage(), e);
        }
    }
}
