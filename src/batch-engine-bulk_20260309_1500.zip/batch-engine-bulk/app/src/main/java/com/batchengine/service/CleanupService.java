package com.batchengine.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.attribute.FileTime;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.stream.Stream;

/**
 * Business logic for the Cleanup job.
 * Writes a heartbeat entry to the cleanup log file and deletes log files that
 * are older than the configured retention period.
 */
@Service
public class CleanupService {

    private static final Logger logger = LoggerFactory.getLogger(CleanupService.class);
    /** Dedicated logger — routed by logback-spring.xml to cleanup-job.log with rolling policy. */
    private static final Logger jobLogger = LoggerFactory.getLogger("cleanup-job");
    private static final DateTimeFormatter DATE_FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Value("${batchengine.cleanup.log-file:logs/cleanup-job.log}")
    private String logFilePath;

    @Value("${batchengine.jobs.configuration.cleanup.log-retention-days:30}")
    private int logRetentionDays;

    /**
     * Main processing method called by CleanupJob.
     * Writes a heartbeat entry and removes log files older than logRetentionDays.
     */
    public void process() {
        LocalDateTime currentTime = LocalDateTime.now();

        try {
            jobLogger.info("[{}] Cleanup job executed - System running normally",
                    currentTime.format(DATE_FORMATTER));

            int deletedCount = deleteOldLogFiles();

            if (deletedCount > 0) {
                logger.info("Cleanup completed - deleted {} log file(s) older than {} day(s)",
                        deletedCount, logRetentionDays);
            } else {
                logger.debug("Cleanup completed - no log files exceeded retention of {} day(s)", logRetentionDays);
            }

        } catch (IOException e) {
            logger.error("Cleanup job IO error at {}: {}", currentTime.format(DATE_FORMATTER), e.getMessage(), e);
            jobLogger.error("[{}] Cleanup job IO error: {}", currentTime.format(DATE_FORMATTER), e.getMessage());
        } catch (Exception e) {
            logger.error("Cleanup job failed at {}: {}", currentTime.format(DATE_FORMATTER), e.getMessage(), e);
            jobLogger.error("[{}] Cleanup job failed: {}", currentTime.format(DATE_FORMATTER), e.getMessage());
        }
    }

    /**
     * Walks the log directory and deletes any {@code .log} files whose last-modified
     * time is older than {@code logRetentionDays} days.
     *
     * @return the number of files successfully deleted
     * @throws IOException if the directory cannot be read
     */
    private int deleteOldLogFiles() throws IOException {
        Path logDir = Paths.get(logFilePath).getParent();
        if (logDir == null || !Files.exists(logDir)) {
            logger.warn("Log directory does not exist, skipping old-file cleanup: {}", logDir);
            return 0;
        }

        Instant cutoff = Instant.now().minus(logRetentionDays, ChronoUnit.DAYS);
        int deletedCount = 0;

        try (Stream<Path> files = Files.walk(logDir, 1)) {
            for (Path file : (Iterable<Path>) files::iterator) {
                if (!Files.isRegularFile(file) || !file.getFileName().toString().endsWith(".log")) {
                    continue;
                }
                FileTime lastModified = Files.getLastModifiedTime(file);
                if (lastModified.toInstant().isBefore(cutoff)) {
                    try {
                        Files.delete(file);
                        logger.info("Deleted old log file: {} (last modified: {})", file.getFileName(), lastModified);
                        deletedCount++;
                    } catch (IOException e) {
                        logger.warn("Failed to delete old log file {}: {}", file.getFileName(), e.getMessage());
                    }
                }
            }
        }

        return deletedCount;
    }
}
