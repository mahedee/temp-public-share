package com.batchengine.repository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.condition.ConditionalOnBean;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.dao.DataAccessException;
import org.springframework.transaction.annotation.Transactional;

import javax.sql.DataSource;

/**
 * Repository for Manual Account Entry data access.
 * Contains all SQL queries related to manual account entry processing.
 */
@Repository
@ConditionalOnBean(DataSource.class)
public class ManualAccountEntryRepository {

    private static final Logger logger = LoggerFactory.getLogger(ManualAccountEntryRepository.class);

    @Autowired
    private JdbcTemplate jdbcTemplate;

    /**
     * Process manual account entries.
     * Executes all 5 steps in sequence to update the relevant tables.
     * All steps run within a single transaction — any failure rolls back every step.
     * HikariCP borrows a connection at the start of the transaction and returns it to
     * the pool automatically on commit or rollback.
     */
    @Transactional(rollbackFor = Exception.class)
    public void processEntries() {
        logger.info("Processing manual account entries...");

        try {
            int step1Rows = markProcessingStatus();
            logger.info("Step 1 completed - BMO_ACCOUNTS_MANUAL marked as PROCESSING: {} row(s)", step1Rows);

            if (step1Rows == 0) {
                logger.info("No records to process. Skipping remaining steps.");
                return;
            }

            int step2Rows = updateAccountDynamic();
            logger.info("Step 2 completed - ACCOUNT_DYNAMIC updated: {} row(s)", step2Rows);

            int step3Rows = updateWorkflowWorkitemLink();
            logger.info("Step 3 completed - WORKFLOW_WORKITEM_LINK updated: {} row(s)", step3Rows);

            int step4Rows = updateBmoAccPhDetails();
            logger.info("Step 4 completed - BMO_ACC_PH_DETAILS updated: {} row(s)", step4Rows);

            int step5Rows = softDeleteManualEntries();
            logger.info("Step 5 completed - BMO_ACCOUNTS_MANUAL soft-deleted and finalised: {} row(s)", step5Rows);

            logger.info("Manual account entry processing completed successfully.");

        } catch (RuntimeException e) {
            logger.error("Manual account entry processing aborted. Cause: {}", e.getMessage());
            throw e;
        }
    }

    /**
     * Step 1: Mark BMO_ACCOUNTS_MANUAL records as PROCESSING.
     * Targets active, non-deleted manual entries that have a matching record in ACCOUNTS.
     */
    public int markProcessingStatus() {
        String sql =
            "UPDATE BMO_ACCOUNTS_MANUAL man " +
            "SET STATUS = 'PROCESSING' " +
            "WHERE man.IS_DELETED = 'N' AND man.STATUS = 'ACTIVE' " +
            "  AND EXISTS ( " +
            "        SELECT 1 " +
            "        FROM   ACCOUNTS acc " +
            "        WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID " +
            "      )";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 1 failed - Unable to mark BMO_ACCOUNTS_MANUAL records as PROCESSING. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 1 - markProcessingStatus failed", e);
        }
    }

    /**
     * Step 2: Update ACCOUNT_ID in ACCOUNT_DYNAMIC.
     * Replaces the temporary ACCOUNT_SOURCE_REF_ID-based key with the canonical ACCOUNT_ID
     * from ACCOUNTS, but only where the target ACCOUNT_ID does not already exist in the table.
     */
    public int updateAccountDynamic() {
        String sql =
            "UPDATE ACCOUNT_DYNAMIC dyn " +
            "SET ACCOUNT_ID = ( " +
            "    SELECT acc.ACCOUNT_ID " +
            "    FROM   BMO_ACCOUNTS_MANUAL man " +
            "    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID " +
            "    WHERE  acc.ACCOUNT_SOURCE_REF_ID = dyn.ACCOUNT_ID " +
            "      AND  man.IS_DELETED = 'N' " +
            "      AND  man.STATUS = 'PROCESSING' " +
            "      AND  acc.ACCOUNT_ID IS NOT NULL " +
            "    FETCH FIRST 1 ROW ONLY " +
            ") " +
            "WHERE EXISTS ( " +
            "    SELECT 1 " +
            "    FROM   BMO_ACCOUNTS_MANUAL man " +
            "    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID " +
            "    WHERE  man.ACCOUNT_SOURCE_REF_ID = dyn.ACCOUNT_ID " +
            "      AND  man.IS_DELETED = 'N' " +
            "      AND  man.STATUS = 'PROCESSING' " +
            "      AND  acc.ACCOUNT_ID IS NOT NULL " +
            "      AND  NOT EXISTS ( " +
            "              SELECT 1 " +
            "              FROM   ACCOUNT_DYNAMIC existing " +
            "              WHERE  existing.ACCOUNT_ID = acc.ACCOUNT_ID " +
            "          ) " +
            ")";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 2 failed - Unable to update ACCOUNT_DYNAMIC. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 2 - updateAccountDynamic failed", e);
        }
    }

    /**
     * Step 3: Update LINKED_ENTITY_KEY in WORKFLOW_WORKITEM_LINK.
     * Replaces the ACCOUNT_SOURCE_REF_ID-based key with the canonical ACCOUNT_ID from ACCOUNTS.
     */
    public int updateWorkflowWorkitemLink() {
        String sql =
            "UPDATE WORKFLOW_WORKITEM_LINK wwl " +
            "SET LINKED_ENTITY_KEY = ( " +
            "    SELECT acc.ACCOUNT_ID " +
            "    FROM   BMO_ACCOUNTS_MANUAL man " +
            "    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID " +
            "    WHERE  man.ACCOUNT_SOURCE_REF_ID = wwl.LINKED_ENTITY_KEY " +
            "      AND  man.IS_DELETED = 'N' " +
            "      AND  man.STATUS = 'PROCESSING' " +
            "      AND  acc.ACCOUNT_ID IS NOT NULL " +
            "    FETCH FIRST 1 ROW ONLY " +
            ") " +
            "WHERE EXISTS ( " +
            "    SELECT 1 " +
            "    FROM   BMO_ACCOUNTS_MANUAL man " +
            "    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID " +
            "    WHERE  man.ACCOUNT_SOURCE_REF_ID = wwl.LINKED_ENTITY_KEY " +
            "      AND  man.IS_DELETED = 'N' " +
            "      AND  man.STATUS = 'PROCESSING' " +
            "      AND  acc.ACCOUNT_ID IS NOT NULL " +
            ")";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 3 failed - Unable to update WORKFLOW_WORKITEM_LINK. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 3 - updateWorkflowWorkitemLink failed", e);
        }
    }

    /**
     * Step 4: Update FCM_CP_ACCOUNT_ID in BMO_ACC_PH_DETAILS (Account Restriction Details).
     * Replaces the ACCOUNT_SOURCE_REF_ID-based key with the canonical ACCOUNT_ID from ACCOUNTS.
     */
    public int updateBmoAccPhDetails() {
        String sql =
            "UPDATE BMO_ACC_PH_DETAILS ph " +
            "SET FCM_CP_ACCOUNT_ID = ( " +
            "    SELECT acc.ACCOUNT_ID " +
            "    FROM   BMO_ACCOUNTS_MANUAL man " +
            "    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID " +
            "    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID " +
            "      AND  man.IS_DELETED = 'N' " +
            "      AND  man.STATUS = 'PROCESSING' " +
            "      AND  acc.ACCOUNT_ID IS NOT NULL " +
            "    FETCH FIRST 1 ROW ONLY " +
            ") " +
            "WHERE EXISTS ( " +
            "    SELECT 1 " +
            "    FROM   BMO_ACCOUNTS_MANUAL man " +
            "    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID " +
            "    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID " +
            "      AND  man.IS_DELETED = 'N' " +
            "      AND  man.STATUS = 'PROCESSING' " +
            "      AND  acc.ACCOUNT_ID IS NOT NULL " +
            ")";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 4 failed - Unable to update BMO_ACC_PH_DETAILS. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 4 - updateBmoAccPhDetails failed", e);
        }
    }

    /**
     * Step 5: Soft-delete and finalise PROCESSING records in BMO_ACCOUNTS_MANUAL.
     * Sets IS_DELETED = 'Y', STATUS = 'DELETED', and records the canonical ACCOUNT_ID
     * from ACCOUNTS to mark these manual entries as fully processed.
     */
    public int softDeleteManualEntries() {
        String sql =
            "UPDATE BMO_ACCOUNTS_MANUAL man " +
            "SET    ACCOUNT_ID = ( " +
            "           SELECT acc.ACCOUNT_ID " +
            "           FROM   ACCOUNTS acc " +
            "           WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID " +
            "           FETCH FIRST 1 ROW ONLY " +
            "       ), " +
            "       IS_DELETED = 'Y', " +
            "       STATUS     = 'DELETED' " +
            "WHERE  man.IS_DELETED = 'N' " +
            "  AND  man.STATUS = 'PROCESSING' " +
            "  AND  EXISTS ( " +
            "           SELECT 1 " +
            "           FROM   ACCOUNTS acc " +
            "           WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID " +
            "             AND  acc.ACCOUNT_ID IS NOT NULL " +
            "       )";
        try {
            return jdbcTemplate.update(sql);
        } catch (DataAccessException e) {
            logger.error("Step 5 failed - Unable to soft-delete and finalise BMO_ACCOUNTS_MANUAL records. Error: {}", e.getMessage(), e);
            throw new RuntimeException("Step 5 - softDeleteManualEntries failed", e);
        }
    }

    /**
     * Test database connectivity.
     */
    public boolean testConnection() {
        try {
            jdbcTemplate.queryForObject("SELECT 1 FROM DUAL", Integer.class);
            logger.info("Database connection test successful");
            return true;
        } catch (Exception e) {
            logger.error("Database connection test failed: {}", e.getMessage());
            return false;
        }
    }
}
