#!/bin/bash
# ===============================================
# BatchEngine Configuration Update Script
# ===============================================

CONFIG_FILE="config/application.properties"
PROD_CONFIG_FILE="config/application-production.properties"

echo "=========================================="
echo "BatchEngine Configuration Manager"
echo "=========================================="

# Function to show current configuration
show_current_config() {
    echo "Current Job Configuration:"
    echo "----------------------------------------"
    if [ -f "$CONFIG_FILE" ]; then
        echo "Development Configuration:"
        grep -E "batchengine\.jobs\.configuration\.(manual-account-entry|cleanup)\.(enabled|cron)" "$CONFIG_FILE" | sed 's/^/  /'
    fi
    
    if [ -f "$PROD_CONFIG_FILE" ]; then
        echo ""
        echo "Production Configuration:"
        grep -E "batchengine\.jobs\.configuration\.(manual-account-entry|cleanup)\.(enabled|cron)" "$PROD_CONFIG_FILE" | sed 's/^/  /'
    fi
    echo "----------------------------------------"
}

# Function to update job schedule
update_job_schedule() {
    local config_file="$1"
    local job_name="$2"
    local new_cron="$3"
    
    if [ -f "$config_file" ]; then
        # Use sed to update the cron expression
        sed -i "s|batchengine\.jobs\.configuration\.$job_name\.cron=.*|batchengine.jobs.configuration.$job_name.cron=$new_cron|g" "$config_file"
        echo "  Updated $job_name schedule to: $new_cron"
    fi
}

# Function to toggle job enable/disable
toggle_job_enabled() {
    local config_file="$1"
    local job_name="$2"
    local enabled="$3"
    
    if [ -f "$config_file" ]; then
        sed -i "s|batchengine\.jobs\.configuration\.$job_name\.enabled=.*|batchengine.jobs.configuration.$job_name.enabled=$enabled|g" "$config_file"
        echo "  Set $job_name enabled to: $enabled"
    fi
}

# Show current configuration
show_current_config

echo ""
echo "Select configuration to update:"
echo "1) Development (application.properties)"
echo "2) Production (application-production.properties)"
echo "3) Both"
echo "4) Show current config only"
echo "5) Exit"
read -p "Enter choice (1-5): " choice

case $choice in
    4)
        exit 0
        ;;
    5)
        exit 0
        ;;
esac

if [ "$choice" = "1" ] || [ "$choice" = "3" ]; then
    CONFIG_TO_UPDATE="$CONFIG_FILE"
    echo ""
    echo "Updating Development Configuration..."
    
    # Manual Account Entry Job
    echo "Manual Account Entry Job (current: every 30 seconds)"
    read -p "Enter new cron expression [*/30 * * * * *]: " manual_cron
    manual_cron=${manual_cron:-"*/30 * * * * *"}
    
    read -p "Enable Manual Account Entry Job? [Y/n]: " manual_enabled
    manual_enabled=${manual_enabled:-"Y"}
    [ "$manual_enabled" = "Y" ] || [ "$manual_enabled" = "y" ] && manual_enabled="true" || manual_enabled="false"
    
    # Cleanup Job
    echo ""
    echo "Cleanup Job (current: every 5 seconds)"
    read -p "Enter new cron expression [*/5 * * * * *]: " cleanup_cron
    cleanup_cron=${cleanup_cron:-"*/5 * * * * *"}
    
    read -p "Enable Cleanup Job? [Y/n]: " cleanup_enabled
    cleanup_enabled=${cleanup_enabled:-"Y"}
    [ "$cleanup_enabled" = "Y" ] || [ "$cleanup_enabled" = "y" ] && cleanup_enabled="true" || cleanup_enabled="false"
    
    # Update configuration
    update_job_schedule "$CONFIG_TO_UPDATE" "manual-account-entry" "$manual_cron"
    toggle_job_enabled "$CONFIG_TO_UPDATE" "manual-account-entry" "$manual_enabled"
    update_job_schedule "$CONFIG_TO_UPDATE" "cleanup" "$cleanup_cron"
    toggle_job_enabled "$CONFIG_TO_UPDATE" "cleanup" "$cleanup_enabled"
fi

if [ "$choice" = "2" ] || [ "$choice" = "3" ]; then
    CONFIG_TO_UPDATE="$PROD_CONFIG_FILE"
    echo ""
    echo "Updating Production Configuration..."
    
    # Manual Account Entry Job
    echo "Manual Account Entry Job (current: every 30 seconds)"
    read -p "Enter new cron expression [*/30 * * * * *]: " manual_cron_prod
    manual_cron_prod=${manual_cron_prod:-"*/30 * * * * *"}
    
    read -p "Enable Manual Account Entry Job? [Y/n]: " manual_enabled_prod
    manual_enabled_prod=${manual_enabled_prod:-"Y"}
    [ "$manual_enabled_prod" = "Y" ] || [ "$manual_enabled_prod" = "y" ] && manual_enabled_prod="true" || manual_enabled_prod="false"
    
    # Cleanup Job
    echo ""
    echo "Cleanup Job (current: every 5 seconds)"
    read -p "Enter new cron expression [*/5 * * * * *]: " cleanup_cron_prod
    cleanup_cron_prod=${cleanup_cron_prod:-"*/5 * * * * *"}
    
    read -p "Enable Cleanup Job? [Y/n]: " cleanup_enabled_prod
    cleanup_enabled_prod=${cleanup_enabled_prod:-"Y"}
    [ "$cleanup_enabled_prod" = "Y" ] || [ "$cleanup_enabled_prod" = "y" ] && cleanup_enabled_prod="true" || cleanup_enabled_prod="false"
    
    # Update configuration
    update_job_schedule "$CONFIG_TO_UPDATE" "manual-account-entry" "$manual_cron_prod"
    toggle_job_enabled "$CONFIG_TO_UPDATE" "manual-account-entry" "$manual_enabled_prod"
    update_job_schedule "$CONFIG_TO_UPDATE" "cleanup" "$cleanup_cron_prod"
    toggle_job_enabled "$CONFIG_TO_UPDATE" "cleanup" "$cleanup_enabled_prod"
fi

echo ""
echo "Configuration updated successfully!"
echo ""
echo "To apply changes in production:"
echo "1. Copy updated config files to server: scp config/* user@server:/opt/batch-engine/config/"
echo "2. Restart service: sudo systemctl restart batch-engine"
echo ""
echo "To test locally:"
echo "java -jar target/batch-engine.jar"