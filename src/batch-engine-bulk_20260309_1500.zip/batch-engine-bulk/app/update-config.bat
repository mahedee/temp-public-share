@echo off
REM ===============================================
REM BatchEngine Configuration Update Script (Windows)
REM ===============================================

set CONFIG_FILE=config\application.properties
set PROD_CONFIG_FILE=config\application-production.properties

echo ==========================================
echo BatchEngine Configuration Manager
echo ==========================================

REM Show current configuration
echo Current Job Configuration:
echo ----------------------------------------
if exist "%CONFIG_FILE%" (
    echo Development Configuration:
    findstr /R "batchengine\.jobs\.configuration\.*\.\(enabled\|cron\)" "%CONFIG_FILE%"
)

if exist "%PROD_CONFIG_FILE%" (
    echo.
    echo Production Configuration:
    findstr /R "batchengine\.jobs\.configuration\.*\.\(enabled\|cron\)" "%PROD_CONFIG_FILE%"
)
echo ----------------------------------------

echo.
echo Select configuration to update:
echo 1) Development (application.properties)
echo 2) Production (application-production.properties) 
echo 3) Show current config only
echo 4) Exit
set /p choice="Enter choice (1-4): "

if "%choice%"=="3" goto :end
if "%choice%"=="4" goto :end

if "%choice%"=="1" (
    set CONFIG_TO_UPDATE=%CONFIG_FILE%
    echo.
    echo Updating Development Configuration...
    goto :update_config
)

if "%choice%"=="2" (
    set CONFIG_TO_UPDATE=%PROD_CONFIG_FILE%
    echo.
    echo Updating Production Configuration...
    goto :update_config
)

echo Invalid choice. Exiting...
goto :end

:update_config
REM Manual Account Entry Job
echo Manual Account Entry Job
set /p "manual_cron=Enter new cron expression [*/30 * * * * *]: "
if "%manual_cron%"=="" set manual_cron=*/30 * * * * *

set /p "manual_enabled_input=Enable Manual Account Entry Job? [Y/n]: "
if "%manual_enabled_input%"=="" set manual_enabled_input=Y
if /i "%manual_enabled_input%"=="Y" (set manual_enabled=true) else (set manual_enabled=false)

REM Cleanup Job
echo.
echo Cleanup Job
set /p "cleanup_cron=Enter new cron expression [*/5 * * * * *]: "
if "%cleanup_cron%"=="" set cleanup_cron=*/5 * * * * *

set /p "cleanup_enabled_input=Enable Cleanup Job? [Y/n]: "
if "%cleanup_enabled_input%"=="" set cleanup_enabled_input=Y
if /i "%cleanup_enabled_input%"=="Y" (set cleanup_enabled=true) else (set cleanup_enabled=false)

REM Create temporary PowerShell script for sed-like functionality
echo $content = Get-Content "%CONFIG_TO_UPDATE%" > temp_update.ps1
echo $content ^| ForEach-Object { >> temp_update.ps1
echo     $_ -replace "batchengine\.jobs\.configuration\.manual-account-entry\.cron=.*", "batchengine.jobs.configuration.manual-account-entry.cron=%manual_cron%" ^| >> temp_update.ps1
echo     ForEach-Object { $_ -replace "batchengine\.jobs\.configuration\.manual-account-entry\.enabled=.*", "batchengine.jobs.configuration.manual-account-entry.enabled=%manual_enabled%" } ^| >> temp_update.ps1
echo     ForEach-Object { $_ -replace "batchengine\.jobs\.configuration\.cleanup\.cron=.*", "batchengine.jobs.configuration.cleanup.cron=%cleanup_cron%" } ^| >> temp_update.ps1
echo     ForEach-Object { $_ -replace "batchengine\.jobs\.configuration\.cleanup\.enabled=.*", "batchengine.jobs.configuration.cleanup.enabled=%cleanup_enabled%" } >> temp_update.ps1
echo } ^| Set-Content "%CONFIG_TO_UPDATE%" >> temp_update.ps1

REM Execute PowerShell script
powershell -ExecutionPolicy Bypass -File temp_update.ps1

REM Clean up
del temp_update.ps1

echo.
echo Configuration updated successfully!
echo.
echo Updated Manual Account Entry: %manual_enabled% with schedule %manual_cron%
echo Updated Cleanup Job: %cleanup_enabled% with schedule %cleanup_cron%
echo.
echo To test changes:
echo java -jar target\batch-engine.jar
echo.

:end
pause