# BatchEngine

**Multi-job batch processing engine with configurable scheduling for Oracle databases**

BatchEngine is a robust, Spring Boot-based application designed to handle multiple scheduled batch jobs with different execution frequencies. It provides enterprise-grade features including automatic retries, comprehensive logging, and systemd integration for Linux environments.

## 🚀 Features

- **Multiple Configurable Jobs**: Run different batch jobs with individual schedules
- **Oracle Database Integration**: Optimized for Oracle database operations
- **Flexible Scheduling**: Use cron expressions for precise timing control
- **Automatic Retries**: Built-in retry mechanisms with configurable backoff
- **Comprehensive Logging**: Detailed logging with job execution tracking
- **Systemd Integration**: Run as a Linux system service with auto-restart
- **Health Monitoring**: Spring Boot Actuator endpoints for monitoring
- **Zero Downtime Deployment**: Hot deployment capabilities
- **Resource Management**: Connection pooling and resource optimization

## 📋 Prerequisites

- Java 11 or higher
- Oracle Database (11g or higher)
- Linux server (for production deployment)
- Maven 3.6+ (for building)

## 🏗️ Architecture

```
BatchEngine/
├── src/main/java/com/batchengine/
│   ├── BatchEngineApplication.java          # Main Spring Boot application
│   ├── config/
│   │   └── JobConfiguration.java            # Job configuration management
│   ├── service/
│   │   ├── DatabaseService.java             # Database operations
│   │   └── jobs/                            # Individual job services
│   │       ├── ManualAccountEntryService.java # Account entry processing
│   │       └── CleanupJobService.java       # Cleanup operations
├── config/                                  # External configuration (runtime editable)
│   ├── application.properties               # Development configuration
│   └── application-production.properties    # Production configuration
├── database-setup.sql                       # Database schema
├── batch-engine.service                     # Systemd service file
├── deploy.sh                               # Deployment script
├── update-config.sh                        # Configuration update script (Linux)
├── update-config.bat                       # Configuration update script (Windows)
└── README.md                               # This file
```

## 📦 Quick Start

### 1. Clone and Build

```bash
git clone <repository-url>
cd batch-engine
mvn clean package
```

### 2. Database Setup

Execute the database setup script in your Oracle database:

```sql
-- Run the commands in database-setup.sql
sqlplus your_username/your_password@your_database @database-setup.sql
```

### 3. Configuration

Update `config/application.properties` for development or `config/application-production.properties` for production:

```properties
# Database connection
spring.datasource.url=jdbc:oracle:thin:@your-host:1521:your-sid
spring.datasource.username=your_username
spring.datasource.password=your_password

# Enable/disable jobs as needed
batchengine.jobs.configuration.manual-account-entry.enabled=true
batchengine.jobs.configuration.cleanup.enabled=true
```

### 4. Run Locally

```bash
java -jar target/batch-engine.jar
```

### 5. Deploy to Linux (Production)

```bash
# Make deployment script executable
chmod +x deploy.sh

# Full installation (requires sudo)
sudo ./deploy.sh install
```

## 🔧 Configuration

### Job Configuration

Each job can be individually configured in `application.properties`:

```properties
# Job Template
batchengine.jobs.configuration.{job-name}.enabled=true|false
batchengine.jobs.configuration.{job-name}.cron=cron-expression
batchengine.jobs.configuration.{job-name}.description=Job description
batchengine.jobs.configuration.{job-name}.retry-attempts=3
batchengine.jobs.configuration.{job-name}.retry-delay=5000
```

### Available Jobs

| Job Name | Default Schedule | Description |
|----------|------------------|-------------|
| `manual-account-entry` | Every 30 seconds | Processes manual account entries |
| `cleanup` | Every 5 seconds | Writes cleanup job logs |

### Cron Expression Examples

```properties
# Every 2 minutes
0 */2 * * * *

# Every 15 minutes  
0 */15 * * * *

# Daily at 2 AM
0 0 2 * * *

# Every Monday at 8 AM
0 0 8 * * MON

# 1st day of month at midnight
0 0 0 1 * *

# Business hours only (9 AM to 5 PM, Mon-Fri)
0 0 9-17 * * MON-FRI
```

## 🚀 Deployment

### Linux Service Management

After deployment with `deploy.sh install`:

```bash
# Start service
sudo systemctl start batch-engine

# Stop service
sudo systemctl stop batch-engine

# Restart service
sudo systemctl restart batch-engine

# Check status
sudo systemctl status batch-engine

# View real-time logs
sudo journalctl -u batch-engine -f

# View application logs
sudo tail -f /opt/batch-engine/logs/batch-engine.log
```

### Configuration Updates

For application updates:

```bash
# Build new version
mvn clean package

# Deploy without full reinstall
sudo ./deploy.sh deploy-only
```

### Runtime Configuration Changes

**Using Configuration Scripts:**

```bash
# Windows (Development)
update-config.bat

# Linux (Production)
chmod +x update-config.sh
./update-config.sh
```

**Manual Configuration Update:**

1. Edit configuration files:
   ```bash
   # Development
   nano config/application.properties
   
   # Production (on server)
   sudo nano /opt/batch-engine/config/application-production.properties
   ```

2. Apply changes:
   ```bash
   # Local testing
   java -jar target/batch-engine.jar
   
   # Production deployment
   sudo systemctl restart batch-engine
   ```

## 📊 Monitoring

### Health Check Endpoints

BatchEngine provides monitoring endpoints:

```bash
# Application health
curl http://localhost:8080/actuator/health

# Application info  
curl http://localhost:8080/actuator/info

# Metrics
curl http://localhost:8080/actuator/metrics
```

### Database Monitoring

Query job execution history:

```sql
-- Recent job executions
SELECT job_name, status, execution_time, message 
FROM batch_job_log 
WHERE execution_time >= SYSDATE - 1
ORDER BY execution_time DESC;

-- Job success rates
SELECT job_name, 
       COUNT(*) as total_executions,
       SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) as successful,
       ROUND(SUM(CASE WHEN status = 'SUCCESS' THEN 1 ELSE 0 END) * 100.0 / COUNT(*), 2) as success_rate
FROM batch_job_log 
WHERE execution_time >= SYSDATE - 7
GROUP BY job_name;
```

## 🔧 Troubleshooting

### Common Issues

1. **Service won't start**
   ```bash
   # Check logs for errors
   sudo journalctl -u batch-engine --no-pager -l
   
   # Verify Java installation
   java -version
   
   # Check database connectivity
   sqlplus username/password@database
   ```

2. **Database connection errors**
   - Verify Oracle database is running
   - Check connection parameters in config
   - Ensure database user has proper permissions
   - Test connection manually

3. **Jobs not executing**
   - Check if jobs are enabled in configuration
   - Verify cron expressions are valid
   - Review application logs for errors

### Log Locations

- **System logs**: `sudo journalctl -u batch-engine`
- **Application logs**: `/opt/batch-engine/logs/batch-engine.log`
- **Job execution logs**: Check `batch_job_log` table in database

## 🔒 Security

### Service Security

The systemd service runs with restricted permissions:
- Dedicated `batchengine` user (no shell access)
- Protected system directories
- Private temporary directory
- Limited file system access

### Database Security

- Use dedicated database user with minimal required permissions
- Store passwords in environment variables for production
- Enable Oracle database auditing
- Use encrypted connections when possible

## 🧪 Testing

### Run Tests

```bash
mvn test
```

### Manual Testing

```bash
# Test database connection
java -jar batch-engine.jar --spring.profiles.active=test

# Test specific job (requires application running)
# Jobs will execute according to their schedule
```

## 📚 Development

### Adding New Jobs

1. Create new job service in `service/jobs/` package
2. Annotate with `@Service` and `@ConditionalOnProperty`
3. Add `@Scheduled` method with configuration property
4. Add configuration properties to `application.properties`
5. Include job logic in `DatabaseService` if needed

Example:
```java
@Service
@ConditionalOnProperty(name = "batchengine.jobs.configuration.my-job.enabled", havingValue = "true")
public class MyJobService {
    
    @Scheduled(cron = "${batchengine.jobs.configuration.my-job.cron:0 0 * * * *}")
    public void executeMyJob() {
        // Job logic here
    }
}
```

### Local Development

```bash
# Run with development profile
java -jar batch-engine.jar --spring.profiles.active=development

# Enable debug logging
java -jar batch-engine.jar --logging.level.com.batchengine=DEBUG
```

## 📄 License

[Your License Here]

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Add tests
5. Submit a pull request

## 📞 Support

For support and questions:
- Create an issue in the repository
- Contact the development team
- Check the troubleshooting section

---

**BatchEngine** - Reliable, scalable batch processing for your enterprise needs.