#!/bin/bash

# ===============================================
# BatchEngine Installation and Deployment Script
# ===============================================

set -e

# Configuration
APP_NAME="batch-engine"
APP_VERSION="1.0.0"
APP_USER="batchengine"
APP_GROUP="batchengine"
APP_HOME="/opt/batch-engine"
SERVICE_FILE="batch-engine.service"
JAR_FILE="batch-engine.jar"

echo "=========================================="
echo "BatchEngine Deployment Script"
echo "=========================================="

# Check if running as root
if [ "$EUID" -ne 0 ]; then 
    echo "Please run as root (use sudo)"
    exit 1
fi

# Function to create application user
create_app_user() {
    echo "Creating application user: $APP_USER"
    if ! id "$APP_USER" &>/dev/null; then
        useradd --system --shell /bin/false --home-dir $APP_HOME --create-home $APP_USER
        echo "User $APP_USER created successfully"
    else
        echo "User $APP_USER already exists"
    fi
}

# Function to create directories
create_directories() {
    echo "Creating application directories..."
    mkdir -p $APP_HOME/{logs,config,backup}
    chown -R $APP_USER:$APP_GROUP $APP_HOME
    chmod 755 $APP_HOME
    chmod 755 $APP_HOME/logs
    echo "Directories created successfully"
}

# Function to install Java if not present
install_java() {
    echo "Checking Java installation..."
    if ! command -v java &> /dev/null; then
        echo "Java not found. Installing OpenJDK 11..."
        if command -v yum &> /dev/null; then
            yum install -y java-11-openjdk java-11-openjdk-devel
        elif command -v apt &> /dev/null; then
            apt update && apt install -y openjdk-11-jdk
        else
            echo "Please install Java 11 manually"
            exit 1
        fi
    else
        echo "Java is already installed: $(java -version 2>&1 | head -n1)"
    fi
}

# Function to build application
build_application() {
    echo "Building BatchEngine application..."
    if [ ! -f "pom.xml" ]; then
        echo "Error: pom.xml not found. Please run this script from the project root directory."
        exit 1
    fi
    
    # Install Maven if not present
    if ! command -v mvn &> /dev/null; then
        echo "Maven not found. Installing Maven..."
        if command -v yum &> /dev/null; then
            yum install -y maven
        elif command -v apt &> /dev/null; then
            apt install -y maven
        fi
    fi
    
    # Build the application
    mvn clean package -DskipTests
    
    if [ ! -f "target/$JAR_FILE" ]; then
        echo "Error: Build failed. JAR file not found."
        exit 1
    fi
    
    echo "Application built successfully"
}

# Function to deploy application
deploy_application() {
    echo "Deploying application..."
    
    # Stop service if running
    if systemctl is-active --quiet $APP_NAME; then
        echo "Stopping $APP_NAME service..."
        systemctl stop $APP_NAME
    fi
    
    # Backup existing jar if it exists
    if [ -f "$APP_HOME/$JAR_FILE" ]; then
        echo "Backing up existing application..."
        cp $APP_HOME/$JAR_FILE $APP_HOME/backup/$JAR_FILE.$(date +%Y%m%d_%H%M%S)
    fi
    
    # Copy new jar file
    cp target/$JAR_FILE $APP_HOME/
    chown $APP_USER:$APP_GROUP $APP_HOME/$JAR_FILE
    chmod 644 $APP_HOME/$JAR_FILE
    
    # Copy configuration files from external config folder
    if [ -f "config/application.properties" ]; then
        cp config/application.properties $APP_HOME/config/
        chown $APP_USER:$APP_GROUP $APP_HOME/config/application.properties
    fi
    
    if [ -f "config/application-production.properties" ]; then
        cp config/application-production.properties $APP_HOME/config/
        chown $APP_USER:$APP_GROUP $APP_HOME/config/application-production.properties
    fi
    
    echo "Application deployed successfully"
}

# Function to install systemd service
install_service() {
    echo "Installing systemd service..."
    
    # Copy service file
    cp $SERVICE_FILE /etc/systemd/system/
    
    # Reload systemd
    systemctl daemon-reload
    
    # Enable service
    systemctl enable $APP_NAME
    
    echo "Service installed and enabled"
}

# Function to start service
start_service() {
    echo "Starting $APP_NAME service..."
    systemctl start $APP_NAME
    
    # Wait a moment and check status
    sleep 5
    if systemctl is-active --quiet $APP_NAME; then
        echo "✅ $APP_NAME service started successfully!"
        systemctl status $APP_NAME --no-pager --lines=10
    else
        echo "❌ Failed to start $APP_NAME service"
        systemctl status $APP_NAME --no-pager --lines=20
        exit 1
    fi
}

# Function to show service management commands
show_commands() {
    echo ""
    echo "=========================================="
    echo "Service Management Commands:"
    echo "=========================================="
    echo "Start service:      sudo systemctl start $APP_NAME"
    echo "Stop service:       sudo systemctl stop $APP_NAME"
    echo "Restart service:    sudo systemctl restart $APP_NAME"
    echo "Service status:     sudo systemctl status $APP_NAME"
    echo "View logs:          sudo journalctl -u $APP_NAME -f"
    echo "View app logs:      sudo tail -f $APP_HOME/logs/batch-engine.log"
    echo ""
    echo "Configuration file: $APP_HOME/config/application.properties"
    echo "Application home:   $APP_HOME"
    echo ""
}

# Main execution
main() {
    echo "Starting BatchEngine deployment..."
    
    create_app_user
    create_directories
    install_java
    build_application
    deploy_application
    install_service
    start_service
    show_commands
    
    echo ""
    echo "✅ BatchEngine deployment completed successfully!"
    echo ""
}

# Handle command line arguments
case "${1:-}" in
    "install")
        main
        ;;
    "deploy-only")
        deploy_application
        systemctl restart $APP_NAME
        ;;
    "start")
        systemctl start $APP_NAME
        ;;
    "stop")
        systemctl stop $APP_NAME
        ;;
    "status")
        systemctl status $APP_NAME
        ;;
    "logs")
        journalctl -u $APP_NAME -f
        ;;
    *)
        echo "Usage: $0 {install|deploy-only|start|stop|status|logs}"
        echo ""
        echo "Commands:"
        echo "  install      - Full installation (build, deploy, install service)"
        echo "  deploy-only  - Deploy application and restart service"
        echo "  start        - Start the service"
        echo "  stop         - Stop the service"
        echo "  status       - Show service status"
        echo "  logs         - Follow service logs"
        echo ""
        exit 1
        ;;
esac