# GitHub Copilot Instructions for BatchEngine Application

## Project Overview
This is a Java-based batch processing application designed for high-volume data processing tasks.

## Environment & Compatibility Requirements
- **Target Platform**: Linux server environment (Red Hat)
- **Java Version**: OpenJDK 11.0.25 LTS (Red Hat distribution)
  ```
  openjdk version "11.0.25" 2024-10-15 LTS
  OpenJDK Runtime Environment (Red_Hat-11.0.25.0.9-1)
  OpenJDK 64-Bit Server VM (Red_Hat-11.0.25.0.9-1)
  ```
- **Compatibility**: All code must be Java 11 compatible (no Java 12+ features)
- **File System**: Use forward slashes for paths, ensure Linux path compatibility and use windows compatible paths when necessary (e.g., for development on Windows)

## Framework & Technology Stack
- **Build Tool**: Maven
- **Spring Framework**: Use Spring Boot 2.x for Java 11 compatibility
