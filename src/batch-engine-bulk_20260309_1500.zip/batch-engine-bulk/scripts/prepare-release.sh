#!/bin/bash

# Batch Engine Release Preparation Script
# Run from the scripts directory

set -e

echo "========================================="
echo "  Preparing Batch Engine Release Package"
echo "========================================="

# Navigate to project root (parent of scripts directory)
cd "$(dirname "$0")/.."

echo "Building application..."
cd app
mvn clean package -DskipTests
cd ..

# Create release directory
VERSION=$(date +"%Y%m%d_%H%M%S")
RELEASE_DIR="release/batch-engine-$VERSION"
echo "Creating release directory: $RELEASE_DIR"
mkdir -p $RELEASE_DIR

# Copy essential files
echo "Copying files..."
cp app/target/batch-engine.jar $RELEASE_DIR/
cp -r app/config $RELEASE_DIR/
cp -r scripts $RELEASE_DIR/
cp -r docs $RELEASE_DIR/ 2>/dev/null || echo "Warning: No docs directory found"
cp README.md $RELEASE_DIR/ 2>/dev/null || echo "Warning: No README.md found"

# Create simple systemd service file
echo "Creating service file..."
cat > $RELEASE_DIR/batch-engine.service << 'EOF'
[Unit]
Description=Batch Engine Service
After=network.target

[Service]
Type=simple
User=batchengine
Group=batchengine
WorkingDirectory=/opt/batch-engine
ExecStart=/usr/bin/java -jar /opt/batch-engine/batch-engine.jar
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF

# Create simple install script
echo "Creating install script..."
cat > $RELEASE_DIR/install.sh << 'EOF'
#!/bin/bash
set -e

echo "Installing Batch Engine..."

# Install to /opt/batch-engine
sudo mkdir -p /opt/batch-engine
sudo cp -r * /opt/batch-engine/
sudo useradd -r -m -d /opt/batch-engine -s /bin/false batchengine 2>/dev/null || true
sudo chown -R batchengine:batchengine /opt/batch-engine
sudo chmod +x /opt/batch-engine/scripts/*.sh

# Install systemd service
sudo cp /opt/batch-engine/batch-engine.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable batch-engine

echo "Installation complete!"
echo "Start: sudo systemctl start batch-engine"
echo "Status: sudo systemctl status batch-engine"
EOF

chmod +x $RELEASE_DIR/install.sh

# Create start/stop scripts for Windows users
cat > $RELEASE_DIR/start-windows.bat << 'EOF'
@echo off
echo Starting Batch Engine...
java -jar batch-engine.jar
pause
EOF

cat > $RELEASE_DIR/stop-windows.bat << 'EOF'
@echo off
echo Stopping Batch Engine...
taskkill /f /im java.exe
pause
EOF

# Package everything
echo "Creating package..."
cd release
tar -czf batch-engine-$VERSION.tar.gz batch-engine-$VERSION/
cd ..

echo "========================================="
echo "✅ Release package created successfully!"
echo "📦 Location: release/batch-engine-$VERSION.tar.gz"
echo "🚀 Deploy: Extract and run ./install.sh"
echo "========================================="