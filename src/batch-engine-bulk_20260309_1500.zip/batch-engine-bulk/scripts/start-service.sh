#!/bin/bash

# Simple Batch Engine Service Start Script

SERVICE_NAME="batch-engine"

echo "Starting Batch Engine Service..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo $0"
    exit 1
fi

# Check if already running
if systemctl is-active --quiet $SERVICE_NAME; then
    echo "Service is already running"
    systemctl status $SERVICE_NAME --no-pager
    exit 0
fi

# Start service
systemctl start $SERVICE_NAME

# Wait for startup
sleep 5

# Check status
if systemctl is-active --quiet $SERVICE_NAME; then
    echo "✓ Service started successfully"
    systemctl status $SERVICE_NAME --no-pager
    echo ""
    echo "Commands:"
    echo "  Status: sudo systemctl status $SERVICE_NAME"
    echo "  Logs:   sudo journalctl -u $SERVICE_NAME -f"
    echo "  Stop:   sudo ./scripts/stop-service.sh"
else
    echo "✗ Service failed to start"
    systemctl status $SERVICE_NAME --no-pager
    echo ""
    echo "Check logs: sudo journalctl -u $SERVICE_NAME -n 20"
    exit 1
fi