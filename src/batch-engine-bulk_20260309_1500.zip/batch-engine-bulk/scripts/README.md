# Batch Engine Scripts

Simple deployment and management scripts for the Batch Engine application.

## Scripts

### prepare-release.sh
Creates a deployment package ready for Linux servers.

```bash
./scripts/prepare-release.sh
```

**Output:** `release/batch-engine-YYYYMMDD_HHMMSS.tar.gz`

### start-service.sh
Starts the Batch Engine systemd service.

```bash
sudo ./scripts/start-service.sh
```

### stop-service.sh
Stops the Batch Engine systemd service.

```bash
sudo ./scripts/stop-service.sh
```

## Quick Deployment

1. **Build release package:**
   ```bash
   ./scripts/prepare-release.sh
   ```

2. **Copy to Linux server:**
   ```bash
   scp release/batch-engine-*.tar.gz user@server:/tmp/
   ```

3. **Install on server:**
   ```bash
   ssh user@server
   cd /tmp
   tar -xzf batch-engine-*.tar.gz
   cd batch-engine-*
   sudo ./install.sh
   ```

4. **Start service:**
   ```bash
   sudo ./scripts/start-service.sh
   ```

## Service Management

```bash
# Start
sudo ./scripts/start-service.sh

# Stop  
sudo ./scripts/stop-service.sh

# Status
sudo systemctl status batch-engine

# Logs
sudo journalctl -u batch-engine -f
```

**Note:** On Linux, make scripts executable with: `chmod +x scripts/*.sh`