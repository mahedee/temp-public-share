@echo off
setlocal enabledelayedexpansion

echo =========================================
echo   Preparing Batch Engine Release Package
echo =========================================

:: Navigate to project root (parent of scripts directory)
cd /d "%~dp0\.."

:: Build application
echo Building application...
cd app
call mvn clean package -DskipTests
if errorlevel 1 (
    echo ERROR: Build failed!
    pause
    exit /b 1
)
cd ..

:: Create release directory with timestamp
for /f "tokens=2 delims==" %%a in ('wmic OS Get localdatetime /value') do set "dt=%%a"
set "VERSION=%dt:~0,4%%dt:~4,2%%dt:~6,2%_%dt:~8,2%%dt:~10,2%%dt:~12,2%"
set "RELEASE_DIR=release\batch-engine-%VERSION%"

echo Creating release directory: %RELEASE_DIR%
if not exist release mkdir release
if exist "%RELEASE_DIR%" rmdir /s /q "%RELEASE_DIR%"
mkdir "%RELEASE_DIR%"

:: Copy essential files
echo Copying files...
copy "app\target\batch-engine.jar" "%RELEASE_DIR%\" > nul
xcopy "app\config" "%RELEASE_DIR%\config\" /e /i /q > nul
xcopy "scripts" "%RELEASE_DIR%\scripts\" /e /i /q > nul
if exist "docs" xcopy "docs" "%RELEASE_DIR%\docs\" /e /i /q > nul
if exist "README.md" copy "README.md" "%RELEASE_DIR%\" > nul

:: Create systemd service file
echo Creating service file...
(
echo [Unit]
echo Description=Batch Engine Service
echo After=network.target
echo.
echo [Service]
echo Type=simple
echo User=batchengine
echo Group=batchengine
echo WorkingDirectory=/opt/batch-engine
echo ExecStart=/usr/bin/java -jar /opt/batch-engine/batch-engine.jar
echo Restart=always
echo RestartSec=10
echo StandardOutput=journal
echo StandardError=journal
echo.
echo [Install]
echo WantedBy=multi-user.target
) > "%RELEASE_DIR%\batch-engine.service"

:: Create install script for Linux
echo Creating install script...
(
echo #!/bin/bash
echo set -e
echo.
echo echo "Installing Batch Engine..."
echo.
echo # Install to /opt/batch-engine
echo sudo mkdir -p /opt/batch-engine
echo sudo cp -r * /opt/batch-engine/
echo sudo useradd -r -m -d /opt/batch-engine -s /bin/false batchengine 2^>/dev/null ^|^| true
echo sudo chown -R batchengine:batchengine /opt/batch-engine
echo sudo chmod +x /opt/batch-engine/scripts/*.sh
echo.
echo # Install systemd service
echo sudo cp /opt/batch-engine/batch-engine.service /etc/systemd/system/
echo sudo systemctl daemon-reload
echo sudo systemctl enable batch-engine
echo.
echo echo "Installation complete!"
echo echo "Start: sudo systemctl start batch-engine"
echo echo "Status: sudo systemctl status batch-engine"
) > "%RELEASE_DIR%\install.sh"

:: Create Windows start script
echo Creating Windows scripts...
(
echo @echo off
echo echo Starting Batch Engine...
echo java -jar batch-engine.jar
echo pause
) > "%RELEASE_DIR%\start-windows.bat"

:: Create Windows stop script
(
echo @echo off
echo echo Stopping Batch Engine...
echo taskkill /f /im java.exe
echo pause
) > "%RELEASE_DIR%\stop-windows.bat"

:: Create README
(
echo # Batch Engine Release Package
echo.
echo ## Requirements
echo - **Linux**: OpenJDK 11.0.25 LTS ^(Red Hat distribution^) or compatible
echo - **Windows**: Java 11+ for testing
echo.
echo ## Linux Deployment ^(Recommended^)
echo 1. Extract package: `tar -xzf batch-engine-%VERSION%.tar.gz`
echo 2. Navigate: `cd batch-engine-%VERSION%`
echo 3. Install: `sudo ./install.sh`
echo 4. Start service: `sudo systemctl start batch-engine`
echo 5. Check status: `sudo systemctl status batch-engine`
echo.
echo ## Windows Testing
echo 1. Start: `start-windows.bat`
echo 2. Stop: `stop-windows.bat`
echo.
echo ## Configuration
echo - Edit `config/application.properties` for settings
echo - Production config: `config/application-production.properties`
echo.
echo ## Logs
echo - Linux: `journalctl -u batch-engine -f`
echo - Windows: Console output
echo.
echo ## Manual Start
echo ```bash
echo java -jar batch-engine.jar
echo ```
echo.
echo Built with Spring Boot 2.7.18 for Java 11 compatibility.
) > "%RELEASE_DIR%\README.md"

:: Create compressed package using PowerShell
echo Creating package...
powershell -Command "& {Compress-Archive -Path 'release\batch-engine-%VERSION%\*' -DestinationPath 'release\batch-engine-%VERSION%.zip' -Force}"

:: Display results
echo =========================================
echo ✅ Release package created successfully!
echo 📦 Location: release\batch-engine-%VERSION%.zip
echo 📁 Directory: %RELEASE_DIR%
echo 🚀 Deploy: Extract and run install.sh (Linux)
echo 🎯 Test: Use start-windows.bat (Windows)
echo =========================================

:: Show package contents
echo.
echo 📋 Package contents:
dir "%RELEASE_DIR%" /b

pause