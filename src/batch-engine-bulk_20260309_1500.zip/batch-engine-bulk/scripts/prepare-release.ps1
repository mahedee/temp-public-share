# Simple Batch Engine Release Preparation Script for Windows

Write-Host "Building Batch Engine Release Package..." -ForegroundColor Green

# Navigate to app directory (where pom.xml is located)
if (Test-Path "app\pom.xml") {
    Set-Location "app"
    Write-Host "Working from app directory" -ForegroundColor Gray
} elseif (Test-Path "pom.xml") {
    Write-Host "Working from current directory" -ForegroundColor Gray
} else {
    Write-Host "Error: pom.xml not found in current directory or app subdirectory!" -ForegroundColor Red
    exit 1
}

# Build application
Write-Host "Building application with Maven..." -ForegroundColor Yellow
mvn clean package -DskipTests

if (-not (Test-Path "target\batch-engine.jar")) {
    Write-Host "Error: JAR file not found after build!" -ForegroundColor Red
    exit 1
}

# Navigate back to project root for creating release
Set-Location ".."

# Create release directory
$version = Get-Date -Format "yyyyMMdd_HHmmss"
$releaseDir = "release\batch-engine-$version"
New-Item -ItemType Directory -Path $releaseDir -Force | Out-Null

Write-Host "Created release directory: $releaseDir" -ForegroundColor Yellow

# Copy files
Write-Host "Copying application files..." -ForegroundColor Yellow
Copy-Item "app\target\batch-engine.jar" "$releaseDir\"
if (Test-Path "app\config") {
    Copy-Item "app\config" "$releaseDir\" -Recurse -Force
} elseif (Test-Path "config") {
    Copy-Item "config" "$releaseDir\" -Recurse -Force
}
Copy-Item "scripts" "$releaseDir\" -Recurse -Force

if (Test-Path "docs") {
    Copy-Item "docs" "$releaseDir\" -Recurse -Force
} else {
    Write-Host "No docs directory found, skipping..." -ForegroundColor Gray
}

# Create systemd service file
Write-Host "Creating systemd service file..." -ForegroundColor Yellow
@"
[Unit]
Description=Batch Engine Service
After=network.target

[Service]
Type=simple
User=batch-engine
Group=batch-engine
WorkingDirectory=/opt/batch-engine
ExecStart=/usr/bin/java -jar /opt/batch-engine/batch-engine.jar --spring.config.location=file:/opt/batch-engine/config/
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
"@ | Out-File -FilePath "$releaseDir\batch-engine.service" -Encoding UTF8

# Create Linux install script
Write-Host "Creating installation script..." -ForegroundColor Yellow
@"
#!/bin/bash
set -e

echo "Installing Batch Engine..."

# Check if running as root
if [ "`$EUID" -ne 0 ]; then
    echo "Please run as root (use sudo)"
    exit 1
fi

# Create directories
mkdir -p /opt/batch-engine /var/log/batch-engine

# Create service user (ignore if exists)
useradd -r -s /bin/false -d /opt/batch-engine batch-engine 2>/dev/null || true

# Copy files
cp batch-engine.jar /opt/batch-engine/
cp -r config /opt/batch-engine/
cp -r scripts /opt/batch-engine/
cp batch-engine.service /etc/systemd/system/

# Set permissions
chown -R batch-engine:batch-engine /opt/batch-engine /var/log/batch-engine
chmod +x /opt/batch-engine/scripts/*.sh

# Enable service
systemctl daemon-reload
systemctl enable batch-engine

echo "Installation complete!"
echo ""
echo "Management commands:"
echo "  Start:  sudo systemctl start batch-engine"
echo "  Stop:   sudo systemctl stop batch-engine"
echo "  Status: sudo systemctl status batch-engine"
echo "  Logs:   sudo journalctl -u batch-engine -f"
"@ | Out-File -FilePath "$releaseDir\install.sh" -Encoding UTF8

# Create Windows batch files for local testing
Write-Host "Creating Windows batch files..." -ForegroundColor Yellow

# start-windows.bat
@"
@echo off
echo Starting Batch Engine on Windows...
cd /d "%~dp0"
java -jar batch-engine.jar
pause
"@ | Out-File -FilePath "$releaseDir\start-windows.bat" -Encoding UTF8

# stop-windows.bat
@"
@echo off
echo Stopping Batch Engine...
tasklist | findstr java.exe
for /f "tokens=2" %%i in ('tasklist /fi "imagename eq java.exe" /fo csv /nh') do (
    wmic process where "ProcessId=%%i" get CommandLine | find "batch-engine.jar" >nul
    if not errorlevel 1 (
        echo Stopping process %%i
        taskkill /PID %%i /F
    )
)
echo Done.
pause
"@ | Out-File -FilePath "$releaseDir\stop-windows.bat" -Encoding UTF8

# Create README
Write-Host "Creating README..." -ForegroundColor Yellow
@"
# Batch Engine Release Package

## For Linux Deployment
1. Extract this package on Linux server
2. Run: ``sudo ./install.sh``
3. Start: ``sudo systemctl start batch-engine``

## For Windows Testing
1. Run: ``start-windows.bat``
2. Stop: ``stop-windows.bat``

## Files Included
- ``batch-engine.jar`` - Main application
- ``config/`` - Configuration files
- ``scripts/`` - Management scripts  
- ``install.sh`` - Linux installation script
- ``batch-engine.service`` - Systemd service file
- ``start-windows.bat`` - Windows start script
- ``stop-windows.bat`` - Windows stop script

## Linux Management
``````bash
sudo systemctl start batch-engine    # Start service
sudo systemctl stop batch-engine     # Stop service  
sudo systemctl status batch-engine   # Check status
sudo journalctl -u batch-engine -f   # View logs
``````

## Windows Testing
- Double-click ``start-windows.bat`` to start
- Double-click ``stop-windows.bat`` to stop
- Check logs in console output

## Health Check
- Linux: ``curl http://localhost:8080/actuator/health``
- Windows: Open ``http://localhost:8080/actuator/health`` in browser
"@ | Out-File -FilePath "$releaseDir\README.md" -Encoding UTF8

# Create package
Write-Host "Creating ZIP package..." -ForegroundColor Yellow
$packageName = "batch-engine-$version.zip"
$packagePath = "release\$packageName"

if (Test-Path $packagePath) {
    Remove-Item $packagePath -Force
}

Add-Type -AssemblyName System.IO.Compression.FileSystem
[System.IO.Compression.ZipFile]::CreateFromDirectory($releaseDir, $packagePath)

# Get package info
$packageSize = [math]::Round((Get-Item $packagePath).Length / 1MB, 2)

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green
Write-Host "Release Package Created Successfully!" -ForegroundColor Green  
Write-Host "=========================================" -ForegroundColor Green
Write-Host "Package: $packagePath" -ForegroundColor White
Write-Host "Size: $packageSize MB" -ForegroundColor White
Write-Host "Version: $version" -ForegroundColor White

Write-Host ""
Write-Host "Package Contents:" -ForegroundColor Yellow
Get-ChildItem $releaseDir -Recurse -File | ForEach-Object { 
    $relativePath = $_.FullName.Replace((Get-Item $releaseDir).FullName, "")
    Write-Host "  $relativePath" -ForegroundColor Gray
}

Write-Host ""
Write-Host "Deployment Instructions:" -ForegroundColor Cyan
Write-Host "========================" -ForegroundColor Cyan
Write-Host "For Linux:" -ForegroundColor White
Write-Host "1. Copy $packageName to Linux server" -ForegroundColor Gray
Write-Host "2. Extract: unzip $packageName" -ForegroundColor Gray  
Write-Host "3. Install: cd batch-engine-$version && sudo ./install.sh" -ForegroundColor Gray
Write-Host "4. Start: sudo systemctl start batch-engine" -ForegroundColor Gray

Write-Host ""
Write-Host "For Windows Testing:" -ForegroundColor White
Write-Host "1. Extract $packageName" -ForegroundColor Gray
Write-Host "2. Double-click start-windows.bat" -ForegroundColor Gray

Write-Host ""
Write-Host "=========================================" -ForegroundColor Green