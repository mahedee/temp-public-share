#!/bin/bash

# Simple Batch Engine Service Stop Script

SERVICE_NAME="batch-engine"

echo "Stopping Batch Engine Service..."

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "Please run as root: sudo $0"
    exit 1
fi

# Check if running
if ! systemctl is-active --quiet $SERVICE_NAME; then
    echo "Service is not running"
    systemctl status $SERVICE_NAME --no-pager
    exit 0
fi

# Stop service
systemctl stop $SERVICE_NAME

# Wait for shutdown
sleep 3

# Check status
if ! systemctl is-active --quiet $SERVICE_NAME; then
    echo "✓ Service stopped successfully"
    systemctl status $SERVICE_NAME --no-pager
    echo ""
    echo "Commands:"
    echo "  Start:  sudo ./scripts/start-service.sh"
    echo "  Status: sudo systemctl status $SERVICE_NAME"
    echo "  Logs:   sudo journalctl -u $SERVICE_NAME -n 20"
else
    echo "✗ Service failed to stop"
    systemctl status $SERVICE_NAME --no-pager
    echo ""
    echo "Force stop: sudo systemctl kill $SERVICE_NAME"
    exit 1
fi