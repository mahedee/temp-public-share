# Linux Deployment Guide - Background Service

## Overview
This guide explains how to deploy the Batch Engine application as a background service on Linux systems using systemd.

## Prerequisites
- Linux system with systemd (Ubuntu 16.04+, CentOS 7+, etc.)
- Java 11 or higher installed
- Application JAR file built and ready
- Root or sudo access

## Deployment Steps

### 1. Create Application Directory Structure

```bash
# Create application directories
sudo mkdir -p /opt/batch-engine
sudo mkdir -p /opt/batch-engine/config
sudo mkdir -p /opt/batch-engine/logs
sudo mkdir -p /var/log/batch-engine

# Create service user
sudo useradd -r -s /bin/false -d /opt/batch-engine batch-engine
sudo chown -R batch-engine:batch-engine /opt/batch-engine
sudo chown -R batch-engine:batch-engine /var/log/batch-engine
```

### 2. Deploy Application Files

```bash
# Copy JAR file
sudo cp target/batch-engine.jar /opt/batch-engine/

# Copy configuration files
sudo cp config/application.properties /opt/batch-engine/config/
sudo cp config/application-production.properties /opt/batch-engine/config/

# Set proper permissions
sudo chown batch-engine:batch-engine /opt/batch-engine/batch-engine.jar
sudo chown -R batch-engine:batch-engine /opt/batch-engine/config/
sudo chmod 755 /opt/batch-engine/batch-engine.jar
```

### 3. Create Systemd Service File

Create the service file:
```bash
sudo nano /etc/systemd/system/batch-engine.service
```

Add the following content:
```ini
[Unit]
Description=Batch Engine - Multi-job batch processing application
After=network.target

[Service]
Type=simple
User=batch-engine
Group=batch-engine
WorkingDirectory=/opt/batch-engine
ExecStart=/usr/bin/java -jar /opt/batch-engine/batch-engine.jar --spring.config.location=file:/opt/batch-engine/config/
ExecStop=/bin/kill -SIGTERM $MAINPID
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal
SyslogIdentifier=batch-engine

# Environment variables
Environment=JAVA_HOME=/usr/lib/jvm/default-java
Environment=SPRING_PROFILES_ACTIVE=production

# Security settings
NoNewPrivileges=yes
PrivateTmp=yes
ProtectSystem=strict
ProtectHome=yes
ReadWritePaths=/opt/batch-engine/logs /var/log/batch-engine

# Resource limits
LimitNOFILE=65536
MemoryMax=1G

[Install]
WantedBy=multi-user.target
```

### 4. Create Application Wrapper Script (Optional)

Create a startup script for better control:
```bash
sudo nano /opt/batch-engine/start-batch-engine.sh
```

Add content:
```bash
#!/bin/bash

# Batch Engine Startup Script
JAVA_HOME=/usr/lib/jvm/default-java
APP_HOME=/opt/batch-engine
JAR_FILE=$APP_HOME/batch-engine.jar
CONFIG_DIR=$APP_HOME/config
LOG_DIR=/var/log/batch-engine

# JVM Options
JVM_OPTS="-Xms512m -Xmx1024m"
JVM_OPTS="$JVM_OPTS -XX:+UseG1GC"
JVM_OPTS="$JVM_OPTS -XX:+HeapDumpOnOutOfMemoryError"
JVM_OPTS="$JVM_OPTS -XX:HeapDumpPath=$LOG_DIR"

# Spring Boot Options
SPRING_OPTS="--spring.config.location=file:$CONFIG_DIR/"
SPRING_OPTS="$SPRING_OPTS --spring.profiles.active=production"
SPRING_OPTS="$SPRING_OPTS --logging.file.path=$LOG_DIR"

# Start application
exec $JAVA_HOME/bin/java $JVM_OPTS -jar $JAR_FILE $SPRING_OPTS
```

Make it executable:
```bash
sudo chmod +x /opt/batch-engine/start-batch-engine.sh
sudo chown batch-engine:batch-engine /opt/batch-engine/start-batch-engine.sh
```

### 5. Update Production Configuration

Update the production properties file:
```bash
sudo nano /opt/batch-engine/config/application-production.properties
```

Add production-specific settings:
```properties
# Production Configuration
spring.application.name=BatchEngine
server.port=8080
management.endpoints.web.exposure.include=health,info,metrics

# Logging Configuration
logging.level.com.batchengine=INFO
logging.level.org.springframework=WARN
logging.file.path=/var/log/batch-engine
logging.file.name=/var/log/batch-engine/batch-engine.log
logging.pattern.file=%d{yyyy-MM-dd HH:mm:ss.SSS} [%thread] %-5level %logger{36} - %msg%n
logging.logback.rollingpolicy.max-file-size=50MB
logging.logback.rollingpolicy.max-history=30

# Database Configuration (when enabled)
# batchengine.database.enabled=true
# spring.datasource.url=jdbc:oracle:thin:@//prod-db:1521/PROD
# spring.datasource.username=${DB_USERNAME}
# spring.datasource.password=${DB_PASSWORD}

# Job Configurations
batchengine.jobs.configuration.manual-account-entry.enabled=true
batchengine.jobs.configuration.manual-account-entry.cron=0 */30 * * * *
batchengine.jobs.configuration.cleanup.enabled=true
batchengine.jobs.configuration.cleanup.cron=0 */5 * * * *
```

### 6. Enable and Start the Service

```bash
# Reload systemd configuration
sudo systemctl daemon-reload

# Enable service to start on boot
sudo systemctl enable batch-engine

# Start the service
sudo systemctl start batch-engine

# Check service status
sudo systemctl status batch-engine
```

## Service Management Commands

### Basic Operations
```bash
# Start service
sudo systemctl start batch-engine

# Stop service
sudo systemctl stop batch-engine

# Restart service
sudo systemctl restart batch-engine

# Reload configuration without restart
sudo systemctl reload batch-engine

# Check status
sudo systemctl status batch-engine

# Enable auto-start on boot
sudo systemctl enable batch-engine

# Disable auto-start
sudo systemctl disable batch-engine
```

### Monitoring and Logs
```bash
# View real-time logs
sudo journalctl -u batch-engine -f

# View recent logs
sudo journalctl -u batch-engine -n 50

# View logs from specific date
sudo journalctl -u batch-engine --since "2026-02-26 00:00:00"

# View application logs
tail -f /var/log/batch-engine/batch-engine.log

# Check service dependencies
sudo systemctl list-dependencies batch-engine
```

## Health Checks and Monitoring

### 1. Create Health Check Script
```bash
sudo nano /opt/batch-engine/health-check.sh
```

Content:
```bash
#!/bin/bash

# Health Check Script for Batch Engine
SERVICE_NAME="batch-engine"
HEALTH_URL="http://localhost:8080/actuator/health"
LOG_FILE="/var/log/batch-engine/health-check.log"

# Check if service is running
if systemctl is-active --quiet $SERVICE_NAME; then
    echo "$(date): Service is running" >> $LOG_FILE
    
    # Check HTTP endpoint
    if curl -f -s $HEALTH_URL > /dev/null; then
        echo "$(date): Health check passed" >> $LOG_FILE
        exit 0
    else
        echo "$(date): Health check failed - HTTP endpoint not responding" >> $LOG_FILE
        exit 1
    fi
else
    echo "$(date): Service is not running" >> $LOG_FILE
    exit 1
fi
```

Make executable:
```bash
sudo chmod +x /opt/batch-engine/health-check.sh
```

### 2. Setup Cron for Health Checks
```bash
# Add to crontab for monitoring
sudo crontab -e

# Add this line to check every 5 minutes
*/5 * * * * /opt/batch-engine/health-check.sh
```

## Log Rotation Setup

Create logrotate configuration:
```bash
sudo nano /etc/logrotate.d/batch-engine
```

Content:
```
/var/log/batch-engine/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    copytruncate
    su batch-engine batch-engine
}
```

## Firewall Configuration

If using firewall, allow the application port:
```bash
# UFW (Ubuntu)
sudo ufw allow 8080/tcp

# firewalld (CentOS/RHEL)
sudo firewall-cmd --permanent --add-port=8080/tcp
sudo firewall-cmd --reload

# iptables
sudo iptables -A INPUT -p tcp --dport 8080 -j ACCEPT
```

## Deployment Automation Script

Create a deployment script:
```bash
sudo nano /opt/batch-engine/deploy.sh
```

Content:
```bash
#!/bin/bash

# Batch Engine Deployment Script
echo "Starting Batch Engine deployment..."

# Variables
APP_DIR="/opt/batch-engine"
SERVICE_NAME="batch-engine"
JAR_FILE="batch-engine.jar"

# Stop service
echo "Stopping service..."
sudo systemctl stop $SERVICE_NAME

# Backup current JAR
echo "Creating backup..."
sudo mv $APP_DIR/$JAR_FILE $APP_DIR/$JAR_FILE.backup.$(date +%Y%m%d_%H%M%S)

# Copy new JAR
echo "Deploying new version..."
sudo cp $JAR_FILE $APP_DIR/
sudo chown batch-engine:batch-engine $APP_DIR/$JAR_FILE

# Start service
echo "Starting service..."
sudo systemctl start $SERVICE_NAME

# Check status
sleep 5
if sudo systemctl is-active --quiet $SERVICE_NAME; then
    echo "Deployment successful! Service is running."
else
    echo "Deployment failed! Check logs:"
    sudo journalctl -u $SERVICE_NAME -n 20
fi
```

## Troubleshooting

### Common Issues
1. **Service fails to start**
   ```bash
   # Check logs
   sudo journalctl -u batch-engine -n 50
   
   # Check file permissions
   ls -la /opt/batch-engine/
   ```

2. **Permission denied errors**
   ```bash
   # Fix permissions
   sudo chown -R batch-engine:batch-engine /opt/batch-engine
   sudo chmod 755 /opt/batch-engine/batch-engine.jar
   ```

3. **Port already in use**
   ```bash
   # Check what's using the port
   sudo netstat -tulpn | grep :8080
   sudo lsof -i :8080
   ```

### Recovery Procedures
```bash
# Restart from backup
sudo systemctl stop batch-engine
sudo cp /opt/batch-engine/batch-engine.jar.backup.* /opt/batch-engine/batch-engine.jar
sudo systemctl start batch-engine

# Reset service
sudo systemctl reset-failed batch-engine
sudo systemctl daemon-reload
sudo systemctl restart batch-engine
```

## Security Best Practices

1. **Run as non-root user** ✓ (already configured)
2. **Limit file system access** ✓ (systemd security settings)
3. **Use environment variables for secrets**
4. **Enable firewall rules**
5. **Regular security updates**
6. **Monitor logs for suspicious activity**

## Production Checklist

- [ ] Service user created
- [ ] Application files deployed with correct permissions
- [ ] Systemd service file configured
- [ ] Production configuration updated
- [ ] Service enabled and started
- [ ] Health checks configured
- [ ] Log rotation setup
- [ ] Firewall rules applied
- [ ] Monitoring in place
- [ ] Backup procedures documented

## Support and Maintenance

For ongoing maintenance:
- Monitor system resources regularly
- Review application logs daily
- Update application and system packages
- Test backup and recovery procedures
- Review and update configuration as needed

The application will now run continuously as a background service, executing jobs according to the configured schedules.