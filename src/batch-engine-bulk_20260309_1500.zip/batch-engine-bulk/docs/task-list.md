## Tasks list
- Update manual-account-entry-job.log and cleanup-job.log as follows. - Include following properties in application.properties for logging configuration:
logging.file.name=logs/batch-engine.log
logging.logback.rollingpolicy.max-file-size=50MB
logging.logback.rollingpolicy.max-history=30
logging.logback.rollingpolicy.file-name-pattern=logs/batch-engine.%d{yyyy-MM-dd}.%i.log

- Keep 1 application.properties file for both Linux and Windows, with environment-specific properties in application-production.properties
- Make sure for each database operation, the connection is closed properly to avoid connection leaks. 
- Encrypt and decrypt database passwords
