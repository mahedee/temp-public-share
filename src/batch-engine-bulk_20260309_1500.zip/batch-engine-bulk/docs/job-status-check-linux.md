# Job Status Check - Linux Manual

## Overview
This manual explains how to check the status of batch engine jobs running on Linux systems.

## Prerequisites
- Batch Engine application running on Linux
- Terminal access
- Basic Linux command knowledge

## Methods to Check Job Status

### 1. Application Logs
Check the application logs for job execution details:

```bash
# View real-time logs
tail -f logs/batch-engine.log

# Search for specific service logs
grep "ManualAccountEntryService" logs/batch-engine.log

# View last 50 lines
tail -n 50 logs/batch-engine.log

# Search for job completion status
grep -E "(started|completed)" logs/batch-engine.log
```

### 2. Process Status
Check if the Java application is running:

```bash
# Find Java processes
ps aux | grep java

# Check specific batch engine process
ps aux | grep batch-engine

# Get process ID and resource usage
top -p $(pgrep -f batch-engine)
```

### 3. Port and Network Status
Verify the application is listening on the correct port:

```bash
# Check if port 8080 is in use
netstat -tulpn | grep :8080

# Alternative using ss command
ss -tulpn | grep :8080

# Check if application responds
curl -I http://localhost:8080/health
```

### 4. Health Check Endpoints
If Spring Boot Actuator is enabled:

```bash
# Check application health
curl http://localhost:8080/actuator/health

# View scheduled tasks
curl http://localhost:8080/actuator/scheduledtasks

# Get application info
curl http://localhost:8080/actuator/info

# Custom service status endpoint
curl http://localhost:8080/service-status
```

### 5. System Monitoring
Monitor system resources:

```bash
# CPU and memory usage
htop

# Disk usage
df -h

# System load
uptime

# Memory usage details
free -h
```

### 6. Log Analysis Commands
Useful commands for log analysis:

```bash
# Count successful job executions today
grep "$(date +%Y-%m-%d)" logs/batch-engine.log | grep "completed" | wc -l

# Find error messages
grep -i error logs/batch-engine.log

# Get job duration statistics
grep "Duration:" logs/batch-engine.log | tail -10

# Monitor logs in real-time with filtering
tail -f logs/batch-engine.log | grep "ManualAccountEntryService"
```

## Troubleshooting

### Application Not Running
```bash
# Check if process exists
pgrep -f batch-engine

# If not running, check startup logs
cat logs/startup.log

# Restart application
nohup java -jar batch-engine.jar > logs/app.log 2>&1 &
```

### Jobs Not Executing
```bash
# Check scheduler status in logs
grep -i "scheduler\|cron" logs/batch-engine.log

# Verify system time and timezone
date
timedatectl status
```

### High Resource Usage
```bash
# Check memory usage
ps -o pid,%mem,rss,comm -p $(pgrep -f batch-engine)

# Monitor file handles
lsof -p $(pgrep -f batch-engine)

# Check disk I/O
iotop -p $(pgrep -f batch-engine)
```

## Best Practices

1. **Regular Monitoring**: Set up cron jobs to check application status
   ```bash
   # Add to crontab (crontab -e)
   */5 * * * * curl -s http://localhost:8080/actuator/health > /dev/null || echo "App down" | mail admin@company.com
   ```

2. **Log Rotation**: Ensure logs don't fill up disk space
   ```bash
   # Check log file sizes
   ls -lh logs/
   
   # Setup logrotate for application logs
   sudo nano /etc/logrotate.d/batch-engine
   ```

3. **Automated Alerts**: Use monitoring tools like Nagios, Zabbix, or custom scripts

## Quick Reference Commands

| Task | Command |
|------|---------|
| Check if app is running | `pgrep -f batch-engine` |
| View real-time logs | `tail -f logs/batch-engine.log` |
| Check port status | `netstat -tulpn \| grep :8080` |
| Health check | `curl http://localhost:8080/actuator/health` |
| Resource usage | `top -p $(pgrep -f batch-engine)` |
| Find errors | `grep -i error logs/batch-engine.log` |

## Support
For additional support, check the application documentation or contact the development team.