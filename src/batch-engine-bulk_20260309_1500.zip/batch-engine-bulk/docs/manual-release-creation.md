# Manual Release Package Creation Guide

## Prerequisites
- Java 11+ installed
- Maven 3.6+ installed
- Git Bash or PowerShell (Windows) / Terminal (Linux)

## Step-by-Step Instructions

### 1. Build the Application
```bash
cd app/
mvn clean package -DskipTests
```

### 2. Create Release Directory
```bash
# Navigate to project root
cd ../

# Create timestamped release directory
VERSION=$(date +"%Y%m%d_%H%M%S")  # Linux/Mac
# For Windows: set VERSION=%date:~10,4%%date:~4,2%%date:~7,2%_%time:~0,2%%time:~3,2%%time:~6,2%

mkdir -p release/batch-engine-$VERSION
```

### 3. Copy Essential Files
```bash
# Copy JAR file
cp app/target/batch-engine.jar release/batch-engine-$VERSION/

# Copy configuration
cp -r app/config release/batch-engine-$VERSION/

# Copy scripts
cp -r scripts release/batch-engine-$VERSION/

# Copy documentation (optional)
cp -r docs release/batch-engine-$VERSION/ 2>/dev/null || true

# Copy README (optional)
cp README.md release/batch-engine-$VERSION/ 2>/dev/null || true
```

### 4. Create Linux Service File
```bash
cat > release/batch-engine-$VERSION/batch-engine.service << 'EOF'
[Unit]
Description=Batch Engine Service
After=network.target

[Service]
Type=simple
User=batchengine
Group=batchengine
WorkingDirectory=/opt/batch-engine
ExecStart=/usr/bin/java -jar /opt/batch-engine/batch-engine.jar
Restart=always
RestartSec=10
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
EOF
```

### 5. Create Linux Install Script
```bash
cat > release/batch-engine-$VERSION/install.sh << 'EOF'
#!/bin/bash
set -e

echo "Installing Batch Engine..."

# Install to /opt/batch-engine
sudo mkdir -p /opt/batch-engine
sudo cp -r * /opt/batch-engine/
sudo useradd -r -m -d /opt/batch-engine -s /bin/false batchengine 2>/dev/null || true
sudo chown -R batchengine:batchengine /opt/batch-engine
sudo chmod +x /opt/batch-engine/scripts/*.sh

# Install systemd service
sudo cp /opt/batch-engine/batch-engine.service /etc/systemd/system/
sudo systemctl daemon-reload
sudo systemctl enable batch-engine

echo "Installation complete!"
echo "Start: sudo systemctl start batch-engine"
echo "Status: sudo systemctl status batch-engine"
EOF

chmod +x release/batch-engine-$VERSION/install.sh
```

### 6. Create Windows Testing Scripts
```bash
# Start script for Windows
cat > release/batch-engine-$VERSION/start-windows.bat << 'EOF'
@echo off
echo Starting Batch Engine...
java -jar batch-engine.jar
pause
EOF

# Stop script for Windows
cat > release/batch-engine-$VERSION/stop-windows.bat << 'EOF'
@echo off
echo Stopping Batch Engine...
taskkill /f /im java.exe
pause
EOF
```

### 7. Create Documentation
```bash
cat > release/batch-engine-$VERSION/README.md << EOF
# Batch Engine Release Package

## Requirements
- **Linux**: OpenJDK 11.0.25 LTS (Red Hat distribution) or compatible
- **Windows**: Java 11+ for testing

## Linux Deployment (Recommended)
1. Extract package: \`tar -xzf batch-engine-$VERSION.tar.gz\`
2. Navigate: \`cd batch-engine-$VERSION\`
3. Install: \`sudo ./install.sh\`
4. Start service: \`sudo systemctl start batch-engine\`
5. Check status: \`sudo systemctl status batch-engine\`

## Windows Testing
1. Start: \`start-windows.bat\`
2. Stop: \`stop-windows.bat\`

## Configuration
- Edit \`config/application.properties\` for settings
- Production config: \`config/application-production.properties\`

## Logs
- Linux: \`journalctl -u batch-engine -f\`
- Windows: Console output

## Manual Start
\`\`\`bash
java -jar batch-engine.jar
\`\`\`

Built with Spring Boot 2.7.18 for Java 11 compatibility.
EOF
```

### 8. Package the Release
```bash
# Create compressed archive
cd release/
tar -czf batch-engine-$VERSION.tar.gz batch-engine-$VERSION/

# For Windows (alternative)
zip -r batch-engine-$VERSION.zip batch-engine-$VERSION/
```

### 9. Verify Package Contents
```bash
# List contents
ls -la batch-engine-$VERSION/

# Expected files:
# - batch-engine.jar
# - config/
# - scripts/
# - docs/ (optional)
# - batch-engine.service
# - install.sh
# - start-windows.bat
# - stop-windows.bat
# - README.md
```

## Quick Commands Summary

### Linux/Mac One-liner
```bash
cd app && mvn clean package -DskipTests && cd .. && \
VERSION=$(date +"%Y%m%d_%H%M%S") && \
mkdir -p release/batch-engine-$VERSION && \
cp app/target/batch-engine.jar release/batch-engine-$VERSION/ && \
cp -r app/config scripts release/batch-engine-$VERSION/
```

### Windows PowerShell One-liner
```powershell
cd app; mvn clean package -DskipTests; cd ..; 
$VERSION = (Get-Date -Format "yyyyMMdd_HHmmss"); 
New-Item -Path "release\batch-engine-$VERSION" -ItemType Directory -Force; 
Copy-Item "app\target\batch-engine.jar" "release\batch-engine-$VERSION\"; 
Copy-Item "app\config","scripts" "release\batch-engine-$VERSION\" -Recurse
```

## Notes
- Use automated scripts: `prepare-release.sh` (Linux) or `prepare-release.bat` (Windows)
- Always test the JAR before packaging: `java -jar batch-engine.jar`
- Verify Java 11 compatibility in target environment
- Package size should be ~18-21 MB