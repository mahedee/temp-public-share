# Running Batch Engine with nohup in Linux

## Overview
This guide shows how to run Batch Engine using `nohup` (no hang up) for background execution without systemd service management.

## Prerequisites
- Java 11+ installed
- Batch Engine JAR file deployed
- Terminal access to Linux server

## Step-by-Step Instructions

### 1. Start Application with nohup
```bash
# Navigate to application directory
cd /opt/batch-engine

# Start application in background
nohup java -jar batch-engine.jar > batch-engine.log 2>&1 &

# Alternative with custom log location
nohup java -jar batch-engine.jar > /var/log/batch-engine/app.log 2>&1 &
```

**What this does:**
- `nohup` - Prevents process from stopping when terminal closes
- `> batch-engine.log` - Redirects stdout to log file
- `2>&1` - Redirects stderr to same file as stdout
- `&` - Runs process in background

### 2. Check if Application is Running

#### Method 1: Check Process by Name
```bash
# Find Java processes containing "batch-engine"
ps aux | grep batch-engine

# More specific search
ps aux | grep "java.*batch-engine.jar"
```

#### Method 2: Check Process by PID
```bash
# Save PID when starting (recommended)
nohup java -jar batch-engine.jar > batch-engine.log 2>&1 & echo $! > batch-engine.pid

# Check if process is running
if [ -f batch-engine.pid ]; then
  PID=$(cat batch-engine.pid)
  if ps -p $PID > /dev/null; then
    echo "Batch Engine is running (PID: $PID)"
  else
    echo "Batch Engine is not running"
  fi
else
  echo "PID file not found"
fi
```

#### Method 3: Check Application Health
```bash
# Check if application is responding (if health endpoint is enabled)
curl -f http://localhost:8080/actuator/health || echo "Application not responding"

# Check log file for recent activity
tail -f batch-engine.log
```

### 3. Stop Application

#### Method 1: Kill by Process Name
```bash
# Find and kill process
pkill -f "java.*batch-engine.jar"

# Or more aggressive
pkill -9 -f "java.*batch-engine.jar"
```

#### Method 2: Kill by PID (Recommended)
```bash
# If you saved PID when starting
if [ -f batch-engine.pid ]; then
  PID=$(cat batch-engine.pid)
  kill $PID
  echo "Sent SIGTERM to process $PID"
  
  # Wait a few seconds then force kill if needed
  sleep 5
  if ps -p $PID > /dev/null; then
    kill -9 $PID
    echo "Force killed process $PID"
  fi
  
  # Clean up PID file
  rm -f batch-engine.pid
else
  echo "PID file not found"
fi
```

### 4. Complete Management Scripts

#### Start Script (`start.sh`)
```bash
#!/bin/bash
set -e

APP_DIR="/opt/batch-engine"
APP_JAR="batch-engine.jar"
PID_FILE="batch-engine.pid"
LOG_FILE="batch-engine.log"

cd "$APP_DIR"

# Check if already running
if [ -f "$PID_FILE" ]; then
  PID=$(cat "$PID_FILE")
  if ps -p "$PID" > /dev/null 2>&1; then
    echo "Batch Engine is already running (PID: $PID)"
    exit 1
  else
    echo "Removing stale PID file"
    rm -f "$PID_FILE"
  fi
fi

echo "Starting Batch Engine..."
nohup java -jar "$APP_JAR" > "$LOG_FILE" 2>&1 & echo $! > "$PID_FILE"

sleep 2
PID=$(cat "$PID_FILE")
if ps -p "$PID" > /dev/null 2>&1; then
  echo "Batch Engine started successfully (PID: $PID)"
  echo "Log file: $APP_DIR/$LOG_FILE"
else
  echo "Failed to start Batch Engine"
  rm -f "$PID_FILE"
  exit 1
fi
```

#### Stop Script (`stop.sh`)
```bash
#!/bin/bash

APP_DIR="/opt/batch-engine"
PID_FILE="batch-engine.pid"

cd "$APP_DIR"

if [ ! -f "$PID_FILE" ]; then
  echo "PID file not found. Application may not be running."
  exit 1
fi

PID=$(cat "$PID_FILE")

if ! ps -p "$PID" > /dev/null 2>&1; then
  echo "Process $PID not running. Removing stale PID file."
  rm -f "$PID_FILE"
  exit 1
fi

echo "Stopping Batch Engine (PID: $PID)..."
kill "$PID"

# Wait for graceful shutdown
for i in {1..10}; do
  if ! ps -p "$PID" > /dev/null 2>&1; then
    echo "Batch Engine stopped successfully"
    rm -f "$PID_FILE"
    exit 0
  fi
  echo "Waiting for shutdown... ($i/10)"
  sleep 1
done

# Force kill if graceful shutdown failed
echo "Force killing process..."
kill -9 "$PID" 2>/dev/null || true
rm -f "$PID_FILE"
echo "Batch Engine force stopped"
```

#### Status Script (`status.sh`)
```bash
#!/bin/bash

APP_DIR="/opt/batch-engine"
PID_FILE="batch-engine.pid"
LOG_FILE="batch-engine.log"

cd "$APP_DIR"

if [ ! -f "$PID_FILE" ]; then
  echo "Status: STOPPED (no PID file)"
  exit 1
fi

PID=$(cat "$PID_FILE")

if ps -p "$PID" > /dev/null 2>&1; then
  echo "Status: RUNNING"
  echo "PID: $PID"
  echo "Started: $(ps -o lstart= -p "$PID")"
  echo "Memory: $(ps -o rss= -p "$PID" | awk '{printf "%.1f MB", $1/1024}')"
  echo "Log file: $APP_DIR/$LOG_FILE"
  
  # Show last few log lines
  if [ -f "$LOG_FILE" ]; then
    echo ""
    echo "Recent log entries:"
    tail -5 "$LOG_FILE"
  fi
else
  echo "Status: STOPPED (process not found)"
  rm -f "$PID_FILE"
  exit 1
fi
```

### 5. Make Scripts Executable
```bash
chmod +x start.sh stop.sh status.sh
```

## Usage Examples

### Basic Commands
```bash
# Start application
./start.sh

# Check status
./status.sh

# Stop application
./stop.sh
```

### Manual Commands
```bash
# Start manually
nohup java -jar batch-engine.jar > app.log 2>&1 & echo $! > app.pid

# Check if running
ps -p $(cat app.pid)

# View logs
tail -f app.log

# Stop manually
kill $(cat app.pid) && rm app.pid
```

### Monitoring
```bash
# Watch process continuously
watch 'ps aux | grep batch-engine'

# Monitor logs in real-time
tail -f batch-engine.log

# Check memory usage
ps -p $(cat batch-engine.pid) -o pid,ppid,cmd,rss
```

## Troubleshooting

### Application Won't Start
```bash
# Check Java version
java -version

# Check if JAR file exists and is executable
ls -la batch-engine.jar

# Check for port conflicts
netstat -tlnp | grep :8080

# Review startup logs
cat batch-engine.log
```

### Application Stops Unexpectedly
```bash
# Check system logs
dmesg | tail -20
journalctl --since "1 hour ago" | grep java

# Check disk space
df -h

# Check memory
free -h
```

### Performance Issues
```bash
# Monitor resources
top -p $(cat batch-engine.pid)

# Check JVM settings
ps -p $(cat batch-engine.pid) -f
```

## Notes
- **Advantages**: Simple, no systemd required, direct log files
- **Disadvantages**: No automatic restart, manual process management
- **Best for**: Development, testing, simple deployments
- **Alternative**: Use systemd service for production environments
- **Log Rotation**: Consider setting up logrotate for log files