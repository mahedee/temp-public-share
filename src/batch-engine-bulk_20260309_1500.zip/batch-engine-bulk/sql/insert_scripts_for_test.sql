-- =============================================================
-- Bind variable declarations (SQL*Plus / SQLcl)
-- Change the values below to test with different source ref IDs
-- =============================================================
VAR acc_source_ref_id_1 VARCHAR2(50)
VAR acc_source_ref_id_2 VARCHAR2(50)
VAR account_id_1 VARCHAR2(50)
VAR account_id_2 VARCHAR2(50)

EXEC :acc_source_ref_id_1 := 'SRC-REF-016'
EXEC :acc_source_ref_id_2 := 'SRC-REF-017'
EXEC :account_id_1 := 'UMAN-ACC-016'
EXEC :account_id_2 := 'UMAN-ACC-017'


-- =============================================================
-- Insert into BMO_ACCOUNTS_MANUAL
-- =============================================================
INSERT INTO EFCM_NETREVEAL.BMO_ACCOUNTS_MANUAL
    (ACCOUNT_ID, ACCOUNT_SOURCE_UNIQUE_ID, ACCOUNT_SOURCE_REF_ID, ACCOUNT_NAME, MAIN_CUSTOMER_NAME, FULL_CUSTOMER_NAME, FULL_ADDRESS, CREATED_BY, MODIFIED_BY, IS_DELETED, ORGUNIT_ID, STATUS)
VALUES
    (:acc_source_ref_id_1, :acc_source_ref_id_1, :acc_source_ref_id_1, 'ACC-SAVINGS-001', 'John Smith', 'John Michael Smith', '123 Main Street, Toronto, ON, M5V 2T6, Canada', 'ADMIN', 'ADMIN', 'N', 1001, 'ACTIVE');

INSERT INTO EFCM_NETREVEAL.BMO_ACCOUNTS_MANUAL
    (ACCOUNT_ID, ACCOUNT_SOURCE_UNIQUE_ID, ACCOUNT_SOURCE_REF_ID, ACCOUNT_NAME, MAIN_CUSTOMER_NAME, FULL_CUSTOMER_NAME, FULL_ADDRESS, CREATED_BY, MODIFIED_BY, IS_DELETED, ORGUNIT_ID, STATUS)
VALUES
    (:acc_source_ref_id_2, :acc_source_ref_id_2, :acc_source_ref_id_2, 'ACC-CHEQUING-002', 'Emily Johnson', 'Emily Rose Johnson', '456 Queen Street West, Vancouver, BC, V6B 1B8, Canada', 'ADMIN', 'ADMIN', 'N', 1001, 'ACTIVE');


-- =============================================================
-- Insert into ACCOUNT_DYNAMIC
-- ACCOUNT_ID holds ACCOUNT_SOURCE_REF_ID until the batch job
-- replaces it with the canonical ACCOUNT_ID from ACCOUNTS
-- =============================================================
INSERT INTO EFCM_NETREVEAL.ACCOUNT_DYNAMIC
    (ACCOUNT_ID, BALANCE_BASE)
VALUES
    (:acc_source_ref_id_1, 15250.75);

INSERT INTO EFCM_NETREVEAL.ACCOUNT_DYNAMIC
    (ACCOUNT_ID, BALANCE_BASE)
VALUES
    (:acc_source_ref_id_2, 8430.50);


-- =============================================================
-- Insert into WORKFLOW_WORKITEM_LINK
-- LINKED_ENTITY_KEY holds ACCOUNT_SOURCE_REF_ID until the batch
-- job replaces it with the canonical ACCOUNT_ID from ACCOUNTS.
-- NVL guards against NULL when the table is empty;
-- +1 / +2 offsets prevent duplicate IDs within the same batch.
-- =============================================================
INSERT INTO EFCM_NETREVEAL.WORKFLOW_WORKITEM_LINK (
    ID, ENTITY_NAME, ENTITY_KEY, ENTITY_KEY_NUM,
    LINKED_ENTITY_NAME, LINKED_ENTITY_KEY, LINKED_ENTITY_KEY_NUM,
    FROM_TIMESTAMP, TO_TIMESTAMP,
    ENTITY_LINK_CODE, LINK_TIME_STATUS, LINK_TYPE,
    CONFIDENCE_SCORE, LINK_CONFIDENCE_TYPE
) VALUES (
    (SELECT NVL(MAX(ID), 0) + 1 FROM EFCM_NETREVEAL.WORKFLOW_WORKITEM_LINK),
    'WORKITEM', 'WI-1001', 1001,
    'ACCOUNT', :acc_source_ref_id_1, 2001,
    TIMESTAMP '2024-01-01 08:00:00.000000',
    TIMESTAMP '9999-12-31 23:59:59.000000',
    'WI_ACCOUNT_LINK', 'C', 'DIRECT',
    95, 'SYSTEM'
);

INSERT INTO EFCM_NETREVEAL.WORKFLOW_WORKITEM_LINK (
    ID, ENTITY_NAME, ENTITY_KEY, ENTITY_KEY_NUM,
    LINKED_ENTITY_NAME, LINKED_ENTITY_KEY, LINKED_ENTITY_KEY_NUM,
    FROM_TIMESTAMP, TO_TIMESTAMP,
    ENTITY_LINK_CODE, LINK_TIME_STATUS, LINK_TYPE,
    CONFIDENCE_SCORE, LINK_CONFIDENCE_TYPE
) VALUES (
    (SELECT NVL(MAX(ID), 0) + 2 FROM EFCM_NETREVEAL.WORKFLOW_WORKITEM_LINK),
    'WORKITEM', 'WI-1002', 1002,
    'ACCOUNT', :acc_source_ref_id_2, 2002,
    TIMESTAMP '2024-01-01 08:00:00.000000',
    TIMESTAMP '9999-12-31 23:59:59.000000',
    'WI_ACCOUNT_LINK', 'C', 'DIRECT',
    95, 'SYSTEM'
);


-- =============================================================
-- Insert into BMO_ACC_PH_DETAILS
-- FCM_CP_ACCOUNT_ID holds ACCOUNT_SOURCE_REF_ID until the batch
-- job replaces it with the canonical ACCOUNT_ID from ACCOUNTS.
-- NVL guards against NULL; +1 / +2 prevent duplicate keys.
-- =============================================================
INSERT INTO EFCM_NETREVEAL.BMO_ACC_PH_DETAILS (
    FCM_CP_PHONE_KEY, FCM_CP_CASE_KEY, FCM_CP_ACCOUNT_ID,
    FCM_CP_PHONENO, FCM_CP_DATETIME, FCM_CP_DATE,
    FCM_CP_OUTCOME, FCM_CP_ASSIGNED_TO, FCM_CP_CALL_NEEDED
) VALUES (
    (SELECT NVL(MAX(FCM_CP_PHONE_KEY), 0) + 1 FROM EFCM_NETREVEAL.BMO_ACC_PH_DETAILS),
    1001, :acc_source_ref_id_1,
    '+1-416-555-0101', TIMESTAMP '2025-02-10 09:17:00.000000', DATE '2025-02-10',
    'RESOLVED', 'john.smith', 'N'
);

INSERT INTO EFCM_NETREVEAL.BMO_ACC_PH_DETAILS (
    FCM_CP_PHONE_KEY, FCM_CP_CASE_KEY, FCM_CP_ACCOUNT_ID,
    FCM_CP_PHONENO, FCM_CP_DATETIME, FCM_CP_DATE,
    FCM_CP_OUTCOME, FCM_CP_ASSIGNED_TO, FCM_CP_CALL_NEEDED
) VALUES (
    (SELECT NVL(MAX(FCM_CP_PHONE_KEY), 0) + 2 FROM EFCM_NETREVEAL.BMO_ACC_PH_DETAILS),
    1002, :acc_source_ref_id_2,
    '+1-647-555-0202', TIMESTAMP '2025-02-12 14:31:00.000000', DATE '2025-02-12',
    'PENDING', 'jane.doe', 'Y'
);


-- Insert into ACCOUNTS

INSERT INTO EFCM_NETREVEAL.ACCOUNTS
    (ACCOUNT_ID, ACCOUNT_SOURCE_UNIQUE_ID, ACCOUNT_SOURCE_REF_ID, ACCOUNT_NAME, PRIMARY_CUSTOMER_ID, 
     ACCOUNT_STATUS_CODE, CURRENCY_CODE, BRANCH_ID, RELATIONSHIP_MGR_ID, PRODUCT_SOURCE_TYPE_CODE, 
     ORG_UNIT_CODE, ORG_UNIT_ID, DATE_OPENED, DATE_CLOSED, ACCOUNT_BALANCE, CREDIT_DEBIT_CODE, 
     OVERDRAFT_LIMIT, RISK_SCORE, ACCOUNT_SEGMENT, DORMANT_STATUS_FLAG, FROZEN_STATUS_FLAG, 
     CREDIT_GRADE, BALANCE_DATE, LANGUAGE_PREF_CODE)
VALUES
    (:account_id_1, :acc_source_ref_id_1, :acc_source_ref_id_1, 'SAVINGS-JOHN-SMITH', 'CUST-1001',
     'ACTIVE', 'CAD', 'BR-TORONTO-01', 'RM-001', 'SAVINGS',
     'OU-ON', 1001, DATE '2018-03-15', NULL, 15250.75, 'CREDIT',
     500.00, 72.5, 'RETAIL', 'N', 'N',
     'A', DATE '2026-03-01', 'EN');

INSERT INTO EFCM_NETREVEAL.ACCOUNTS
    (ACCOUNT_ID, ACCOUNT_SOURCE_UNIQUE_ID, ACCOUNT_SOURCE_REF_ID, ACCOUNT_NAME, PRIMARY_CUSTOMER_ID, 
     ACCOUNT_STATUS_CODE, CURRENCY_CODE, BRANCH_ID, RELATIONSHIP_MGR_ID, PRODUCT_SOURCE_TYPE_CODE, 
     ORG_UNIT_CODE, ORG_UNIT_ID, DATE_OPENED, DATE_CLOSED, ACCOUNT_BALANCE, CREDIT_DEBIT_CODE, 
     OVERDRAFT_LIMIT, RISK_SCORE, ACCOUNT_SEGMENT, DORMANT_STATUS_FLAG, FROZEN_STATUS_FLAG, 
     CREDIT_GRADE, BALANCE_DATE, LANGUAGE_PREF_CODE)
VALUES
    (:account_id_2, :acc_source_ref_id_2, :acc_source_ref_id_2, 'CHEQUING-EMILY-JOHNSON', 'CUST-1002',
     'ACTIVE', 'CAD', 'BR-VANCOUVER-01', 'RM-002', 'CHEQUING',
     'OU-BC', 1001, DATE '2019-06-20', NULL, 8430.50, 'CREDIT',
     1000.00, 65.0, 'RETAIL', 'N', 'N',
     'A', DATE '2026-03-01', 'EN');

COMMIT;


-- SELECT * FROM BMO_ACCOUNTS_MANUAL;
-- SELECT * FROM ACCOUNT_DYNAMIC;
-- SELECT * FROM WORKFLOW_WORKITEM_LINK;
-- SELECT * FROM BMO_ACC_PH_DETAILS;
-- SELECT * FROM ACCOUNTS;


