-- ===============================================
-- ACCOUNT_DYNAMIC - Sample Data Insert
-- ===============================================
-- Description : 5 sample records for ACCOUNT_DYNAMIC table
--               Mandatory fields only
--               ACCOUNT_ID matches ACCOUNTS table
-- Table       : ACCOUNT_DYNAMIC
-- Date        : 2026-03-02
-- ===============================================

-- Mandatory fields:
-- ACCOUNT_ID    - NOT NULL, PK
-- LAST_UPDATED  - NOT NULL, DEFAULT CURRENT_TIMESTAMP
-- BALANCE_BASE  - NOT NULL

INSERT INTO EFCM_NETREVEAL.ACCOUNT_DYNAMIC
    (ACCOUNT_ID, BALANCE_BASE)
VALUES
    ('SRC-REF-001', 15250.75);

INSERT INTO EFCM_NETREVEAL.ACCOUNT_DYNAMIC
    (ACCOUNT_ID, BALANCE_BASE)
VALUES
    ('SRC-REF-002', 8430.50);

COMMIT;


SELECT * FROM EFCM_NETREVEAL.ACCOUNT_DYNAMIC;


