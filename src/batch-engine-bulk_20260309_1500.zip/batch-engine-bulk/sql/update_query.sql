-- 1. Update ACCOUNT_DYNAMIC table
-- Replace ACCOUNT_ID with the matching one from ACCOUNTS (via manual override if exists and not deleted)

UPDATE ACCOUNT_DYNAMIC dyn
SET ACCOUNT_ID = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = dyn.ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  acc.ACCOUNT_ID IS NOT NULL
    FETCH FIRST 1 ROW ONLY 
)
WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = dyn.ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  acc.ACCOUNT_ID IS NOT NULL
);


-- 2. Update WORKFLOW_WORKITEM_LINK table
-- Replace LINKED_ENTITY_KEY (which holds ACCOUNT_ID) with the correct one from ACCOUNTS

UPDATE WORKFLOW_WORKITEM_LINK wwl
SET LINKED_ENTITY_KEY = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = wwl.LINKED_ENTITY_KEY
      AND  man.IS_DELETED = 'N'
      AND  acc.ACCOUNT_ID IS NOT NULL
    FETCH FIRST 1 ROW ONLY
)

WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = wwl.LINKED_ENTITY_KEY
      AND  man.IS_DELETED = 'N'
      AND  acc.ACCOUNT_ID IS NOT NULL
);


-- 3. Placeholder for the third update (incomplete in screenshot)
-- Update BMO_ACC_PH_DETAILS (likely similar pattern)
-- Uncomment / complete once you have the full statement

UPDATE BMO_ACC_PH_DETAILS ph
SET FCM_CP_ACCOUNT_ID = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  acc.ACCOUNT_ID IS NOT NULL
    FETCH FIRST 1 ROW ONLY
)
WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  acc.ACCOUNT_ID IS NOT NULL
);




-- 3. Update BMO_ACC_PH_DETAILS
-- Replace FCM_CP_ACCOUNT_ID with the correct canonical ACCOUNT_ID from ACCOUNTS
-- (only when a non-deleted manual override exists)

UPDATE BMO_ACC_PH_DETAILS ph
SET FCM_CP_ACCOUNT_ID = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID
      AND  man.IS_DELETED             = 'N'
    FETCH FIRST 1 ROW ONLY          -- or AND ROWNUM = 1 in older Oracle versions
)

WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS        acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID
      AND  man.IS_DELETED             = 'N'
      AND  acc.ACCOUNT_ID             IS NOT NULL
);


-- 4. Update BMO_ACCOUNTS_MANUAL (soft-delete + set correct ACCOUNT_ID)
-- Mark as deleted ('Y') and update ACCOUNT_ID to the canonical one from ACCOUNTS

UPDATE BMO_ACCOUNTS_MANUAL man
SET ACCOUNT_ID = (
    SELECT acc.ACCOUNT_ID
    FROM   ACCOUNTS acc
    WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID),
    IS_DELETED = 'Y'
WHERE  man.IS_DELETED = 'N'
  AND  EXISTS (
           SELECT 1
           FROM   ACCOUNTS acc
           WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID
       );