
-- Step 1: Update BMO_ACCOUNTS_MANUAL, set STATUS = 'PROCESSING' for records that have a matching non-deleted entry in ACCOUNTS
-- Mark these records as 'PROCESSING' to indicate they are in the middle of being updated. Next steps will be executed only on this records.
UPDATE BMO_ACCOUNTS_MANUAL man
SET STATUS = 'PROCESSING'
WHERE  man.IS_DELETED = 'N' AND man.STATUS = 'ACTIVE'
  AND  EXISTS (
           SELECT 1
           FROM   ACCOUNTS acc
           WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID
  );

COMMIT;


-- Step 2: Update ACCOUNT_DYNAMIC table
-- Replace ACCOUNT_ID with the matching one from ACCOUNTS (via manual override if exists and not deleted)
-- For manual entry account_id of ACCOUNT_DYNAMIC will match ACCOUNT_SOURCE_REF_ID in BMO_ACCOUNTS_MANUAL, which will then be used to find the correct ACCOUNT_ID from ACCOUNTS

UPDATE ACCOUNT_DYNAMIC dyn
SET ACCOUNT_ID = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  acc.ACCOUNT_SOURCE_REF_ID = dyn.ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  man.STATUS = 'PROCESSING'
      AND  acc.ACCOUNT_ID IS NOT NULL
    FETCH FIRST 1 ROW ONLY 
)
WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = dyn.ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  man.STATUS = 'PROCESSING'
      AND  acc.ACCOUNT_ID IS NOT NULL
      AND  NOT EXISTS (
              SELECT 1
              FROM   ACCOUNT_DYNAMIC existing
              WHERE  existing.ACCOUNT_ID = acc.ACCOUNT_ID
          )
);

COMMIT;


-- Step 3. Update WORKFLOW_WORKITEM_LINK table
-- Replace LINKED_ENTITY_KEY (which holds ACCOUNT_ID) with the correct one from ACCOUNTS

UPDATE WORKFLOW_WORKITEM_LINK wwl
SET LINKED_ENTITY_KEY = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = wwl.LINKED_ENTITY_KEY
      AND  man.IS_DELETED = 'N'
      AND  man.STATUS = 'PROCESSING'
      AND  acc.ACCOUNT_ID IS NOT NULL
    FETCH FIRST 1 ROW ONLY
)

WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = wwl.LINKED_ENTITY_KEY
      AND  man.IS_DELETED = 'N'
      AND  man.STATUS = 'PROCESSING'
      AND  acc.ACCOUNT_ID IS NOT NULL
);

COMMIT;

-- Step 4. Update ACCOUNT_ID for Account Restriction Details
-- Update BMO_ACC_PH_DETAILS (likely similar pattern)
-- Uncomment / complete once you have the full statement

UPDATE BMO_ACC_PH_DETAILS ph
SET FCM_CP_ACCOUNT_ID = (
    SELECT acc.ACCOUNT_ID
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  man.STATUS = 'PROCESSING'
      AND  acc.ACCOUNT_ID IS NOT NULL
    FETCH FIRST 1 ROW ONLY
)
WHERE EXISTS (
    SELECT 1
    FROM   BMO_ACCOUNTS_MANUAL man
    INNER JOIN ACCOUNTS  acc ON man.ACCOUNT_SOURCE_REF_ID = acc.ACCOUNT_SOURCE_REF_ID
    WHERE  man.ACCOUNT_SOURCE_REF_ID = ph.FCM_CP_ACCOUNT_ID
      AND  man.IS_DELETED = 'N'
      AND  man.STATUS = 'PROCESSING'
      AND  acc.ACCOUNT_ID IS NOT NULL
);

COMMIT;



-- Step 5. Update BMO_ACCOUNTS_MANUAL (soft-delete + set correct ACCOUNT_ID)
-- Mark as deleted ('Y') and update ACCOUNT_ID to the canonical one from ACCOUNTS
-- Set STATUS to 'DELETED' to indicate these records have been processed and should not be used anymore. This also helps to prevent any future confusion or accidental use of these manual entries.

  UPDATE BMO_ACCOUNTS_MANUAL man
  SET  ACCOUNT_ID = (
           SELECT acc.ACCOUNT_ID
           FROM   ACCOUNTS acc
           WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID
           FETCH FIRST 1 ROW ONLY
       ),
       IS_DELETED = 'Y',
       STATUS     = 'DELETED'
  WHERE  man.IS_DELETED = 'N'
  AND  man.STATUS = 'PROCESSING'
  AND  EXISTS (
           SELECT 1
           FROM   ACCOUNTS acc
           WHERE  acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID
             AND  acc.ACCOUNT_ID IS NOT NULL
             AND  NOT EXISTS (
                      SELECT 1
                      FROM   BMO_ACCOUNTS_MANUAL existing
                      WHERE  existing.ACCOUNT_ID = acc.ACCOUNT_ID
                  )
       );

COMMIT;


/*
  SELECT man.ACCOUNT_SOURCE_REF_ID, man.ACCOUNT_ID, man.IS_DELETED, acc.ACCOUNT_ID
  FROM   ACCOUNTS acc
  INNER JOIN BMO_ACCOUNTS_MANUAL man ON acc.ACCOUNT_SOURCE_REF_ID = man.ACCOUNT_SOURCE_REF_ID
  WHERE  man.IS_DELETED = 'N' AND man.STATUS = 'PROCESSING'

  select * from BMO_ACCOUNTS_MANUAL order by ACCOUNT_SOURCE_REF_ID;
  select * from ACCOUNTS order by ACCOUNT_SOURCE_REF_ID;

  delete from bmo_accounts_manual where account_source_ref_id in ('SRC-REF-005', 'SRC-REF-006');
  commit;

  select * from accounts where account_source_ref_id in ('SRC-REF-005', 'SRC-REF-006');
  select * from BMO_ACCOUNTS_MANUAL where account_source_ref_id in ('SRC-REF-016', 'SRC-REF-017');

*/