-- ============================================================
-- Sample Data for EFCM_NETREVEAL.BMO_ACC_PH_DETAILS
-- ============================================================

-- Insert 1: Completed call, outcome recorded
INSERT INTO EFCM_NETREVEAL.BMO_ACC_PH_DETAILS (
    FCM_CP_PHONE_KEY, FCM_CP_CASE_KEY, FCM_CP_ACCOUNT_ID,
    FCM_CP_PHONENO, FCM_CP_DATETIME, FCM_CP_DATE,
    FCM_CP_OUTCOME, FCM_CP_ASSIGNED_TO, FCM_CP_CALL_NEEDED
) VALUES (
    10, 1001, 'SRC-REF-001',
    '+1-416-555-0101', TIMESTAMP '2025-02-10 09:17:00.000000', DATE '2025-02-10',
    'RESOLVED', 'john.smith', 'N'
);

-- Insert 2: Call needed, pending outcome
INSERT INTO EFCM_NETREVEAL.BMO_ACC_PH_DETAILS (
    FCM_CP_PHONE_KEY, FCM_CP_CASE_KEY, FCM_CP_ACCOUNT_ID,
    FCM_CP_PHONENO, FCM_CP_DATETIME, FCM_CP_DATE,
    FCM_CP_OUTCOME, FCM_CP_ASSIGNED_TO, FCM_CP_CALL_NEEDED
) VALUES (
    11, 1002, 'SRC-REF-002',
    '+1-647-555-0202', TIMESTAMP '2025-02-12 14:31:00.000000', DATE '2025-02-12',
    'PENDING', 'jane.doe', 'Y'
);


COMMIT;

--SELECT * FROM EFCM_NETREVEAL.BMO_ACC_PH_DETAILS;