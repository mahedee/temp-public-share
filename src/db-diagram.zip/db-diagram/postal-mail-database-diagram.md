# EFCM Postal Mail Database Schema Diagram

## Database Overview
This database supports the EFCM Postal Mail system with four types of letters: Demand, Hold Notice, ID Theft, and Relationship Term letters.

## Entity Relationship Diagram

```mermaid
erDiagram
    %% Combined Table
    POSTAL_MAIL_LETTERS {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_20 LETTER_TYPE "NOT NULL"
        VARCHAR2_4000 CUSTOMER_NAME "NOT NULL"
        TIMESTAMP SENT_DATE "Nullable - updated after sending"
        VARCHAR2_3200 FULL_ADDRESS "NOT NULL"
        VARCHAR2_4 ACCOUNT_SOURCE_REF_ID "Required for DEMAND, HOLD_NOTICE, RELATIONSHIP_TERM"
        NUMBER_22 BALANCE "Only for DEMAND"
        VARCHAR2_4000 HOLD_REASON "Only for HOLD_NOTICE"
        NUMBER_22 HOLD_AMOUNT "Only for HOLD_NOTICE"
        NUMBER_22 DEPOSIT_AMOUNT "Only for HOLD_NOTICE"
        TIMESTAMP DEPOSIT_DATE "Only for HOLD_NOTICE"
        TIMESTAMP ACC_CLOSE_DT "Only for RELATIONSHIP_TERM"
        VARCHAR2_1000 ANALYST_NAME "Only for RELATIONSHIP_TERM"
        VARCHAR2_13 INBOUND_PHONE "Only for RELATIONSHIP_TERM"
        VARCHAR2_4000 ADDITIONAL_NAME1
        VARCHAR2_4000 ADDITIONAL_NAME2
        VARCHAR2_4000 ADDITIONAL_NAME3
        VARCHAR2_4000 ADDITIONAL_NAME4
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
        TIMESTAMP MODIFIED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 MODIFIED_BY "DEFAULT USER"
        VARCHAR2_10 RECORD_STATUS "DEFAULT 'ACTIVE'"
    }
```

```mermaid
erDiagram
    %% Individual Letter Tables
    DEMAND_LETTER {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_4000 CUSTOMER_NAME "NOT NULL"
        TIMESTAMP CURRENT_DATE "NOT NULL"
        VARCHAR2_3200 FULL_ADDRESS "NOT NULL"
        VARCHAR2_4 ACCOUNT_SOURCE_REF_ID "NOT NULL"
        NUMBER_22 BALANCE "NOT NULL"
        VARCHAR2_4000 ADDITIONAL_NAME1
        VARCHAR2_4000 ADDITIONAL_NAME2
        VARCHAR2_4000 ADDITIONAL_NAME3
        VARCHAR2_4000 ADDITIONAL_NAME4
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
        TIMESTAMP MODIFIED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 MODIFIED_BY "DEFAULT USER"
        VARCHAR2_10 RECORD_STATUS "DEFAULT 'ACTIVE'"
    }

    HOLD_NOTICE_LETTER {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_4000 CUSTOMER_NAME "NOT NULL"
        TIMESTAMP SENT_DATE "NOT NULL"
        VARCHAR2_3200 FULL_ADDRESS "NOT NULL"
        VARCHAR2_4 ACCOUNT_SOURCE_REF_ID "NOT NULL"
        VARCHAR2_4000 HOLD_REASON "NOT NULL"
        VARCHAR2_4000 ADDITIONAL_NAME1
        VARCHAR2_4000 ADDITIONAL_NAME2
        VARCHAR2_4000 ADDITIONAL_NAME3
        VARCHAR2_4000 ADDITIONAL_NAME4
        NUMBER_22 HOLD_AMOUNT
        NUMBER_22 DEPOSIT_AMOUNT
        TIMESTAMP DEPOSIT_DATE
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
        TIMESTAMP MODIFIED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 MODIFIED_BY "DEFAULT USER"
        VARCHAR2_10 RECORD_STATUS "DEFAULT 'ACTIVE'"
    }

    ID_THEFT_LETTER {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_4000 CUSTOMER_NAME "NOT NULL"
        TIMESTAMP SENT_DATE "NOT NULL"
        VARCHAR2_3200 FULL_ADDRESS "NOT NULL"
        VARCHAR2_4000 ADDITIONAL_NAME1
        VARCHAR2_4000 ADDITIONAL_NAME2
        VARCHAR2_4000 ADDITIONAL_NAME3
        VARCHAR2_4000 ADDITIONAL_NAME4
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
        TIMESTAMP MODIFIED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 MODIFIED_BY "DEFAULT USER"
        VARCHAR2_10 RECORD_STATUS "DEFAULT 'ACTIVE'"
    }

    RELATIONSHIP_TERM_LETTER {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_4000 CUSTOMER_NAME "NOT NULL"
        TIMESTAMP SENT_DATE "NOT NULL"
        VARCHAR2_3200 FULL_ADDRESS "NOT NULL"
        VARCHAR2_4 ACCOUNT_SOURCE_REF_ID "NOT NULL"
        TIMESTAMP ACC_CLOSE_DT "NOT NULL"
        VARCHAR2_1000 ANALYST_NAME
        VARCHAR2_13 INBOUND_PHONE "NOT NULL"
        VARCHAR2_4000 ADDITIONAL_NAME1
        VARCHAR2_4000 ADDITIONAL_NAME2
        VARCHAR2_4000 ADDITIONAL_NAME3
        VARCHAR2_4000 ADDITIONAL_NAME4
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
        TIMESTAMP MODIFIED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 MODIFIED_BY "DEFAULT USER"
        VARCHAR2_10 RECORD_STATUS "DEFAULT 'ACTIVE'"
    }

    %% Combined Table
    POSTAL_MAIL_LETTERS {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_20 LETTER_TYPE "NOT NULL"
        VARCHAR2_4000 CUSTOMER_NAME "NOT NULL"
        TIMESTAMP SENT_DATE "Nullable - updated after sending"
        VARCHAR2_3200 FULL_ADDRESS "NOT NULL"
        VARCHAR2_4 ACCOUNT_SOURCE_REF_ID "Required for DEMAND, HOLD_NOTICE, RELATIONSHIP_TERM"
        NUMBER_22 BALANCE "Only for DEMAND"
        VARCHAR2_4000 HOLD_REASON "Only for HOLD_NOTICE"
        NUMBER_22 HOLD_AMOUNT "Only for HOLD_NOTICE"
        NUMBER_22 DEPOSIT_AMOUNT "Only for HOLD_NOTICE"
        TIMESTAMP DEPOSIT_DATE "Only for HOLD_NOTICE"
        TIMESTAMP ACC_CLOSE_DT "Only for RELATIONSHIP_TERM"
        VARCHAR2_1000 ANALYST_NAME "Only for RELATIONSHIP_TERM"
        VARCHAR2_13 INBOUND_PHONE "Only for RELATIONSHIP_TERM"
        VARCHAR2_4000 ADDITIONAL_NAME1
        VARCHAR2_4000 ADDITIONAL_NAME2
        VARCHAR2_4000 ADDITIONAL_NAME3
        VARCHAR2_4000 ADDITIONAL_NAME4
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
        TIMESTAMP MODIFIED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 MODIFIED_BY "DEFAULT USER"
        VARCHAR2_10 RECORD_STATUS "DEFAULT 'ACTIVE'"
    }

    %% Processing Log Table
    POSTAL_MAIL_PROCESSING_LOG {
        NUMBER ID PK "Auto-generated"
        VARCHAR2_50 LETTER_TYPE "NOT NULL"
        VARCHAR2_200 FILE_NAME "NOT NULL"
        TIMESTAMP PROCESSING_DATE "NOT NULL"
        NUMBER RECORDS_COUNT "DEFAULT 0"
        NUMBER FILE_SIZE_BYTES
        VARCHAR2_20 PROCESSING_STATUS "DEFAULT 'PENDING'"
        VARCHAR2_4000 ERROR_MESSAGE
        TIMESTAMP START_TIME
        TIMESTAMP END_TIME
        NUMBER DURATION_SECONDS
        TIMESTAMP CREATED_DATE "DEFAULT CURRENT_TIMESTAMP"
        VARCHAR2_100 CREATED_BY "DEFAULT USER"
    }

    %% Relationships
    POSTAL_MAIL_PROCESSING_LOG ||--o{ DEMAND_LETTER : "processes"
    POSTAL_MAIL_PROCESSING_LOG ||--o{ HOLD_NOTICE_LETTER : "processes"
    POSTAL_MAIL_PROCESSING_LOG ||--o{ ID_THEFT_LETTER : "processes"
    POSTAL_MAIL_PROCESSING_LOG ||--o{ RELATIONSHIP_TERM_LETTER : "processes"
    POSTAL_MAIL_PROCESSING_LOG ||--o{ POSTAL_MAIL_LETTERS : "processes"
```

## Table Relationships

### Primary Tables Structure

#### 1. **Individual Letter Tables** (Legacy/Specific Use)
- `DEMAND_LETTER` - Stores demand letters with balance information
- `HOLD_NOTICE_LETTER` - Stores hold notice letters with hold reasons and amounts
- `ID_THEFT_LETTER` - Stores ID theft letters (minimal fields required)
- `RELATIONSHIP_TERM_LETTER` - Stores relationship termination letters

#### 2. **Combined Table** (Unified Approach)
- `POSTAL_MAIL_LETTERS` - Unified table containing all letter types with `LETTER_TYPE` discriminator

#### 3. **Processing Log Table**
- `POSTAL_MAIL_PROCESSING_LOG` - Tracks file generation and batch processing

## Field Specifications by Letter Type

### Common Fields (All Letter Types)
- `CUSTOMER_NAME` - VARCHAR2(4000) - Required
- `FULL_ADDRESS` - VARCHAR2(3200) - Required  
- `ADDITIONAL_NAME1-4` - VARCHAR2(4000) - Optional
- Audit fields (CREATED_DATE, CREATED_BY, MODIFIED_DATE, MODIFIED_BY, RECORD_STATUS)

### Letter Type Specific Fields

| Field | DEMAND | HOLD_NOTICE | ID_THEFT | RELATIONSHIP_TERM |
|-------|--------|-------------|----------|-------------------|
| `ACCOUNT_SOURCE_REF_ID` | ✅ Required | ✅ Required | ❌ Not Used | ✅ Required |
| `BALANCE` | ✅ Required | ❌ Not Used | ❌ Not Used | ❌ Not Used |
| `HOLD_REASON` | ❌ Not Used | ✅ Required | ❌ Not Used | ❌ Not Used |
| `HOLD_AMOUNT` | ❌ Not Used | ✅ Optional | ❌ Not Used | ❌ Not Used |
| `DEPOSIT_AMOUNT` | ❌ Not Used | ✅ Optional | ❌ Not Used | ❌ Not Used |
| `DEPOSIT_DATE` | ❌ Not Used | ✅ Optional | ❌ Not Used | ❌ Not Used |
| `ACC_CLOSE_DT` | ❌ Not Used | ❌ Not Used | ❌ Not Used | ✅ Required |
| `ANALYST_NAME` | ❌ Not Used | ❌ Not Used | ❌ Not Used | ✅ Optional |
| `INBOUND_PHONE` | ❌ Not Used | ❌ Not Used | ❌ Not Used | ✅ Required |

## Indexes Created

### Individual Tables Indexes
```sql
-- DEMAND_LETTER indexes
IDX_DEMAND_LETTER_CUST_NAME (CUSTOMER_NAME)
IDX_DEMAND_LETTER_ACCT_REF (ACCOUNT_SOURCE_REF_ID)
IDX_DEMAND_LETTER_DATE (CURRENT_DATE)

-- HOLD_NOTICE_LETTER indexes
IDX_HOLD_LETTER_CUST_NAME (CUSTOMER_NAME)
IDX_HOLD_LETTER_ACCT_REF (ACCOUNT_SOURCE_REF_ID)
IDX_HOLD_LETTER_SENT_DATE (SENT_DATE)

-- ID_THEFT_LETTER indexes
IDX_ID_THEFT_CUST_NAME (CUSTOMER_NAME)
IDX_ID_THEFT_SENT_DATE (SENT_DATE)

-- RELATIONSHIP_TERM_LETTER indexes
IDX_REL_TERM_CUST_NAME (CUSTOMER_NAME)
IDX_REL_TERM_ACCT_REF (ACCOUNT_SOURCE_REF_ID)
IDX_REL_TERM_SENT_DATE (SENT_DATE)
IDX_REL_TERM_CLOSE_DATE (ACC_CLOSE_DT)
```

### Combined Table Indexes
```sql
-- POSTAL_MAIL_LETTERS indexes
IDX_POSTAL_LETTERS_TYPE (LETTER_TYPE)
IDX_POSTAL_LETTERS_CUST_NAME (CUSTOMER_NAME)
IDX_POSTAL_LETTERS_SENT_DATE (SENT_DATE)
IDX_POSTAL_LETTERS_ACCT_REF (ACCOUNT_SOURCE_REF_ID)
IDX_POSTAL_LETTERS_STATUS (RECORD_STATUS)
IDX_POSTAL_LETTERS_TYPE_DATE (LETTER_TYPE, SENT_DATE) -- Composite
```

### Processing Log Indexes
```sql
-- POSTAL_MAIL_PROCESSING_LOG indexes
IDX_PROC_LOG_TYPE_DATE (LETTER_TYPE, PROCESSING_DATE) -- Composite
IDX_PROC_LOG_STATUS (PROCESSING_STATUS)
```

## Constraints and Business Rules

### Check Constraints
- `RECORD_STATUS` ∈ ('ACTIVE', 'INACTIVE', 'PROCESSED')
- `PROCESSING_STATUS` ∈ ('PENDING', 'IN_PROGRESS', 'COMPLETED', 'FAILED')
- `LETTER_TYPE` ∈ ('DEMAND', 'HOLD_NOTICE', 'ID_THEFT', 'RELATIONSHIP_TERM')

### Trigger-Enforced Business Rules
- **DEMAND letters**: Require `ACCOUNT_SOURCE_REF_ID` and `BALANCE`
- **HOLD_NOTICE letters**: Require `ACCOUNT_SOURCE_REF_ID` and `HOLD_REASON`
- **ID_THEFT letters**: No account reference required
- **RELATIONSHIP_TERM letters**: Require `ACCOUNT_SOURCE_REF_ID`, `ACC_CLOSE_DT`, and `INBOUND_PHONE`

## File Processing Workflow

```mermaid
graph TD
    A[Letter Created] --> B[SENT_DATE = NULL]
    B --> C[Record Status = ACTIVE]
    C --> D[Daily Batch Job 11:00 PM EST]
    D --> E[Generate File]
    E --> F[Update SENT_DATE]
    F --> G[Record Status = PROCESSED]
    G --> H[Log in PROCESSING_LOG]
    
    H --> I{File Type}
    I -->|DEMAND| J[EFCM.PostalMail.DemandLetter.YYYYMMDD.txt]
    I -->|HOLD_NOTICE| K[EFCM.PostalMail.HoldLetter.YYYYMMDD.txt]
    I -->|ID_THEFT| L[EFCM.PostalMail.IDTheftLetter.YYYYMMDD.txt]
    I -->|RELATIONSHIP_TERM| M[EFCM.PostalMail.RelationTermLetter.YYYYMMDD.txt]
```

## Views Available

### Summary Views
- `V_POSTAL_MAIL_SUMMARY` - Summary of individual tables
- `V_COMBINED_POSTAL_MAIL_SUMMARY` - Summary of combined table by letter type

### Letter-Specific Views (from Combined Table)
- `V_DEMAND_LETTERS_COMBINED` - Demand letters only
- `V_HOLD_NOTICE_LETTERS_COMBINED` - Hold notice letters only
- `V_ID_THEFT_LETTERS_COMBINED` - ID theft letters only
- `V_RELATIONSHIP_TERM_LETTERS_COMBINED` - Relationship term letters only

## Design Patterns Used

1. **Table Per Type** - Individual tables for each letter type
2. **Single Table Inheritance** - Combined table with discriminator column
3. **Audit Trail Pattern** - Created/Modified timestamps and users
4. **Processing Log Pattern** - Separate table for batch job tracking
5. **Soft Delete Pattern** - RECORD_STATUS instead of physical deletion

## Storage Considerations

- **Large Text Fields**: VARCHAR2(4000) for names and reasons
- **Address Storage**: VARCHAR2(3200) for full addresses
- **Monetary Fields**: NUMBER(22) for balance and amounts
- **Timestamp Precision**: Full timestamp with microseconds
- **Auto-generated Keys**: IDENTITY columns for primary keys
